<?php
// layout/ui.php — komponen tampilan yang dipakai berulang.

function ui_head(string $judul, string $desc = '', string $aksiHtml = ''): string
{
    return '<div class="page-head"><div><h2>' . e($judul) . '</h2>'
        . ($desc !== '' ? '<p>' . e($desc) . '</p>' : '') . '</div>'
        . ($aksiHtml !== '' ? '<div class="d-flex flex-wrap gap-2">' . $aksiHtml . '</div>' : '') . '</div>';
}

/** Kartu KPI. $warna: blue, teal, amber, rose, violet, green */
function ui_kpi(string $warna, string $icon, string $label, string $nilai, string $foot = ''): string
{
    return '<div class="kpi kpi-' . e($warna) . '"><div class="kpi-icon"><i class="fas ' . e($icon) . '"></i></div>'
        . '<div class="kpi-label">' . e($label) . '</div><div class="kpi-value">' . e($nilai) . '</div>'
        . ($foot !== '' ? '<div class="kpi-foot">' . $foot . '</div>' : '') . '</div>';
}

function ui_kosong(string $icon, string $judul, string $teks = ''): string
{
    return '<div class="empty-state"><div class="empty-icon"><i class="fas ' . e($icon) . '"></i></div>'
        . '<h4>' . e($judul) . '</h4>' . ($teks !== '' ? '<p class="mb-0">' . e($teks) . '</p>' : '') . '</div>';
}

/** Data aman untuk disisipkan ke <script>. */
function ui_js($data): string
{
    return json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
}

/** Badge status jumlah berdasarkan unit tersedia & batas minimum. */
function ui_badge_stok(int $tersedia, int $minimum, int $aktif = 1): string
{
    if (!$aktif) return badge('Diarsipkan', 'secondary');
    if ($tersedia <= 0) return badge('Habis', 'danger');
    if ($tersedia <= $minimum) return badge('Menipis', 'warning');
    return badge('Aman', 'success');
}

/** Filter pill. $opsi = [nilai => [label, jumlah]]; $base = parameter URL lain. */
function ui_pills(array $opsi, string $aktif, string $param, array $base = []): string
{
    $html = '<div class="d-flex flex-wrap gap-2">';
    foreach ($opsi as $nilai => [$label, $jumlah]) {
        $cls = (string)$nilai === $aktif ? ' active' : '';
        $q = array_merge($base, [$param => $nilai]);
        $html .= '<a class="filter-pill' . $cls . '" href="' . e(base_url() . '?' . http_build_query($q)) . '">'
            . e($label) . ($jumlah !== null ? ' <span class="count">' . (int)$jumlah . '</span>' : '') . '</a>';
    }
    return $html . '</div>';
}

/** Tombol aksi kecil dengan ikon. */
function ui_btn_link(string $href, string $icon, string $warna = 'light', string $title = ''): string
{
    return '<a class="btn btn-sm btn-icon ' . ($warna === 'light' ? 'btn-light' : 'btn-' . e($warna)) . '" href="' . e($href) . '"'
        . ($title !== '' ? ' title="' . e($title) . '" data-toggle="tooltip"' : '') . '><i class="fas ' . e($icon) . '"></i></a>';
}

/** Pilihan kategori/merek/lokasi sebagai opsi html dari tabel. */
function ui_opsi_tabel(string $tabel, string $labelKolom, string $selected = '', string $placeholder = '-- Pilih --', string $where = ''): string
{
    $allowed = ['kategori', 'merek', 'lokasi'];
    if (!in_array($tabel, $allowed, true)) return '';
    $label = $tabel === 'kategori' ? "CONCAT(nama, ' (', kode_prefix, ')')" : 'nama';
    $rows = db_all(db(), "SELECT id, $label AS lbl FROM $tabel ORDER BY nama");
    $html = '<option value="">' . e($placeholder) . '</option>';
    foreach ($rows as $r) {
        $sel = ((string)$r['id'] === (string)$selected) ? ' selected' : '';
        $html .= '<option value="' . (int)$r['id'] . '"' . $sel . '>' . e($r['lbl']) . '</option>';
    }
    return $html;
}

/** Opsi semua barang (termasuk nonaktif bila sudah pernah dipakai). */
function opsi_barang_semua(mysqli $con, int $selected = 0): string
{
    $rows = db_all($con, "SELECT id, kode_barang, nama_barang FROM barang ORDER BY nama_barang");
    $html = '';
    foreach ($rows as $b) {
        $sel = (int)$b['id'] === $selected ? ' selected' : '';
        $html .= '<option value="' . (int)$b['id'] . '"' . $sel . '>' . e($b['kode_barang'] . ' — ' . $b['nama_barang']) . '</option>';
    }
    return $html;
}

