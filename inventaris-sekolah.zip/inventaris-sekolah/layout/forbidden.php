<?php
// layout/forbidden.php — halaman "akses ditolak" (dipanggil dari require_perm)
?>
<!doctype html>
<html lang="id">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Akses Ditolak</title>
<link rel="stylesheet" href="<?= e(base_url()) ?>assets/css/app.css"></head>
<body class="center-page">
  <div class="empty-state card-soft">
    <div class="empty-icon text-danger"><i class="fas fa-lock"></i></div>
    <h4>Akses ditolak</h4>
    <p class="text-muted mb-3">Akun Anda tidak memiliki izin untuk membuka halaman ini.</p>
    <a class="btn btn-primary" href="<?= e(url('dashboard')) ?>"><i class="fas fa-arrow-left mr-1"></i> Kembali ke Beranda</a>
  </div>
</body>
</html>
