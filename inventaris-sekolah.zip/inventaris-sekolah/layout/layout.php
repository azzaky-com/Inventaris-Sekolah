<?php
// layout/layout.php — kerangka halaman: head, sidebar, topbar, dan footer.

/** Daftar menu sidebar. 'perm' = izin yang dibutuhkan untuk melihat menu. */
require_once __DIR__ . '/ui.php';

function menu_sidebar(): array
{
    $semua = ['admin', 'operator', 'kepala_sekolah'];
    $ops   = ['admin', 'operator'];
    $ap    = ['admin', 'kepala_sekolah'];
    return [
        'Ringkasan' => [
            ['m' => 'dashboard', 'label' => 'Beranda', 'icon' => 'fa-home', 'roles' => $semua],
            ['m' => 'cari', 'label' => 'Pencarian', 'icon' => 'fa-search', 'roles' => $semua],
        ],
        'Persetujuan' => [
            ['m' => 'persetujuan', 'label' => 'Persetujuan', 'icon' => 'fa-check-double', 'roles' => $ap, 'alert' => 'menunggu'],
        ],
        'Barang' => [
            ['m' => 'barang', 'label' => 'Data Barang', 'icon' => 'fa-boxes', 'roles' => $semua],
            ['m' => 'pindai', 'label' => 'Pindai QR', 'icon' => 'fa-qrcode', 'roles' => $semua],
            ['m' => 'aset', 'label' => 'Nilai & Penyusutan', 'icon' => 'fa-chart-line', 'roles' => $ap],
        ],
        'Operasional' => [
            ['m' => 'masuk', 'label' => 'Barang Masuk', 'icon' => 'fa-truck-loading', 'roles' => $ops],
            ['m' => 'keluar', 'label' => 'Pemakaian & Keluar', 'icon' => 'fa-tint', 'roles' => $ops],
            ['m' => 'pindah', 'label' => 'Pindah Ruangan', 'icon' => 'fa-exchange-alt', 'roles' => $ops],
            ['m' => 'peminjaman', 'label' => 'Peminjaman', 'icon' => 'fa-hand-holding', 'roles' => $ops, 'alert' => 'terlambat'],
            ['m' => 'kerusakan', 'label' => 'Kerusakan', 'icon' => 'fa-tools', 'roles' => $ops],
            ['m' => 'penghapusan', 'label' => 'Penghapusan Aset', 'icon' => 'fa-archive', 'roles' => $ops],
            ['m' => 'opname', 'label' => 'Opname barang', 'icon' => 'fa-clipboard-check', 'roles' => $ops],
        ],
        'Master Data' => [
            ['m' => 'kategori', 'label' => 'Kategori', 'icon' => 'fa-tags', 'roles' => ['admin']],
            ['m' => 'merek', 'label' => 'Merek', 'icon' => 'fa-copyright', 'roles' => ['admin']],
            ['m' => 'lokasi', 'label' => 'Lokasi / Ruangan', 'icon' => 'fa-door-open', 'roles' => ['admin']],
        ],
        'Laporan' => [
            ['m' => 'laporan', 'label' => 'Laporan & Cetak', 'icon' => 'fa-file-invoice', 'roles' => $semua],
        ],
        'Administrasi' => [
            ['m' => 'tahun', 'label' => 'Tahun Ajaran', 'icon' => 'fa-calendar-alt', 'roles' => ['admin']],
            ['m' => 'pengguna', 'label' => 'Pengguna', 'icon' => 'fa-users-cog', 'roles' => ['admin']],
            ['m' => 'pemeliharaan', 'label' => 'Pemeliharaan Data', 'icon' => 'fa-database', 'roles' => ['admin']],
            ['m' => 'log', 'label' => 'Log Aktivitas', 'icon' => 'fa-history', 'roles' => ['admin', 'kepala_sekolah']],
            ['m' => 'pengaturan', 'label' => 'Pengaturan Sekolah', 'icon' => 'fa-school', 'roles' => ['admin']],
        ],
    ];
}

function layout_atas(string $judul, string $m, string $subjudul = ''): void
{
    $auth = auth_user();
    $tema = "<script>
        (function(){
          var t = localStorage.getItem('inv-tema');
          if (!t) t = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
          document.documentElement.setAttribute('data-theme', t);
        })();
    </script>";
    ?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?= e($judul) ?> · <?= e(APP_NAME) ?></title>
    <link rel="icon" type="image/png" href="<?= e(base_url()) ?>assets/img/favicon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?= $tema ?>
    <link rel="stylesheet" href="<?= e(base_url()) ?>assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= e(base_url()) ?>assets/vendor/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?= e(base_url()) ?>assets/vendor/select2/css/select2.min.css">
    <link rel="stylesheet" href="<?= e(base_url()) ?>assets/vendor/datatables/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= e(base_url()) ?>assets/css/app.css?v=<?= e(APP_VERSION) ?>">
</head>
<body class="app-body" data-base="<?= e(base_url()) ?>">
<div class="app-shell">
    <aside class="sidebar" id="sidebar">
        <a class="brand" href="<?= e(url('dashboard')) ?>">
            <span class="brand-mark"><i class="fas fa-warehouse"></i></span>
            <span class="brand-text">
                <strong>Inventaris</strong>
                <small>UPT SMP Negeri 8 Medan</small>
            </span>
        </a>
        <nav class="sidebar-nav">
            <div class="sidebar-role"><span><?= e(ROLE_LABEL[user_role()] ?? '') ?></span></div>
            <?php
            $counts = ringkasan_notifikasi();
            $canApprove = can('kerusakan.setujui');
            foreach (menu_sidebar() as $grup => $items):
                $tampil = array_filter($items, function ($it) { return in_array(user_role(), $it['roles'], true); });
                if (!$tampil) continue;
            ?>
                <div class="nav-caption"><?= e($grup) ?></div>
                <?php foreach ($tampil as $it):
                    $aktif = $m === $it['m'] ? ' active' : '';
                    $badge = '';
                    if (!empty($it['alert'])) {
                        $n = $it['alert'] === 'terlambat' ? $counts['terlambat'] : ($canApprove ? $counts['menunggu'] : 0);
                        if ($n > 0) $badge = '<span class="nav-badge">' . (int)$n . '</span>';
                    }
                ?>
                    <a class="nav-link<?= $aktif ?>" href="<?= e(url($it['m'])) ?>">
                        <i class="fas <?= e($it['icon']) ?>"></i>
                        <span class="nav-label"><?= e($it['label']) ?></span>
                        <?= $badge ?>
                    </a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </nav>
        <div class="sidebar-footer">
            <div class="small text-muted-soft">v<?= e(APP_VERSION) ?></div>
        </div>
    </aside>
    <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

    <div class="main">
        <header class="topbar">
            <button class="icon-btn" id="sidebarToggle" type="button" aria-label="Buka menu">
                <i class="fas fa-bars"></i>
            </button>
            <div class="topbar-title">
                <h1 class="page-title"><?= e($judul) ?></h1>
                <?php if ($subjudul !== ''): ?><div class="page-sub"><?= e($subjudul) ?></div><?php endif; ?>
            </div>

            <div class="topbar-actions">
                <form class="topbar-search d-none d-md-flex" action="<?= e(base_url()) ?>" method="get">
                    <input type="hidden" name="m" value="cari">
                    <i class="fas fa-search"></i>
                    <input type="search" name="q" placeholder="Cari barang, peminjam, BA…" value="<?= e(get_str('q')) ?>" aria-label="Cari barang">
                </form>

                <?php $totalNotif = $counts['terlambat'] + $counts['menipis'] + $counts['menunggu']; ?>
                <div class="dropdown">
                    <button class="icon-btn position-relative" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" aria-label="Notifikasi">
                        <i class="fas fa-bell"></i>
                        <?php if ($totalNotif > 0): ?><span class="dot-badge"><?= (int)$totalNotif ?></span><?php endif; ?>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right dropdown-notif">
                        <div class="dropdown-header">Perlu perhatian</div>
                        <?php if ($counts['menunggu'] > 0): ?>
                        <a class="dropdown-item" href="<?= e(url('persetujuan')) ?>">
                            <span class="notif-icon bg-soft-warning"><i class="fas fa-file-signature"></i></span>
                            <span><strong><?= (int)$counts['menunggu'] ?></strong> pengajuan menunggu persetujuan</span>
                        </a>
                        <?php endif; ?>
                        <?php if ($counts['terlambat'] > 0): ?>
                        <a class="dropdown-item" href="<?= e(url('peminjaman', ['status' => 'Terlambat'])) ?>">
                            <span class="notif-icon bg-soft-danger"><i class="fas fa-clock"></i></span>
                            <span><strong><?= (int)$counts['terlambat'] ?></strong> peminjaman melewati tenggat</span>
                        </a>
                        <?php endif; ?>
                        <?php if ($counts['menipis'] > 0): ?>
                        <a class="dropdown-item" href="<?= e(url('barang', ['stok' => 'menipis'])) ?>">
                            <span class="notif-icon bg-soft-info"><i class="fas fa-layer-group"></i></span>
                            <span><strong><?= (int)$counts['menipis'] ?></strong> barang hampir habis</span>
                        </a>
                        <?php endif; ?>
                        <?php if ($counts['menunggu'] + $counts['terlambat'] + $counts['menipis'] === 0): ?>
                        <div class="dropdown-item-text text-muted small py-2"><i class="fas fa-check-circle text-success mr-1"></i> Semua sudah beres.</div>
                        <?php endif; ?>
                    </div>
                </div>

                <button class="icon-btn" id="themeToggle" type="button" aria-label="Ganti tema" title="Ganti tema terang/gelap">
                    <i class="fas fa-moon"></i>
                </button>

                <div class="dropdown">
                    <button class="user-chip" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="avatar"><?= e(mb_strtoupper(mb_substr($auth['nama'] ?? 'U', 0, 1))) ?></span>
                        <span class="user-meta d-none d-lg-flex">
                            <strong><?= e($auth['nama'] ?? '') ?></strong>
                            <small><?= e(ROLE_LABEL[user_role()] ?? '') ?></small>
                        </span>
                        <i class="fas fa-chevron-down small"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="<?= e(url('akun')) ?>"><i class="fas fa-user-cog fa-fw mr-2"></i>Akun Saya</a>
                        <?php if (can('pengaturan.kelola')): ?>
                        <a class="dropdown-item" href="<?= e(url('pengaturan')) ?>"><i class="fas fa-school fa-fw mr-2"></i>Pengaturan Sekolah</a>
                        <?php endif; ?>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-danger" href="#" data-toggle="modal" data-target="#modalLogout"><i class="fas fa-sign-out-alt fa-fw mr-2"></i>Keluar</a>
                    </div>
                </div>
            </div>
        </header>

        <main class="content">
<?php
}

function layout_bawah(): void
{
    $flash = flash_ambil();
    ?>
        </main>

        <footer class="app-footer">
            <span>© <?= date('Y') ?> <?= e(APP_NAME) ?> · UPT SMP Negeri 8 Medan</span>
            <span class="text-muted-soft">Dibuat dengan PHP & MySQL</span>
        </footer>
    </div>
</div>

<!-- Modal konfirmasi keluar -->
<div class="modal fade" id="modalLogout" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-body text-center p-4">
                <div class="empty-icon text-danger mb-2"><i class="fas fa-sign-out-alt"></i></div>
                <h6 class="font-weight-bold">Keluar dari aplikasi?</h6>
                <p class="text-muted small mb-3">Anda perlu login kembali untuk melanjutkan.</p>
                <div class="d-flex justify-content-center gap-2">
                    <button class="btn btn-light" type="button" data-dismiss="modal">Batal</button>
                    <a class="btn btn-danger" href="<?= e(base_url()) ?>logout.php">Ya, keluar</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script id="flash-data" type="application/json"><?= json_encode($flash, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
<script src="<?= e(base_url()) ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="<?= e(base_url()) ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(base_url()) ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?= e(base_url()) ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="<?= e(base_url()) ?>assets/vendor/select2/js/select2.min.js"></script>
<script src="<?= e(base_url()) ?>assets/vendor/jquery-mask/jquery-mask.min.js"></script>
<script src="<?= e(base_url()) ?>assets/vendor/sweet-alert/sweetalert2.all.min.js"></script>
<?php if (!empty($GLOBALS['page_js_vendor'])): foreach ($GLOBALS['page_js_vendor'] as $src): ?>
<script src="<?= e($src) ?>"></script>
<?php endforeach; endif; ?>
<script src="<?= e(base_url()) ?>assets/js/app.js?v=<?= e(APP_VERSION) ?>"></script>
<?php if (!empty($GLOBALS['page_js'])): ?>
<script>
<?= $GLOBALS['page_js'] ?>
</script>
<?php endif; ?>
</body>
</html>
<?php
}
