<?php
// print/cetak.php — halaman cetak laporan, berita acara opname, dan label QR (siap disimpan sebagai PDF).
require_once __DIR__ . '/../config/bootstrap.php';
require_once __DIR__ . '/../layout/ui.php';
require_login();
require_perm('laporan.lihat');
if (get_str('jenis', 20) === 'aset') require_perm('nilai.lihat');

$con = db();
$jenis = get_str('jenis', 20) ?: 'inventaris';
$cfg = pengaturan_all();
$base = base_url();
$instansi = $cfg['nama_instansi'] ?? APP_NAME;
$tglCetak = date('d-m-Y H:i');
$oleh = user_nama();

/** Cetak selesai: bungkus halaman standar. */
function cetak_mulai(string $judul, string $base): void
{
    ?>
<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($judul) ?></title>
<link rel="stylesheet" href="<?= e($base) ?>assets/css/print.css">
</head><body>
<div class="toolbar-print no-print">
    <span>Pratinjau cetak — gunakan <em>Simpan sebagai PDF</em> pada dialog cetak.</span>
    <span><a href="javascript:window.close()">Tutup</a> <button type="button" onclick="window.print()">Cetak / PDF</button></span>
</div>
<div class="sheet">
    <?php
}

function cetak_kop(array $cfg, string $base, string $instansi): void
{
    ?>
    <div class="kop">
        <img src="<?= e($base) ?>assets/img/favicon.png" alt="">
        <div class="kop-text">
            <h1><?= e(mb_strtoupper($instansi)) ?></h1>
            <h2>Sistem Informasi Inventaris Sekolah</h2>
            <p><?= e($cfg['alamat'] ?? '') ?></p>
        </div>
    </div>
    <?php
}

function cetak_ttd(array $items): void
{
    echo '<div class="ttd">';
    foreach ($items as $it) {
        echo '<div class="blok"><div>' . e($it['jabatan']) . '</div><div class="garis">' . e($it['nama'] ?: '................................') . '</div>'
           . '<div class="nip">' . ($it['nip'] ? 'NIP. ' . e($it['nip']) : '&nbsp;') . '</div></div>';
    }
    echo '</div>';
}

if ($jenis === 'label') {
    // ---------- LABEL QR ----------
    $where = ['b.aktif = 1']; $tipe = ''; $par = [];
    $bid = get_int('barang_id');
    if ($bid) { $where[] = 'b.id = ?'; $tipe .= 'i'; $par[] = $bid; }
    $kat = get_int('kategori_id'); if ($kat) { $where[] = 'b.kategori_id = ?'; $tipe .= 'i'; $par[] = $kat; }
    $lok = get_int('lokasi_id'); if ($lok) { $where[] = 'b.lokasi_id = ?'; $tipe .= 'i'; $par[] = $lok; }
    $rows = db_all($con,
        "SELECT b.id, b.kode_barang, b.nama_barang, l.nama AS lokasi FROM barang b LEFT JOIN lokasi l ON l.id = b.lokasi_id
         WHERE " . implode(' AND ', $where) . " ORDER BY b.kode_barang LIMIT 300", $tipe, $par);
    cetak_mulai('Label Aset — ' . $instansi, $base);
    ?>
    <div class="label-grid">
    <?php foreach ($rows as $i => $b): ?>
        <div class="label-item">
            <div class="qr" id="qr<?= $i ?>"></div>
            <div class="lt">
                <div class="kode"><?= e($b['kode_barang']) ?></div>
                <div class="nm"><?= e(potong($b['nama_barang'], 48)) ?></div>
                <div class="sm"><?= e($instansi) ?></div>
                <div class="sm"><?= e($b['lokasi'] ?: '') ?></div>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
    <?php if (!$rows): ?><p>Tidak ada barang untuk filter ini.</p><?php endif; ?>
    </div>
    <?php
    $labels = [];
    foreach ($rows as $b) $labels[] = url_absolut('?' . http_build_query(['m' => 'barang', 'aksi' => 'detail', 'id' => $b['id']]));
    ?>
    <script src="<?= e($base) ?>assets/vendor/qrcode/qrcode.js"></script>
    <script>
    (function () {
      var urls = <?= ui_js($labels) ?>;
      urls.forEach(function (u, i) {
        var box = document.getElementById('qr' + i);
        if (!box) return;
        var qr = qrcode(0, 'M'); qr.addData(u); qr.make();
        box.innerHTML = qr.createImgTag(3, 0);
      });
      window.addEventListener('load', function () { if (location.search.indexOf('auto=1') !== -1) window.print(); });
    })();
    </script>
    </body></html>
    <?php
    exit;
}

if ($jenis === 'opname') {
    // ---------- BERITA ACARA OPNAME ----------
    $id = get_int('id');
    $o = db_row($con, "SELECT o.*, l.nama AS lokasi FROM stok_opname o LEFT JOIN lokasi l ON l.id = o.lokasi_id WHERE o.id = ?", 'i', [$id]);
    if (!$o || $o['status'] !== 'Selesai') { http_response_code(404); exit('Berita acara hanya tersedia untuk sesi yang sudah selesai.'); }
    $items = db_all($con,
        "SELECT i.*, b.kode_barang, b.nama_barang, b.satuan FROM stok_opname_item i JOIN barang b ON b.id = i.barang_id
         WHERE i.opname_id = ? ORDER BY b.kode_barang", 'i', [$id]);
    $selisihN = 0; $totalSel = 0;
    foreach ($items as $it) { if ((int)$it['selisih'] !== 0) { $selisihN++; $totalSel += (int)$it['selisih']; } }
    cetak_mulai('Berita Acara ' . $o['kode'], $base);
    cetak_kop($cfg, $base, $instansi);
    ?>
    <h3 class="judul">Berita Acara Opname barang</h3>
    <div class="sub-judul"><?= e($o['kode']) ?> · <?= e($o['judul']) ?> · <?= tgl_indo($o['tanggal'], true) ?> · Lingkup: <?= e($o['lokasi'] ?: 'Seluruh barang aktif') ?></div>
    <p style="text-align:justify">Pada tanggal <?= tgl_indo($o['tanggal'], true) ?> telah dilaksanakan pencacahan fisik barang inventaris dengan hasil sebagai berikut.</p>
    <div class="ringkas"><span>Jumlah barang dicacah: <b><?= count($items) ?></b></span><span>Barang dengan selisih: <b><?= $selisihN ?></b></span><span>Total selisih unit: <b><?= ($totalSel > 0 ? '+' : '') . $totalSel ?></b></span></div>
    <table class="laporan">
        <thead><tr><th style="width:30px">No</th><th>Kode</th><th>Nama Barang</th><th>Sat.</th><th>Jumlah Sistem</th><th>Fisik</th><th>Selisih</th><th>Keterangan</th></tr></thead>
        <tbody>
        <?php $n = 1; foreach ($items as $it): $sel = (int)$it['selisih']; ?>
            <tr>
                <td class="c"><?= $n++ ?></td>
                <td><?= e($it['kode_barang']) ?></td>
                <td><?= e($it['nama_barang']) ?></td>
                <td class="c"><?= e($it['satuan']) ?></td>
                <td class="num"><?= angka($it['stok_sistem']) ?></td>
                <td class="num"><?= $it['stok_fisik'] !== null ? angka($it['stok_fisik']) : '-' ?></td>
                <td class="num"><?= $sel === 0 ? '0' : ($sel > 0 ? '+' : '−') . angka(abs($sel)) ?></td>
                <td><?= e($it['keterangan'] ?? '') ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p class="catatan-kecil">Selisih disesuaikan ke jumlah sistem pada saat finalisasi (<?= $o['finalized_at'] ? waktu_indo($o['finalized_at']) : '-' ?>).</p>
    <?php
    cetak_ttd([
        ['jabatan' => 'Penanggung Jawab BMN', 'nama' => $cfg['penanggung_jawab_bmn'] ?? '', 'nip' => $cfg['nip_pjbmn'] ?? ''],
        ['jabatan' => 'Panitia Opname', 'nama' => '', 'nip' => ''],
        ['jabatan' => 'Mengetahui, Kepala Sekolah', 'nama' => $cfg['kepala_sekolah'] ?? '', 'nip' => $cfg['nip_kepala'] ?? ''],
    ]);
    echo '</div>';
    echo '<div class="catatan-kecil no-print" style="margin:0 auto;max-width:1000px;padding:0 18px;">Dicetak ' . e($tglCetak) . ' oleh ' . e($oleh) . '</div>';
    echo '</body></html>';
    exit;
}


if ($jenis === 'kib') {
    // ---------- KARTU INVENTARIS BARANG (KIB) ----------
    $id = get_int('id');
    $b = barang_detail($con, $id);
    if (!$b || $b['jenis_barang'] !== 'aset') { http_response_code(404); exit('KIB hanya tersedia untuk aset tetap.'); }
    $p = penyusutan_batch($con, $b);
    $lok = barang_per_lokasi($con, $id);
    $mut = array_slice(array_reverse(mutasi_berjalan($con, $id)['rows']), 0, 25);
    $pindah = db_all($con, "SELECT p.tanggal, p.jumlah, la.nama AS asal, lt.nama AS tujuan FROM pemindahan p
                            JOIN lokasi la ON la.id = p.lokasi_asal_id JOIN lokasi lt ON lt.id = p.lokasi_tujuan_id
                            WHERE p.barang_id = ? ORDER BY p.tanggal DESC", 'i', [$id]);
    cetak_mulai('KIB ' . $b['kode_barang'], $base);
    cetak_kop($cfg, $base, $instansi);
    ?>
    <h3 class="judul">Kartu Inventaris Barang — Aset Tetap</h3>
    <div class="sub-judul">Kode <?= e($b['kode_barang']) ?><?= $b['kode_bmn'] ? ' · Kode BMN ' . e($b['kode_bmn']) : '' ?> · dicetak <?= e($tglCetak) ?></div>
    <table class="laporan" style="margin-bottom:12px">
        <tbody>
            <tr><th style="width:22%;text-align:left">Nama barang</th><td><?= e($b['nama_barang']) ?></td><th style="width:20%;text-align:left">Kategori</th><td><?= e($b['kategori']) ?></td></tr>
            <tr><th style="text-align:left">Merek / tipe</th><td><?= e($b['merek'] ?? '-') ?></td><th style="text-align:left">Sumber dana</th><td><?= e($b['sumber_dana']) ?></td></tr>
            <tr><th style="text-align:left">Tanggal perolehan</th><td><?= $b['tanggal_perolehan'] ? tgl_indo($b['tanggal_perolehan'], true) : '-' ?></td><th style="text-align:left">Masa manfaat</th><td><?= (int)$b['masa_manfaat_tahun'] ?> tahun · nilai sisa <?= rupiah(0) === '' ? '' : e(number_format((float)$b['nilai_residu_persen'], 0, ',', '.')) ?>%</td></tr>
            <tr><th style="text-align:left">Harga satuan</th><td><?= rupiah($b['harga_perolehan']) ?></td><th style="text-align:left">Jumlah unit</th><td><?= angka($b['stok_total']) ?> <?= e($b['satuan']) ?></td></tr>
            <tr><th style="text-align:left">Spesifikasi</th><td colspan="3"><?= e($b['keterangan'] ?: '-') ?></td></tr>
        </tbody>
    </table>
    <?php if ($p['ok']): ?>
    <table class="laporan" style="margin-bottom:12px">
        <thead><tr><th>Nilai perolehan</th><th>Akumulasi penyusutan</th><th>Nilai buku</th><th>Sisa masa manfaat</th><th>Status</th></tr></thead>
        <tbody><tr><td class="num"><?= rupiah($p['perolehan_total']) ?></td><td class="num"><?= rupiah($p['akum_total']) ?></td><td class="num"><?= rupiah($p['nilai_buku_total']) ?></td>
            <td><?= e(label_sisa_bulan($p['sisa_bulan'])) ?></td><td><?= e($p['status'] === 'habis' ? 'Habis masa manfaat' : ($p['status'] === 'segera' ? 'Segera habis' : 'Berjalan')) ?></td></tr></tbody>
    </table>
    <?php endif; ?>
    <table class="laporan" style="margin-bottom:12px">
        <thead><tr><th>Ruangan</th><th>Penanggung jawab</th><th>Jumlah</th><th>Dipinjam</th><th>Rusak</th><th>Tersedia</th></tr></thead>
        <tbody>
        <?php foreach ($lok as $l): $t = (int)$l['stok'] - (int)$l['dipinjam'] - (int)$l['rusak']; ?>
            <tr><td><?= e($l['nama']) ?></td><td><?= e($l['penanggung_jawab'] ?? '-') ?></td><td class="num"><?= angka($l['stok']) ?></td><td class="num"><?= angka($l['dipinjam']) ?></td><td class="num"><?= angka($l['rusak']) ?></td><td class="num"><?= angka($t) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <table class="laporan">
        <thead><tr><th>Waktu</th><th>Mutasi</th><th>Referensi</th><th>Keterangan</th><th>+/-</th><th>Saldo total</th></tr></thead>
        <tbody>
        <?php foreach ($mut as $m): ?>
            <tr><td><?= waktu_indo($m['tanggal']) ?></td><td><?= e(LABEL_MUTASI[$m['jenis']] ?? $m['jenis']) ?></td><td><?= e($m['referensi']) ?></td><td><?= e($m['keterangan']) ?></td>
                <td class="num"><?= e(fmt_sel((int)$m['perubahan_total'], 'ttl')) ?></td><td class="num"><?= angka($m['saldo_total']) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php cetak_ttd([
        ['jabatan' => 'Penanggung Jawab BMN', 'nama' => $cfg['penanggung_jawab_bmn'] ?? '', 'nip' => $cfg['nip_pjbmn'] ?? ''],
        ['jabatan' => 'Mengetahui, Kepala Sekolah', 'nama' => $cfg['kepala_sekolah'] ?? '', 'nip' => $cfg['nip_kepala'] ?? ''],
    ]); ?>
    <div class="catatan-kecil">Dicetak <?= e($tglCetak) ?> oleh <?= e($oleh) ?></div>
    </div></body></html>
    <?php exit;
}

if ($jenis === 'ba_hapus') {
    // ---------- BERITA ACARA PENGHAPUSAN ----------
    $id = get_int('id');
    $p = db_row($con,
        "SELECT p.*, b.kode_barang, b.nama_barang, b.kode_bmn, b.merek_id, l.nama AS lokasi, k.nama AS kategori, m.nama AS merek
         FROM penghapusan p JOIN barang b ON b.id = p.barang_id JOIN lokasi l ON l.id = p.lokasi_id
         JOIN kategori k ON k.id = b.kategori_id LEFT JOIN merek m ON m.id = b.merek_id WHERE p.id = ?", 'i', [$id]);
    if (!$p || $p['status'] !== 'Disetujui') { http_response_code(404); exit('Berita acara hanya tersedia untuk penghapusan yang sudah disetujui.'); }
    cetak_mulai('BA ' . $p['nomor_ba'], $base);
    cetak_kop($cfg, $base, $instansi);
    $nilaiUnit = (float)$p['nilai_buku_unit'];
    ?>
    <h3 class="judul">Berita Acara Penghapusan Barang Milik Sekolah</h3>
    <div class="sub-judul">Nomor: <?= e($p['nomor_ba']) ?> · Tanggal <?= tgl_indo($p['tanggal_setujui'], true) ?></div>
    <p style="text-align:justify">Pada hari ini, <?= tgl_indo($p['tanggal_setujui'], true) ?>, Kepala Sekolah telah menyetujui penghapusan barang milik sekolah dari daftar inventaris dengan rincian sebagai berikut:</p>
    <table class="laporan" style="margin-bottom:12px">
        <thead><tr><th>No</th><th>Kode</th><th>Nama barang</th><th>Merek</th><th>Ruangan</th><th>Jumlah</th><th>Nilai buku/unit</th><th>Nilai buku total</th></tr></thead>
        <tbody><tr><td class="c">1</td><td><?= e($p['kode_barang']) ?><?= $p['kode_bmn'] ? '<br><small>BMN ' . e($p['kode_bmn']) . '</small>' : '' ?></td><td><?= e($p['nama_barang']) ?></td>
            <td><?= e($p['merek'] ?? '-') ?></td><td><?= e($p['lokasi']) ?></td><td class="num"><?= angka($p['jumlah']) ?></td>
            <td class="num"><?= rupiah($nilaiUnit) ?></td><td class="num"><?= rupiah($nilaiUnit * (int)$p['jumlah']) ?></td></tr></tbody>
    </table>
    <p><strong>Alasan penghapusan:</strong> <?= e($p['alasan']) ?><br><strong>Uraian:</strong> <?= e($p['keterangan'] ?: '-') ?><br>
       <strong>Dasar usulan:</strong> diusulkan <?= tgl_indo($p['tanggal_usul']) ?> oleh <?= e($p['diusulkan_oleh']) ?><?= $p['kerusakan_id'] ? ' (laporan ' . rusak_kode((int)$p['kerusakan_id']) . ')' : '' ?>.</p>
    <p style="text-align:justify">Jumlah barang tersebut telah dikurangi dari daftar inventaris sekolah pada tanggal penetapan. Berita acara ini dibuat untuk dipergunakan sebagaimana mestinya.</p>
    <?php cetak_ttd([
        ['jabatan' => 'Mengetahui, Kepala Sekolah', 'nama' => $cfg['kepala_sekolah'] ?? '', 'nip' => $cfg['nip_kepala'] ?? ''],
        ['jabatan' => 'Penanggung Jawab BMN', 'nama' => $cfg['penanggung_jawab_bmn'] ?? '', 'nip' => $cfg['nip_pjbmn'] ?? ''],
    ]); ?>
    <div class="catatan-kecil">Dicetak <?= e($tglCetak) ?> oleh <?= e($oleh) ?></div>
    </div></body></html>
    <?php exit;
}

if ($jenis === 'surat') {
    // ---------- SURAT PENGINGAT PENGEMBALIAN ----------
    $id = get_int('id');
    $p = db_row($con,
        "SELECT p.*, b.nama_barang, b.kode_barang FROM peminjaman p JOIN barang b ON b.id = p.barang_id WHERE p.id = ?", 'i', [$id]);
    if (!$p || $p['status'] !== 'Dipinjam') { http_response_code(404); exit('Surat pengingat hanya untuk peminjaman yang masih berjalan.'); }
    $telat = max(0, (int)floor((strtotime(date('Y-m-d')) - strtotime($p['tanggal_rencana_kembali'])) / 86400));
    cetak_mulai('Surat Pengingat ' . $p['kode_barang'], $base);
    cetak_kop($cfg, $base, $instansi);
    ?>
    <h3 class="judul">Surat Pengingat Pengembalian Barang</h3>
    <div class="sub-judul">Nomor: PJ-<?= (int)$p['id'] ?>/<?= date('Y') ?> · <?= tgl_indo(date('Y-m-d'), true) ?></div>
    <p>Kepada Yth. <strong><?= e($p['peminjam']) ?></strong><?= $p['unit'] ? ' (' . e($p['unit']) . ')' : '' ?></p>
    <p style="text-align:justify">Dengan hormat, kami mengingatkan bahwa barang inventaris sekolah berikut yang dipinjam pada tanggal <?= tgl_indo($p['tanggal_pinjam'], true) ?> belum dikembalikan seluruhnya:</p>
    <table class="laporan" style="margin-bottom:12px">
        <thead><tr><th>Kode</th><th>Nama barang</th><th>Jumlah belum kembali</th><th>Batas kembali</th></tr></thead>
        <tbody><tr><td><?= e($p['kode_barang']) ?></td><td><?= e($p['nama_barang']) ?></td><td class="num"><?= angka($p['sisa']) ?> unit</td>
            <td><?= tgl_indo($p['tanggal_rencana_kembali'], true) ?><?= $telat > 0 ? ' (terlambat ' . $telat . ' hari)' : '' ?></td></tr></tbody>
    </table>
    <p style="text-align:justify">Mohon barang dikembalikan ke <?= e($p['kategori'] ?? 'ruang inventaris') ?> paling lambat tanggal tersebut. Apabila barang tidak dapat dikembalikan, mohon segera hubungi Penanggung Jawab BMN. Terima kasih atas kerja samanya.</p>
    <?php cetak_ttd([
        ['jabatan' => 'Penanggung Jawab BMN', 'nama' => $cfg['penanggung_jawab_bmn'] ?? '', 'nip' => $cfg['nip_pjbmn'] ?? ''],
    ]); ?>
    <div class="catatan-kecil">Dicetak <?= e($tglCetak) ?> oleh <?= e($oleh) ?></div>
    </div></body></html>
    <?php exit;
}

if ($jenis === 'tutup_buku') {
    // ---------- TUTUP BUKU TAHUN AJARAN ----------
    $id = get_int('id');
    $t = db_row($con, "SELECT * FROM tahun_ajaran WHERE id = ? AND status = 'Ditutup'", 'i', [$id]);
    if (!$t) { http_response_code(404); exit('Tutup buku hanya tersedia untuk tahun ajaran yang sudah ditutup.'); }
    $rows = db_all($con,
        "SELECT tb.*, b.kode_barang, b.nama_barang, k.nama AS kategori FROM tutup_buku tb
         JOIN barang b ON b.id = tb.barang_id JOIN kategori k ON k.id = b.kategori_id
         WHERE tb.tahun_ajaran_id = ? ORDER BY k.nama, b.nama_barang", 'i', [$id]);
    $tot = ['perolehan' => 0, 'akum' => 0, 'buku' => 0];
    foreach ($rows as $r0) { $tot['perolehan'] += $r0['perolehan']; $tot['akum'] += $r0['akumulasi']; $tot['buku'] += $r0['nilai_buku']; }
    cetak_mulai('Tutup Buku ' . $t['nama'], $base);
    cetak_kop($cfg, $base, $instansi);
    ?>
    <h3 class="judul">Tutup Buku Inventaris Tahun Ajaran <?= e($t['nama']) ?></h3>
    <div class="sub-judul">Posisi per <?= tgl_indo($t['tanggal_selesai'], true) ?> · ditutup <?= waktu_indo($t['ditutup_pada']) ?> oleh <?= e($t['ditutup_oleh']) ?></div>
    <div class="ringkas"><span>Jumlah barang: <b><?= count($rows) ?></b></span><span>Nilai perolehan: <b><?= rupiah($tot['perolehan']) ?></b></span><span>Akumulasi: <b><?= rupiah($tot['akum']) ?></b></span><span>Nilai buku: <b><?= rupiah($tot['buku']) ?></b></span></div>
    <table class="laporan">
        <thead><tr><th>No</th><th>Kode</th><th>Nama barang</th><th>Kategori</th><th>Total unit</th><th>Tersedia</th><th>Perolehan</th><th>Akumulasi</th><th>Nilai buku</th></tr></thead>
        <tbody>
        <?php $n = 1; foreach ($rows as $r0): ?>
            <tr><td class="c"><?= $n++ ?></td><td><?= e($r0['kode_barang']) ?></td><td><?= e($r0['nama_barang']) ?></td><td><?= e($r0['kategori']) ?></td>
                <td class="num"><?= angka($r0['stok_total']) ?></td><td class="num"><?= angka($r0['tersedia']) ?></td>
                <td class="num"><?= rupiah($r0['perolehan']) ?></td><td class="num"><?= rupiah($r0['akumulasi']) ?></td><td class="num"><?= rupiah($r0['nilai_buku']) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php cetak_ttd([
        ['jabatan' => 'Penanggung Jawab BMN', 'nama' => $cfg['penanggung_jawab_bmn'] ?? '', 'nip' => $cfg['nip_pjbmn'] ?? ''],
        ['jabatan' => 'Mengetahui, Kepala Sekolah', 'nama' => $cfg['kepala_sekolah'] ?? '', 'nip' => $cfg['nip_kepala'] ?? ''],
    ]); ?>
    <div class="catatan-kecil">Dicetak <?= e($tglCetak) ?> oleh <?= e($oleh) ?></div>
    </div></body></html>
    <?php exit;
}

// ---------- LAPORAN TABEL ----------
if (!isset(JENIS_LAPORAN[$jenis])) $jenis = 'inventaris';
try {
    $data = laporan_data($jenis, laporan_filter_request());
} catch (AppException $ex) {
    cetak_mulai('Laporan', $base);
    echo '<p>' . e($ex->getMessage()) . '</p></div></body></html>';
    exit;
}
cetak_mulai($data['judul'] . ' — ' . $instansi, $base);
cetak_kop($cfg, $base, $instansi);
?>
<h3 class="judul"><?= e($data['judul']) ?></h3>
<div class="sub-judul"><?= e($data['filter']) ?></div>
<div class="ringkas">
    <?php foreach ($data['ringkas'] as $lbl => $nilai): ?><span><?= e($lbl) ?>: <b><?= e((string)$nilai) ?></b></span><?php endforeach; ?>
</div>
<table class="laporan">
    <thead><tr><th style="width:28px">No</th>
        <?php foreach ($data['kolom'] as [$label]): ?><th><?= e($label) ?></th><?php endforeach; ?>
    </tr></thead>
    <tbody>
    <?php if (!$data['rows']): ?>
        <tr><td colspan="<?= count($data['kolom']) + 1 ?>" class="c">Tidak ada data pada periode/filter ini.</td></tr>
    <?php endif; ?>
    <?php $n = 1; foreach ($data['rows'] as $row): ?>
        <tr>
            <td class="c"><?= $n++ ?></td>
            <?php foreach ($data['kolom'] as [$label, $key, $fmt]):
                $isNum = in_array($fmt, ['int', 'rupiah', 'ttl'], true);
                $val = fmt_sel($row[$key] ?? null, $fmt);
            ?>
                <td class="<?= $isNum ? 'num' : '' ?>"><?= e($val) ?></td>
            <?php endforeach; ?>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php
if ($jenis === 'inventaris' || $jenis === 'rusak' || $jenis === 'masuk' || $jenis === 'keluar' || $jenis === 'pinjam') {
    cetak_ttd([
        ['jabatan' => 'Mengetahui, Kepala Sekolah', 'nama' => $cfg['kepala_sekolah'] ?? '', 'nip' => $cfg['nip_kepala'] ?? ''],
        ['jabatan' => 'Penanggung Jawab BMN', 'nama' => $cfg['penanggung_jawab_bmn'] ?? '', 'nip' => $cfg['nip_pjbmn'] ?? ''],
    ]);
}
?>
<div class="catatan-kecil">Dicetak <?= e($tglCetak) ?> oleh <?= e($oleh) ?> · <?= e(APP_NAME) ?> v<?= e(APP_VERSION) ?></div>
</div>
</body></html>
