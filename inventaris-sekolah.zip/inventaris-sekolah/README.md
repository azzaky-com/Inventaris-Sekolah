# Inventaris Sekolah v4

Aplikasi inventaris dan aset sekolah berbasis **PHP + MySQL/MariaDB**. Versi 4 menambahkan jumlah per ruangan, persetujuan berlapis, penghapusan aset dengan berita acara resmi, tutup buku tahun ajaran, dan pengarsipan per tahun ajaran.

## 1. Persyaratan

- PHP 7.4 atau lebih baru (diuji pada PHP 8.3). Ekstensi: `mysqli`, `mbstring`, `json`.
- MySQL 5.7+ atau MariaDB 10.2+ (diuji pada MariaDB 10.11).
- Apache (XAMPP/Laragon) atau server PHP bawaan. Pemindai QR memerlukan HTTPS atau `localhost`.

## 2. Instalasi baru

1. Salin folder `inventaris-sekolah` ke `htdocs` (XAMPP) atau `www` (Laragon).
2. Buat database kosong `inventaris` (utf8mb4_unicode_ci), lalu impor `database/inventaris.sql`.
3. Buka `http://localhost/inventaris-sekolah/`.

| Username   | Password       | Peran          |
|------------|----------------|----------------|
| `admin`    | `admin12345`   | Administrator  |
| `operator` | `operator123`  | Operator       |
| `kepsek`   | `kepsek12345`  | Kepala Sekolah |

**Ganti semua password sebelum dipakai.** Nama sekolah dan pejabat pada data contoh bersifat fiktif (ubah di menu Pengaturan Sekolah).

## 3. Memasang ulang

Cukup hapus folder versi sebelumnya dan pasang paket ini dengan langkah di bagian 2. Tidak ada migrasi: `database/inventaris.sql` adalah instalasi lengkap yang sesuai dengan aplikasi ini.

## 4. Peran dan menu

| Peran | Menu utama | Tidak tersedia |
|---|---|---|
| **Operator** (TU / gudang) | Beranda operasional, Data Barang, Pindai QR, Barang Masuk, Pemakaian & Keluar, Pindah Ruangan, Peminjaman, Kerusakan, Penghapusan (usul), Opname barang, Laporan | Persetujuan, Nilai & Penyusutan, Tahun Ajaran, Pemeliharaan, Pengguna |
| **Kepala Sekolah** | Beranda keputusan, Persetujuan, Data Barang (lihat), Nilai & Penyusutan, Laporan, Log | Input transaksi, Tahun Ajaran, Pemeliharaan, Pengguna |
| **Administrator** | Semua menu | — |

Akses dicek di server pada setiap halaman dan aksi, bukan hanya di menu.

## 5. Jumlah per ruangan

- Setiap barang punya jumlah di tiap ruangan. Jumlah seluruh ruangan selalu sama dengan total unit.
- Barang masuk, pemakaian/keluar, peminjaman, dan laporan kerusakan **wajib memilih ruangan**. Dropdown ruangan menampilkan jumlah yang tersedia di tiap ruangan dan menonaktifkan ruangan yang habis.
- **Pindah ruangan** memindahkan unit antar ruangan tanpa mengubah total unit. Unit yang sedang dipinjam atau rusak tidak bisa dipindahkan.
- Detail barang menampilkan tabel per ruangan: jumlah, dipinjam, rusak, dan tersedia.

## 6. Persetujuan berlapis

- **Barang masuk bernilai besar** (jumlah × harga ≥ ambang, default Rp 10.000.000; diatur di database `pengaturan.ambang_persetujuan_masuk`) menunggu persetujuan Kepala Sekolah. Jumlah belum bertambah sampai disetujui. Saldo awal pendataan tidak perlu persetujuan.
- **Penghapusan aset**: operator mengusulkan dengan alasan dan uraian. Kepala Sekolah menyetujui atau menolak. Saat disetujui, jumlah berkurang dan **berita acara dengan nomor resmi** (mis. `BA-HAPUS/2026/002`) terbit. Berita acara bisa dicetak.
- **Rusak permanen** pada laporan kerusakan otomatis menerbitkan berita acara.
- Semua persetujuan muncul di halaman **Persetujuan**.

## 7. Peminjaman: pengembalian sebagian dan pengingat

- Pengembalian bisa dicatat **sebagian**. Unit yang kembali dan unit yang hilang dicatat terpisah. Sisa yang belum kembali tetap berstatus "Dipinjam" dan tampil di daftar.
- Pinjaman selesai saat seluruh unit kembali (*Dikembalikan*) atau dinyatakan hilang seluruhnya (*Hilang*).
- Isi nomor WhatsApp peminjam untuk tombol **kirim pengingat WhatsApp** (membuka WhatsApp dengan pesan siap kirim). Tombol bel mencatat bahwa pengingat sudah dikirim. Surat pengingat resmi bisa dicetak.

## 8. Tahun ajaran & tutup buku

- Menu **Tahun Ajaran** (Administrator) menampilkan tahun berjalan dan daftar tahun.
- **Tutup tahun ajaran** menyimpan posisi setiap aset (jumlah, tersedia, perolehan, akumulasi penyusutan, nilai buku) dan **mengunci** semua transaksi dengan tanggal dalam periode itu. Transaksi terkunci tidak bisa dicatat, diubah, atau dibatalkan.
- Penutupan ditolak bila masih ada barang masuk menunggu, usulan penghapusan, atau opname draft pada periode itu.
- Tutup buku bisa dicetak sebagai dokumen resmi.

## 9. Pengarsipan per tahun ajaran

Menu **Pemeliharaan Data** (Administrator) mengarsipkan data berdasarkan tahun ajaran yang sudah ditutup. Untuk setiap tahun tersedia:
1. **Unduh** arsip kartu persediaan dan log (CSV).
2. **Arsipkan** setelah diunduh dan dikonfirmasi.

Pengarsipan kartu persediaan **tidak mengubah angka aset**. Riwayat rinci sebelum tanggal batas dihapus, tetapi sisa setiap batch pembelian disimpan kembali dengan tanggal dan harga asli. Akibatnya penyusutan dan nilai buku sebelum dan sesudah arsip sama. Ini sudah diuji: total nilai buku Rp 601.401.000 tetap sama sebelum dan sesudah arsip.

Pemeliharaan juga punya alat manual (per tanggal), bersih foto kerusakan yang tidak terpakai, dan bersih kunci login kedaluwarsa. Data dalam 30 hari terakhir tidak bisa diarsipkan.

## 10. Pindai QR & pencarian

- **Pindai Aset**: buka kamera dan arahkan ke label QR aset. Hasil langsung membuka halaman detail. Bisa juga mengetik kode barang (mis. `ELK-0001`).
- **Pencarian** (kotak di atas): mencari barang, peminjaman, laporan kerusakan, berita acara, dan pengguna sekaligus, sesuai hak akses.

## 11. Dokumen cetak

Di menu cetak dan dari halaman terkait:
- **KIB (Kartu Inventaris Barang)** untuk aset tetap: data perolehan, penyusutan, jumlah per ruangan, dan riwayat mutasi. Dibuka dari detail barang.
- **Berita acara penghapusan** dengan nomor resmi.
- **Surat pengingat pengembalian** untuk peminjaman yang berjalan.
- **Tutup buku** tahun ajaran.
- Laporan baru: **Jumlah per Ruangan** dan **Berita Acara Penghapusan**. Filter tahun ajaran tersedia di laporan.

## 12. Aturan jumlah (penting)

```
total unit   = jumlah unit yang dimiliki sekolah  (= jumlah jumlah per ruangan)
dipinjam     = sisa unit pada peminjaman yang masih berjalan
rusak        = unit pada laporan kerusakan yang belum selesai/dihapus
tersedia     = total unit − dipinjam − rusak
```

Kartu persediaan menyimpan **perubahan** (total dan tersedia). Saldo berjalan dihitung dari perubahan menurut tanggal, sehingga transaksi yang diberi tanggal mundur tetap benar. Invarian yang diuji: jumlah perubahan kartu persediaan = total unit, dan tidak ada jumlah negatif di ruangan mana pun.

## 13. Penyusutan per batch (FIFO)

Penyusutan dihitung per batch pembelian: setiap penambahan jumlah menjadi batch dengan tanggal dan harga sendiri, dan setiap pengurangan mengambil unit tertua lebih dulu. Penyusutan garis lurus dihitung per bulan penuh dari tanggal masing-masing batch. Detail barang menampilkan tabel batch.

## 14. Struktur folder

```
index.php            router modul (?m=...), CSRF, hak akses per aksi
api.php              endpoint JSON: ruangan per barang, cari kode (untuk pindai & dropdown)
login.php / logout.php / export.php
config/              konfigurasi, koneksi, auth, helper, jumlah & transaksi, penyusutan, tahun ajaran,
                     arsip, laporan
modules/             satu file per halaman (dashboard per peran, barang, aset, persetujuan, penghapusan,
                     pemindahan, pindai, cari, peminjaman, tahun ajaran, pemeliharaan, laporan, dll.)
layout/              kerangka halaman (menu per peran), komponen UI, halaman 403
print/cetak.php      cetak laporan, KIB, berita acara, surat pengingat, tutup buku, label QR
database/            inventaris.sql (instalasi lengkap: skema + data contoh)
assets/              CSS, JS, vendor (Bootstrap 4.6, jQuery, DataTables, Select2, Chart.js, jsQR, dll.)
uploads/barang_rusak/  foto kerusakan (eksekusi PHP dinonaktifkan)
```

## 15. Perubahan dari v3

### Perbaikan v4.1
- Tabel Barang Masuk dan Peminjaman gagal diurutkan dan dicari (kolom tidak valid di atribut tabel).
- Laju pemakaian habis pakai tampil sebagai "0" untuk nilai kecil; sekarang dua desimal.
- Lonceng notifikasi dan badge sidebar kini sesuai peran dan selalu konsisten.
- Beranda Kepala Sekolah menampilkan seluruh antrean persetujuan (pembelian, penghapusan, perbaikan).
- Beranda menampilkan sisa peminjaman yang belum kembali, bukan jumlah awal.
- Operator tidak lagi melihat nilai buku atau nilai aset di daftar barang dan laporan inventaris.
- Angka KPI besar tidak terpotong di layar kecil; tombol di header tidak lagi bergeser saat turun baris.
- Kontrol DataTables, kolom sekunder pada layar kecil, dan indikator fokus keyboard diperbaiki.

- **Jumlah per ruangan** dengan pindah ruangan, pilihan ruangan di setiap transaksi, dan tabel per ruangan di detail barang.
- **Persetujuan berlapis**: barang masuk bernilai besar dan penghapusan aset.
- **Berita acara penghapusan** dengan nomor resmi, otomatis untuk rusak permanen.
- **Pengembalian sebagian** dan pencatatan hilang sebagian.
- **Tutup buku tahun ajaran** dengan penguncian periode dan snapshot posisi aset.
- **Pengarsipan per tahun ajaran** yang tidak mengubah angka penyusutan.
- **Pindai QR, pencarian global, pengingat WhatsApp, KIB, dan dokumen cetak** baru.
- **Perbaikan**:
  - Saldo awal pendataan kini langsung disetujui (sebelumnya bisa tertahan di persetujuan).
  - Pengarsipan sebelumnya mengubah penyusutan karena tanggal batch dihapus. Sekarang tanggal dan harga asli dipertahankan.
  - Halaman barang masuk error karena fungsi duplikat, dan ikon laporan baru belum terdaftar. Keduanya sudah diperbaiki.

## 16. Pengujian dan batasan

Diuji di MariaDB 10.11 dan PHP 8.3 pada database yang dibangun dari nol:
- Crawl 111 halaman untuk admin: 110 tampil tanpa error, satu 404 yang disengaja (berita acara sesi opname yang belum final).
- Hak akses per role (operator dan Kepala Sekolah) sesuai desain.
- Alur v4 dari ujung ke ujung: pindah ruangan, pemakaian melebihi jumlah ditolak, persetujuan berlapis, pengembalian sebagian, penghapusan dengan nomor BA, kunci periode, dan arsip per tahun ajaran.
- Invarian jumlah dan nilai buku sebelum dan sesudah arsip.

Belum diuji: tampilan dan JavaScript di browser sungguhan (dropdown ruangan, pemindai kamera, grafik, DataTables), PHP 7.4, dan Apache. Pengingat WhatsApp membuka WhatsApp dengan pesan siap kirim, tetapi pengiriman tetap dilakukan manual. KIB memakai tata letak dan isian yang lazim, tetapi belum disesuaikan dengan formulir resmi Kementerian Keuangan. Sebelum dipakai di sekolah, buka setiap menu sekali di browser dan periksa format KIB dengan Penanggung Jawab BMN.

## 17. Lisensi pihak ketiga

Bootstrap, jQuery, DataTables, Select2, SweetAlert2 (MIT); Font Awesome Free (CC BY 4.0 / SIL OFL / MIT); Chart.js (MIT); qrcode-generator (MIT); jsQR (Apache-2.0).
