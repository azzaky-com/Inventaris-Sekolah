<?php
// logout.php — mengakhiri sesi pengguna.
require_once __DIR__ . '/config/bootstrap.php';
logout_proses();
redirect(base_url() . 'login.php');
