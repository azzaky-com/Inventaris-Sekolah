<?php
// api.php — endpoint kecil (JSON) untuk isian formulir dan pemindai: ruangan per barang, dan cari kode.
require_once __DIR__ . '/config/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
if (auth_user() === null) { http_response_code(401); echo json_encode(['error' => 'login']); exit; }
$aksi = get_str('aksi', 20);
$con = db();

if ($aksi === 'lokasi') {
    $barang = get_int('barang_id');
    $out = [];
    foreach (barang_per_lokasi($con, $barang) as $l) {
        $tersedia = (int)$l['stok'] - (int)$l['dipinjam'] - (int)$l['rusak'];
        $out[] = ['id' => (int)$l['id'], 'nama' => $l['nama'], 'tersedia' => $tersedia, 'stok' => (int)$l['stok']];
    }
    echo json_encode(['lokasi' => $out]);
    exit;
}

if ($aksi === 'kode') {
    $kode = strtoupper(str_bersih($_GET['kode'] ?? '', 20));
    $b = db_row($con, "SELECT id, nama_barang, kode_barang FROM barang WHERE kode_barang = ?", 's', [$kode]);
    echo json_encode(['ketemu' => (bool)$b, 'id' => $b ? (int)$b['id'] : null, 'nama' => $b['nama_barang'] ?? null]);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'aksi']);
