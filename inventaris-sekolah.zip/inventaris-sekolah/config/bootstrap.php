<?php
// config/bootstrap.php — dimuat oleh semua halaman: konfigurasi, sesi, keamanan dasar, dan helper.

require_once __DIR__ . '/app.php';

error_reporting(E_ALL);
ini_set('display_errors', APP_DEBUG ? '1' : '0');
ini_set('log_errors', '1');
date_default_timezone_set(ZONA_WAKTU);

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

// Header keamanan dasar
if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/inventaris.php';
require_once __DIR__ . '/penyusutan.php';
require_once __DIR__ . '/tahun.php';
require_once __DIR__ . '/arsip.php';
require_once __DIR__ . '/transaksi.php';
require_once __DIR__ . '/laporan.php';

// Tangkap error fatal dan tampilkan halaman ramah (detail hanya bila APP_DEBUG).
set_exception_handler(function (Throwable $e) {
    error_log('[' . APP_NAME . '] ' . $e->getMessage() . ' di ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) http_response_code(500);
    echo '<!doctype html><meta charset="utf-8"><title>Kesalahan</title>';
    echo '<body style="font-family:system-ui;padding:40px;text-align:center">';
    echo '<h2>Terjadi kesalahan pada sistem</h2><p>Silakan coba lagi. Bila terus berulang, hubungi administrator.</p>';
    if (APP_DEBUG) echo '<pre style="text-align:left">' . htmlspecialchars((string)$e) . '</pre>';
    echo '</body>';
});
