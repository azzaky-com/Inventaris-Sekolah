<?php
// config/database.php — koneksi database MySQL / MariaDB (utf8mb4, zona waktu WIB).
// Bisa diatur lewat environment variable (DB_HOST, DB_USER, DB_PASS, DB_NAME)
// atau langsung mengubah nilai default di bawah ini.

$DB_HOST = getenv('DB_HOST') ?: 'localhost';
$DB_USER = getenv('DB_USER') ?: 'root';
$DB_PASS = getenv('DB_PASS') ?: '';
$DB_NAME = getenv('DB_NAME') ?: 'inventaris';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $con = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
    mysqli_set_charset($con, 'utf8mb4');
    mysqli_query($con, "SET time_zone = '+07:00'");
} catch (Throwable $e) {
    error_log('Koneksi database gagal: ' . $e->getMessage());
    http_response_code(500);
    exit('Koneksi database gagal. Periksa config/database.php dan pastikan MySQL/MariaDB sudah berjalan.');
}

// Helper query (prepared statement) ----------------------------------------

/** Ambil semua baris hasil query. $types & $params untuk prepared statement. */
function db_all(mysqli $con, string $sql, string $types = '', array $params = []): array
{
    if ($params === []) {
        $res = mysqli_query($con, $sql);
        return $res ? mysqli_fetch_all($res, MYSQLI_ASSOC) : [];
    }
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $res  = mysqli_stmt_get_result($stmt);
    $rows = $res ? mysqli_fetch_all($res, MYSQLI_ASSOC) : [];
    mysqli_stmt_close($stmt);
    return $rows;
}

/** Ambil satu baris, atau null bila kosong. */
function db_row(mysqli $con, string $sql, string $types = '', array $params = []): ?array
{
    $rows = db_all($con, $sql, $types, $params);
    return $rows[0] ?? null;
}

/** Ambil nilai kolom pertama dari baris pertama, atau null. */
function db_value(mysqli $con, string $sql, string $types = '', array $params = [])
{
    $row = db_row($con, $sql, $types, $params);
    if ($row === null) return null;
    return reset($row);
}

/** Jalankan INSERT/UPDATE/DELETE. Mengembalikan ['affected' => int, 'insert_id' => int]. */
function db_exec(mysqli $con, string $sql, string $types = '', array $params = []): array
{
    if ($params === []) {
        mysqli_query($con, $sql);
        return ['affected' => mysqli_affected_rows($con), 'insert_id' => mysqli_insert_id($con)];
    }
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $hasil = ['affected' => mysqli_stmt_affected_rows($stmt), 'insert_id' => mysqli_stmt_insert_id($stmt)];
    mysqli_stmt_close($stmt);
    return $hasil;
}

/** Jalankan fungsi di dalam transaksi database. Aman dipanggil bersarang (hanya level terluar yang commit). */
function db_tx(mysqli $con, callable $fn)
{
    static $depth = 0;
    if ($depth > 0) {
        return $fn($con);
    }
    mysqli_begin_transaction($con);
    $depth = 1;
    try {
        $hasil = $fn($con);
        mysqli_commit($con);
        $depth = 0;
        return $hasil;
    } catch (Throwable $e) {
        mysqli_rollback($con);
        $depth = 0;
        throw $e;
    }
}
