<?php
// config/laporan.php — sumber data laporan. Dipakai bersama oleh layar laporan, halaman cetak, dan ekspor CSV.

const JENIS_LAPORAN = [
    'inventaris' => 'Laporan Inventaris Barang',
    'masuk'      => 'Laporan Barang Masuk',
    'keluar'     => 'Laporan Barang Keluar',
    'pinjam'     => 'Laporan Peminjaman Barang',
    'rusak'      => 'Laporan Kerusakan & Perbaikan',
    'kartu'      => 'Kartu Persediaan Barang',
    'mutasi'     => 'Jurnal Mutasi Jumlah',
    'aset'       => 'Laporan Nilai Aset & Penyusutan',
    'lokasi'     => 'Jumlah per Ruangan',
    'penghapusan'=> 'Berita Acara Penghapusan',
];

const LABEL_MUTASI = [
    'masuk'            => 'Barang Masuk',
    'keluar'           => 'Barang Keluar',
    'pinjam'           => 'Dipinjam',
    'kembali'          => 'Dikembalikan',
    'hilang'           => 'Hilang',
    'rusak'            => 'Dilaporkan Rusak',
    'selesai_perbaikan'=> 'Selesai Diperbaiki',
    'rusak_permanen'   => 'Rusak Permanen (Dihapus)',
    'opname'           => 'Penyesuaian Opname',
    'koreksi'          => 'Koreksi / Pembatalan',
    'saldo_awal'       => 'Saldo Terbawa dari Arsip',
];

/** Baca filter laporan dari query string (sudah divalidasi). */
function laporan_filter_request(): array
{
    $f = laporan_filter_request_dasar();
    $tid = get_int('tahun_id');
    if ($tid) {
        $t = db_row(db(), "SELECT tanggal_mulai, tanggal_selesai FROM tahun_ajaran WHERE id = ?", 'i', [$tid]);
        if ($t) { $f['dari'] = $t['tanggal_mulai']; $f['sampai'] = $t['tanggal_selesai']; }
    }
    return $f;
}

function laporan_filter_request_dasar(): array
{
    return [
        'dari'        => tanggal_valid($_GET['dari'] ?? ''),
        'sampai'      => tanggal_valid($_GET['sampai'] ?? ''),
        'barang_id'   => get_int('barang_id') ?: null,
        'kategori_id' => get_int('kategori_id') ?: null,
        'lokasi_id'   => get_int('lokasi_id') ?: null,
        'status'      => get_str('status', 40) ?: null,
        'jenis'       => get_str('jenis_mutasi', 40) ?: null,
    ];
}

/** Bangun klausa WHERE dari daftar [sql, tipe, nilai]. Nilai null dilewati. */
function sql_where(array $klausa): array
{
    $sql = []; $tipe = ''; $param = [];
    foreach ($klausa as $k) {
        [$s, $t, $v] = $k;
        if ($t === '') { $sql[] = $s; continue; }   // klausa tetap, selalu berlaku
        if ($v === null) continue;
        $sql[]   = $s;
        $tipe   .= $t;
        $param[] = $v;
    }
    return [$sql ? implode(' AND ', $sql) : '1=1', $tipe, $param];
}

/** Hasil laporan: judul, kolom [label, key, fmt], baris, ringkasan, deskripsi filter. */
function laporan_data(string $jenis, array $f): array
{
    $con = db();
    switch ($jenis) {
        case 'inventaris': return laporan_inventaris($con, $f);
        case 'masuk':      return laporan_transaksi($con, $f, 'masuk');
        case 'keluar':     return laporan_transaksi($con, $f, 'keluar');
        case 'pinjam':     return laporan_pinjam($con, $f);
        case 'rusak':      return laporan_rusak($con, $f);
        case 'kartu':      return laporan_kartu($con, $f);
        case 'mutasi':     return laporan_mutasi($con, $f);
        case 'aset':       return laporan_aset($con, $f);
        case 'lokasi':     return laporan_lokasi($con, $f);
        case 'penghapusan': return laporan_penghapusan($con, $f);
    }
    throw new AppException('Jenis laporan tidak dikenal.');
}

function laporan_meta(string $jenis, array $kolom, array $rows, array $ringkas, string $filter): array
{
    return [
        'judul'   => JENIS_LAPORAN[$jenis] ?? 'Laporan',
        'kolom'   => $kolom,
        'rows'    => $rows,
        'ringkas' => $ringkas,
        'filter'  => $filter,
    ];
}

function deskripsi_periode(array $f): string
{
    if ($f['dari'] || $f['sampai']) {
        return 'Periode: ' . ($f['dari'] ? tgl_indo($f['dari']) : '...') . ' s/d ' . ($f['sampai'] ? tgl_indo($f['sampai']) : '...');
    }
    return 'Periode: seluruh data';
}

function laporan_inventaris(mysqli $con, array $f): array
{
    [$where, $tipe, $param] = sql_where([
        ['b.aktif = 1', '', null],
        ['b.kategori_id = ?', 'i', $f['kategori_id']],
        ['b.lokasi_id = ?', 'i', $f['lokasi_id']],
    ]);
    $rows = db_all($con,
        "SELECT x.*, (x.total - x.dipinjam - x.rusak) AS tersedia, (x.total * x.harga) AS nilai FROM (
            SELECT b.kode_barang, b.nama_barang, k.nama AS kategori, COALESCE(m.nama, '-') AS merek,
                   COALESCE(l.nama, '-') AS lokasi, b.satuan, b.stok_total AS total, b.stok_minimum AS minimum,
                   b.harga_perolehan AS harga, b.sumber_dana, b.tahun_perolehan,
                   (SELECT COALESCE(SUM(p.sisa),0) FROM peminjaman p WHERE p.barang_id=b.id AND p.status='Dipinjam') AS dipinjam,
                   (SELECT COALESCE(SUM(r.jumlah),0) FROM kerusakan r WHERE r.barang_id=b.id AND r.status NOT IN ('Selesai','Rusak Permanen')) AS rusak
            FROM barang b
            JOIN kategori k ON k.id = b.kategori_id
            LEFT JOIN merek m ON m.id = b.merek_id
            LEFT JOIN lokasi l ON l.id = b.lokasi_id
            WHERE $where
            ORDER BY k.nama, b.nama_barang
        ) x", $tipe, $param);

    $total = 0; $nilai = 0; $tersedia = 0;
    foreach ($rows as $r) { $total += $r['total']; $nilai += $r['nilai']; $tersedia += $r['tersedia']; }

    $kolom = [
        ['Kode', 'kode_barang', 'text'], ['Nama Barang', 'nama_barang', 'text'], ['Kategori', 'kategori', 'text'],
        ['Merek', 'merek', 'text'], ['Lokasi', 'lokasi', 'text'], ['Sat.', 'satuan', 'text'],
        ['Total', 'total', 'int'], ['Dipinjam', 'dipinjam', 'int'], ['Rusak', 'rusak', 'int'],
        ['Tersedia', 'tersedia', 'int'], ['Harga/Unit', 'harga', 'rupiah'], ['Nilai Aset', 'nilai', 'rupiah'],
    ];
    $meta = laporan_meta('inventaris', $kolom, $rows, [
        'Jenis barang' => count($rows), 'Total unit' => $total, 'Tersedia' => $tersedia, 'Total nilai aset' => rupiah($nilai),
    ], 'Kategori & lokasi: ' . ($f['kategori_id'] ? 'terpilih' : 'semua') . ' / ' . ($f['lokasi_id'] ? 'terpilih' : 'semua'));
    if (!can('nilai.lihat')) {
        $meta['kolom'] = array_values(array_filter($meta['kolom'], function ($k) { return !in_array($k[1], ['harga', 'nilai'], true); }));
        foreach ($meta['rows'] as &$r) { unset($r['harga'], $r['nilai']); }
        unset($r);
        unset($meta['ringkas']['Total nilai aset']);
    }
    return $meta;
}

function laporan_transaksi(mysqli $con, array $f, string $jenis): array
{
    $tabel = $jenis === 'masuk' ? 'barang_masuk' : 'barang_keluar';
    [$where, $tipe, $param] = sql_where([
        ['t.tanggal >= ?', 's', $f['dari']],
        ['t.tanggal <= ?', 's', $f['sampai']],
        ['t.barang_id = ?', 'i', $f['barang_id']],
    ]);
    if ($jenis === 'masuk') {
        $where .= " AND t.status = 'Disetujui'";
        $rows = db_all($con,
            "SELECT t.tanggal, b.kode_barang, b.nama_barang, t.jumlah, t.harga_satuan AS harga,
                    (t.jumlah * t.harga_satuan) AS nilai, t.sumber_dana, t.nomor_dokumen, t.keterangan
             FROM barang_masuk t JOIN barang b ON b.id = t.barang_id
             WHERE $where ORDER BY t.tanggal DESC, t.id DESC", $tipe, $param);
        $total = array_sum(array_column($rows, 'jumlah'));
        $nilai = array_sum(array_column($rows, 'nilai'));
        $kolom = [
            ['Tanggal', 'tanggal', 'tgl'], ['Kode', 'kode_barang', 'text'], ['Nama Barang', 'nama_barang', 'text'],
            ['Jumlah', 'jumlah', 'int'], ['Harga/Unit', 'harga', 'rupiah'], ['Nilai', 'nilai', 'rupiah'],
            ['Sumber Dana', 'sumber_dana', 'text'], ['No. Dokumen', 'nomor_dokumen', 'text'], ['Keterangan', 'keterangan', 'text'],
        ];
        $ringkas = ['Jumlah transaksi' => count($rows), 'Total unit masuk' => $total, 'Total nilai' => rupiah($nilai)];
    } else {
        $rows = db_all($con,
            "SELECT t.tanggal, b.kode_barang, b.nama_barang, t.jumlah, t.alasan, t.penerima, t.keterangan
             FROM barang_keluar t JOIN barang b ON b.id = t.barang_id
             WHERE $where ORDER BY t.tanggal DESC, t.id DESC", $tipe, $param);
        $total = array_sum(array_column($rows, 'jumlah'));
        $kolom = [
            ['Tanggal', 'tanggal', 'tgl'], ['Kode', 'kode_barang', 'text'], ['Nama Barang', 'nama_barang', 'text'],
            ['Jumlah', 'jumlah', 'int'], ['Alasan', 'alasan', 'text'], ['Penerima / Unit', 'penerima', 'text'],
            ['Keterangan', 'keterangan', 'text'],
        ];
        $ringkas = ['Jumlah transaksi' => count($rows), 'Total unit keluar' => $total];
    }
    return laporan_meta($jenis === 'masuk' ? 'masuk' : 'keluar', $kolom, $rows, $ringkas, deskripsi_periode($f));
}

function laporan_pinjam(mysqli $con, array $f): array
{
    $statusSql = null; $statusTipe = ''; $statusParam = null;
    $klausa = [
        ['p.tanggal_pinjam >= ?', 's', $f['dari']],
        ['p.tanggal_pinjam <= ?', 's', $f['sampai']],
        ['p.barang_id = ?', 'i', $f['barang_id']],
    ];
    if ($f['status'] === 'Terlambat') {
        $klausa[] = ["(p.status = 'Dipinjam' AND p.tanggal_rencana_kembali < CURDATE())", '', null];
        // nilai null dilewati, jadi tambahkan langsung ke where di bawah
    } elseif ($f['status']) {
        $klausa[] = ['p.status = ?', 's', $f['status']];
    }
    [$where, $tipe, $param] = sql_where($klausa);
    if ($f['status'] === 'Terlambat') {
        $where .= " AND p.status = 'Dipinjam' AND p.tanggal_rencana_kembali < CURDATE()";
    }
    $rows = db_all($con,
        "SELECT b.kode_barang, b.nama_barang, p.jumlah, p.peminjam, p.tipe_peminjam, p.unit,
                p.tanggal_pinjam, p.tanggal_rencana_kembali, p.tanggal_kembali,
                CASE WHEN p.status = 'Dipinjam' AND p.tanggal_rencana_kembali < CURDATE() THEN 'Terlambat' ELSE p.status END AS status,
                p.kondisi_pinjam, p.kondisi_kembali, p.keterangan
         FROM peminjaman p JOIN barang b ON b.id = p.barang_id
         WHERE $where ORDER BY p.tanggal_pinjam DESC, p.id DESC", $tipe, $param);
    $kolom = [
        ['Kode', 'kode_barang', 'text'], ['Nama Barang', 'nama_barang', 'text'], ['Jml', 'jumlah', 'int'],
        ['Peminjam', 'peminjam', 'text'], ['Tipe', 'tipe_peminjam', 'text'], ['Unit / Keperluan', 'unit', 'text'],
        ['Tgl Pinjam', 'tanggal_pinjam', 'tgl'], ['Rencana Kembali', 'tanggal_rencana_kembali', 'tgl'],
        ['Tgl Kembali', 'tanggal_kembali', 'tgl'], ['Status', 'status', 'text'], ['Kondisi Kembali', 'kondisi_kembali', 'text'],
    ];
    $terlambat = count(array_filter($rows, function ($r) { return $r['status'] === 'Terlambat'; }));
    return laporan_meta('pinjam', $kolom, $rows, [
        'Jumlah peminjaman' => count($rows), 'Masih dipinjam' => count(array_filter($rows, function ($r) { return $r['status'] === 'Dipinjam' || $r['status'] === 'Terlambat'; })),
        'Terlambat' => $terlambat,
    ], deskripsi_periode(['dari' => $f['dari'], 'sampai' => $f['sampai']]));
}

function laporan_rusak(mysqli $con, array $f): array
{
    [$where, $tipe, $param] = sql_where([
        ['r.tanggal_lapor >= ?', 's', $f['dari']],
        ['r.tanggal_lapor <= ?', 's', $f['sampai']],
        ['r.status = ?', 's', $f['status']],
        ['r.barang_id = ?', 'i', $f['barang_id']],
    ]);
    $rows = db_all($con,
        "SELECT r.id, b.kode_barang, b.nama_barang, r.jumlah, r.tanggal_lapor, r.pelapor, r.deskripsi,
                r.status, COALESCE(r.teknisi, '-') AS teknisi, r.estimasi_biaya AS estimasi, r.biaya_aktual AS aktual, r.tanggal_selesai
         FROM kerusakan r JOIN barang b ON b.id = r.barang_id
         WHERE $where ORDER BY r.tanggal_lapor DESC, r.id DESC", $tipe, $param);
    $kolom = [
        ['No.', 'id', 'text'], ['Tgl Lapor', 'tanggal_lapor', 'tgl'], ['Kode', 'kode_barang', 'text'],
        ['Nama Barang', 'nama_barang', 'text'], ['Jml', 'jumlah', 'int'], ['Pelapor', 'pelapor', 'text'],
        ['Kerusakan', 'deskripsi', 'text'], ['Status', 'status', 'text'], ['Teknisi', 'teknisi', 'text'],
        ['Estimasi', 'estimasi', 'rupiah'], ['Biaya Aktual', 'aktual', 'rupiah'], ['Selesai', 'tanggal_selesai', 'tgl'],
    ];
    $biaya = array_sum(array_map(function ($r) { return (float)$r['aktual']; }, $rows));
    return laporan_meta('rusak', $kolom, $rows, [
        'Jumlah laporan' => count($rows), 'Masih aktif' => count(array_filter($rows, function ($r) { return !in_array($r['status'], ['Selesai', 'Rusak Permanen'], true); })),
        'Total biaya perbaikan' => rupiah($biaya),
    ], deskripsi_periode(['dari' => $f['dari'], 'sampai' => $f['sampai']]));
}


function laporan_kartu(mysqli $con, array $f): array
{
    if (!$f['barang_id']) {
        throw new AppException('Pilih barang terlebih dahulu untuk kartu persediaan.');
    }
    $barang = barang_detail($con, $f['barang_id']);
    if (!$barang) throw new AppException('Barang tidak ditemukan.');

    $m = mutasi_berjalan($con, (int)$f['barang_id'], $f['dari'], $f['sampai']);
    $rows = [];
    if ($f['dari']) {
        $rows[] = ['tanggal' => $f['dari'] . ' 00:00:00', 'jenis' => 'Saldo Awal', 'referensi' => '-',
            'keterangan' => 'Saldo sebelum periode', 'jumlah' => 0, 'perubahan_total' => 0,
            'saldo_total' => $m['awal']['t'], 'saldo_tersedia' => $m['awal']['s'], 'user_nama' => '-'];
    }
    foreach ($m['rows'] as $r) {
        $r['jenis'] = LABEL_MUTASI[$r['jenis']] ?? $r['jenis'];
        $rows[] = $r;
    }
    $kolom = [
        ['Waktu', 'tanggal', 'waktu'], ['Jenis', 'jenis', 'text'], ['Referensi', 'referensi', 'text'],
        ['Keterangan', 'keterangan', 'text'], ['Jumlah', 'jumlah', 'int'], ['+/-', 'perubahan_total', 'ttl'],
        ['Saldo Total', 'saldo_total', 'int'], ['Saldo Tersedia', 'saldo_tersedia', 'int'], ['Oleh', 'user_nama', 'text'],
    ];
    return laporan_meta('kartu', $kolom, $rows, [
        'Barang' => $barang['kode_barang'] . ' — ' . $barang['nama_barang'],
        'Saldo akhir total' => $m['akhir']['t'],
        'Saldo akhir tersedia' => $m['akhir']['s'],
    ], deskripsi_periode(['dari' => $f['dari'], 'sampai' => $f['sampai']]));
}


function laporan_mutasi(mysqli $con, array $f): array
{
    $jenisSql = $f['jenis'] && isset(LABEL_MUTASI[$f['jenis']]) ? $f['jenis'] : null;
    [$where, $tipe, $param] = sql_where([
        ['DATE(m.tanggal) >= ?', 's', $f['dari']],
        ['DATE(m.tanggal) <= ?', 's', $f['sampai']],
        ['m.jenis = ?', 's', $jenisSql],
        ['m.barang_id = ?', 'i', $f['barang_id']],
    ]);
    $rows = db_all($con,
        "SELECT m.tanggal, b.kode_barang, b.nama_barang, m.jenis, m.referensi, m.jumlah, m.perubahan_total,
                m.perubahan_tersedia, m.user_nama, m.keterangan
         FROM mutasi m JOIN barang b ON b.id = m.barang_id
         WHERE $where ORDER BY m.tanggal DESC, m.id DESC LIMIT 1000", $tipe, $param);
    foreach ($rows as &$r) {
        $r['jenis'] = LABEL_MUTASI[$r['jenis']] ?? $r['jenis'];
    }
    unset($r);
    $kolom = [
        ['Waktu', 'tanggal', 'waktu'], ['Kode', 'kode_barang', 'text'], ['Nama Barang', 'nama_barang', 'text'],
        ['Jenis', 'jenis', 'text'], ['Referensi', 'referensi', 'text'], ['Jumlah', 'jumlah', 'int'],
        ['Total +/-', 'perubahan_total', 'ttl'], ['Tersedia +/-', 'perubahan_tersedia', 'ttl'],
        ['Oleh', 'user_nama', 'text'], ['Keterangan', 'keterangan', 'text'],
    ];
    return laporan_meta('mutasi', $kolom, $rows, ['Jumlah catatan' => count($rows) . (count($rows) >= 1000 ? ' (dibatasi 1000)' : '')],
        deskripsi_periode(['dari' => $f['dari'], 'sampai' => $f['sampai']]));
}

/** Format satu sel laporan untuk tampilan HTML. */
function fmt_sel($nilai, string $fmt): string
{
    if ($nilai === null || $nilai === '') return '-';
    switch ($fmt) {
        case 'rupiah': return rupiah($nilai);
        case 'int':    return angka($nilai);
        case 'tgl':    return tgl_indo((string)$nilai);
        case 'waktu':  return waktu_indo((string)$nilai);
        case 'ttl':    $n = (int)$nilai; return $n > 0 ? '+' . angka($n) : ($n < 0 ? '−' . angka(abs($n)) : '0');
        default:       return (string)$nilai;
    }
}

/** Format sel untuk CSV (angka mentah, tanggal ISO). */
function fmt_csv($nilai, string $fmt): string
{
    if ($nilai === null) return '';
    if ($fmt === 'tgl' || $fmt === 'waktu') return (string)$nilai;
    if ($fmt === 'int' || $fmt === 'rupiah' || $fmt === 'ttl') return (string)(int)round((float)$nilai);
    return (string)$nilai;
}

/** Laporan nilai aset: penyusutan garis lurus per barang aset aktif. */
function laporan_aset(mysqli $con, array $f): array
{
    if (!can('nilai.lihat')) throw new AppException('Laporan nilai aset hanya untuk Administrator dan Kepala Sekolah.');
    [$where, $tipe, $param] = sql_where([
        ['b.aktif = 1', '', null],
        ['b.jenis_barang = ?', 's', 'aset'],
        ['b.kategori_id = ?', 'i', $f['kategori_id']],
        ['b.lokasi_id = ?', 'i', $f['lokasi_id']],
    ]);
    $barang = db_all($con,
        "SELECT b.*, k.nama AS kategori, COALESCE(l.nama, '-') AS lokasi
         FROM barang b JOIN kategori k ON k.id = b.kategori_id LEFT JOIN lokasi l ON l.id = b.lokasi_id
         WHERE $where ORDER BY k.nama, b.nama_barang", $tipe, $param);
    $rows = [];
    $perolehan = 0; $akum = 0; $buku = 0; $tahun = 0;
    foreach ($barang as $b) {
        $p = hitung_penyusutan($b);
        if (!$p['ok']) {
            $rows[] = ['kode_barang' => $b['kode_barang'], 'nama_barang' => $b['nama_barang'], 'kategori' => $b['kategori'],
                'lokasi' => $b['lokasi'], 'total' => (int)$b['stok_total'], 'perolehan' => null, 'per_tahun' => null,
                'akum' => null, 'nilai_buku' => null, 'sisa' => 'Belum diatur (masa manfaat / tanggal)', 'tgl_habis' => '-'];
            continue;
        }
        $perolehan += $p['perolehan_total']; $akum += $p['akum_total']; $buku += $p['nilai_buku_total']; $tahun += $p['per_tahun_total'];
        $rows[] = ['kode_barang' => $b['kode_barang'], 'nama_barang' => $b['nama_barang'], 'kategori' => $b['kategori'],
            'lokasi' => $b['lokasi'], 'total' => (int)$b['stok_total'], 'perolehan' => $p['perolehan_total'],
            'per_tahun' => $p['per_tahun_total'], 'akum' => $p['akum_total'], 'nilai_buku' => $p['nilai_buku_total'],
            'sisa' => label_sisa_bulan($p['sisa_bulan']), 'tgl_habis' => $p['tgl_habis']];
    }
    $kolom = [
        ['Kode', 'kode_barang', 'text'], ['Nama Barang', 'nama_barang', 'text'], ['Kategori', 'kategori', 'text'],
        ['Lokasi', 'lokasi', 'text'], ['Unit', 'total', 'int'], ['Nilai Perolehan', 'perolehan', 'rupiah'],
        ['Penyusutan / Tahun', 'per_tahun', 'rupiah'], ['Akumulasi', 'akum', 'rupiah'], ['Nilai Buku', 'nilai_buku', 'rupiah'],
        ['Sisa Masa Manfaat', 'sisa', 'text'], ['Habis Masa Manfaat', 'tgl_habis', 'text'],
    ];
    return laporan_meta('aset', $kolom, $rows, [
        'Nilai perolehan' => rupiah($perolehan),
        'Akumulasi penyusutan' => rupiah($akum),
        'Nilai buku' => rupiah($buku),
        'Penyusutan per tahun (perkiraan)' => rupiah($tahun),
    ], 'Perhitungan: garis lurus, dihitung sampai hari ini (perkiraan)');
}

/**
 * Riwayat satu barang, urut waktu, dengan saldo berjalan yang DIHITUNG dari perubahan
 * (tidak bergantung urutan penyimpanan). Juga mengembalikan saldo awal periode & akhir.
 */
function mutasi_berjalan(mysqli $con, int $barangId, ?string $dari = null, ?string $sampai = null): array
{
    $awal = ['t' => 0, 's' => 0];
    if ($dari) {
        $r = db_row($con,
            "SELECT COALESCE(SUM(perubahan_total),0) AS t, COALESCE(SUM(perubahan_tersedia),0) AS s
             FROM mutasi WHERE barang_id = ? AND DATE(tanggal) < ?", 'is', [$barangId, $dari]);
        $awal = ['t' => (int)$r['t'], 's' => (int)$r['s']];
    }
    [$where, $tipe, $par] = sql_where([
        ['m.barang_id = ?', 'i', $barangId],
        ['DATE(m.tanggal) >= ?', 's', $dari],
        ['DATE(m.tanggal) <= ?', 's', $sampai],
    ]);
    $rows = db_all($con, "SELECT m.* FROM mutasi m WHERE $where ORDER BY m.tanggal ASC, m.id ASC", $tipe, $par);
    $t = $awal['t']; $s = $awal['s'];
    foreach ($rows as &$r) {
        $t += (int)$r['perubahan_total'];
        $s += (int)$r['perubahan_tersedia'];
        $r['saldo_total'] = $t;
        $r['saldo_tersedia'] = $s;
    }
    unset($r);
    return ['awal' => $awal, 'rows' => $rows, 'akhir' => ['t' => $t, 's' => $s]];
}


/** Jumlah per ruangan: tiap barang di tiap ruangan, dengan dipinjam, rusak, dan tersedia. */
function laporan_lokasi(mysqli $con, array $f): array
{
    [$where, $tipe, $param] = sql_where([
        ['b.aktif = 1', '', null],
        ['sl.lokasi_id = ?', 'i', $f['lokasi_id']],
        ['sl.barang_id = ?', 'i', $f['barang_id']],
        ['b.kategori_id = ?', 'i', $f['kategori_id']],
    ]);
    $rows = db_all($con,
        "SELECT x.*, (x.stok - x.dipinjam - x.rusak) AS tersedia FROM (
            SELECT l.nama AS ruangan, b.kode_barang, b.nama_barang, b.satuan, k.nama AS kategori, sl.jumlah AS stok,
                (SELECT COALESCE(SUM(p.sisa),0) FROM peminjaman p WHERE p.barang_id = sl.barang_id AND p.lokasi_asal_id = sl.lokasi_id AND p.status = 'Dipinjam') AS dipinjam,
                (SELECT COALESCE(SUM(k2.jumlah),0) FROM kerusakan k2 WHERE k2.barang_id = sl.barang_id AND k2.lokasi_id = sl.lokasi_id AND k2.status NOT IN ('Selesai','Rusak Permanen')) AS rusak
            FROM stok_lokasi sl JOIN barang b ON b.id = sl.barang_id JOIN lokasi l ON l.id = sl.lokasi_id JOIN kategori k ON k.id = b.kategori_id
            WHERE $where ORDER BY l.nama, b.nama_barang) x", $tipe, $param);
    $kolom = [
        ['Ruangan', 'ruangan', 'text'], ['Kode', 'kode_barang', 'text'], ['Nama Barang', 'nama_barang', 'text'],
        ['Kategori', 'kategori', 'text'], ['Sat.', 'satuan', 'text'], ['Jumlah', 'stok', 'int'],
        ['Dipinjam', 'dipinjam', 'int'], ['Rusak', 'rusak', 'int'], ['Tersedia', 'tersedia', 'int'],
    ];
    return laporan_meta('lokasi', $kolom, $rows, [
        'Baris' => count($rows),
        'Total unit' => angka(array_sum(array_column($rows, 'stok'))),
        'Total tersedia' => angka(array_sum(array_column($rows, 'tersedia'))),
    ], 'Jumlah per ruangan (posisi saat ini)');
}

/** Berita acara penghapusan yang sudah disetujui. */
function laporan_penghapusan(mysqli $con, array $f): array
{
    [$where, $tipe, $param] = sql_where([
        ['p.status = ?', 's', 'Disetujui'],
        ['p.tanggal_usul >= ?', 's', $f['dari']],
        ['p.tanggal_usul <= ?', 's', $f['sampai']],
    ]);
    $rows = db_all($con,
        "SELECT p.nomor_ba, p.tanggal_setujui, b.kode_barang, b.nama_barang, l.nama AS ruangan, p.jumlah, p.alasan,
                p.nilai_buku_unit, (p.jumlah * p.nilai_buku_unit) AS nilai_total, p.disetujui_oleh
         FROM penghapusan p JOIN barang b ON b.id = p.barang_id JOIN lokasi l ON l.id = p.lokasi_id
         WHERE $where ORDER BY p.tanggal_setujui DESC, p.id DESC", $tipe, $param);
    $kolom = [
        ['No. BA', 'nomor_ba', 'text'], ['Tgl Setuju', 'tanggal_setujui', 'tgl'], ['Kode', 'kode_barang', 'text'],
        ['Nama Barang', 'nama_barang', 'text'], ['Ruangan', 'ruangan', 'text'], ['Jml', 'jumlah', 'int'],
        ['Alasan', 'alasan', 'text'], ['Nilai Buku/Unit', 'nilai_buku_unit', 'rupiah'], ['Nilai Total', 'nilai_total', 'rupiah'],
        ['Disetujui oleh', 'disetujui_oleh', 'text'],
    ];
    return laporan_meta('penghapusan', $kolom, $rows, [
        'Jumlah BA' => count($rows),
        'Total nilai buku dihapus' => rupiah(array_sum(array_column($rows, 'nilai_total'))),
    ], deskripsi_periode(['dari' => $f['dari'], 'sampai' => $f['sampai']]));
}
