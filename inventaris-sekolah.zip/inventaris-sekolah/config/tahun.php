<?php
// config/tahun.php — tahun ajaran, penguncian periode, dan tutup buku.
//
// Setelah tahun ajaran ditutup, semua transaksi dengan tanggal sampai akhir tahun itu
// tidak dapat dicatat, diubah, atau dibatalkan. Posisi aset dicatat sebagai snapshot.

function tahun_daftar(mysqli $con): array
{
    return db_all($con, "SELECT * FROM tahun_ajaran ORDER BY tanggal_mulai DESC");
}

function tahun_aktif(mysqli $con): ?array
{
    return db_row($con, "SELECT * FROM tahun_ajaran WHERE status = 'Aktif' ORDER BY tanggal_mulai DESC LIMIT 1");
}

/** Tahun ajaran yang sudah ditutup dan mencakup tanggal ini (null bila periode terbuka). */
function periode_terkunci(mysqli $con, string $tgl): ?array
{
    return db_row($con,
        "SELECT * FROM tahun_ajaran WHERE status = 'Ditutup' AND ? <= tanggal_selesai ORDER BY tanggal_selesai ASC LIMIT 1",
        's', [$tgl]);
}

/** Lempar error bila tanggal berada di periode yang sudah ditutup. */
function periode_cek(mysqli $con, string $tgl): void
{
    $t = periode_terkunci($con, $tgl);
    if ($t) {
        throw new AppException('Tanggal ' . tgl_indo($tgl) . ' berada dalam tahun ajaran ' . $t['nama']
            . ' yang sudah ditutup. Transaksi pada tanggal tersebut tidak dapat dicatat atau diubah.');
    }
}

/**
 * Tutup tahun ajaran: buat snapshot posisi setiap barang pada akhir periode,
 * kunci periodenya, dan sinkronkan pengaturan tahun ajaran ke tahun berikutnya.
 */
function tahun_tutup(mysqli $con, int $id): void
{
    if (!can('tahun.kelola')) {
        throw new AppException('Hanya Administrator yang dapat menutup tahun ajaran.');
    }
    db_tx($con, function (mysqli $con) use ($id) {
        $t = db_row($con, "SELECT * FROM tahun_ajaran WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$t) throw new AppException('Tahun ajaran tidak ditemukan.');
        if ($t['status'] !== 'Aktif') throw new AppException('Tahun ajaran ini sudah ditutup.');
        $akhir = $t['tanggal_selesai'];

        $masuk = (int)db_value($con, "SELECT COUNT(*) FROM barang_masuk WHERE status = 'Menunggu' AND tanggal <= ?", 's', [$akhir]);
        $hapus = (int)db_value($con, "SELECT COUNT(*) FROM penghapusan WHERE status = 'Diusulkan' AND tanggal_usul <= ?", 's', [$akhir]);
        $opname = (int)db_value($con, "SELECT COUNT(*) FROM stok_opname WHERE status = 'Draft' AND tanggal <= ?", 's', [$akhir]);
        if ($masuk + $hapus + $opname > 0) {
            throw new AppException("Selesaikan dulu pekerjaan yang masih terbuka pada periode ini: {$masuk} barang masuk menunggu persetujuan, {$hapus} usulan penghapusan, {$opname} sesi opname draft.");
        }

        $barang = db_all($con,
            "SELECT DISTINCT b.* FROM barang b JOIN mutasi m ON m.barang_id = b.id WHERE m.tanggal <= ?", 's', [$akhir . ' 23:59:59']);
        foreach ($barang as $b) {
            $pos = db_row($con,
                "SELECT COALESCE(SUM(perubahan_total),0) AS total, COALESCE(SUM(perubahan_tersedia),0) AS tersedia
                 FROM mutasi WHERE barang_id = ? AND tanggal <= ?", 'is', [(int)$b['id'], $akhir . ' 23:59:59']);
            $p = penyusutan_batch($con, $b, $akhir);
            db_exec($con,
                "INSERT INTO tutup_buku (tahun_ajaran_id, barang_id, stok_total, tersedia, perolehan, akumulasi, nilai_buku)
                 VALUES (?, ?, ?, ?, ?, ?, ?)",
                'iiiiddd',
                [$id, (int)$b['id'], (int)$pos['total'], (int)$pos['tersedia'],
                 $p['ok'] ? $p['perolehan_total'] : 0.0, $p['ok'] ? $p['akum_total'] : 0.0, $p['ok'] ? $p['nilai_buku_total'] : 0.0]);
        }

        db_exec($con, "UPDATE tahun_ajaran SET status = 'Ditutup', ditutup_pada = NOW(), ditutup_oleh = ? WHERE id = ?",
            'si', [user_nama(), $id]);

        // Tahun berikutnya: buat bila belum ada, lalu jadikan tahun berjalan
        $tahunMulai = (int)substr($t['tanggal_mulai'], 0, 4) + 1;
        $namaBaru = $tahunMulai . '/' . ($tahunMulai + 1);
        $ada = db_value($con, "SELECT id FROM tahun_ajaran WHERE nama = ?", 's', [$namaBaru]);
        if (!$ada) {
            db_exec($con, "INSERT INTO tahun_ajaran (nama, tanggal_mulai, tanggal_selesai, status) VALUES (?, ?, ?, 'Aktif')",
                'sss', [$namaBaru, $tahunMulai . '-07-15', ($tahunMulai + 1) . '-07-14']);
        } else {
            db_exec($con, "UPDATE tahun_ajaran SET status = 'Aktif' WHERE id = ?", 'i', [(int)$ada]);
        }
        db_exec($con, "INSERT INTO pengaturan (kunci, nilai) VALUES ('tahun_ajaran', ?) ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)",
            's', [$namaBaru]);
        log_aktivitas('UBAH', 'tahun', "Menutup tahun ajaran {$t['nama']}; tahun berjalan {$namaBaru}");
    });
}
