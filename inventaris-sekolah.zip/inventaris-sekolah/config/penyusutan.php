<?php
// config/penyusutan.php — penyusutan aset (garis lurus) dan estimasi pemakaian barang habis pakai.
//
// Aset tetap  : nilai yang disusutkan = harga − nilai residu, dibagi masa manfaat (bulan).
//               Dihitung per bulan penuh sejak tanggal perolehan. Semua unit dianggap diperoleh
//               pada tanggal yang sama (perkiraan; batch pembelian terpisah belum dilacak).
// Habis pakai: rata-rata pemakaian 90 hari terakhir (alasan "Pemakaian Operasional"),
//               sisa hari = unit tersedia ÷ rata-rata per hari.

/** Hitung penyusutan & nilai buku aset. $b = baris barang (butuh harga, masa, residu, tanggal, jumlah). */
function hitung_penyusutan(array $b, ?string $hari = null): array
{
    $harga = (float)$b['harga_perolehan'];
    $masa  = (int)($b['masa_manfaat_tahun'] ?? 0);
    $tgl   = !empty($b['tanggal_perolehan']) ? $b['tanggal_perolehan']
           : (!empty($b['tahun_perolehan']) ? $b['tahun_perolehan'] . '-01-01' : null);
    $stok  = (int)$b['stok_total'];
    if ($masa <= 0 || !$tgl || $harga <= 0) {
        return ['ok' => false];
    }
    $residu      = $harga * ((float)($b['nilai_residu_persen'] ?? 0) / 100);
    $dasar       = max(0.0, $harga - $residu);
    $bulanTotal  = $masa * 12;
    $perBulanUnit = $dasar / $bulanTotal;

    $awal = new DateTime($tgl);
    $kini = new DateTime($hari ?: 'today');
    $umur = 0;
    if ($kini > $awal) {
        $umur = (((int)$kini->format('Y') - (int)$awal->format('Y')) * 12)
              + ((int)$kini->format('n') - (int)$awal->format('n'));
        if ((int)$kini->format('j') < (int)$awal->format('j')) $umur--;   // hitung bulan penuh
        $umur = max(0, min($umur, $bulanTotal));
    }
    $sisa      = $bulanTotal - $umur;
    $akumUnit  = $perBulanUnit * $umur;
    $nbUnit    = max(0.0, $harga - $akumUnit);
    $tglHabis  = (clone $awal)->modify('+' . $masa . ' years');

    return [
        'ok'              => true,
        'masa_tahun'      => $masa,
        'per_tahun_unit'  => $perBulanUnit * 12,
        'umur_bulan'      => $umur,
        'sisa_bulan'      => $sisa,
        'persen_pakai'    => min(100, $umur / $bulanTotal * 100),
        'akum_unit'       => $akumUnit,
        'nilai_buku_unit' => $nbUnit,
        'per_tahun_total' => $perBulanUnit * 12 * $stok,
        'akum_total'      => $akumUnit * $stok,
        'nilai_buku_total'=> $nbUnit * $stok,
        'perolehan_total' => $harga * $stok,
        'tgl_perolehan'   => $awal->format('Y-m-d'),
        'tgl_habis'       => $tglHabis->format('Y-m-d'),
        'status'          => $sisa <= 0 ? 'habis' : ($sisa <= 12 ? 'segera' : 'berjalan'),
    ];
}

/** Label sisa masa manfaat, mis. "2 tahun 3 bulan". */
function label_sisa_bulan(int $bulan): string
{
    if ($bulan <= 0) return 'Habis masa manfaat';
    $t = intdiv($bulan, 12);
    $m = $bulan % 12;
    $out = ($t ? $t . ' tahun' : '') . ($t && $m ? ' ' : '') . ($m ? $m . ' bulan' : '');
    return $out;
}

/** Rata-rata pemakaian habis pakai per barang (90 hari terakhir). Map: barang_id => data. */
function estimasi_pemakaian_semua(mysqli $con): array
{
    $rows = db_all($con,
        "SELECT k.barang_id, SUM(k.jumlah) AS total, DATEDIFF(CURDATE(), MIN(k.tanggal)) + 1 AS span
         FROM barang_keluar k
         WHERE k.alasan = 'Pemakaian Operasional' AND k.tanggal >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
         GROUP BY k.barang_id");
    $out = [];
    foreach ($rows as $r) {
        $periode = max(7, min(90, (int)$r['span']));
        $out[(int)$r['barang_id']] = [
            'total'   => (int)$r['total'],
            'periode' => $periode,
            'rata'    => (int)$r['total'] / $periode,
        ];
    }
    return $out;
}

/** Perkiraan sisa pakai dari unit tersedia dan rata-rata pemakaian. */
function estimasi_sisa_pakai(?array $est, int $tersedia): array
{
    if (!$est || $est['rata'] <= 0) {
        return ['ok' => false, 'rata' => 0.0, 'status' => 'belum'];
    }
    $sisaHari = $tersedia <= 0 ? 0 : (int)floor($tersedia / $est['rata']);
    $status = $sisaHari <= SISA_PAKAI_DARURAT ? 'darurat' : ($sisaHari <= SISA_PAKAI_SEGERA ? 'segera' : 'aman');
    // Saran pesan: cukup untuk 60 hari pemakaian dikurangi unit tersedia
    $saranPesan = max(0, (int)ceil($est['rata'] * 60) - $tersedia);
    return [
        'ok'         => true,
        'rata'       => round($est['rata'], 2),
        'sisa_hari'  => $sisaHari,
        'tgl_habis'  => date('Y-m-d', strtotime('+' . $sisaHari . ' days')),
        'status'     => $status,
        'saran_pesan'=> $saranPesan,
    ];
}

/** Daftar aset aktif beserta penyusutannya. Filter opsional kategori/lokasi. */
function aset_daftar(mysqli $con, ?int $kategori = null, ?int $lokasi = null): array
{
    [$where, $tipe, $par] = sql_where([
        ['b.aktif = 1', '', null],
        ['b.jenis_barang = ?', 's', 'aset'],
        ['b.kategori_id = ?', 'i', $kategori],
        ['b.lokasi_id = ?', 'i', $lokasi],
    ]);
    $rows = db_all($con,
        "SELECT b.*, k.nama AS kategori, COALESCE(l.nama, '-') AS lokasi,
            (SELECT COALESCE(SUM(p.sisa),0) FROM peminjaman p WHERE p.barang_id = b.id AND p.status = 'Dipinjam') AS dipinjam,
            (SELECT COALESCE(SUM(x.jumlah),0) FROM kerusakan x WHERE x.barang_id = b.id AND x.status NOT IN ('Selesai','Rusak Permanen')) AS rusak
         FROM barang b JOIN kategori k ON k.id = b.kategori_id LEFT JOIN lokasi l ON l.id = b.lokasi_id
         WHERE $where ORDER BY k.nama, b.nama_barang", $tipe, $par);
    foreach ($rows as &$r) {
        $r['tersedia'] = (int)$r['stok_total'] - (int)$r['dipinjam'] - (int)$r['rusak'];
        $r['p'] = penyusutan_batch($con, $r);
    }
    unset($r);
    return $rows;
}

/** Ringkasan nilai aset (perolehan, akumulasi, nilai buku, penyusutan per tahun). */
function aset_ringkas(array $rows): array
{
    $t = ['perolehan' => 0.0, 'akum' => 0.0, 'buku' => 0.0, 'per_tahun' => 0.0, 'unit' => 0, 'habis' => 0, 'segera' => 0, 'belum' => 0];
    foreach ($rows as $r) {
        $t['unit'] += (int)$r['stok_total'];
        if (!$r['p']['ok']) { $t['belum']++; continue; }
        $t['perolehan'] += $r['p']['perolehan_total'];
        $t['akum']      += $r['p']['akum_total'];
        $t['buku']      += $r['p']['nilai_buku_total'];
        $t['per_tahun'] += $r['p']['per_tahun_total'];
        if ($r['p']['status'] === 'habis') $t['habis']++;
        if ($r['p']['status'] === 'segera') $t['segera']++;
    }
    return $t;
}


/**
 * Penyusutan per batch pembelian (FIFO) dari kartu persediaan.
 * Setiap penambahan jumlah menjadi batch dengan tanggal & harga sendiri. Setiap pengurangan
 * (keluar, hilang, penghapusan, rusak permanen) mengambil unit TERTUA lebih dulu.
 * $asOf: hitung posisi sampai tanggal tertentu (untuk tutup buku). Null = hari ini.
 */
function penyusutan_batch(mysqli $con, array $b, ?string $asOf = null): array
{
    $harga = (float)$b['harga_perolehan'];
    $masa  = (int)($b['masa_manfaat_tahun'] ?? 0);
    if ($masa <= 0 || $harga <= 0) {
        return ['ok' => false, 'units' => (int)($b['stok_total'] ?? 0)];
    }
    $residu    = (float)($b['nilai_residu_persen'] ?? 0) / 100;
    $masaBulan = $masa * 12;
    $akhir     = ($asOf ?: date('Y-m-d')) . ' 23:59:59';

    $hargaBm = [];
    foreach (db_all($con, "SELECT id, harga_satuan FROM barang_masuk WHERE barang_id = ?", 'i', [(int)$b['id']]) as $r) {
        $hargaBm[(int)$r['id']] = (float)$r['harga_satuan'];
    }
    $ev = db_all($con,
        "SELECT tanggal, perubahan_total, referensi FROM mutasi
         WHERE barang_id = ? AND perubahan_total <> 0 AND tanggal <= ? ORDER BY tanggal ASC, id ASC",
        'is', [(int)$b['id'], $akhir]);

    $batch = [];
    foreach ($ev as $e) {
        $q = (int)$e['perubahan_total'];
        if ($q > 0) {
            $hb = 0.0;
            if (preg_match('/^BM-(\d+)$/', (string)$e['referensi'], $mm)) {
                $hb = isset($hargaBm[(int)$mm[1]]) ? $hargaBm[(int)$mm[1]] : 0.0;
            }
            $batch[] = ['tgl' => substr((string)$e['tanggal'], 0, 10), 'waktu' => (string)$e['tanggal'], 'ref' => (string)$e['referensi'],
                        'sisa' => $q, 'harga' => $hb > 0 ? $hb : $harga];
        } else {
            $butuh = -$q;
            foreach ($batch as $i => $unused) {
                if ($butuh <= 0) break;
                if ($batch[$i]['sisa'] <= 0) continue;
                $ambil = min($butuh, $batch[$i]['sisa']);
                $batch[$i]['sisa'] -= $ambil;
                $butuh -= $ambil;
            }
        }
    }

    $kini = new DateTime(substr($akhir, 0, 10));
    $units = 0; $perolehan = 0.0; $akum = 0.0; $buku = 0.0; $perTahun = 0.0; $persen = 0.0;
    $sisaMin = null; $tglHabis = null; $tglPerolehan = null; $detail = [];
    foreach ($batch as $bt) {
        if ($bt['sisa'] <= 0) continue;
        $u = (int)$bt['sisa']; $h = (float)$bt['harga'];
        $perBulan = ($h * (1 - $residu)) / $masaBulan;
        $awal = new DateTime($bt['tgl']);
        $umur = 0;
        if ($kini > $awal) {
            $umur = (((int)$kini->format('Y') - (int)$awal->format('Y')) * 12) + ((int)$kini->format('n') - (int)$awal->format('n'));
            if ((int)$kini->format('j') < (int)$awal->format('j')) $umur--;
            $umur = max(0, min($umur, $masaBulan));
        }
        $sisaB  = $masaBulan - $umur;
        $akumU  = $perBulan * $umur;
        $nbU    = max(0.0, $h - $akumU);
        $tglH   = (clone $awal)->modify('+' . $masa . ' years')->format('Y-m-d');
        $units     += $u;
        $perolehan += $h * $u;
        $akum      += $akumU * $u;
        $buku      += $nbU * $u;
        $perTahun  += $perBulan * 12 * $u;
        $persen    += ($umur / $masaBulan * 100) * $u;
        $sisaMin    = $sisaMin === null ? $sisaB : min($sisaMin, $sisaB);
        if ($tglHabis === null || $tglH < $tglHabis) $tglHabis = $tglH;
        if ($tglPerolehan === null || $bt['tgl'] < $tglPerolehan) $tglPerolehan = $bt['tgl'];
        $detail[] = ['tgl' => $bt['tgl'], 'waktu' => $bt['waktu'], 'ref' => $bt['ref'], 'units' => $u, 'harga' => $h, 'umur_bulan' => $umur, 'sisa_bulan' => $sisaB,
            'akum_unit' => $akumU, 'nilai_buku_unit' => $nbU, 'tgl_habis' => $tglH, 'persen' => $umur / $masaBulan * 100];
    }

    if ($units === 0) {
        return ['ok' => true, 'masa_tahun' => $masa, 'units' => 0, 'perolehan_total' => 0.0, 'akum_total' => 0.0,
            'nilai_buku_total' => 0.0, 'per_tahun_total' => 0.0, 'per_tahun_unit' => 0.0, 'akum_unit' => 0.0,
            'nilai_buku_unit' => 0.0, 'persen_pakai' => 0.0, 'sisa_bulan' => $masaBulan, 'tgl_habis' => '-',
            'tgl_perolehan' => null, 'status' => 'berjalan', 'batches' => []];
    }
    $sisaMin = (int)$sisaMin;
    return [
        'ok' => true, 'masa_tahun' => $masa, 'units' => $units,
        'perolehan_total' => $perolehan, 'akum_total' => $akum, 'nilai_buku_total' => $buku,
        'per_tahun_total' => $perTahun, 'per_tahun_unit' => $perTahun / $units,
        'akum_unit' => $akum / $units, 'nilai_buku_unit' => $buku / $units,
        'persen_pakai' => $persen / $units, 'sisa_bulan' => $sisaMin, 'tgl_habis' => $tglHabis,
        'tgl_perolehan' => $tglPerolehan,
        'status' => $sisaMin <= 0 ? 'habis' : ($sisaMin <= 12 ? 'segera' : 'berjalan'),
        'batches' => $detail,
    ];
}

/** Nilai buku per unit saat ini (dipakai untuk berita acara penghapusan). */
function aset_nilai_buku_unit(mysqli $con, int $barangId): float
{
    $b = db_row($con, "SELECT * FROM barang WHERE id = ?", 'i', [$barangId]);
    if (!$b) return 0.0;
    $p = penyusutan_batch($con, $b);
    return $p['ok'] ? (float)$p['nilai_buku_unit'] : 0.0;
}
