<?php
// page.php - central lightweight router used in some installs (upgrade to include mutasi & barang_aktif)
$views = 'views/home.php';
$home = $master = $transaksi = $laporan = false;

if (isset($_GET['backup_app'])) {
    include('proses/backup_app.php');
} elseif (isset($_GET['backup_db'])) {
    include('proses/backup_db.php');
} elseif (isset($_GET['merek'])) {
    $master = $merek = true;
    $views = 'views/master/merek.php';
} elseif (isset($_GET['kategori'])) {
    $master = $kategori = true;
    $views = 'views/master/kategori.php';
} elseif (isset($_GET['barang'])) {
    $master = $barang = true;
    $views = 'views/master/barang.php';
} elseif (isset($_GET['pengguna'])) {
    $master = $pengguna = true;
    $views = 'views/master/pengguna.php';
} elseif (isset($_GET['barang_masuk'])) {
    $transaksi = $barang_masuk = true;
    $views = 'views/transaksi/barang_masuk.php';
} elseif (isset($_GET['barang_keluar'])) {
    $transaksi = $barang_keluar = true;
    $views = 'views/transaksi/barang_keluar.php';
} elseif (isset($_GET['barang_rusak'])) {
    $transaksi = $barang_rusak = true;
    $views = 'views/transaksi/barang_rusak.php';
} elseif (isset($_GET['barang_dipinjam'])) {
    $transaksi = $barang_dipinjam = true;
    $views = 'views/transaksi/barang_dipinjam.php';
} elseif (isset($_GET['mutasi'])) {
    $laporan = $mutasi = true;
    $views = 'views/mutasi.php';
} elseif (isset($_GET['barang_aktif'])) {
    $laporan = $barang_aktif = true;
    $views = 'views/barang_aktif.php';
} elseif (isset($_GET['lap_barang_masuk'])) {
    $laporan = $lap_barang_masuk = true;
    $views = 'views/laporan/lap_barang_masuk.php';
} elseif (isset($_GET['lap_barang_keluar'])) {
    $laporan = $lap_barang_keluar = true;
    $views = 'views/laporan/lap_barang_keluar.php';
} elseif (isset($_GET['lap_barang_rusak'])) {
    $laporan = $lap_barang_rusak = true;
    $views = 'views/laporan/lap_barang_rusak.php';
} elseif (isset($_GET['lap_barang_dipinjam'])) {
    $laporan = $lap_barang_dipinjam = true;
    $views = 'views/laporan/lap_barang_dipinjam.php';
} else {
    $home = true;
    $views = 'views/home.php';
}
?>