<style>
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600&display=swap');

    :root {
        --sidebar-w: 230px;
        --sidebar-w-collapsed: 70px;
        --bg-a: #03101d;
        --bg-b: #01070e;
        --accent: #00eaff;
        --muted: #cfeef8;
        --radius: 12px;
    }

    .sidebar {
        width: var(--sidebar-w);
        min-width: var(--sidebar-w);
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        padding: 12px 10px;
        display: flex;
        flex-direction: column;
        gap: 8px;
        background: linear-gradient(180deg, var(--bg-a), var(--bg-b));
        border-right: 1px solid rgba(0,234,255,0.07);
        color: var(--muted);
        transition: width .25s ease;
        z-index: 1200;
        overflow: hidden;
    }

    .sidebar.collapsed {
        width: var(--sidebar-w-collapsed);
        min-width: var(--sidebar-w-collapsed);
    }

    .sidebar-brand {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 4px;
        font-family: 'Orbitron', sans-serif;
        text-decoration: none;
        color: var(--muted);
    }

    .sidebar-brand .fa-school {
        font-size: 22px;
        color: var(--accent);
    }

    .sidebar-brand-text sup {
        font-size: 10px;
        color: #fff;
    }

    .sidebar-divider {
        height: 1px;
        border: none;
        background: rgba(255,255,255,0.08);
        margin: 6px 0;
    }

    .sidebar-heading {
        font-family: 'Orbitron';
        font-size: 10px;
        letter-spacing: 1.4px;
        margin: 5px 4px;
        color: var(--accent);
    }

    .navbar-nav {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .nav-item {
        width: 100%;
    }

    .sidebar .nav-link {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 12px;
        border-radius: var(--radius);
        color: var(--muted);
        text-decoration: none;
        font-size: 14px;
        background: rgba(255,255,255,0.02);
        border: 1px solid rgba(255,255,255,0.03);
        transition: .22s ease;
        white-space: nowrap;
    }

    .sidebar .nav-link:hover,
    .nav-item.active > .nav-link {
        background: rgba(0,255,255,0.06);
        border: 1px solid rgba(0,255,255,0.18);
        box-shadow: 0 0 18px rgba(0,255,255,0.15);
        transform: translateX(4px);
        color: var(--accent) !important;
    }

    .nav-link i {
        width: 22px;
        font-size: 16px;
        text-align: center;
        transition: .22s;
    }

    .sidebar .nav-link:hover i,
    .nav-item.active i {
        transform: translateY(-2px) scale(1.08);
        color: var(--accent);
    }

    .collapse-inner {
        display: flex;
        flex-direction: column;
        gap: 4px;
        background: rgba(255,255,255,0.03);
        border-radius: 8px;
        margin: 4px 0 6px 0;
        padding: 6px;
    }

    .collapse-inner a {
        padding: 7px 8px;
        border-radius: 8px;
        transition: .18s;
        color: #e8f8ff;
        font-size: 13px;
    }

    .collapse-inner a:hover,
    .collapse-inner a.active {
        background: rgba(0,234,255,0.1);
        transform: translateX(3px);
        color: var(--accent) !important;
    }
</style>


<ul class="navbar-nav sidebar sidebar-dark accordion" id="accordionSidebar">

    <a class="sidebar-brand" href="<?=base_url();?>">
        <i class="fas fa-school"></i>
        <div class="sidebar-brand-text">
            INVENTARIS <br>
            <sup>UPT SMP NEGERI 8 MEDAN</sup>
        </div>
    </a>

    <hr class="sidebar-divider"/>

    <li class="nav-item <?=isset($home)?'active':'';?>">
        <a class="nav-link" href="<?=base_url();?>">
            <i class="fas fa-home"></i> <span>Beranda</span>
        </a>
    </li>

    <hr class="sidebar-divider"/>

    <div class="sidebar-heading">MENU</div>

    <?php if($_SESSION['level']=='admin'): ?>

    <li class="nav-item <?=isset($master)?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#master">
            <i class="fas fa-boxes"></i> <span>Master Data</span>
        </a>
        <div id="master" class="collapse">
            <div class="collapse-inner">
                <a class="<?=isset($merek)?'active':'';?>" href="?merek">Merek</a>
                <a class="<?=isset($kategori)?'active':'';?>" href="?kategori">Kategori</a>
                <a class="<?=isset($barang)?'active':'';?>" href="?barang">Barang</a>
                <a class="<?=isset($pengguna)?'active':'';?>" href="?pengguna">Pengguna</a>
            </div>
        </div>
    </li>

    <li class="nav-item <?=isset($transaksi)?'active':'';?>">
        <a class="nav-link collapsed" data-toggle="collapse" data-target="#transaksi">
            <i class="fas fa-exchange-alt"></i> <span>Transaksi</span>
        </a>
             <div id="transaksi" class="collapse">

            <div class="collapse-inner">
                <a class="<?=isset($barang_masuk)?'active':'';?>" href="?barang_masuk">Barang Masuk</a>
                <!-- <a class="<?=isset($barang_keluar)?'active':'';?>" href="?barang_keluar">Barang Keluar</a> -->
                <a class="<?=isset($barang_rusak)?'active':'';?>" href="?barang_rusak">Barang Rusak</a>
                <a class="<?=isset($barang_dipinjam)?'active':'';?>" href="?barang_dipinjam">Barang Dipinjam</a>
            </div>
        </div>
    </li>

    <li class="nav-item <?=isset($laporan)?'active':'';?>">
        <a class="nav-link collapsed" data-toggle="collapse" data-target="#laporan">
            <i class="fas fa-file-alt"></i> <span>Laporan</span>
        </a>
            <div id="laporan" class="collapse">
            <div class="collapse-inner">
                <a class="<?=isset($lap_barang_masuk)?'active':'';?>" href="?lap_barang_masuk">Barang Masuk</a>
                <!-- <a class="<?=isset($lap_barang_keluar)?'active':'';?>" href="?lap_barang_keluar">Barang Keluar</a> -->
                <a class="<?=isset($lap_barang_rusak)?'active':'';?>" href="?lap_barang_rusak">Barang Rusak</a>
                <a class="<?=isset($lap_barang_dipinjam)?'active':'';?>" href="?lap_barang_dipinjam">Barang Dipinjam</a>
                <a class="<?=isset($barang_aktif)?'active':'';?>" href="?barang_aktif">Stok Barang Aktif</a>
                <a href="<?=base_url();?>process/lap_stok_barang.php" target="_blank">Stok Barang (Cetak)</a>
            </div>
        </div>
    </li>

    <li class="nav-item <?=isset($mutasi)?'active':'';?>">
        <a class="nav-link" href="?mutasi">
            <i class="fas fa-random"></i> <span>Mutasi Barang</span>
        </a>
    </li>

    <?php endif; ?>
</ul>


<script>
(function(){
    let sb = document.querySelector('.sidebar');
    if(!sb) return;
    let main = document.querySelector('#content') || document.body;
    function apply(){
        let w = sb.getBoundingClientRect().width + 'px';
        if(main === document.body) document.body.style.paddingLeft = w;
        else main.style.marginLeft = w;
    }
    apply();
    new MutationObserver(apply).observe(sb,{attributes:true});
    window.addEventListener('resize',()=>setTimeout(apply,200));
})();
</script>


