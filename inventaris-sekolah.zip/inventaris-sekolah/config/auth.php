<?php
// config/auth.php — login, sesi, dan hak akses berbasis role.

const ROLE_LABEL = [
    'admin'          => 'Administrator',
    'operator'       => 'Operator',
    'kepala_sekolah' => 'Kepala Sekolah',
];

/** Peta izin per role. '*' berarti semua izin. */
function hak_akses_map(): array
{
    $umum = ['dashboard', 'master.lihat', 'transaksi.lihat', 'laporan.lihat', 'akun'];
    return [
        'admin' => ['*'],
        'operator' => array_merge($umum, [
            'barang.kelola', 'transaksi.input', 'kerusakan.proses', 'opname.input',
        ]),
        'kepala_sekolah' => array_merge($umum, [
            'kerusakan.setujui', 'opname.finalisasi', 'log.lihat', 'nilai.lihat', 'masuk.setujui', 'penghapusan.setujui',
        ]),
    ];
}

function auth_user(): ?array
{
    return $_SESSION['auth'] ?? null;
}

function user_nama(): string
{
    return $_SESSION['auth']['nama'] ?? 'Sistem';
}

function user_id(): ?int
{
    return isset($_SESSION['auth']['id']) ? (int)$_SESSION['auth']['id'] : null;
}

function user_role(): string
{
    return $_SESSION['auth']['role'] ?? '';
}

function can(string $perm): bool
{
    $role = user_role();
    $map  = hak_akses_map();
    if (!isset($map[$role])) return false;
    return in_array('*', $map[$role], true) || in_array($perm, $map[$role], true);
}

/** Hentikan akses bila tidak punya izin. */
function require_perm(string $perm): void
{
    if (!can($perm)) {
        http_response_code(403);
        include __DIR__ . '/../layout/forbidden.php';
        exit;
    }
}

/** Wajib login. Juga memvalidasi ulang akun ke database (aktif & role terbaru). */
function require_login(): void
{
    $auth = auth_user();
    if ($auth === null) {
        $_SESSION['next'] = $_SERVER['REQUEST_URI'] ?? '';
        redirect(base_url() . 'login.php');
    }

    if (time() - (int)($auth['aktivitas'] ?? 0) > SESSION_IDLE_MENIT * 60) {
        session_unset();
        session_destroy();
        redirect(base_url() . 'login.php?timeout=1');
    }

    // Validasi ulang akun: bila dinonaktifkan/dihapus, sesi langsung dicabut.
    $row = db_row(db(), "SELECT id, nama, role, aktif FROM users WHERE id = ?", 'i', [(int)$auth['id']]);
    if ($row === null || (int)$row['aktif'] !== 1) {
        session_unset();
        session_destroy();
        redirect(base_url() . 'login.php?akun=nonaktif');
    }

    $_SESSION['auth']['nama']      = $row['nama'];
    $_SESSION['auth']['role']      = $row['role'];
    $_SESSION['auth']['aktivitas'] = time();
}

/** Proses login. Melempar AppException bila gagal. */
function login_proses(string $username, string $password): void
{
    $con = db();
    $ip  = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    // Bersihkan kunci yang sudah kedaluwarsa agar tabel tidak menumpuk.
    db_exec($con, "DELETE FROM login_throttle WHERE terkunci_sampai IS NOT NULL AND terkunci_sampai < NOW()");

    // Cek kunci sementara akibat terlalu banyak percobaan gagal.
    $th = db_row($con, "SELECT gagal, terkunci_sampai FROM login_throttle WHERE ip = ?", 's', [$ip]);
    if ($th && $th['terkunci_sampai'] && strtotime($th['terkunci_sampai']) > time()) {
        $sisa = (int)ceil((strtotime($th['terkunci_sampai']) - time()) / 60);
        throw new AppException("Terlalu banyak percobaan login. Coba lagi dalam {$sisa} menit.");
    }

    $user = db_row($con, "SELECT * FROM users WHERE username = ?", 's', [$username]);
    // Tetap jalankan password_verify agar waktu respons tidak membocorkan keberadaan username.
    $hashCek = $user['password'] ?? '$2y$10$abcdefghijklmnopqrstuuKs1Y8T1sGQvdc7sYp7zYQf8WmH0ZB9S';
    $cocok   = password_verify($password, $hashCek);

    if (!$user || !$cocok || (int)$user['aktif'] !== 1) {
        $gagal = ($th ? (int)$th['gagal'] : 0) + 1;
        $kunci = null;
        if ($gagal >= LOGIN_MAX_GAGAL) {
            $kunci = date('Y-m-d H:i:s', time() + LOGIN_KUNCI_MENIT * 60);
            $gagal = 0;
        }
        db_exec($con, "INSERT INTO login_throttle (ip, gagal, terkunci_sampai) VALUES (?, ?, ?)
                       ON DUPLICATE KEY UPDATE gagal = VALUES(gagal), terkunci_sampai = VALUES(terkunci_sampai)",
                'sis', [$ip, $gagal, $kunci]);
        throw new AppException('Username atau password salah.');
    }

    db_exec($con, "DELETE FROM login_throttle WHERE ip = ?", 's', [$ip]);

    // Cegah session fixation
    session_regenerate_id(true);
    $_SESSION['auth'] = [
        'id'        => (int)$user['id'],
        'username'  => $user['username'],
        'nama'      => $user['nama'],
        'role'      => $user['role'],
        'login_at'  => time(),
        'aktivitas' => time(),
    ];
    db_exec($con, "UPDATE users SET last_login = NOW() WHERE id = ?", 'i', [(int)$user['id']]);
    log_aktivitas('LOGIN', 'auth', 'Masuk ke aplikasi');
}

function logout_proses(): void
{
    if (auth_user()) {
        log_aktivitas('LOGOUT', 'auth', 'Keluar dari aplikasi');
    }
    session_unset();
    session_destroy();
}

/** Alamat tujuan setelah login (hanya path lokal yang aman). */
function login_tujuan(): string
{
    $next = $_SESSION['next'] ?? '';
    unset($_SESSION['next']);
    $base = base_url();
    if (is_string($next) && $next !== '' && strpos($next, $base) === 0 && strpos($next, '//') === false) {
        return $next;
    }
    return url('dashboard');
}
