<?php
// config/function.php
// Utility functions used across the app

if (session_status() === PHP_SESSION_NONE) {
    // Do not start session here if the including script already starts it;
    // but safe to start if not started.
    session_start();
}

if (!function_exists('session_timeout')) {
    function session_timeout()
    {
        // lama waktu 30 menit = 1800 detik
        if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
            session_unset();
            session_destroy();
            // gunakan base_url() untuk redirect
            header('Location: ' . base_url() . 'login.php');
            exit;
        }
        $_SESSION['LAST_ACTIVITY'] = time();
    }
}

if (!function_exists('delMask')) {
    function delMask($str)
    {
        return (int) str_replace('.', '', $str);
    }
}

if (!function_exists('hakAkses')) {
    function hakAkses(array $allowed)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $akses = isset($_SESSION['level']) ? $_SESSION['level'] : null;
        if (!in_array($akses, $allowed)) {
            // redirect to home jika tidak punya akses
            header('Location: ' . base_url());
            exit;
        }
    }
}

if (!function_exists('bulan')) {
    function bulan($bln)
    {
        $bulan = [
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        return isset($bulan[(int)$bln]) ? $bulan[(int)$bln] : null;
    }
}

if (!function_exists('tahun')) {
    function tahun()
    {
        $start = 2020;
        $end = (int)date('Y') + 1;
        $arr = [];
        for ($y = $start; $y <= $end; $y++) $arr[] = (string)$y;
        return $arr;
    }
}

if (!function_exists('list_merek')) {
    function list_merek()
    {
        $connPath = __DIR__ . '/conn.php';
        if (file_exists($connPath)) include $connPath;
        else return '';

        global $con;
        $query = mysqli_query($con, "SELECT * FROM merek ORDER BY nama_merek ASC");
        $opt = "";
        if ($query) {
            while ($row = mysqli_fetch_assoc($query)) {
                $opt .= "<option value=\"" . htmlspecialchars($row['idmerek']) . "\">" . htmlspecialchars($row['nama_merek']) . "</option>";
            }
        }
        return $opt;
    }
}

if (!function_exists('list_kategori')) {
    function list_kategori()
    {
        $connPath = __DIR__ . '/conn.php';
        if (file_exists($connPath)) include $connPath;
        else return '';

        global $con;
        $query = mysqli_query($con, "SELECT * FROM kategori ORDER BY nama_kategori ASC");
        $opt = "";
        if ($query) {
            while ($row = mysqli_fetch_assoc($query)) {
                $opt .= "<option value=\"" . htmlspecialchars($row['idkategori']) . "\">" . htmlspecialchars($row['nama_kategori']) . "</option>";
            }
        }
        return $opt;
    }
}

if (!function_exists('list_barang')) {
    function list_barang()
    {
        $connPath = __DIR__ . '/conn.php';
        if (file_exists($connPath)) include $connPath;
        else return '';

        global $con;
        $kategori = mysqli_query($con, "SELECT * FROM kategori ORDER BY nama_kategori ASC");
        $opt = "";
        if ($kategori) {
            while ($row = mysqli_fetch_assoc($kategori)) {
                $barang = mysqli_query($con, "SELECT x.*, x1.nama_merek FROM barang x JOIN merek x1 ON x1.idmerek=x.merek_id WHERE kategori_id='" . (int)$row['idkategori'] . "' ORDER BY nama_barang ASC");
                $opt .= "<optgroup label=\"" . htmlspecialchars($row['nama_kategori']) . " | " . htmlspecialchars($row['keterangan']) . "\">";
                if ($barang) {
                    while ($row2 = mysqli_fetch_assoc($barang)) {
                        $opt .= "<option value=\"" . htmlspecialchars($row2['idbarang']) . "\">" . htmlspecialchars($row2['nama_barang']) . " - " . htmlspecialchars($row2['nama_merek']) . "</option>";
                    }
                }
                $opt .= "</optgroup>";
            }
        }
        return $opt;
    }
}

if (!function_exists('encrypt')) {
    function encrypt($str)
    {
        return base64_encode($str);
    }
}

if (!function_exists('decrypt')) {
    function decrypt($str)
    {
        return base64_decode($str);
    }
}

if (!function_exists('base_url')) {
    function base_url()
    {
        $base_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
        $base_url .= "://" . $_SERVER['HTTP_HOST'];
        // gunakan path script name untuk konsistensi
        $script = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/';
        $base_url .= $script;
        return $base_url;
    }
}

if (!function_exists('list_barang_stok')) {
    function list_barang_stok()
    {
        $connPath = __DIR__ . '/conn.php';
        if (file_exists($connPath)) include $connPath;
        else return '';

        global $con;
        $kategori = mysqli_query($con, "SELECT * FROM kategori ORDER BY nama_kategori ASC");
        $opt = "";
        if ($kategori) {
            while ($row = mysqli_fetch_assoc($kategori)) {
                $barang = mysqli_query($con, "
                    SELECT x.*, x1.nama_merek 
                    FROM barang x 
                    JOIN merek x1 ON x1.idmerek=x.merek_id 
                    WHERE kategori_id='" . (int)$row['idkategori'] . "' 
                    AND stok > 0
                    ORDER BY nama_barang ASC
                ");
                
                if ($barang && mysqli_num_rows($barang) > 0) {
                    $opt .= "<optgroup label=\"" . htmlspecialchars($row['nama_kategori']) . " | " . htmlspecialchars($row['keterangan']) . "\">";
                    while ($row2 = mysqli_fetch_assoc($barang)) {
                        $opt .= "<option value=\"" . htmlspecialchars($row2['idbarang']) . "\">";
                        $opt .= htmlspecialchars($row2['kode_barang']) . " - " . htmlspecialchars($row2['nama_barang']);
                        $opt .= " [" . htmlspecialchars($row2['nama_merek']) . "]";
                        $opt .= " (Stok: " . (int)$row2['stok'] . ")";
                        $opt .= "</option>";
                    }
                    $opt .= "</optgroup>";
                }
            }
        }
        return $opt;
    }
}
?>