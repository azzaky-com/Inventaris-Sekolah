<?php
// config/transaksi.php — layanan transaksi (aturan bisnis).
// Semua perubahan jumlah berjalan dalam transaksi DB. Periode yang sudah ditutup dikunci.

// ---------------------------------------------------------------------------
// Barang masuk
// ---------------------------------------------------------------------------

function ambang_persetujuan_masuk(mysqli $con): float
{
    $v = db_value($con, "SELECT nilai FROM pengaturan WHERE kunci = 'ambang_persetujuan_masuk'");
    return $v === null ? 10000000.0 : (float)$v;
}

/** Menerapkan barang masuk yang sudah disetujui ke total unit, ruangan, dan kartu persediaan. */
function masuk_terapkan(mysqli $con, int $id): void
{
    $m = db_row($con, "SELECT * FROM barang_masuk WHERE id = ?", 'i', [$id]);
    $barangId = (int)$m['barang_id'];
    db_value($con, "SELECT id FROM barang WHERE id = ? FOR UPDATE", 'i', [$barangId]);
    ubah_stok_total($con, $barangId, (int)$m['jumlah']);
    stok_lokasi_ubah($con, $barangId, (int)$m['lokasi_id'], (int)$m['jumlah']);
    if ((float)$m['harga_satuan'] > 0) {
        db_exec($con, "UPDATE barang SET harga_perolehan = ? WHERE id = ?", 'di', [$m['harga_satuan'], $barangId]);
    }
    catat_mutasi($con, $barangId, 'masuk', (int)$m['jumlah'], (int)$m['jumlah'], 'BM-' . $id,
        $m['keterangan'] !== '' ? $m['keterangan'] : 'Barang masuk', $m['tanggal'] . ' ' . date('H:i:s'));
}

/** Catat barang masuk. Nilai di atas ambang menunggu persetujuan Kepala Sekolah (jumlah belum bertambah). */
function transaksi_masuk_tambah(mysqli $con, array $d): int
{
    return db_tx($con, function (mysqli $con) use ($d) {
        periode_cek($con, $d['tanggal']);
        $b = db_row($con, "SELECT id, aktif, lokasi_id FROM barang WHERE id = ? FOR UPDATE", 'i', [$d['barang_id']]);
        if (!$b) throw new AppException('Barang tidak ditemukan.');
        if ((int)$b['aktif'] !== 1) throw new AppException('Barang sudah diarsipkan dan tidak dapat ditambah jumlahnya.');
        $lokasi = !empty($d['lokasi_id']) ? (int)$d['lokasi_id'] : (int)$b['lokasi_id'];
        if (!$lokasi) throw new AppException('Pilih ruangan tempat barang disimpan.');
        $nilai = (float)$d['jumlah'] * (float)$d['harga_satuan'];
        // Saldo awal (pendataan inventaris yang sudah ada) tidak perlu persetujuan; pembelian baru perlu.
        $perluSetuju = empty($d['saldo_awal']) && $nilai > 0 && $nilai >= ambang_persetujuan_masuk($con);
        $status = $perluSetuju ? 'Menunggu' : 'Disetujui';

        $id = db_exec($con,
            "INSERT INTO barang_masuk (tanggal, barang_id, lokasi_id, jumlah, harga_satuan, sumber_dana, nomor_dokumen, keterangan, status, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            'siiidssssi',
            [$d['tanggal'], $d['barang_id'], $lokasi, $d['jumlah'], $d['harga_satuan'], $d['sumber_dana'],
             $d['nomor_dokumen'], $d['keterangan'], $status, user_id()])['insert_id'];
        if ($status === 'Disetujui') {
            masuk_terapkan($con, $id);
        }
        log_aktivitas('TAMBAH', 'barang_masuk', "Barang masuk BM-{$id}: {$d['jumlah']} unit" . ($status === 'Menunggu' ? ' (menunggu persetujuan)' : ''));
        return $id;
    });
}

function transaksi_masuk_setujui(mysqli $con, int $id): void
{
    if (!can('masuk.setujui')) throw new AppException('Persetujuan barang masuk hanya untuk Kepala Sekolah atau Administrator.');
    db_tx($con, function (mysqli $con) use ($id) {
        $m = db_row($con, "SELECT * FROM barang_masuk WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$m) throw new AppException('Data barang masuk tidak ditemukan.');
        if ($m['status'] !== 'Menunggu') throw new AppException('Transaksi ini tidak sedang menunggu persetujuan.');
        periode_cek($con, $m['tanggal']);
        db_exec($con, "UPDATE barang_masuk SET status = 'Disetujui', disetujui_oleh = ?, tanggal_setujui = NOW() WHERE id = ?",
            'si', [user_nama(), $id]);
        masuk_terapkan($con, $id);
        log_aktivitas('UBAH', 'barang_masuk', "Menyetujui barang masuk BM-{$id}");
    });
}

function transaksi_masuk_tolak(mysqli $con, int $id, string $alasan): void
{
    if (!can('masuk.setujui')) throw new AppException('Persetujuan barang masuk hanya untuk Kepala Sekolah atau Administrator.');
    $m = db_row($con, "SELECT status, tanggal FROM barang_masuk WHERE id = ?", 'i', [$id]);
    if (!$m || $m['status'] !== 'Menunggu') throw new AppException('Transaksi ini tidak sedang menunggu persetujuan.');
    periode_cek($con, $m['tanggal']);
    db_exec($con, "UPDATE barang_masuk SET status = 'Ditolak', disetujui_oleh = ?, tanggal_setujui = NOW(), keterangan = ? WHERE id = ?",
        'ssi', [user_nama(), 'Ditolak: ' . $alasan, $id]);
    log_aktivitas('UBAH', 'barang_masuk', "Menolak barang masuk BM-{$id}");
}

function transaksi_masuk_ubah(mysqli $con, int $id, array $d): void
{
    db_tx($con, function (mysqli $con) use ($id, $d) {
        $old = db_row($con, "SELECT * FROM barang_masuk WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$old) throw new AppException('Data barang masuk tidak ditemukan.');
        if ($old['status'] === 'Ditolak') throw new AppException('Transaksi yang sudah ditolak tidak dapat diubah.');
        periode_cek($con, $old['tanggal']);
        periode_cek($con, $d['tanggal']);
        $barangId = (int)$old['barang_id'];
        db_value($con, "SELECT id FROM barang WHERE id = ? FOR UPDATE", 'i', [$barangId]);

        $delta = (int)$d['jumlah'] - (int)$old['jumlah'];
        db_exec($con,
            "UPDATE barang_masuk SET tanggal = ?, jumlah = ?, harga_satuan = ?, sumber_dana = ?, nomor_dokumen = ?, keterangan = ? WHERE id = ?",
            'sidsssi', [$d['tanggal'], $d['jumlah'], $d['harga_satuan'], $d['sumber_dana'], $d['nomor_dokumen'], $d['keterangan'], $id]);
        if ($old['status'] === 'Disetujui' && $delta !== 0) {
            ubah_stok_total($con, $barangId, $delta);
            stok_lokasi_ubah($con, $barangId, (int)$old['lokasi_id'], $delta);
            catat_mutasi($con, $barangId, 'koreksi', abs($delta), $delta, 'BM-' . $id,
                "Koreksi jumlah barang masuk dari {$old['jumlah']} menjadi {$d['jumlah']}");
        }
        log_aktivitas('UBAH', 'barang_masuk', "Mengubah barang masuk BM-{$id}");
    });
}

/** Batalkan barang masuk. Transaksi yang sudah disetujui akan mengurangi jumlah sebagai koreksi. */
function transaksi_masuk_hapus(mysqli $con, int $id): void
{
    db_tx($con, function (mysqli $con) use ($id) {
        $old = db_row($con, "SELECT * FROM barang_masuk WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$old) throw new AppException('Data barang masuk tidak ditemukan.');
        periode_cek($con, $old['tanggal']);
        $barangId = (int)$old['barang_id'];
        if ($old['status'] === 'Disetujui') {
            db_value($con, "SELECT id FROM barang WHERE id = ? FOR UPDATE", 'i', [$barangId]);
            ubah_stok_total($con, $barangId, -(int)$old['jumlah']);
            stok_lokasi_ubah($con, $barangId, (int)$old['lokasi_id'], -(int)$old['jumlah']);
            catat_mutasi($con, $barangId, 'koreksi', (int)$old['jumlah'], -(int)$old['jumlah'], 'BM-' . $id,
                'Pembatalan transaksi barang masuk');
        }
        db_exec($con, "DELETE FROM barang_masuk WHERE id = ?", 'i', [$id]);
        log_aktivitas('HAPUS', 'barang_masuk', "Membatalkan barang masuk BM-{$id}");
    });
}

// ---------------------------------------------------------------------------
// Barang keluar / pemakaian
// ---------------------------------------------------------------------------

function transaksi_keluar_tambah(mysqli $con, array $d): int
{
    return db_tx($con, function (mysqli $con) use ($d) {
        periode_cek($con, $d['tanggal']);
        $b = db_row($con, "SELECT id, lokasi_id FROM barang WHERE id = ? FOR UPDATE", 'i', [$d['barang_id']]);
        if (!$b) throw new AppException('Barang tidak ditemukan.');
        $lokasi = !empty($d['lokasi_id']) ? (int)$d['lokasi_id'] : (int)$b['lokasi_id'];
        if (!$lokasi) throw new AppException('Pilih ruangan asal barang.');
        lokasi_cek_tersedia($con, (int)$d['barang_id'], $lokasi, (int)$d['jumlah']);
        $id = db_exec($con,
            "INSERT INTO barang_keluar (tanggal, barang_id, lokasi_id, jumlah, alasan, penerima, keterangan, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            'siiisssi', [$d['tanggal'], $d['barang_id'], $lokasi, $d['jumlah'], $d['alasan'], $d['penerima'], $d['keterangan'], user_id()])['insert_id'];
        ubah_stok_total($con, (int)$d['barang_id'], -(int)$d['jumlah']);
        stok_lokasi_ubah($con, (int)$d['barang_id'], $lokasi, -(int)$d['jumlah']);
        catat_mutasi($con, (int)$d['barang_id'], 'keluar', (int)$d['jumlah'], -(int)$d['jumlah'],
            'BK-' . $id, $d['alasan'] . ($d['penerima'] !== '' ? ' — ' . $d['penerima'] : ''), $d['tanggal'] . ' ' . date('H:i:s'));
        log_aktivitas('TAMBAH', 'barang_keluar', "Pemakaian/keluar BK-{$id}: {$d['jumlah']} unit");
        return $id;
    });
}

function transaksi_keluar_hapus(mysqli $con, int $id): void
{
    db_tx($con, function (mysqli $con) use ($id) {
        $old = db_row($con, "SELECT * FROM barang_keluar WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$old) throw new AppException('Data barang keluar tidak ditemukan.');
        periode_cek($con, $old['tanggal']);
        $barangId = (int)$old['barang_id'];
        db_value($con, "SELECT id FROM barang WHERE id = ? FOR UPDATE", 'i', [$barangId]);
        ubah_stok_total($con, $barangId, (int)$old['jumlah']);
        stok_lokasi_ubah($con, $barangId, (int)$old['lokasi_id'], (int)$old['jumlah']);
        catat_mutasi($con, $barangId, 'koreksi', (int)$old['jumlah'], (int)$old['jumlah'], 'BK-' . $id,
            'Pembatalan transaksi barang keluar');
        db_exec($con, "DELETE FROM barang_keluar WHERE id = ?", 'i', [$id]);
        log_aktivitas('HAPUS', 'barang_keluar', "Membatalkan barang keluar BK-{$id}");
    });
}

// ---------------------------------------------------------------------------
// Pemindahan antar ruangan (total unit tidak berubah)
// ---------------------------------------------------------------------------

function pemindahan_tambah(mysqli $con, array $d): int
{
    if ((int)$d['lokasi_asal_id'] === (int)$d['lokasi_tujuan_id']) {
        throw new AppException('Ruangan asal dan tujuan harus berbeda.');
    }
    return db_tx($con, function (mysqli $con) use ($d) {
        periode_cek($con, $d['tanggal']);
        $b = db_row($con, "SELECT id, aktif FROM barang WHERE id = ? FOR UPDATE", 'i', [$d['barang_id']]);
        if (!$b || (int)$b['aktif'] !== 1) throw new AppException('Barang tidak ditemukan atau sudah diarsipkan.');
        $barang = (int)$d['barang_id']; $asal = (int)$d['lokasi_asal_id']; $tujuan = (int)$d['lokasi_tujuan_id'];
        lokasi_cek_tersedia($con, $barang, $asal, (int)$d['jumlah']);
        $id = db_exec($con,
            "INSERT INTO pemindahan (barang_id, lokasi_asal_id, lokasi_tujuan_id, jumlah, tanggal, keterangan, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?)",
            'iiiissi', [$barang, $asal, $tujuan, $d['jumlah'], $d['tanggal'], $d['keterangan'], user_id()])['insert_id'];
        stok_lokasi_ubah($con, $barang, $asal, -(int)$d['jumlah']);
        stok_lokasi_ubah($con, $barang, $tujuan, (int)$d['jumlah']);
        $namaAsal = db_value($con, "SELECT nama FROM lokasi WHERE id = ?", 'i', [$asal]);
        $namaTujuan = db_value($con, "SELECT nama FROM lokasi WHERE id = ?", 'i', [$tujuan]);
        catat_mutasi($con, $barang, 'pindah', (int)$d['jumlah'], 0, 'PD-' . $id,
            "Pindah dari {$namaAsal} ke {$namaTujuan}" . ($d['keterangan'] !== '' ? ' — ' . $d['keterangan'] : ''),
            $d['tanggal'] . ' ' . date('H:i:s'));
        log_aktivitas('TAMBAH', 'pemindahan', "Pindah PD-{$id}: {$d['jumlah']} unit dari {$namaAsal} ke {$namaTujuan}");
        return $id;
    });
}

// ---------------------------------------------------------------------------
// Peminjaman (aset saja). Pengembalian bisa sebagian.
// ---------------------------------------------------------------------------

function peminjaman_tambah(mysqli $con, array $d): int
{
    return db_tx($con, function (mysqli $con) use ($d) {
        periode_cek($con, $d['tanggal_pinjam']);
        $b = db_row($con, "SELECT id, nama_barang, aktif, jenis_barang, lokasi_id FROM barang WHERE id = ? FOR UPDATE", 'i', [$d['barang_id']]);
        if (!$b) throw new AppException('Barang tidak ditemukan.');
        if ((int)$b['aktif'] !== 1) throw new AppException('Barang sudah diarsipkan dan tidak dapat dipinjamkan.');
        if ($b['jenis_barang'] !== 'aset') throw new AppException('Barang habis pakai tidak dapat dipinjamkan. Catat sebagai pemakaian di menu Pemakaian & Keluar.');
        $lokasi = !empty($d['lokasi_asal_id']) ? (int)$d['lokasi_asal_id'] : (int)$b['lokasi_id'];
        if (!$lokasi) throw new AppException('Pilih ruangan asal barang.');
        lokasi_cek_tersedia($con, (int)$d['barang_id'], $lokasi, (int)$d['jumlah']);

        $id = db_exec($con,
            "INSERT INTO peminjaman (barang_id, lokasi_asal_id, jumlah, peminjam, kontak, tipe_peminjam, unit, tanggal_pinjam,
                                     tanggal_rencana_kembali, kondisi_pinjam, status, keterangan, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Dipinjam', ?, ?)",
            'iiissssssssi',
            [$d['barang_id'], $lokasi, $d['jumlah'], $d['peminjam'], $d['kontak'], $d['tipe_peminjam'], $d['unit'],
             $d['tanggal_pinjam'], $d['tanggal_rencana_kembali'], $d['kondisi_pinjam'], $d['keterangan'], user_id()])['insert_id'];
        catat_mutasi($con, (int)$d['barang_id'], 'pinjam', (int)$d['jumlah'], 0, 'PJ-' . $id,
            "Dipinjam oleh {$d['peminjam']}" . ($d['unit'] !== '' ? " ({$d['unit']})" : ''), $d['tanggal_pinjam'] . ' ' . date('H:i:s'));
        log_aktivitas('TAMBAH', 'peminjaman', "Peminjaman PJ-{$id}: {$d['jumlah']} unit oleh {$d['peminjam']}");
        return $id;
    });
}

/**
 * Catat pengembalian. $d: kembali (unit kembali), hilang (unit hilang), tanggal_kembali,
 * kondisi_kembali, keterangan. Jumlah kembali + hilang tidak boleh melebihi sisa pinjaman.
 */
function peminjaman_kembali(mysqli $con, int $id, array $d): void
{
    db_tx($con, function (mysqli $con) use ($id, $d) {
        $p = db_row($con, "SELECT * FROM peminjaman WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$p || $p['status'] !== 'Dipinjam') throw new AppException('Peminjaman ini sudah selesai.');
        $k = (int)$d['kembali']; $h = (int)$d['hilang'];
        $sisaLama = (int)$p['sisa'];
        if ($k < 0 || $h < 0 || $k + $h < 1) throw new AppException('Isi jumlah unit yang dikembalikan atau yang hilang.');
        if ($k + $h > $sisaLama) throw new AppException("Jumlah melebihi sisa pinjaman ({$sisaLama} unit).");
        if ($d['tanggal_kembali'] < $p['tanggal_pinjam']) throw new AppException('Tanggal kembali tidak boleh sebelum tanggal pinjam.');
        periode_cek($con, $d['tanggal_kembali']);

        $barangId = (int)$p['barang_id'];
        $lokasi = (int)$p['lokasi_asal_id'];
        db_value($con, "SELECT id FROM barang WHERE id = ? FOR UPDATE", 'i', [$barangId]);

        $dikem = (int)$p['dikembalikan'] + $k;
        $hil = (int)$p['hilang'] + $h;
        $sisaBaru = (int)$p['jumlah'] - $dikem - $hil;
        if ($sisaBaru > 0) {
            $status = 'Dipinjam';
        } else {
            $status = ($dikem === 0 && $hil > 0) ? 'Hilang' : 'Dikembalikan';
        }
        $catatan = trim(($p['keterangan'] ?? '') . ($d['keterangan'] !== ''
            ? "\n[Pengembalian " . tgl_indo($d['tanggal_kembali']) . "] " . $d['keterangan'] : ''));

        db_exec($con,
            "UPDATE peminjaman SET dikembalikan = ?, hilang = ?, status = ?, tanggal_kembali = ?, kondisi_kembali = ?, keterangan = ? WHERE id = ?",
            'iissssi', [$dikem, $hil, $status, $d['tanggal_kembali'], $d['kondisi_kembali'], $catatan, $id]);

        if ($h > 0) {
            ubah_stok_total($con, $barangId, -$h);
            stok_lokasi_ubah($con, $barangId, $lokasi, -$h);
            catat_mutasi($con, $barangId, 'hilang', $h, -$h, 'PJ-' . $id,
                "Hilang saat dipinjam {$p['peminjam']}", $d['tanggal_kembali'] . ' ' . date('H:i:s'));
        }
        if ($k > 0) {
            catat_mutasi($con, $barangId, 'kembali', $k, 0, 'PJ-' . $id,
                "Dikembalikan {$p['peminjam']} — kondisi: {$d['kondisi_kembali']}", $d['tanggal_kembali'] . ' ' . date('H:i:s'));
        }
        log_aktivitas('UBAH', 'peminjaman', "Pengembalian PJ-{$id}: kembali {$k}, hilang {$h}, status {$status}");
    });
}

function peminjaman_perpanjang(mysqli $con, int $id, string $tanggalBaru): void
{
    db_tx($con, function (mysqli $con) use ($id, $tanggalBaru) {
        $p = db_row($con, "SELECT * FROM peminjaman WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$p || $p['status'] !== 'Dipinjam') throw new AppException('Hanya peminjaman yang masih berjalan yang dapat diperpanjang.');
        if ($tanggalBaru <= $p['tanggal_rencana_kembali']) {
            throw new AppException('Tanggal perpanjangan harus lebih lama dari rencana kembali saat ini.');
        }
        db_exec($con, "UPDATE peminjaman SET tanggal_rencana_kembali = ? WHERE id = ?", 'si', [$tanggalBaru, $id]);
        log_aktivitas('UBAH', 'peminjaman', "Perpanjang PJ-{$id} sampai {$tanggalBaru}");
    });
}

/** Catat bahwa peminjam sudah diingatkan (untuk pelacakan). */
function peminjaman_ingatkan(mysqli $con, int $id): void
{
    $n = db_exec($con, "UPDATE peminjaman SET pengingat_terakhir = NOW() WHERE id = ? AND status = 'Dipinjam'", 'i', [$id])['affected'];
    if ($n < 1) throw new AppException('Pengingat hanya untuk peminjaman yang masih berjalan.');
    log_aktivitas('UBAH', 'peminjaman', "Mengirim pengingat untuk PJ-{$id}");
}

// ---------------------------------------------------------------------------
// Kerusakan & perbaikan (aset saja)
// ---------------------------------------------------------------------------

function kerusakan_lapor(mysqli $con, array $d): int
{
    return db_tx($con, function (mysqli $con) use ($d) {
        periode_cek($con, $d['tanggal_lapor']);
        $b = db_row($con, "SELECT id, aktif, jenis_barang, lokasi_id FROM barang WHERE id = ? FOR UPDATE", 'i', [$d['barang_id']]);
        if (!$b) throw new AppException('Barang tidak ditemukan.');
        if ($b['jenis_barang'] !== 'aset') throw new AppException('Kerusakan hanya dicatat untuk aset tetap. Pemakaian habis pakai tidak memerlukan laporan kerusakan.');
        $lokasi = !empty($d['lokasi_id']) ? (int)$d['lokasi_id'] : (int)$b['lokasi_id'];
        if (!$lokasi) throw new AppException('Pilih ruangan tempat barang berada.');
        lokasi_cek_tersedia($con, (int)$d['barang_id'], $lokasi, (int)$d['jumlah']);

        $id = db_exec($con,
            "INSERT INTO kerusakan (barang_id, lokasi_id, jumlah, tanggal_lapor, pelapor, deskripsi, foto, status, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'Dilaporkan', ?)",
            'iiissssi', [$d['barang_id'], $lokasi, $d['jumlah'], $d['tanggal_lapor'], $d['pelapor'], $d['deskripsi'], $d['foto'], user_id()])['insert_id'];
        db_exec($con,
            "INSERT INTO kerusakan_riwayat (kerusakan_id, status_lama, status_baru, catatan, user_nama) VALUES (?, NULL, 'Dilaporkan', ?, ?)",
            'iss', [$id, 'Laporan kerusakan dibuat oleh ' . $d['pelapor'], user_nama()]);
        catat_mutasi($con, (int)$d['barang_id'], 'rusak', (int)$d['jumlah'], 0, 'KR-' . $id,
            'Dilaporkan rusak: ' . potong($d['deskripsi'], 80), $d['tanggal_lapor'] . ' ' . date('H:i:s'));
        log_aktivitas('TAMBAH', 'kerusakan', "Laporan kerusakan KR-{$id}: {$d['jumlah']} unit");
        return $id;
    });
}

function nomor_ba_baru(mysqli $con): string
{
    $tahun = date('Y');
    $max = (int)db_value($con,
        "SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(nomor_ba, '/', -1) AS UNSIGNED)), 0)
         FROM penghapusan WHERE nomor_ba LIKE CONCAT('BA-HAPUS/', ?, '/%')", 's', [$tahun]);
    return sprintf('BA-HAPUS/%s/%03d', $tahun, $max + 1);
}

/** Setiap keputusan rusak permanen otomatis menerbitkan berita acara penghapusan. */
function penghapusan_dari_rusak(mysqli $con, int $kid, array $r): void
{
    $tgl = date('Y-m-d');
    $nilai = aset_nilai_buku_unit($con, (int)$r['barang_id']);
    $nomor = nomor_ba_baru($con);
    db_exec($con,
        "INSERT INTO penghapusan (nomor_ba, barang_id, lokasi_id, jumlah, alasan, tanggal_usul, tanggal_setujui, nilai_buku_unit,
                                  keterangan, status, sumber, kerusakan_id, diusulkan_oleh, disetujui_oleh)
         VALUES (?, ?, ?, ?, 'Rusak permanen', ?, ?, ?, ?, 'Disetujui', 'Kerusakan', ?, ?, ?)",
        'siiissdsiss',
        [$nomor, (int)$r['barang_id'], (int)$r['lokasi_id'], (int)$r['jumlah'], $tgl, $tgl, $nilai,
         'Dari laporan ' . rusak_kode($kid), $kid, $r['pelapor'], user_nama()]);
}

/** Ubah status kerusakan sesuai alur persetujuan. */
function kerusakan_transisi(mysqli $con, int $id, string $ke, array $d): void
{
    db_tx($con, function (mysqli $con) use ($id, $ke, $d) {
        $r = db_row($con, "SELECT * FROM kerusakan WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$r) throw new AppException('Laporan kerusakan tidak ditemukan.');
        $dari = $r['status'];
        $barangId = (int)$r['barang_id'];
        $lokasi = (int)$r['lokasi_id'];
        db_value($con, "SELECT id FROM barang WHERE id = ? FOR UPDATE", 'i', [$barangId]);

        if (!in_array($ke, RUSAK_TRANSISI[$dari] ?? [], true)) {
            throw new AppException("Perubahan status dari \"{$dari}\" ke \"{$ke}\" tidak diizinkan.");
        }
        if (rusak_butuh_persetujuan($dari, $ke) && !can('kerusakan.setujui')) {
            throw new AppException('Tindakan ini memerlukan persetujuan Kepala Sekolah atau Administrator.');
        }
        $estimasi = $d['estimasi_biaya'] ?? null;
        if ($ke === 'Menunggu Persetujuan' && (!$estimasi || $estimasi <= 0)) {
            throw new AppException('Isi estimasi biaya perbaikan sebelum mengajukan persetujuan.');
        }
        $selesai = $ke === 'Selesai' ? ($d['tanggal_selesai'] ?: date('Y-m-d')) : $r['tanggal_selesai'];
        if ($ke === 'Selesai') periode_cek($con, $selesai);
        if ($ke === 'Rusak Permanen') periode_cek($con, date('Y-m-d'));
        $teknisi = $d['teknisi'] !== '' ? $d['teknisi'] : $r['teknisi'];
        $aktual = $d['biaya_aktual'] ?? $r['biaya_aktual'];
        if ($estimasi === null || $estimasi === 0) $estimasi = $r['estimasi_biaya'];

        db_exec($con,
            "UPDATE kerusakan SET status = ?, teknisi = ?, estimasi_biaya = ?, biaya_aktual = ?, tanggal_selesai = ?,
                                  catatan_persetujuan = COALESCE(NULLIF(?, ''), catatan_persetujuan)
             WHERE id = ?",
            'ssddssi', [$ke, $teknisi, $estimasi, $aktual, $selesai, $d['catatan'], $id]);
        db_exec($con,
            "INSERT INTO kerusakan_riwayat (kerusakan_id, status_lama, status_baru, catatan, user_nama) VALUES (?, ?, ?, ?, ?)",
            'issss', [$id, $dari, $ke, $d['catatan'], user_nama()]);

        if ($ke === 'Rusak Permanen') {
            // Unit sudah tidak dihitung sebagai rusak aktif setelah status ini, jadi tersedia tidak berubah
            ubah_stok_total($con, $barangId, -(int)$r['jumlah']);
            stok_lokasi_ubah($con, $barangId, $lokasi, -(int)$r['jumlah']);
            catat_mutasi($con, $barangId, 'rusak_permanen', (int)$r['jumlah'], -(int)$r['jumlah'], 'KR-' . $id,
                'Dihapus dari aset (rusak permanen)');
            penghapusan_dari_rusak($con, $id, $r);
        } elseif ($ke === 'Selesai') {
            catat_mutasi($con, $barangId, 'selesai_perbaikan', (int)$r['jumlah'], 0, 'KR-' . $id,
                'Perbaikan selesai, unit kembali tersedia');
        }
        log_aktivitas('UBAH', 'kerusakan', "KR-{$id}: status {$dari} → {$ke}");
    });
}

// ---------------------------------------------------------------------------
// Penghapusan aset (usulan manual & berita acara)
// ---------------------------------------------------------------------------

function penghapusan_usul(mysqli $con, array $d): int
{
    return db_tx($con, function (mysqli $con) use ($d) {
        periode_cek($con, $d['tanggal_usul']);
        $b = db_row($con, "SELECT id, aktif, jenis_barang, lokasi_id FROM barang WHERE id = ?", 'i', [$d['barang_id']]);
        if (!$b || (int)$b['aktif'] !== 1) throw new AppException('Barang tidak ditemukan atau sudah diarsipkan.');
        if ($b['jenis_barang'] !== 'aset') throw new AppException('Penghapusan hanya untuk aset tetap.');
        $lokasi = !empty($d['lokasi_id']) ? (int)$d['lokasi_id'] : (int)$b['lokasi_id'];
        if (!$lokasi) throw new AppException('Pilih ruangan tempat barang berada.');
        return db_exec($con,
            "INSERT INTO penghapusan (barang_id, lokasi_id, jumlah, alasan, tanggal_usul, keterangan, status, sumber, diusulkan_oleh)
             VALUES (?, ?, ?, ?, ?, ?, 'Diusulkan', 'Manual', ?)",
            'iiissss', [$d['barang_id'], $lokasi, $d['jumlah'], $d['alasan'], $d['tanggal_usul'], $d['keterangan'], user_nama()])['insert_id'];
    });
}

/** Persetujuan Kepala Sekolah: jumlah berkurang dan berita acara terbit dengan nomor resmi. */
function penghapusan_setujui(mysqli $con, int $id): void
{
    if (!can('penghapusan.setujui')) throw new AppException('Persetujuan penghapusan hanya untuk Kepala Sekolah atau Administrator.');
    db_tx($con, function (mysqli $con) use ($id) {
        $p = db_row($con, "SELECT * FROM penghapusan WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$p) throw new AppException('Usulan tidak ditemukan.');
        if ($p['status'] !== 'Diusulkan') throw new AppException('Usulan ini sudah diputuskan.');
        periode_cek($con, date('Y-m-d'));
        $barangId = (int)$p['barang_id'];
        $lokasi = (int)$p['lokasi_id'];
        $jumlah = (int)$p['jumlah'];
        db_value($con, "SELECT id FROM barang WHERE id = ? FOR UPDATE", 'i', [$barangId]);
        lokasi_cek_tersedia($con, $barangId, $lokasi, $jumlah);

        $nomor = nomor_ba_baru($con);
        $nilai = aset_nilai_buku_unit($con, $barangId);
        ubah_stok_total($con, $barangId, -$jumlah);
        stok_lokasi_ubah($con, $barangId, $lokasi, -$jumlah);
        catat_mutasi($con, $barangId, 'penghapusan', $jumlah, -$jumlah, $nomor, 'Dihapus dari aset: ' . $p['alasan']);
        db_exec($con,
            "UPDATE penghapusan SET status = 'Disetujui', nomor_ba = ?, tanggal_setujui = CURDATE(), nilai_buku_unit = ?, disetujui_oleh = ? WHERE id = ?",
            'sdsi', [$nomor, $nilai, user_nama(), $id]);
        log_aktivitas('UBAH', 'penghapusan', "Menyetujui penghapusan, berita acara {$nomor}");
    });
}

function penghapusan_tolak(mysqli $con, int $id, string $alasan): void
{
    if (!can('penghapusan.setujui')) throw new AppException('Persetujuan penghapusan hanya untuk Kepala Sekolah atau Administrator.');
    $n = db_exec($con,
        "UPDATE penghapusan SET status = 'Ditolak', disetujui_oleh = ?, keterangan = CONCAT(keterangan, ' [Ditolak: ', ?, ']') WHERE id = ? AND status = 'Diusulkan'",
        'ssi', [user_nama(), $alasan, $id])['affected'];
    if ($n < 1) throw new AppException('Usulan tidak ditemukan atau sudah diputuskan.');
    log_aktivitas('UBAH', 'penghapusan', "Menolak usulan penghapusan #{$id}");
}

// ---------------------------------------------------------------------------
// Opname barang per ruangan
// ---------------------------------------------------------------------------

function opname_buat(mysqli $con, array $d): int
{
    if (empty($d['lokasi_id'])) throw new AppException('Pilih ruangan untuk sesi opname (opname dilakukan per ruangan).');
    periode_cek($con, $d['tanggal']);
    return db_tx($con, function (mysqli $con) use ($d) {
        $tahun = date('Y');
        $n = (int)db_value($con, "SELECT COUNT(*) FROM stok_opname WHERE YEAR(tanggal) = ?", 'i', [$tahun]) + 1;
        $kode = sprintf('OPN-%s-%03d', $tahun, $n);
        $id = db_exec($con,
            "INSERT INTO stok_opname (kode, judul, tanggal, lokasi_id, status, catatan, created_by) VALUES (?, ?, ?, ?, 'Draft', ?, ?)",
            'sssisi', [$kode, $d['judul'], $d['tanggal'], $d['lokasi_id'], $d['catatan'], user_id()])['insert_id'];
        db_exec($con,
            "INSERT INTO stok_opname_item (opname_id, barang_id, stok_sistem)
             SELECT ?, sl.barang_id, sl.jumlah FROM stok_lokasi sl JOIN barang b ON b.id = sl.barang_id
             WHERE sl.lokasi_id = ? AND b.aktif = 1 AND sl.jumlah > 0",
            'ii', [$id, $d['lokasi_id']]);
        log_aktivitas('TAMBAH', 'opname', "Membuat sesi opname barang {$kode}");
        return $id;
    });
}

function opname_simpan_fisik(mysqli $con, int $id, array $fisik, array $ket): void
{
    $op = db_row($con, "SELECT status FROM stok_opname WHERE id = ?", 'i', [$id]);
    if (!$op) throw new AppException('Sesi opname tidak ditemukan.');
    if ($op['status'] !== 'Draft') throw new AppException('Sesi ini sudah difinalisasi dan tidak dapat diubah.');
    db_tx($con, function (mysqli $con) use ($id, $fisik, $ket) {
        foreach ($fisik as $barangId => $qty) {
            db_exec($con, "UPDATE stok_opname_item SET stok_fisik = ?, keterangan = ? WHERE opname_id = ? AND barang_id = ?",
                'isii', [$qty, $ket[$barangId] ?? null, $id, (int)$barangId]);
        }
    });
}

/** Finalisasi: total unit dan jumlah di ruangan disesuaikan dengan hitung fisik; setiap selisih tercatat. */
function opname_finalisasi(mysqli $con, int $id): void
{
    if (!can('opname.finalisasi')) throw new AppException('Finalisasi opname memerlukan persetujuan Kepala Sekolah atau Administrator.');
    db_tx($con, function (mysqli $con) use ($id) {
        $op = db_row($con, "SELECT * FROM stok_opname WHERE id = ? FOR UPDATE", 'i', [$id]);
        if (!$op) throw new AppException('Sesi opname tidak ditemukan.');
        if ($op['status'] !== 'Draft') throw new AppException('Sesi ini sudah difinalisasi.');
        if (empty($op['lokasi_id'])) throw new AppException('Sesi ini tidak memiliki ruangan dan tidak dapat difinalisasi.');
        periode_cek($con, $op['tanggal']);
        $lokasi = (int)$op['lokasi_id'];
        $kosong = (int)db_value($con, "SELECT COUNT(*) FROM stok_opname_item WHERE opname_id = ? AND stok_fisik IS NULL", 'i', [$id]);
        if ($kosong > 0) throw new AppException("Masih ada {$kosong} barang yang belum diisi jumlah fisiknya.");

        $items = db_all($con, "SELECT * FROM stok_opname_item WHERE opname_id = ?", 'i', [$id]);
        $sesuai = 0; $disesuaikan = 0;
        foreach ($items as $it) {
            $bid = (int)$it['barang_id'];
            db_value($con, "SELECT id FROM barang WHERE id = ? FOR UPDATE", 'i', [$bid]);
            $cur = (int)db_value($con, "SELECT COALESCE((SELECT jumlah FROM stok_lokasi WHERE barang_id = ? AND lokasi_id = ?), 0)", 'ii', [$bid, $lokasi]);
            $selisihSistem = (int)$it['stok_fisik'] - (int)$it['stok_sistem'];
            db_exec($con, "UPDATE stok_opname_item SET selisih = ? WHERE id = ?", 'ii', [$selisihSistem, $it['id']]);
            $koreksi = (int)$it['stok_fisik'] - $cur;
            if ($koreksi !== 0) {
                ubah_stok_total($con, $bid, $koreksi);
                stok_lokasi_ubah($con, $bid, $lokasi, $koreksi);
                catat_mutasi($con, $bid, 'opname', abs($koreksi), $koreksi, 'OP-' . $id,
                    "Penyesuaian opname {$op['kode']} di ruangan (fisik {$it['stok_fisik']})");
                $disesuaikan++;
            } else {
                $sesuai++;
            }
        }
        db_exec($con, "UPDATE stok_opname SET status = 'Selesai', finalized_at = NOW(), finalized_by = ? WHERE id = ?",
            'ii', [user_id(), $id]);
        log_aktivitas('UBAH', 'opname', "Finalisasi {$op['kode']}: {$sesuai} sesuai, {$disesuaikan} disesuaikan");
    });
}
