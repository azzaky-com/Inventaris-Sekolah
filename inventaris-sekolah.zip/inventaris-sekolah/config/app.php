<?php
// config/app.php — pengaturan aplikasi. Ubah sesuai kebutuhan sekolah.

const APP_NAME          = 'Inventaris Sekolah';
const APP_VERSION       = '4.0.0';
const APP_DEBUG         = false;   // true = tampilkan detail error PHP (hanya untuk pengembangan)
const SESSION_IDLE_MENIT = 30;     // logout otomatis bila tidak ada aktivitas selama X menit
const LOGIN_MAX_GAGAL   = 5;       // jumlah percobaan login gagal sebelum dikunci sementara
const LOGIN_KUNCI_MENIT = 10;      // lama kunci sementara (menit)
const UPLOAD_MAKS_BYTES = 2097152; // 2 MB
const ZONA_WAKTU        = 'Asia/Jakarta';

// Daftar pilihan (dipakai di form dan laporan)
const SUMBER_DANA      = ['BOS', 'APBD', 'Hibah', 'Donasi', 'Pribadi', 'Lainnya'];
const ALASAN_KELUAR    = ['Pemakaian Operasional', 'Distribusi ke Unit/Kelas', 'Dihibahkan', 'Dipindahkan ke Lokasi Lain', 'Diserahkan ke Pihak Lain', 'Lainnya'];
const JENIS_BARANG     = ['habis_pakai' => 'Habis pakai', 'aset' => 'Aset tetap'];
const ALASAN_HAPUS     = ['Rusak permanen', 'Hilang', 'Dijual', 'Dihibahkan', 'Dimusnahkan', 'Lainnya'];
const SISA_PAKAI_DARURAT = 14;   // hari: sisa persediaan habis pakai di bawah ini = darurat
const SISA_PAKAI_SEGERA  = 30;   // hari: di bawah ini = perlu segera dipesan
const TIPE_PEMINJAM    = ['Guru', 'Tenaga Kependidikan', 'Siswa', 'Unit / Kelas', 'Lainnya'];
const KONDISI_BARANG   = ['Baik', 'Ada Lecet', 'Perlu Perhatian'];
const KONDISI_KEMBALI  = ['Baik', 'Ada Lecet', 'Perlu Perhatian', 'Rusak'];
