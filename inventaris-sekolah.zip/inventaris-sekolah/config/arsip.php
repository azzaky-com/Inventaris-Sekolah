<?php
// config/arsip.php — pengarsipan kartu persediaan sebelum suatu tanggal, tanpa mengubah angka aset.
//
// Yang dihapus dari kartu persediaan adalah riwayat rinci sebelum batas. Yang disimpan kembali adalah
// SISA setiap batch pembelian pada batas itu, dengan tanggal, harga (via referensi BM-…), dan
// jumlah yang asli. Akibatnya penyusutan, saldo, dan nilai buku sebelum dan sesudah arsip sama.

/**
 * $batas: 'YYYY-MM-DD 00:00:00' (eksklusif). Mengembalikan jumlah baris kartu persediaan yang diarsipkan.
 */
function arsip_mutasi_sebelum(mysqli $con, string $batas, string $label): int
{
    $asOf = date('Y-m-d', strtotime($batas) - 1);
    $ref  = date('Y-m-d H:i:s', strtotime($batas) - 1);
    return db_tx($con, function (mysqli $con) use ($batas, $asOf, $ref, $label) {
        $daftar = db_all($con, "SELECT DISTINCT barang_id FROM mutasi WHERE tanggal < ?", 's', [$batas]);
        $baris = 0;
        foreach ($daftar as $row) {
            $bid = (int)$row['barang_id'];
            $b = db_row($con, "SELECT * FROM barang WHERE id = ?", 'i', [$bid]);
            $tot = (int)db_value($con, "SELECT COALESCE(SUM(perubahan_total),0) FROM mutasi WHERE barang_id = ? AND tanggal < ?", 'is', [$bid, $batas]);
            $tsd = (int)db_value($con, "SELECT COALESCE(SUM(perubahan_tersedia),0) FROM mutasi WHERE barang_id = ? AND tanggal < ?", 'is', [$bid, $batas]);
            $p = penyusutan_batch($con, $b, $asOf);
            $sisa = [];
            if ($p['ok']) {
                foreach ($p['batches'] as $bt) {
                    if ((int)$bt['units'] > 0) $sisa[] = ['waktu' => $bt['waktu'], 'ref' => $bt['ref'], 'units' => (int)$bt['units']];
                }
            }
            $jumlahSisa = array_sum(array_column($sisa, 'units'));
            $hapus = db_exec($con, "DELETE FROM mutasi WHERE barang_id = ? AND tanggal < ?", 'is', [$bid, $batas])['affected'];
            $baris += $hapus;
            if (!$sisa || $jumlahSisa !== $tot) {
                // Tanpa rincian batch (mis. harga/masa belum diatur): satu baris ringkasan
                if ($tot !== 0 || $tsd !== 0) {
                    db_exec($con,
                        "INSERT INTO mutasi (barang_id, tanggal, jenis, jumlah, perubahan_total, perubahan_tersedia, saldo_total, saldo_tersedia, referensi, keterangan, user_nama)
                         VALUES (?, ?, 'saldo_awal', 0, ?, ?, 0, 0, 'ARSIP', ?, ?)",
                        'isiiss', [$bid, $ref, $tot, $tsd, 'Saldo terbawa dari arsip ' . $label, user_nama()]);
                }
                continue;
            }
            $pertama = true;
            foreach ($sisa as $s2) {
                db_exec($con,
                    "INSERT INTO mutasi (barang_id, tanggal, jenis, jumlah, perubahan_total, perubahan_tersedia, saldo_total, saldo_tersedia, referensi, keterangan, user_nama)
                     VALUES (?, ?, 'saldo_awal', 0, ?, ?, 0, 0, ?, ?, ?)",
                    'isiisss', [$bid, $s2['waktu'], $s2['units'], $pertama ? $tsd : 0, $s2['ref'],
                        'Sisa batch terbawa dari arsip ' . $label, user_nama()]);
                $pertama = false;
            }
        }
        log_aktivitas('HAPUS', 'pemeliharaan', "Mengarsipkan {$baris} baris kartu persediaan sebelum " . tgl_indo(substr($batas, 0, 10)) . " ({$label})");
        return $baris;
    });
}
