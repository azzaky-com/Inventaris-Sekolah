<?php
// config/inventaris.php — logika inti jumlah: saldo, kartu persediaan (mutasi), kode barang, log aktivitas.
//
// Prinsip: stok_total adalah jumlah unit yang dimiliki sekolah.
//   dipinjam  = jumlah unit pada peminjaman berstatus 'Dipinjam'
//   rusak     = jumlah unit pada laporan kerusakan yang belum selesai/dihapus
//   tersedia  = stok_total - dipinjam - rusak
// Setiap perubahan jumlah dijalankan dalam transaksi dan dicatat di tabel mutasi.

const STATUS_RUSAK = [
    'Dilaporkan', 'Diperiksa', 'Menunggu Persetujuan', 'Dalam Perbaikan', 'Selesai', 'Rusak Permanen',
];

/** Transisi status kerusakan yang diizinkan. */
const RUSAK_TRANSISI = [
    'Dilaporkan'           => ['Diperiksa'],
    'Diperiksa'            => ['Menunggu Persetujuan', 'Rusak Permanen'],
    'Menunggu Persetujuan' => ['Dalam Perbaikan', 'Rusak Permanen', 'Diperiksa'],
    'Dalam Perbaikan'      => ['Selesai'],
    'Selesai'              => [],
    'Rusak Permanen'       => [],
];

/** Label tombol untuk setiap transisi. */
const RUSAK_AKSI_LABEL = [
    'Diperiksa'            => 'Tandai Sedang Diperiksa',
    'Menunggu Persetujuan' => 'Ajukan Persetujuan Perbaikan',
    'Dalam Perbaikan'      => 'Setujui Perbaikan',
    'Rusak Permanen'       => 'Nyatakan Rusak Permanen (Penghapusan)',
    'Selesai'              => 'Tandai Perbaikan Selesai',
];

/** Apakah transisi ini membutuhkan persetujuan Kepala Sekolah / Administrator. */
function rusak_butuh_persetujuan(string $dari, string $ke): bool
{
    if (in_array($ke, ['Dalam Perbaikan', 'Rusak Permanen'], true)) return true;
    if ($dari === 'Menunggu Persetujuan' && $ke === 'Diperiksa') return true; // penolakan
    return false;
}

/** Saldo jumlah barang saat ini. */
function saldo_barang(mysqli $con, int $barang_id): array
{
    $row = db_row($con,
        "SELECT b.stok_total,
            (SELECT COALESCE(SUM(p.sisa), 0) FROM peminjaman p WHERE p.barang_id = b.id AND p.status = 'Dipinjam') AS dipinjam,
            (SELECT COALESCE(SUM(k.jumlah), 0) FROM kerusakan k WHERE k.barang_id = b.id AND k.status NOT IN ('Selesai', 'Rusak Permanen')) AS rusak
         FROM barang b WHERE b.id = ?",
        'i', [$barang_id]);
    if ($row === null) {
        throw new AppException('Barang tidak ditemukan.');
    }
    $total = (int)$row['stok_total'];
    $dip   = (int)$row['dipinjam'];
    $rus   = (int)$row['rusak'];
    return [
        'total'    => $total,
        'dipinjam' => $dip,
        'rusak'    => $rus,
        'tersedia' => $total - $dip - $rus,
    ];
}

/** Ubah stok_total (delta +/-). Memastikan unit tersedia tidak negatif. */
function ubah_stok_total(mysqli $con, int $barang_id, int $delta): void
{
    if ($delta === 0) return;
    $cur = db_value($con, "SELECT stok_total FROM barang WHERE id = ? FOR UPDATE", 'i', [$barang_id]);
    if ($cur === null) {
        throw new AppException('Barang tidak ditemukan.');
    }
    $s = saldo_barang($con, $barang_id);
    $total_baru    = (int)$cur + $delta;
    $tersedia_baru = $total_baru - $s['dipinjam'] - $s['rusak'];
    if ($tersedia_baru < 0) {
        throw new AppException("Unit tersedia tidak mencukupi. Tersedia saat ini: {$s['tersedia']} unit (sebagian sedang dipinjam atau rusak).");
    }
    if ($total_baru < 0) {
        throw new AppException('Perubahan ini membuat total unit menjadi negatif.');
    }
    db_exec($con, "UPDATE barang SET stok_total = ? WHERE id = ?", 'ii', [$total_baru, $barang_id]);
}

/**
 * Catat satu baris kartu persediaan (mutasi). Dipanggil SETELAH perubahan diterapkan
 * agar saldo yang tersimpan adalah saldo sesudah transaksi.
 *   $jumlah          : jumlah unit yang terlibat (selalu positif)
 *   $perubahan_total : pengaruh terhadap stok_total (+, -, atau 0)
 */

/** Pengaruh satu kejadian terhadap jumlah TERSEDIA (diturunkan dari jenis). */
function perubahan_tersedia_dari(string $jenis, int $jumlah, int $perubahanTotal): int
{
    switch ($jenis) {
        case 'masuk':             return $jumlah;
        case 'keluar':            return -$jumlah;
        case 'pinjam':            return -$jumlah;
        case 'kembali':           return $jumlah;
        case 'hilang':            return 0;     // total turun, dipinjam turun: tersedia tetap
        case 'rusak':             return -$jumlah;
        case 'selesai_perbaikan': return $jumlah;
        case 'rusak_permanen':    return 0;     // total turun, rusak turun: tersedia tetap
        default:                  return $perubahanTotal; // opname & koreksi
    }
}

/**
 * Catat satu baris kartu persediaan. Yang disimpan adalah PERUBAHAN (bukan saldo),
 * sehingga saldo berjalan selalu benar walau transaksi diberi tanggal mundur.
 *   $jumlah          : unit yang terlibat (selalu positif)
 *   $perubahanTotal  : pengaruh terhadap total unit (+, - atau 0)
 */
function catat_mutasi(mysqli $con, int $barang_id, string $jenis, int $jumlah, int $perubahan_total,
                      string $referensi, string $keterangan, ?string $waktu = null): void
{
    $s = saldo_barang($con, $barang_id);   // saldo saat dicatat (informasi tambahan)
    $ptsd = perubahan_tersedia_dari($jenis, $jumlah, $perubahan_total);
    db_exec($con,
        "INSERT INTO mutasi (barang_id, tanggal, jenis, jumlah, perubahan_total, perubahan_tersedia, saldo_total, saldo_tersedia, referensi, keterangan, user_nama)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        'issiiiiisss',
        [$barang_id, $waktu ?? date('Y-m-d H:i:s'), $jenis, $jumlah, $perubahan_total, $ptsd,
         $s['total'], $s['tersedia'], $referensi, $keterangan, user_nama()]);
}

/** Buat kode barang baru berurutan per kategori, mis. ELK-0007. */
function kode_barang_baru(mysqli $con, int $kategori_id): string
{
    $prefix = db_value($con, "SELECT kode_prefix FROM kategori WHERE id = ? FOR UPDATE", 'i', [$kategori_id]);
    if ($prefix === null) {
        throw new AppException('Kategori tidak ditemukan.');
    }
    $max = db_value($con,
        "SELECT COALESCE(MAX(CAST(SUBSTRING(kode_barang, CHAR_LENGTH(?) + 2) AS UNSIGNED)), 0)
         FROM barang WHERE kode_barang LIKE CONCAT(?, '-%')",
        'ss', [$prefix, $prefix]);
    return sprintf('%s-%04d', $prefix, ((int)$max) + 1);
}

/** Catat aktivitas pengguna ke log. */
function log_aktivitas(string $aksi, string $modul, string $deskripsi): void
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    db_exec(db(),
        "INSERT INTO log_aktivitas (user_id, username, aksi, modul, deskripsi, ip) VALUES (?, ?, ?, ?, ?, ?)",
        'isssss',
        [user_id(), $_SESSION['auth']['username'] ?? 'sistem', $aksi, $modul, mb_substr($deskripsi, 0, 250), $ip]);
}

/** Ambil barang beserta nama merek, kategori, dan lokasi. */
function barang_detail(mysqli $con, int $id): ?array
{
    return db_row($con,
        "SELECT b.*, k.nama AS kategori, k.kode_prefix, m.nama AS merek, l.nama AS lokasi, l.penanggung_jawab
         FROM barang b
         JOIN kategori k ON k.id = b.kategori_id
         LEFT JOIN merek m ON m.id = b.merek_id
         LEFT JOIN lokasi l ON l.id = b.lokasi_id
         WHERE b.id = ?",
        'i', [$id]);
}

/** Daftar barang aktif dengan saldo (untuk dropdown transaksi). */
function daftar_barang_saldo(mysqli $con): array
{
    return db_all($con,
        "SELECT b.id, b.kode_barang, b.nama_barang, b.satuan, b.stok_total, b.harga_perolehan, b.jenis_barang,
            (SELECT COALESCE(SUM(p.sisa),0) FROM peminjaman p WHERE p.barang_id = b.id AND p.status = 'Dipinjam') AS dipinjam,
            (SELECT COALESCE(SUM(k.jumlah),0) FROM kerusakan k WHERE k.barang_id = b.id AND k.status NOT IN ('Selesai','Rusak Permanen')) AS rusak
         FROM barang b WHERE b.aktif = 1 ORDER BY b.nama_barang ASC");
}

/** Pilihan barang untuk <select>, dengan keterangan tersedia. */
function opsi_barang(array $rows, int $selected = 0, bool $hanyaTersedia = false, string $jenis = ''): string
{
    $html = '<option value="">-- Pilih barang --</option>';
    foreach ($rows as $b) {
        $tersedia = (int)$b['stok_total'] - (int)$b['dipinjam'] - (int)$b['rusak'];
        if ($hanyaTersedia && $tersedia <= 0) continue;
        if ($jenis !== '' && ($b['jenis_barang'] ?? '') !== $jenis) continue;
        $sel = ((int)$b['id'] === $selected) ? ' selected' : '';
        $html .= '<option value="' . (int)$b['id'] . '" data-tersedia="' . $tersedia . '"' . $sel . '>'
              . e($b['kode_barang'] . ' — ' . $b['nama_barang'] . ' (tersedia ' . $tersedia . ' ' . $b['satuan'] . ')')
              . '</option>';
    }
    return $html;
}

/** Opsi <option> sederhana dari daftar [value => label]. */
function opsi_html(array $daftar, $selected = null, string $placeholder = ''): string
{
    $html = $placeholder !== '' ? '<option value="">' . e($placeholder) . '</option>' : '';
    foreach ($daftar as $val => $label) {
        $sel = ((string)$val === (string)$selected) ? ' selected' : '';
        $html .= '<option value="' . e((string)$val) . '"' . $sel . '>' . e((string)$label) . '</option>';
    }
    return $html;
}

/** Jumlah ringkasan notifikasi untuk topbar (dihitung sekali per request). */
function ringkasan_notifikasi(): array
{
    static $cache = null;
    if ($cache !== null) return $cache;
    $con = db();
    $role = user_role();
    $r = db_row($con,
        "SELECT
            (SELECT COUNT(*) FROM peminjaman WHERE status = 'Dipinjam' AND tanggal_rencana_kembali < CURDATE()) AS terlambat,
            (SELECT COUNT(*) FROM kerusakan WHERE status = 'Menunggu Persetujuan') AS rusak_tunggu,
            (SELECT COUNT(*) FROM barang_masuk WHERE status = 'Menunggu') AS masuk_tunggu,
            (SELECT COUNT(*) FROM penghapusan WHERE status = 'Diusulkan') AS usul_tunggu,
            (SELECT COUNT(*) FROM barang b WHERE b.aktif = 1 AND (b.stok_total
                - (SELECT COALESCE(SUM(p.sisa),0) FROM peminjaman p WHERE p.barang_id = b.id AND p.status = 'Dipinjam')
                - (SELECT COALESCE(SUM(k.jumlah),0) FROM kerusakan k WHERE k.barang_id = b.id AND k.status NOT IN ('Selesai','Rusak Permanen'))) <= b.stok_minimum) AS menipis");
    $penyetuju = in_array($role, ['admin', 'kepala_sekolah'], true);
    $cache = [
        // Kepala Sekolah tidak menindak peminjaman; operator tidak menyetujui apa pun
        'terlambat' => $role === 'kepala_sekolah' ? 0 : (int)$r['terlambat'],
        'menunggu'  => $penyetuju ? (int)$r['rusak_tunggu'] + (int)$r['masuk_tunggu'] + (int)$r['usul_tunggu'] : 0,
        'menipis'   => $role === 'kepala_sekolah' ? 0 : (int)$r['menipis'],
    ];
    return $cache;
}

/** Semua pengaturan sekolah sebagai array [kunci => nilai]. */
function pengaturan_all(): array
{
    $out = [];
    foreach (db_all(db(), "SELECT kunci, nilai FROM pengaturan") as $r) $out[$r['kunci']] = (string)$r['nilai'];
    return $out;
}


// ---------------------------------------------------------------------------
// Jumlah per ruangan. Jumlah seluruh ruangan = stok_total. Unit yang sedang dipinjam
// atau rusak tetap tercatat di ruangan asalnya, tetapi tidak tersedia.
// ---------------------------------------------------------------------------

/** Ubah jumlah fisik di satu ruangan (delta +/-). Tidak boleh di bawah nol. */
function stok_lokasi_ubah(mysqli $con, int $barang, int $lokasi, int $delta): void
{
    if ($delta === 0) return;
    db_exec($con, "INSERT INTO stok_lokasi (barang_id, lokasi_id, jumlah) VALUES (?, ?, 0) ON DUPLICATE KEY UPDATE jumlah = jumlah", 'ii', [$barang, $lokasi]);
    $cur = (int)db_value($con, "SELECT jumlah FROM stok_lokasi WHERE barang_id = ? AND lokasi_id = ? FOR UPDATE", 'ii', [$barang, $lokasi]);
    if ($cur + $delta < 0) {
        throw new AppException('Jumlah di ruangan tersebut tidak mencukupi.');
    }
    db_exec($con, "UPDATE stok_lokasi SET jumlah = jumlah + ? WHERE barang_id = ? AND lokasi_id = ?", 'iii', [$delta, $barang, $lokasi]);
}

/** Rincian satu barang di satu ruangan: jumlah, dipinjam, rusak, dan tersedia. */
function lokasi_stat(mysqli $con, int $barang, int $lokasi): array
{
    $r = db_row($con,
        "SELECT COALESCE((SELECT jumlah FROM stok_lokasi WHERE barang_id = ? AND lokasi_id = ?), 0) AS stok,
            (SELECT COALESCE(SUM(p.sisa), 0) FROM peminjaman p WHERE p.barang_id = ? AND p.lokasi_asal_id = ? AND p.status = 'Dipinjam') AS dipinjam,
            (SELECT COALESCE(SUM(k.jumlah), 0) FROM kerusakan k WHERE k.barang_id = ? AND k.lokasi_id = ? AND k.status NOT IN ('Selesai','Rusak Permanen')) AS rusak",
        'iiiiii', [$barang, $lokasi, $barang, $lokasi, $barang, $lokasi]);
    $stok = (int)$r['stok']; $dip = (int)$r['dipinjam']; $rus = (int)$r['rusak'];
    return ['stok' => $stok, 'dipinjam' => $dip, 'rusak' => $rus, 'tersedia' => $stok - $dip - $rus];
}

/** Pastikan unit yang diminta tersedia di ruangan tertentu. */
function lokasi_cek_tersedia(mysqli $con, int $barang, int $lokasi, int $qty): void
{
    $s = lokasi_stat($con, $barang, $lokasi);
    if ($qty > $s['tersedia']) {
        $nama = db_value($con, "SELECT nama FROM lokasi WHERE id = ?", 'i', [$lokasi]);
        throw new AppException("Di {$nama} hanya tersedia {$s['tersedia']} unit (sebagian sedang dipinjam atau rusak).");
    }
}

/** Daftar ruangan untuk satu barang (untuk dropdown & detail). */
function barang_per_lokasi(mysqli $con, int $barang): array
{
    return db_all($con,
        "SELECT l.id, l.nama, l.penanggung_jawab, sl.jumlah AS stok,
            (SELECT COALESCE(SUM(p.sisa),0) FROM peminjaman p WHERE p.barang_id = sl.barang_id AND p.lokasi_asal_id = l.id AND p.status = 'Dipinjam') AS dipinjam,
            (SELECT COALESCE(SUM(k.jumlah),0) FROM kerusakan k WHERE k.barang_id = sl.barang_id AND k.lokasi_id = l.id AND k.status NOT IN ('Selesai','Rusak Permanen')) AS rusak
         FROM stok_lokasi sl JOIN lokasi l ON l.id = sl.lokasi_id
         WHERE sl.barang_id = ? ORDER BY l.nama", 'i', [$barang]);
}
