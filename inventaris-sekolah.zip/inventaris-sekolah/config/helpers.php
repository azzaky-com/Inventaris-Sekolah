<?php
// config/helpers.php — fungsi bantu umum: input, output, URL, flash, CSRF, format.

/** Exception untuk kesalahan yang aman ditampilkan langsung ke pengguna. */
class AppException extends RuntimeException {}

function db(): mysqli
{
    return $GLOBALS['con'];
}

/** Escape HTML. Gunakan untuk SEMUA data yang ditampilkan. */
function e($v): string
{
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Path dasar aplikasi, mis. "/inventaris-sekolah/" (selalu diakhiri "/"). */
function base_url(): string
{
    static $base = null;
    if ($base !== null) return $base;

    $root = str_replace('\\', '/', dirname(__DIR__));
    $doc  = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/') : '';

    if ($doc !== '' && stripos($root, $doc) === 0) {
        $path = substr($root, strlen($doc));
    } else {
        // Cadangan: turunkan dari SCRIPT_NAME
        $dir  = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
        if (in_array(basename($dir), ['print', 'modules', 'layout', 'config'], true)) $dir = dirname($dir);
        $path = rtrim($dir, '/');
    }
    $base = rtrim($path, '/') . '/';
    return $base;
}

/** URL ke halaman modul, mis. url('barang', ['aksi' => 'edit', 'id' => 5]). */
function url(string $m = 'dashboard', array $params = []): string
{
    return base_url() . '?' . http_build_query(array_merge(['m' => $m], $params));
}

/** URL absolut (dipakai untuk QR code). */
function url_absolut(string $path = ''): string
{
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') == 443);
    $host  = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return ($https ? 'https' : 'http') . '://' . $host . base_url() . $path;
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/** Halaman saat ini (untuk redirect setelah POST). */
function url_sekarang(): string
{
    return base_url() . '?' . http_build_query($_GET);
}

// Flash message ------------------------------------------------------------

function flash(string $tipe, string $pesan): void
{
    $_SESSION['flash'][] = ['tipe' => $tipe, 'pesan' => $pesan];
}

function flash_ambil(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

// Nilai formulir lama (dikembalikan saat validasi gagal) -------------------

function old_set(array $data): void
{
    $_SESSION['old'] = $data;
}

function old(string $key, $default = '')
{
    return $_SESSION['old'][$key] ?? $default;
}

function old_bersihkan(): void
{
    unset($_SESSION['old']);
}

// CSRF ---------------------------------------------------------------------

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(csrf_token()) . '">';
}

function csrf_cek(): void
{
    $token = $_POST['_token'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        throw new AppException('Sesi formulir sudah berakhir. Silakan muat ulang halaman lalu coba lagi.');
    }
}

// Pembersih input ----------------------------------------------------------

/** String bersih: buang karakter kontrol, trim, batasi panjang. */
function str_bersih($v, int $maks = 255): string
{
    if (!is_string($v)) return '';
    $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $v);
    $v = trim($v);
    return mb_substr($v, 0, $maks, 'UTF-8');
}

/** Angka bulat dari input. Titik/koma pemisah ribuan dibuang: "1.200" -> 1200. */
function angka_bersih($v): int
{
    return (int)preg_replace('/\D/', '', (string)$v);
}

/** Tanggal format Y-m-d yang valid, atau null. */
function tanggal_valid($v): ?string
{
    if (!is_string($v) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) return null;
    [$y, $m, $d] = array_map('intval', explode('-', $v));
    return checkdate($m, $d, $y) ? $v : null;
}

/** Ambil dan validasi kode/keterangan opsional dari $_POST. */
function post_str(string $key, int $maks = 255): string
{
    return str_bersih($_POST[$key] ?? '', $maks);
}

function post_int(string $key): int
{
    return angka_bersih($_POST[$key] ?? '');
}

function get_int(string $key): int
{
    return angka_bersih($_GET[$key] ?? '');
}

function get_str(string $key, int $maks = 255): string
{
    return str_bersih($_GET[$key] ?? '', $maks);
}

// Format tampilan ----------------------------------------------------------

function rupiah($n): string
{
    return 'Rp ' . number_format((float)$n, 0, ',', '.');
}

function angka($n): string
{
    return number_format((float)$n, 0, ',', '.');
}

function tgl_indo(?string $tgl, bool $panjang = false): string
{
    if (!$tgl) return '-';
    $ts = strtotime($tgl);
    if ($ts === false) return '-';
    $bulan   = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    $singkat = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    $d = (int)date('j', $ts);
    $m = (int)date('n', $ts);
    $y = date('Y', $ts);
    return $panjang ? "$d {$bulan[$m]} $y" : sprintf('%02d %s %s', $d, $singkat[$m], $y);
}

function waktu_indo(?string $waktu): string
{
    if (!$waktu) return '-';
    return tgl_indo($waktu) . ' ' . date('H:i', strtotime($waktu));
}

/** Selisih hari dari hari ini (positif = masih di masa depan). */
function selisih_hari(?string $tgl): ?int
{
    if (!$tgl) return null;
    $today = new DateTime('today');
    $target = new DateTime($tgl);
    return (int)$today->diff($target)->format('%r%a');
}

/** Badge status berwarna (gaya pastel). */
function badge(string $teks, string $warna = 'secondary'): string
{
    return '<span class="badge-soft badge-' . e($warna) . '">' . e($teks) . '</span>';
}

function badge_status(string $status): string
{
    $peta = [
        'Dipinjam'               => 'warning',
        'Dikembalikan'           => 'success',
        'Hilang'                 => 'danger',
        'Terlambat'              => 'danger',
        'Dilaporkan'             => 'info',
        'Diperiksa'              => 'primary',
        'Menunggu Persetujuan'   => 'warning',
        'Dalam Perbaikan'        => 'purple',
        'Selesai'                => 'success',
        'Rusak Permanen'         => 'danger',
        'Draft'                  => 'secondary',
        'Baik'                   => 'success',
        'Ada Lecet'              => 'warning',
        'Perlu Perhatian'        => 'danger',
        'Masuk'                  => 'success',
        'Keluar'                 => 'secondary',
    ];
    return badge($status, $peta[$status] ?? 'secondary');
}

/** Teks ringkas dengan batas panjang. */
function potong(?string $teks, int $panjang = 60): string
{
    $teks = (string)$teks;
    return mb_strlen($teks) > $panjang ? mb_substr($teks, 0, $panjang - 1) . '…' : $teks;
}

/** Tahun yang dapat dipilih pada form. */
function daftar_tahun(): array
{
    $now = (int)date('Y');
    $out = [];
    for ($y = $now + 1; $y >= 2000; $y--) $out[] = $y;
    return $out;
}

/** Terjemahkan error MySQL yang umum menjadi pesan ramah. Null bila tidak dikenali. */
function db_pesan(mysqli_sql_exception $e): ?string
{
    switch ((int)$e->getCode()) {
        case 1062: return 'Data dengan nilai yang sama sudah terdaftar. Nama/kode harus unik.';
        case 1451: return 'Data tidak dapat dihapus karena masih digunakan oleh data lain.';
        case 1452: return 'Data acuan tidak ditemukan. Periksa pilihan kategori, merek, atau lokasi.';
    }
    return null;
}

/** Kode laporan kerusakan, mis. KR-0003. */
function rusak_kode(int $id): string
{
    return 'KR-' . str_pad((string)$id, 4, '0', STR_PAD_LEFT);
}

/** Laju pemakaian (unit/hari): dua desimal, tanpa nol berlebih. */
function angka_rate($n): string
{
    $s = number_format((float)$n, 2, ',', '.');
    return rtrim(rtrim($s, '0'), ',') ?: '0';
}
