<?php
// login.php — halaman masuk aplikasi.
require_once __DIR__ . '/config/bootstrap.php';

if (auth_user() !== null) {
    redirect(url('dashboard'));
}

$pesan = null;
$tipe  = 'error';
if (($_GET['timeout'] ?? '') === '1') { $pesan = 'Sesi Anda telah berakhir karena tidak aktif. Silakan masuk kembali.'; $tipe = 'info'; }
if (($_GET['akun'] ?? '') === 'nonaktif') { $pesan = 'Akun Anda tidak aktif. Hubungi administrator.'; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        csrf_cek();
        $username = str_bersih($_POST['username'] ?? '', 30);
        $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
        if ($username === '' || $password === '') {
            throw new AppException('Username dan password wajib diisi.');
        }
        login_proses($username, $password);
        redirect(login_tujuan());
    } catch (AppException $ex) {
        $pesan = $ex->getMessage();
    } catch (Throwable $ex) {
        error_log('[login] ' . $ex->getMessage());
        $pesan = 'Terjadi kesalahan. Silakan coba lagi.';
    }
}
$oldUser = str_bersih($_POST['username'] ?? '', 30);
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Masuk · <?= e(APP_NAME) ?></title>
    <link rel="icon" type="image/png" href="<?= e(base_url()) ?>assets/img/favicon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(base_url()) ?>assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= e(base_url()) ?>assets/vendor/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?= e(base_url()) ?>assets/css/app.css?v=<?= e(APP_VERSION) ?>">
</head>
<body class="login-body">
<div class="login-wrap">
    <section class="login-hero">
        <div class="hero-inner">
            <span class="brand-mark brand-mark-lg"><i class="fas fa-warehouse"></i></span>
            <h2>Inventaris Sekolah</h2>
            <p>Kelola aset dan barang sekolah dengan rapi: jumlah real-time, peminjaman, kerusakan, hingga opname barang.</p>
            <ul class="hero-list">
                <li><i class="fas fa-check-circle"></i> Kartu persediaan & jejak audit lengkap</li>
                <li><i class="fas fa-check-circle"></i> Persetujuan pembelian, perbaikan &amp; penghapusan</li>
                <li><i class="fas fa-check-circle"></i> Label QR untuk setiap aset</li>
            </ul>
            <img class="hero-img" src="<?= e(base_url()) ?>assets/img/icon.png" alt="Ilustrasi inventaris">
        </div>
    </section>

    <section class="login-form-side">
        <div class="login-card">
            <div class="login-head">
                <h3>Selamat datang 👋</h3>
                <p class="text-muted">Masuk untuk melanjutkan ke dashboard inventaris.</p>
            </div>

            <?php if ($pesan): ?>
                <div class="alert alert-<?= $tipe === 'info' ? 'info' : 'danger' ?> alert-soft" role="alert">
                    <i class="fas fa-exclamation-circle mr-1"></i> <?= e($pesan) ?>
                </div>
            <?php endif; ?>

            <form method="post" autocomplete="off" novalidate>
                <?= csrf_field() ?>
                <div class="form-group">
                    <label for="username">Username</label>
                    <div class="input-icon">
                        <i class="fas fa-user"></i>
                        <input type="text" class="form-control" id="username" name="username" value="<?= e($oldUser) ?>" maxlength="30" required autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" class="form-control" id="password" name="password" maxlength="200" required>
                        <button class="btn-eye" type="button" id="togglePass" aria-label="Tampilkan password"><i class="fas fa-eye"></i></button>
                    </div>
                </div>
                <button class="btn btn-primary btn-block btn-lg" type="submit">
                    <i class="fas fa-sign-in-alt mr-1"></i> Masuk
                </button>
            </form>

            <p class="text-muted small text-center mt-4 mb-0">
                Lupa password? Minta Administrator untuk mengatur ulang.
            </p>
        </div>
    </section>
</div>
<script src="<?= e(base_url()) ?>assets/vendor/jquery/jquery.min.js"></script>
<script>
$('#togglePass').on('click', function () {
    var $p = $('#password'), show = $p.attr('type') === 'password';
    $p.attr('type', show ? 'text' : 'password');
    $(this).find('i').toggleClass('fa-eye fa-eye-slash');
});
</script>
</body>
</html>
