<?php
session_start();
include('config/conn.php');

$base_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
$base_url .= "://".$_SERVER['HTTP_HOST'];
$base_url .= str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']);

if(isset($_POST['cek_login'])){
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $error = '';

    if(empty($username) || empty($password)){
        $error = 'Harap isi username dan password';
    } else {
        $user = mysqli_query($con,"SELECT * FROM users WHERE username='$username'") or die(mysqli_error($con));
        if(mysqli_num_rows($user) > 0){
            $data = mysqli_fetch_array($user);
            if(password_verify($password, $data['password'])){
                $_SESSION['iduser']   = $data['id_users'];
                $_SESSION['username'] = $data['username'];
                $_SESSION['fullname'] = $data['nama'];
                $_SESSION['level']    = $data['level'];
                header("Location:".$base_url);
                exit;
            } else {
                $error = 'Password anda salah';
            }
        } else {
            $error = 'Username tidak terdaftar';
        }
    }
    $_SESSION['error'] = $error;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>INVENTARIS SMP NEGERI 8 MEDAN</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="icon" type="image/png" href="<?=$base_url;?>assets/img/favicon.png">
<link href="<?=$base_url;?>assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700&family=Poppins:wght@200;400;600&display=swap" rel="stylesheet">

<style>
/* ===== GLOBAL TECH BACKGROUND ===== */
body {
    margin: 0;
    height: 100vh;
    overflow: hidden;
    font-family: 'Poppins', sans-serif;
    background: radial-gradient(circle at top, #051c34 0%, #020c19 70%);
    position: relative;
}

/* Particle Animation */
.particles {
    width: 100%;
    height: 100%;
    position: absolute;
    overflow: hidden;
    top: 0;
    left: 0;
}
.particle {
    position: absolute;
    width: 3px;
    height: 3px;
    background: #00d2ff;
    border-radius: 50%;
    animation: float 6s infinite linear;
    opacity: 0.7;
}
@keyframes float {
    from { transform: translateY(100vh); }
    to { transform: translateY(-10vh); }
}

/* ===== CARD GLASS FUTURISTIC ===== */
.login-box {
    width: 420px;
    padding: 40px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(255,255,255,0.08);
    backdrop-filter: blur(15px);
    border-radius: 20px;
    border: 1px solid rgba(0,255,255,0.3);
    box-shadow: 0 0 25px rgba(0,255,255,0.3);
    animation: fadeIn 1.2s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translate(-50%, -40%); }
    to   { opacity: 1; transform: translate(-50%, -50%); }
}

.title {
    text-align: center;
    font-family: 'Orbitron', sans-serif;
    font-size: 26px;
    letter-spacing: 2px;
    color: #00eaff;
    margin-bottom: 20px;
    text-shadow: 0 0 10px #00d2ff;
}

.input-tech {
    width: 100%;
    padding: 14px 18px;
    margin-bottom: 18px;
    background: rgba(255,255,255,.05);
    border: 1px solid rgba(0,255,255,.4);
    border-radius: 50px;
    color: #fff;
    outline: none;
    transition: .3s;
}
.input-tech:focus {
    background: rgba(0,255,255,.15);
    box-shadow: 0 0 12px #00eaff;
}

.input-tech::placeholder { color: #b8e8ff; }

/* ===== BUTTON ===== */
.btn-login {
    width: 100%;
    padding: 14px;
    background: linear-gradient(90deg, #00eaff, #007bff);
    border: none;
    border-radius: 50px;
    font-size: 16px;
    color: #001018;
    cursor: pointer;
    transition: .3s;
    font-weight: bold;
    text-transform: uppercase;
}
.btn-login:hover {
    transform: scale(1.06);
    filter: brightness(1.3);
    box-shadow: 0 0 18px #00eaff;
}

/* Glow Input while typing */
.input-tech:focus + .glow {
    opacity: 1;
}
</style>
</head>
<body>

<div class="particles">
    <?php for($i=0; $i<60; $i++): ?>
        <div class="particle" style="left:<?=rand(0,100)?>%;animation-duration:<?=rand(5,10)?>s;"></div>
    <?php endfor; ?>
</div>

<div class="login-box">
    <div class="title">
    UPT SMP NEGERI 8 MEDAN <br>
    <span style="font-size:14px; color:#8ee9ff; text-shadow:0 0 6px #00eaff;">
        Akreditasi A
    </span>
</div>


    <form method="post" autocomplete="off">
        <input type="text" name="username" class="input-tech" placeholder="Username" required>
        <input type="password" name="password" class="input-tech" placeholder="Password" required>
        <button type="submit" name="cek_login" class="btn-login">Masuk</button>
    </form>
</div>

</body>
</html>
