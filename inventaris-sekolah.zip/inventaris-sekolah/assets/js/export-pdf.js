// Robust export-pdf.js (safe checks for jsPDF + AutoTable) 
// Place this AFTER the library includes shown above.

document.addEventListener('DOMContentLoaded', function () {
  var exportBtn = document.getElementById('exportPdfBtn');
  if (!exportBtn) return;

  exportBtn.addEventListener('click', async function () {
    var btn = this;
    var oldHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menghasilkan PDF...';

    try {
      // Ensure jsPDF is available (UMD exposes window.jspdf and we mapped window.jsPDF)
      var jsPDFConstructor = window.jsPDF || (window.jspdf && window.jspdf.jsPDF);
      if (typeof jsPDFConstructor === 'undefined') throw new Error('jsPDF tidak ditemukan. Pastikan jspdf.umd.min.js dimuat.');

      // Ensure AutoTable is available (plugin attaches autoTable to jsPDF prototype)
      // There are multiple ways the plugin exposes itself; check common ones:
      var hasAutoTable = false;
      try {
        var testDoc = new jsPDFConstructor();
        hasAutoTable = typeof testDoc.autoTable === 'function';
      } catch(e) {
        hasAutoTable = false;
      }

      if (!hasAutoTable) {
        throw new Error('AutoTable plugin tidak ditemukan. Pastikan jspdf.plugin.autotable.min.js dimuat setelah jsPDF dan global jsPDF diekspos.');
      }

      // Build PDF using autotable
      const doc = new jsPDFConstructor('p', 'mm', 'a4');
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 10;
      doc.setFontSize(14);
      doc.text('Daftar Barang Rusak', margin, 12);

      var table = document.querySelector('#dataTable');
      if (!table) throw new Error('Tabel #dataTable tidak ditemukan.');

      // Build columns skipping AKSI column
      var ths = table.querySelectorAll('thead th');
      var columns = [];
      var skipIdx = [];
      ths.forEach(function(th, i){
        var txt = (th.innerText || th.textContent || '').trim();
        if (txt.toLowerCase() === 'aksi') { skipIdx.push(i); return; }
        columns.push({ header: txt || ('col'+i), dataKey: 'c'+i });
      });

      // Build rows
      var rows = [];
      table.querySelectorAll('tbody tr').forEach(function(tr){
        var tds = tr.querySelectorAll('td');
        if (!tds || tds.length === 0) return;
        var row = {};
        var allEmpty = true;
        for (var c=0;c<tds.length;c++){
          if (skipIdx.indexOf(c) !== -1) continue;
          var key = 'c' + c;
          var txt = (tds[c].innerText || tds[c].textContent || '').trim();
          if (txt) allEmpty = false;
          row[key] = txt;
        }
        if (!allEmpty) rows.push(row);
      });

      // prepare autoTable head/body
      var head = [columns.map(function(c){ return c.header; })];
      var body = rows.map(function(r){
        return columns.map(function(c){ return r[c.dataKey] || ''; });
      });

      // Call autoTable
      doc.autoTable({
        startY: 18,
        head: head,
        body: body,
        theme: 'striped',
        styles: { fontSize: 9, cellPadding: 2, overflow: 'linebreak' },
        headStyles: { fillColor: [0, 170, 200], textColor: 255 },
        margin: { left: margin, right: margin },
        didDrawPage: function (data) {
          var pageCount = doc.internal.getNumberOfPages();
          var pageCurrent = doc.internal.getCurrentPageInfo().pageNumber;
          var footerText = 'Halaman ' + pageCurrent + ' / ' + pageCount;
          doc.setFontSize(9);
          doc.setTextColor(120);
          doc.text(footerText, pageWidth - margin - doc.getTextWidth(footerText), pageHeight - 8);
        },
        bodyStyles: { valign: 'top' },
        columnStyles: { 0: { cellWidth: 12 } } // NO column narrow
      });

      // Try auto-print via opening PDF in new tab and calling print()
      try {
        doc.autoPrint();
        var url = doc.output('dataurlstring');
        var w = window.open(url, '_blank');
        setTimeout(function(){
          try { w.focus(); w.print(); } catch(e){ /* maybe blocked */ }
        }, 800);
      } catch (errAuto) {
        // fallback: save PDF
        doc.save('Daftar_Barang_Rusak_' + (new Date()).toISOString().slice(0,10) + '.pdf');
      }

    } catch (err) {
      console.error(err);
      alert('Gagal mengekspor ke PDF: ' + (err.message || err));
    } finally {
      btn.disabled = false;
      btn.innerHTML = oldHtml;
    }
  });
});