/* Inventaris Sekolah — skrip umum */
(function ($) {
  'use strict';

  // ---- Tema terang / gelap ----
  function setTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    try { localStorage.setItem('inv-tema', t); } catch (e) {}
    $('#themeToggle i').attr('class', t === 'dark' ? 'fas fa-sun' : 'fas fa-moon');
  }
  setTheme(document.documentElement.getAttribute('data-theme') || 'light');
  $('#themeToggle').on('click', function () {
    setTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
  });

  // ---- Sidebar ----
  var isMobile = function () { return window.innerWidth < 992; };
  try {
    if (!isMobile() && localStorage.getItem('inv-sidebar') === 'mini') $('body').addClass('sidebar-collapsed');
  } catch (e) {}
  $('#sidebarToggle').on('click', function () {
    if (isMobile()) {
      $('body').toggleClass('sidebar-open');
    } else {
      $('body').toggleClass('sidebar-collapsed');
      try { localStorage.setItem('inv-sidebar', $('body').hasClass('sidebar-collapsed') ? 'mini' : 'full'); } catch (e) {}
    }
  });
  $('#sidebarBackdrop').on('click', function () { $('body').removeClass('sidebar-open'); });

  // ---- Dropdown ruangan sesuai barang (menampilkan jumlah tersedia) ----
  var BASE = document.body.getAttribute('data-base') || '/';
  window.isiLokasi = function (barangId, selector, hint) {
    var $s = $(selector);
    $s.empty();
    if (!barangId) { $s.append('<option value="">-- Pilih barang dulu --</option>'); if (hint) $(hint).text(''); return; }
    $.getJSON(BASE + 'api.php', { aksi: 'lokasi', barang_id: barangId }, function (d) {
      var daftar = d.lokasi || [];
      $s.append('<option value="">-- Pilih ruangan --</option>');
      daftar.forEach(function (l) {
        var opt = $('<option>').val(l.id).text(l.nama + ' (tersedia ' + l.tersedia + ')');
        if (l.tersedia <= 0) opt.prop('disabled', true).text(l.nama + ' (habis)');
        $s.append(opt);
      });
      if (hint) $(hint).text(daftar.length ? '' : 'Barang ini belum tersimpan di ruangan mana pun.');
    });
  };

  // ---- Notifikasi (flash message) ----
  var Toast = window.Swal ? Swal.mixin({
    toast: true, position: 'top-end', showConfirmButton: false, timer: 3800, timerProgressBar: true,
  }) : null;
  try {
    var flashes = JSON.parse(document.getElementById('flash-data').textContent || '[]');
    flashes.forEach(function (f, i) {
      var icon = f.tipe === 'error' ? 'error' : (f.tipe === 'warning' ? 'warning' : (f.tipe === 'info' ? 'info' : 'success'));
      if (!Toast) return;
      if (f.tipe === 'error' && flashes.length === 1) {
        Swal.fire({ icon: 'error', title: 'Perhatian', text: f.pesan, confirmButtonText: 'Mengerti', confirmButtonColor: '#2563eb' });
      } else {
        setTimeout(function () { Toast.fire({ icon: icon, title: f.pesan }); }, 120 * i);
      }
    });
  } catch (e) {}

  // ---- Konfirmasi aksi berbahaya ----
  $(document).on('submit', 'form[data-confirm]', function (ev) {
    var form = this;
    if (form.dataset.confirmed === '1') return;
    ev.preventDefault();
    Swal.fire({
      title: 'Yakin?', text: $(form).data('confirm'), icon: 'warning', showCancelButton: true,
      confirmButtonText: 'Ya, lanjutkan', cancelButtonText: 'Batal',
      confirmButtonColor: '#dc2626', cancelButtonColor: '#64748b', reverseButtons: true,
    }).then(function (r) {
      if (r.isConfirmed) { form.dataset.confirmed = '1'; form.submit(); }
    });
  });
  $(document).on('click', 'a[data-confirm]', function (ev) {
    var href = this.getAttribute('href');
    ev.preventDefault();
    Swal.fire({
      title: 'Yakin?', text: $(this).data('confirm'), icon: 'warning', showCancelButton: true,
      confirmButtonText: 'Ya, lanjutkan', cancelButtonText: 'Batal', confirmButtonColor: '#dc2626', reverseButtons: true,
    }).then(function (r) { if (r.isConfirmed) window.location.href = href; });
  });

  // ---- Validasi formulir Bootstrap ----
  $(document).on('submit', 'form.needs-validation', function (ev) {
    if (!this.checkValidity()) {
      ev.preventDefault(); ev.stopPropagation();
    }
    $(this).addClass('was-validated');
  });

  // ---- Select2 ----
  $('select.select2').each(function () {
    var $s = $(this);
    var $modal = $s.closest('.modal');
    $s.select2({
      width: '100%',
      placeholder: $s.data('placeholder') || 'Pilih…',
      allowClear: !!$s.data('allow-clear'),
      dropdownParent: $modal.length ? $modal : $(document.body),
      language: { noResults: function () { return 'Data tidak ditemukan'; } },
    });
  });

  // ---- Mask angka (rupiah) ----
  $('[data-mask="rupiah"]').each(function () {
    if ($.fn.mask) $(this).mask('#.##0', { reverse: true });
  });

  // ---- DataTables ----
  if ($.fn.DataTable) {
    var bahasa = {
      search: 'Cari:', lengthMenu: 'Tampilkan _MENU_ data', zeroRecords: 'Tidak ada data yang cocok',
      info: 'Menampilkan _START_–_END_ dari _TOTAL_ data', infoEmpty: 'Tidak ada data',
      infoFiltered: '(disaring dari _MAX_ data)', paginate: { first: 'Awal', last: 'Akhir', next: '›', previous: '‹' },
    };
    $('table.datatable').each(function () {
      var $t = $(this);
      var order = $t.data('order');
      var orderOpt = [];
      if (order) {
        var p = String(order).split(':');
        orderOpt = [[parseInt(p[0], 10), p[1] || 'asc']];
      }
      var ncol = $t.find('thead th').length;
      var noSort = ($t.data('nosort') || '').toString().split(',').filter(Boolean).map(Number).filter(function (i) { return i < ncol; });
      $t.DataTable({
        language: bahasa,
        pageLength: $t.data('pagelength') || 15,
        lengthMenu: [10, 15, 25, 50, 100],
        order: (orderOpt.length && orderOpt[0][0] < ncol) ? orderOpt : [],
        columnDefs: noSort.length ? [{ orderable: false, targets: noSort }] : [],
        autoWidth: false,
      });
    });
  }

  // ---- Tooltip & cetak ----
  $('[data-toggle="tooltip"]').tooltip();
  $(document).on('click', '[data-print]', function () { window.print(); });

  // ---- Batas input angka (hint tersedia) ----
  $(document).on('change', 'select[data-max-target]', function () {
    var $opt = $(this).find('option:selected');
    var max = parseInt($opt.data('tersedia'), 10);
    var target = $(this).data('max-target');
    if (!isNaN(max)) {
      $(target).attr('max', max).attr('placeholder', 'maks ' + max);
      $($(this).data('hint')).text(max > 0 ? 'Tersedia untuk dipinjam/keluar: ' + max : 'Unit tersedia habis');
    }
  });
  $('select[data-max-target]').trigger('change');

  // Auto-hilangkan alert statis
  setTimeout(function () { $('.alert[data-auto-hide]').fadeOut(); }, 6000);
})(jQuery);
