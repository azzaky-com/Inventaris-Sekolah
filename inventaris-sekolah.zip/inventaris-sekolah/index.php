<?php
// index.php — pintu masuk (router) aplikasi. Semua halaman modul dibuka lewat ?m=...
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/layout/layout.php';

require_login();

/** Peta modul: file, judul, dan izin akses. */
$ROUTES = [
    'dashboard'   => ['file' => 'dashboard',       'title' => 'Beranda',                  'perm' => 'dashboard'],
    'barang'      => ['file' => 'barang', 'title' => 'Data Barang', 'perm' => 'master.lihat', 'aksi_perm' => ['tambah' => 'barang.kelola', 'edit' => 'barang.kelola']],
    'kategori'    => ['file' => 'referensi', 'title' => 'Kategori Barang', 'perm' => 'master.lihat', 'tipe' => 'kategori', 'aksi_perm' => ['edit' => 'referensi.kelola']],
    'merek'       => ['file' => 'referensi', 'title' => 'Merek', 'perm' => 'master.lihat', 'tipe' => 'merek', 'aksi_perm' => ['edit' => 'referensi.kelola']],
    'lokasi'      => ['file' => 'referensi', 'title' => 'Lokasi / Ruangan', 'perm' => 'master.lihat', 'tipe' => 'lokasi', 'aksi_perm' => ['edit' => 'referensi.kelola']],
    'masuk'       => ['file' => 'transaksi_masuk', 'fn' => 'masuk', 'title' => 'Barang Masuk', 'perm' => 'transaksi.lihat', 'aksi_perm' => ['tambah' => 'transaksi.input', 'edit' => 'transaksi.input']],
    'keluar'      => ['file' => 'transaksi_keluar', 'fn' => 'keluar', 'title' => 'Barang Keluar', 'perm' => 'transaksi.lihat', 'aksi_perm' => ['tambah' => 'transaksi.input']],
    'peminjaman'  => ['file' => 'peminjaman', 'title' => 'Peminjaman Barang', 'perm' => 'transaksi.lihat', 'aksi_perm' => ['tambah' => 'transaksi.input']],
    'kerusakan'   => ['file' => 'kerusakan', 'title' => 'Kerusakan & Perbaikan', 'perm' => 'transaksi.lihat', 'aksi_perm' => ['tambah' => 'transaksi.input']],
    'opname'      => ['file' => 'opname', 'title' => 'Opname barang', 'perm' => 'transaksi.lihat', 'aksi_perm' => ['tambah' => 'transaksi.input']],
    'laporan'     => ['file' => 'laporan',         'title' => 'Laporan & Cetak',          'perm' => 'laporan.lihat'],
    'aset'        => ['file' => 'aset',            'title' => 'Nilai Aset & Penyusutan',  'perm' => 'nilai.lihat'],
    'persetujuan' => ['file' => 'persetujuan',     'title' => 'Persetujuan',              'perm' => 'kerusakan.setujui'],
    'pemeliharaan'=> ['file' => 'pemeliharaan',    'title' => 'Pemeliharaan Data',        'perm' => 'pengaturan.kelola'],
    'pindah'      => ['file' => 'pemindahan',      'title' => 'Pindah Ruangan',           'perm' => 'transaksi.lihat', 'aksi_perm' => ['pindah' => 'transaksi.input']],
    'penghapusan' => ['file' => 'penghapusan',     'title' => 'Penghapusan Aset',         'perm' => 'transaksi.lihat', 'aksi_perm' => ['usul' => 'transaksi.input']],
    'pindai'      => ['file' => 'pindai',          'title' => 'Pindai Aset',              'perm' => 'master.lihat'],
    'cari'        => ['file' => 'cari',            'title' => 'Pencarian',                'perm' => 'master.lihat'],
    'tahun'       => ['file' => 'tahun',           'title' => 'Tahun Ajaran & Tutup Buku', 'perm' => 'tahun.kelola'],
    'pengguna'    => ['file' => 'pengguna',        'title' => 'Pengguna',                 'perm' => 'pengguna.kelola'],
    'log'         => ['file' => 'log',             'title' => 'Log Aktivitas',            'perm' => 'log.lihat'],
    'pengaturan'  => ['file' => 'pengaturan',      'title' => 'Pengaturan Sekolah',       'perm' => 'pengaturan.kelola'],
    'akun'        => ['file' => 'akun',            'title' => 'Akun Saya',                'perm' => 'akun'],
];

$m = get_str('m', 30);
if ($m === '' || !isset($ROUTES[$m])) {
    $m = 'dashboard';
}
$route = $ROUTES[$m];
require_perm($route['perm']);

$aksiGet = get_str('aksi', 20);
if (isset($route['aksi_perm'][$aksiGet])) {
    require_perm($route['aksi_perm'][$aksiGet]);   // dicek sebelum layout dikirim
}
$modul = $route['file'];
$fn = $route['fn'] ?? $modul;
require_once __DIR__ . '/modules/' . $modul . '.php';

// Proses aksi POST (selalu melalui CSRF dan Post-Redirect-Get)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        csrf_cek();
        $postFn = $fn . '_post';
        if (function_exists($postFn)) {
            $postFn($route);
        }
        redirect(url_sekarang());
    } catch (AppException $ex) {
        flash('error', $ex->getMessage());
    } catch (Throwable $ex) {
        error_log('[' . APP_NAME . '] ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
        flash('error', APP_DEBUG ? $ex->getMessage() : 'Terjadi kesalahan saat memproses data. Silakan coba lagi.');
    }
    // Simpan isian formulir (tanpa password) agar tidak perlu diketik ulang
    $kosong = ['password', 'password_lama', 'password_baru', 'password_ulang', '_token'];
    old_set(array_diff_key($_POST, array_flip($kosong)));
    redirect(url_sekarang());
}

$renderFn = $fn . '_render';
layout_atas($route['title'], $m, '');
?>
<?php
$renderFn($route);
?>
<?php
old_bersihkan();
layout_bawah();
