<?php
session_start();
// Opsional: Untuk mencegah warning ditampilkan di tampilan akhir, bisa ditambahkan:
// error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

include('config/conn.php');
include('config/function.php');

if (empty($_SESSION['username']) || empty($_SESSION['level'])) {
    header("Location: login.php");
    exit;
}

// Pastikan fungsi session_timeout() didefinisikan dalam config/function.php
session_timeout();

// ROUTING - HARUS DI ATAS SEBELUM INCLUDE APAPUN
$views = 'views/home.php';
$home = $master = $transaksi = $laporan = false;
$barang_masuk = $barang_keluar = $barang_rusak = $barang_dipinjam = false;
$merek = $kategori = $barang = $pengguna = false;
$lap_barang_masuk = $lap_barang_keluar = $lap_barang_rusak = $lap_barang_dipinjam = false;
$mutasi = $barang_aktif = false;

switch (true) {
    case isset($_GET['barang_rusak']):
        $barang_rusak = true;
        $transaksi = true;
        $views = 'views/transaksi/barang_rusak.php';
        break;

    case isset($_GET['barang_masuk']):
        $barang_masuk = true;
        $transaksi = true;
        $views = 'views/transaksi/barang_masuk.php';
        break;

    case isset($_GET['barang_keluar']):
        $barang_keluar = true;
        $transaksi = true;
        $views = 'views/transaksi/barang_keluar.php';
        break;

    case isset($_GET['barang_dipinjam']):
        $barang_dipinjam = true;
        $transaksi = true;
        $views = 'views/transaksi/barang_dipinjam.php';
        break;

    case isset($_GET['mutasi']):
        $mutasi = true;
        $laporan = true;
        // PATH YANG DIUBAH: Sekarang mencari di views/laporan/mutasi.php
        $views = 'views/master/mutasi.php'; 
        break;

    case isset($_GET['barang_aktif']):
        $barang_aktif = true;
        $laporan = true;
        // PATH 'views/barang_aktif.php' - PERIKSA LOKASI FILE INI JUGA!
        $views = 'views/barang_aktif.php';
        break;

    case isset($_GET['merek']):
        $merek = true;
        $master = true;
        $views = 'views/master/merek.php';
        break;

    case isset($_GET['kategori']):
        $kategori = true;
        $master = true;
        $views = 'views/master/kategori.php';
        break;

    case isset($_GET['barang']):
        $barang = true;
        $master = true;
        $views = 'views/master/barang.php';
        break;

    case isset($_GET['pengguna']):
        $pengguna = true;
        $master = true;
        $views = 'views/master/pengguna.php';
        break;

    case isset($_GET['lap_barang_masuk']):
        $lap_barang_masuk = true;
        $laporan = true;
        $views = 'views/laporan/lap_barang_masuk.php';
        break;

    case isset($_GET['lap_barang_keluar']):
        $lap_barang_keluar = true;
        $laporan = true;
        $views = 'views/laporan/lap_barang_keluar.php';
        break;

    case isset($_GET['lap_barang_rusak']):
        $lap_barang_rusak = true;
        $laporan = true;
        $views = 'views/laporan/lap_barang_rusak.php';
        break;

    case isset($_GET['lap_barang_dipinjam']):
        $lap_barang_dipinjam = true;
        $laporan = true;
        $views = 'views/laporan/lap_barang_dipinjam.php';
        break;


    default:
        $home = true;
        $views = 'views/home.php';
        break;
}

include('config/header.php');
?>

<body id="page-top">

    <div id="wrapper">

        <?php include "config/sidebar.php"; ?>

        <div id="content-wrapper" class="d-flex flex-column">

            <div id="content">
                <?php include "config/topbar.php"; ?>

                <div class="container-fluid">
                    
                    <?php if (isset($_SESSION['success'])): ?>
                    <div class="flash-data-berhasil" data-berhasil="<?= $_SESSION['success']; ?>"></div>
                    <?php endif; unset($_SESSION['success']); ?>

                    <?php if (isset($_SESSION['error'])): ?>
                    <div class="flash-data-gagal" data-gagal="<?= $_SESSION['error']; ?>"></div>
                    <?php endif; unset($_SESSION['error']); ?>
                    
                    <?php 
                        // Baris ini adalah baris include yang menyebabkan Warning (sekitar baris 145)
                        include ($views); 
                    ?>
                </div>
                
            </div>
            <footer class="sticky-footer bg-darkligh">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Az-zaky<?= date('Y'); ?></span>
                    </div>
                </div>
            </footer>
            </div>
        </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php include "config/footer.php"; ?>
</body>
</html>