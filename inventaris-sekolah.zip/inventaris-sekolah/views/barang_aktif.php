<?php
hakAkses(['admin']);
?>

<!-- views/barang_aktif.php -->
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Stok Barang Aktif</h1>
        <div>
            <a id="refreshAktif" class="btn btn-sm btn-secondary"><i class="fas fa-sync"></i> Refresh</a>
            <button id="printAktif" class="btn btn-sm btn-primary"><i class="fas fa-print"></i> Print</button>
            <button id="exportAktifCsv" class="btn btn-sm btn-success"><i class="fas fa-file-csv"></i> Export CSV</button>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <strong>Ringkasan Barang Aktif</strong>
            <span class="small text-muted ml-2">(aktif_qty = total_masuk - total_rusak - total_dipinjam)</span>
        </div>
        <div class="card-body">
            <div class="table-responsive" id="aktifTableContainer">
                <table class="table table-bordered table-hover" id="aktifTable" width="100%">
                    <thead class="thead-light">
                        <tr>
                            <th>#</th>
                            <th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Total Masuk</th>
                            <th>Total Rusak</th>
                            <th>Total Dipinjam</th>
                            <th>Aktif Qty</th>
                            <th>Stok (table barang)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT a.*, b.stok
                                FROM barang_aktif a
                                LEFT JOIN barang b ON b.idbarang = a.barang_id
                                ORDER BY a.aktif_qty DESC, a.nama_barang ASC";
                        $res = mysqli_query($con, $sql);
                        $no = 1;
                        if ($res && mysqli_num_rows($res) > 0) {
                            while ($r = mysqli_fetch_assoc($res)) {
                                echo '<tr>';
                                echo '<td>' . $no++ . '</td>';
                                echo '<td>' . htmlspecialchars($r['kode_barang']) . '</td>';
                                echo '<td>' . htmlspecialchars($r['nama_barang']) . '</td>';
                                echo '<td>' . (int)$r['total_masuk'] . '</td>';
                                echo '<td>' . (int)$r['total_rusak'] . '</td>';
                                echo '<td>' . (int)$r['total_dipinjam'] . '</td>';
                                echo '<td>' . (int)$r['aktif_qty'] . '</td>';
                                echo '<td>' . (int)$r['stok'] . '</td>';
                                echo '</tr>';
                            }
                        } else {
                            echo '<tr><td colspan="8" class="text-center text-muted">Belum ada data barang aktif</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    if (window.jQuery && $.fn.dataTable) {
        $('#aktifTable').DataTable({
            pageLength: 25,
            order: [[6, 'desc']]
        });
    }

    document.getElementById('printAktif').addEventListener('click', function () {
        var container = document.getElementById('aktifTableContainer');
        var w = window.open('', '_blank');
        var css = '<link rel="stylesheet" href="<?= base_url(); ?>assets/css/sb-admin-2.min.css">';
        w.document.write('<html><head><title>Stok Barang Aktif</title>' + css + '</head><body>');
        w.document.write('<h3>Stok Barang Aktif - ' + new Date().toLocaleString() + '</h3>');
        w.document.write(container.innerHTML);
        w.document.write('</body></html>');
        w.document.close();
        setTimeout(function () { w.print(); }, 300);
    });

    document.getElementById('exportAktifCsv').addEventListener('click', function () {
        var rows = Array.from(document.querySelectorAll('#aktifTable tr')).map(tr => {
            return Array.from(tr.querySelectorAll('th,td')).map(td => '"' + td.innerText.replace(/"/g, '""') + '"').join(',');
        }).join('\n');
        var blob = new Blob([rows], { type: 'text/csv;charset=utf-8;' });
        var link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'barang_aktif_' + (new Date()).toISOString().slice(0,10) + '.csv';
        link.click();
    });

    document.getElementById('refreshAktif').addEventListener('click', function () {
        location.reload();
    });
});
</script>