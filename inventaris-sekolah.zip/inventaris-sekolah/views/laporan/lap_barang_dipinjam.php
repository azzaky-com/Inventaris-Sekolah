<?php
hakAkses(['admin']);
?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Laporan Barang Dipinjam</h1>
    </div>

<?php
// --- Prepare data for charts ---

// 1) Status distribution (Dipinjam / Dikembalikan / Hilang-Rusak)
$status_counts = [
    'Dipinjam' => 0,
    'Dikembalikan' => 0,
    'Hilang/Rusak' => 0
];

$sql = "SELECT status, COUNT(*) AS cnt FROM barang_dipinjam GROUP BY status";
$res = mysqli_query($con, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $s = $row['status'];
        $c = (int)$row['cnt'];
        if ($s === 'Dipinjam') {
            $status_counts['Dipinjam'] += $c;
        } elseif ($s === 'Dikembalikan') {
            $status_counts['Dikembalikan'] += $c;
        } elseif ($s === 'Hilang' || $s === 'Rusak') {
            $status_counts['Hilang/Rusak'] += $c;
        } else {
            // unknown status - put into Dikembalikan? or ignore — here we ignore
        }
    }
}

// 2) Monthly trend for last 12 months (based on tanggal_pinjam)
$months_labels = [];
$months_data = [];

// build last 12 months keys (YYYY-MM)
$dt = new DateTime('first day of this month');
for ($i = 11; $i >= 0; $i--) {
    $m = (clone $dt)->modify("-{$i} months");
    $key = $m->format('Y-m');
    $months_labels[] = $m->format('M Y'); // label for display, e.g. "Nov 2025"
    $months_data[$key] = 0;
}

// single query grouping by month to be efficient
$min_month = array_key_first($months_data);
$min_date = $min_month . '-01';
$sql2 = "SELECT DATE_FORMAT(tanggal_pinjam, '%Y-%m') AS ym, COUNT(*) AS cnt
         FROM barang_dipinjam
         WHERE tanggal_pinjam >= '" . mysqli_real_escape_string($con, $min_date) . "'
         GROUP BY ym";
$res2 = mysqli_query($con, $sql2);
if ($res2) {
    while ($r = mysqli_fetch_assoc($res2)) {
        $ym = $r['ym'];
        $cnt = (int)$r['cnt'];
        if (array_key_exists($ym, $months_data)) {
            $months_data[$ym] = $cnt;
        }
    }
}

// convert months_data for JS (preserve order of $months_labels)
$monthly_values = [];
foreach ($months_data as $k => $v) {
    $monthly_values[] = $v;
}

// 3) Top 10 barang paling sering dipinjam (keperluan tabel & optional chart)
$top_barang = [];
$sql3 = "
    SELECT b.kode_barang, b.nama_barang, m.nama_merek, COUNT(bd.idbarang_dipinjam) AS total_pinjam
    FROM barang_dipinjam bd
    JOIN barang b ON b.idbarang = bd.barang_id
    JOIN merek m ON m.idmerek = b.merek_id
    GROUP BY bd.barang_id
    ORDER BY total_pinjam DESC
    LIMIT 10
";
$res3 = mysqli_query($con, $sql3);
if ($res3) {
    while ($r = mysqli_fetch_assoc($res3)) {
        $top_barang[] = $r;
    }
}

// JSON encode for charts (safe)
$pie_labels = array_keys($status_counts);
$pie_data = array_values($status_counts);
$line_labels = $months_labels;
$line_data = $monthly_values;
?>

    <!-- Charts Row -->
    <div class="row mb-4">
        <div class="col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Distribusi Status Peminjaman</h6>
                </div>
                <div class="card-body">
                    <canvas id="statusPieChart" width="100%" height="100%"></canvas>
                    <div class="mt-3 text-muted small">
                        Distribusi peminjaman berdasarkan status saat ini.
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Tren Peminjaman (12 Bulan Terakhir)</h6>
                </div>
                <div class="card-body">
                    <canvas id="monthlyLineChart" width="100%" height="60"></canvas>
                    <div class="mt-3 text-muted small">
                        Jumlah peminjaman per bulan selama 12 bulan terakhir.
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Overview (cards) -->
    <div class="row">
        <!-- Total -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Peminjaman</div>
                            <?php
                            $query_total = mysqli_query($con, "SELECT COUNT(*) AS total FROM barang_dipinjam");
                            $total = 0;
                            if ($query_total) {
                                $r = mysqli_fetch_assoc($query_total);
                                $total = isset($r['total']) ? (int)$r['total'] : 0;
                            }
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= htmlspecialchars($total) ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-handshake fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Masih Dipinjam -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Masih Dipinjam</div>
                            <?php
                            $query_aktif = mysqli_query($con, "SELECT COUNT(*) AS total FROM barang_dipinjam WHERE status='Dipinjam'");
                            $aktif = 0;
                            if ($query_aktif) {
                                $r = mysqli_fetch_assoc($query_aktif);
                                $aktif = isset($r['total']) ? (int)$r['total'] : 0;
                            }
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= htmlspecialchars($aktif) ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sudah Dikembalikan -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Sudah Dikembalikan</div>
                            <?php
                            $query_kembali = mysqli_query($con, "SELECT COUNT(*) AS total FROM barang_dipinjam WHERE status='Dikembalikan'");
                            $kembali = 0;
                            if ($query_kembali) {
                                $r = mysqli_fetch_assoc($query_kembali);
                                $kembali = isset($r['total']) ? (int)$r['total'] : 0;
                            }
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= htmlspecialchars($kembali) ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Hilang / Rusak -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Hilang/Rusak</div>
                            <?php
                            $query_hilang = mysqli_query($con, "SELECT COUNT(*) AS total FROM barang_dipinjam WHERE status IN ('Hilang','Rusak')");
                            $hilang = 0;
                            if ($query_hilang) {
                                $r = mysqli_fetch_assoc($query_hilang);
                                $hilang = isset($r['total']) ? (int)$r['total'] : 0;
                            }
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= htmlspecialchars($hilang) ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-exclamation-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Top 10 Peminjam -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">10 Peminjam Terbanyak</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>PEMINJAM</th>
                                    <th>JUMLAH PEMINJAMAN</th>
                                    <th>BELUM KEMBALI</th>
                                    <th>HILANG/RUSAK</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $n = 1;
                                $query_top = mysqli_query($con, "
                                    SELECT peminjam, 
                                    COUNT(*) AS total_pinjam,
                                    SUM(CASE WHEN status='Dipinjam' THEN 1 ELSE 0 END) AS belum_kembali,
                                    SUM(CASE WHEN status IN ('Hilang','Rusak') THEN 1 ELSE 0 END) AS hilang_rusak
                                    FROM barang_dipinjam
                                    GROUP BY peminjam
                                    ORDER BY total_pinjam DESC
                                    LIMIT 10
                                ");

                                if ($query_top && mysqli_num_rows($query_top) > 0):
                                    while ($row = mysqli_fetch_assoc($query_top)):
                                ?>
                                <tr>
                                    <td><?= $n++ ?></td>
                                    <td><strong><?= htmlspecialchars($row['peminjam']) ?></strong></td>
                                    <td><span class="badge badge-info"><?= htmlspecialchars((int)$row['total_pinjam']) ?></span></td>
                                    <td><span class="badge badge-warning"><?= htmlspecialchars((int)$row['belum_kembali']) ?></span></td>
                                    <td><span class="badge badge-danger"><?= htmlspecialchars((int)$row['hilang_rusak']) ?></span></td>
                                </tr>
                                <?php
                                    endwhile;
                                else:
                                ?>
                                <tr>
                                    <td colspan="5" class="text-center">
                                        <div class="alert alert-info mb-0">Belum ada data peminjaman.</div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Top 10 Barang Paling Sering Dipinjam -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">10 Barang Paling Sering Dipinjam</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>KODE BARANG</th>
                                    <th>NAMA BARANG</th>
                                    <th>MEREK</th>
                                    <th>JUMLAH PEMINJAMAN</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $n = 1;
                                if (!empty($top_barang)):
                                    foreach ($top_barang as $row):
                                ?>
                                <tr>
                                    <td><?= $n++ ?></td>
                                    <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                                    <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                    <td><?= htmlspecialchars($row['nama_merek']) ?></td>
                                    <td><span class="badge badge-primary"><?= htmlspecialchars((int)$row['total_pinjam']) ?></span></td>
                                </tr>
                                <?php
                                    endforeach;
                                else:
                                ?>
                                <tr>
                                    <td colspan="5" class="text-center">
                                        <div class="alert alert-info mb-0">Belum ada data peminjaman.</div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>

<<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {

    // Data dari PHP
    const pieLabels = <?= json_encode($pie_labels, JSON_UNESCAPED_UNICODE) ?>;
    const pieData   = <?= json_encode($pie_data, JSON_NUMERIC_CHECK) ?>;
    const lineLabels = <?= json_encode($line_labels, JSON_UNESCAPED_UNICODE) ?>;
    const lineData   = <?= json_encode($line_data, JSON_NUMERIC_CHECK) ?>;

    const ctxPie = document.getElementById('statusPieChart').getContext('2d');
    const ctxLine = document.getElementById('monthlyLineChart').getContext('2d');

    // Gradien untuk Line Chart
    const gradientLine = ctxLine.createLinearGradient(0, 0, 0, 300);
    gradientLine.addColorStop(0, 'rgba(0, 180, 255, 0.5)');
    gradientLine.addColorStop(1, 'rgba(0, 180, 255, 0)');

    // Gradien tiap slice Pie
    const pieColors = [
        ctxPie.createLinearGradient(0, 0, 200, 0),
        ctxPie.createLinearGradient(0, 0, 200, 0),
        ctxPie.createLinearGradient(0, 0, 200, 0),
    ];
    pieColors[0].addColorStop(0, '#ffca28');
    pieColors[0].addColorStop(1, '#ff9100');

    pieColors[1].addColorStop(0, '#26c6da');
    pieColors[1].addColorStop(1, '#0097a7');

    pieColors[2].addColorStop(0, '#ef5350');
    pieColors[2].addColorStop(1, '#c62828');

    // === Modern PIE CHART ===
    new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: pieLabels,
            datasets: [{
                data: pieData,
                backgroundColor: pieColors,
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 14,
            }]
        },
        options: {
            responsive: true,
            cutout: '55%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        boxWidth: 15
                    }
                },
                tooltip: {
                    callbacks: {
                        label: context => `${context.label}: ${context.raw}x`
                    }
                }
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });

    // === Modern LINE CHART ===
    new Chart(ctxLine, {
        type: 'line',
        data: {
            labels: lineLabels,
            datasets: [{
                label: "Jumlah Peminjaman",
                data: lineData,
                borderColor: "#00b4ff",
                backgroundColor: gradientLine,
                tension: 0.4,
                fill: true,
                pointBackgroundColor: "#00b4ff",
                pointHoverRadius: 10,
                pointRadius: 5,
                borderWidth: 3,
                shadowOffsetX: 0,
                shadowOffsetY: 0
            }]
        },
        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                tooltip: {
                    backgroundColor: "rgba(0,0,0,.8)",
                    padding: 10,
                },
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 }
                }
            }
        }
    });
});
</script>
