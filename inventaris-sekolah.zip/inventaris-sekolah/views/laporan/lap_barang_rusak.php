<?php 
hakAkses(['admin']); 
?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <link href="<?=base_url();?>assets/css/theme-futuristic.css" rel="stylesheet">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard Barang Rusak</h1>
    </div>

    <!-- Statistics Overview -->
    <div class="row">
        <!-- Total Rusak -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total Rusak (Bulan Ini)</div>
                            <?php
                            $bulan_ini = date('Y-m');
                            $query_total = mysqli_query($con, "SELECT COUNT(*) as total FROM barang_rusak WHERE DATE_FORMAT(tanggal_laporan, '%Y-%m') = '$bulan_ini'");
                            $total = ($query_total) ? mysqli_fetch_array($query_total)['total'] : 0;
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-exclamation-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Dalam Proses -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Dalam Proses</div>
                            <?php
                            $query_proses = mysqli_query($con, "SELECT COUNT(*) as total FROM barang_rusak WHERE status IN ('Menunggu Pemeriksaan', 'Dalam Pemeriksaan', 'Sedang Diperbaiki', 'Menunggu Persetujuan Perbaikan')");
                            $proses = ($query_proses) ? mysqli_fetch_array($query_proses)['total'] : 0;
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $proses; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-cog fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Selesai -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Selesai Diperbaiki</div>
                            <?php
                            $query_selesai = mysqli_query($con, "SELECT COUNT(*) as total FROM barang_rusak WHERE status IN ('Selesai Diperbaiki', 'Aset Aktif Kembali')");
                            $selesai = ($query_selesai) ? mysqli_fetch_array($query_selesai)['total'] : 0;
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $selesai; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Biaya -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Biaya (Bulan Ini)</div>
                            <?php
                            $query_biaya = mysqli_query($con, "SELECT SUM(biaya_aktual) as total FROM barang_rusak WHERE DATE_FORMAT(tanggal_laporan, '%Y-%m') = '$bulan_ini' AND biaya_aktual IS NOT NULL");
                            $biaya = ($query_biaya) ? mysqli_fetch_array($query_biaya)['total'] : 0;
                            $biaya = ($biaya) ? $biaya : 0;
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Rp <?= number_format($biaya, 0, ',', '.'); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row">
        <!-- Status Chart -->
        <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Distribusi Status Barang Rusak</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2">
                        <canvas id="statusChart"></canvas>
                    </div>
                    <div class="mt-4 text-center small">
                        <?php
                        $statuses = [
                            'Menunggu Pemeriksaan' => '#f6c23e',
                            'Dalam Pemeriksaan' => '#36b9cc',
                            'Sedang Diperbaiki' => '#4e73df',
                            'Selesai Diperbaiki' => '#1cc88a',
                            'Rusak Permanen' => '#e74a3b'
                        ];
                        foreach($statuses as $status => $color):
                        ?>
                        <span class="mr-2">
                            <i class="fas fa-circle" style="color: <?= $color; ?>"></i> <?= $status; ?>
                        </span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Trend Chart -->
        <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Trend Kerusakan (6 Bulan Terakhir)</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="trendChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Top 10 Barang Sering Rusak -->
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Top 10 Barang Paling Sering Rusak</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>KODE BARANG</th>
                                    <th>NAMA BARANG</th>
                                    <th>MEREK</th>
                                    <th>JUMLAH KERUSAKAN</th>
                                    <th>TOTAL BIAYA</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $n = 1;
                                // FIX ERROR 3: Tambahkan validasi query dan error handling
                                $query_top = mysqli_query($con, "SELECT b.kode_barang, b.nama_barang, m.nama_merek, 
                                                                COUNT(br.idbarang_rusak) as jumlah_rusak,
                                                                SUM(br.biaya_aktual) as total_biaya
                                                                FROM barang_rusak br
                                                                JOIN barang b ON b.idbarang = br.barang_id
                                                                JOIN merek m ON m.idmerek = b.merek_id
                                                                GROUP BY br.barang_id
                                                                ORDER BY jumlah_rusak DESC
                                                                LIMIT 10");
                                
                                if($query_top && mysqli_num_rows($query_top) > 0):
                                    while($row = mysqli_fetch_array($query_top)):
                                ?>
                                <tr>
                                    <td><?= $n++; ?></td>
                                    <td><?= $row['kode_barang']; ?></td>
                                    <td><?= $row['nama_barang']; ?></td>
                                    <td><?= $row['nama_merek']; ?></td>
                                    <td><span class="badge badge-danger"><?= $row['jumlah_rusak']; ?>x</span></td>
                                    <td>Rp <?= number_format($row['total_biaya'] ? $row['total_biaya'] : 0, 0, ',', '.'); ?></td>
                                </tr>
                                <?php 
                                    endwhile;
                                else:
                                ?>
                                <tr>
                                    <td colspan="6" class="text-center">
                                        <div class="alert alert-info mb-0">
                                            Belum ada data barang rusak untuk ditampilkan.
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
// Status Chart
<?php
$status_data = array();
$query_chart = mysqli_query($con, "SELECT status, COUNT(*) as total FROM barang_rusak GROUP BY status");
if($query_chart && mysqli_num_rows($query_chart) > 0) {
    while($row = mysqli_fetch_array($query_chart)) {
        $status_data[$row['status']] = $row['total'];
    }
}
// Jika tidak ada data, set default
if(empty($status_data)) {
    $status_data = ['Belum ada data' => 0];
}
?>
var ctx = document.getElementById("statusChart");
var statusChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: <?= json_encode(array_keys($status_data)); ?>,
        datasets: [{
            data: <?= json_encode(array_values($status_data)); ?>,
            backgroundColor: ['#f6c23e', '#36b9cc', '#4e73df', '#1cc88a', '#e74a3b', '#858796', '#5a5c69'],
            hoverBackgroundColor: ['#f4b619', '#2c9faf', '#2e59d9', '#17a673', '#d52a1a', '#717384', '#484a54'],
            hoverBorderColor: "rgba(234, 236, 244, 1)",
        }],
    },
    options: {
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

// Trend Chart
<?php
$trend_data = array();
for($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i month"));
    $month_label = date('M Y', strtotime("-$i month"));
    $query_trend = mysqli_query($con, "SELECT COUNT(*) as total FROM barang_rusak WHERE DATE_FORMAT(tanggal_laporan, '%Y-%m') = '$month'");
    if($query_trend) {
        $trend_data[$month_label] = mysqli_fetch_array($query_trend)['total'];
    } else {
        $trend_data[$month_label] = 0;
    }
}
?>
var ctx2 = document.getElementById("trendChart");
var trendChart = new Chart(ctx2, {
    type: 'line',
    data: {
        labels: <?= json_encode(array_keys($trend_data)); ?>,
        datasets: [{
            label: "Jumlah Kerusakan",
            lineTension: 0.3,
            backgroundColor: "rgba(78, 115, 223, 0.05)",
            borderColor: "rgba(78, 115, 223, 1)",
            pointRadius: 3,
            pointBackgroundColor: "rgba(78, 115, 223, 1)",
            pointBorderColor: "rgba(78, 115, 223, 1)",
            pointHoverRadius: 3,
            pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
            pointHoverBorderColor: "rgba(78, 115, 223, 1)",
            pointHitRadius: 10,
            pointBorderWidth: 2,
            data: <?= json_encode(array_values($trend_data)); ?>,
        }],
    },
    options: {
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        },
        plugins: {
            legend: {
                display: true
            }
        }
    }
});
</script>
