<?php
// Pastikan hakAkses() ada dan dipanggil
hakAkses(['admin']); 
$now = date('Y-m-d');

// Fungsi pembantu untuk memformat angka (misal: 10000 menjadi 10.000)
if (!function_exists('fmt')) {
    function fmt($n){ 
        return number_format((int)$n, 0, ',', '.'); 
    }
}

// =================================================================
// 1. LOGIKA PENGAMBILAN DATA DARI DATABASE
// Variabel $con (koneksi) harus tersedia dari file config/conn.php
global $con; 

// Inisialisasi default
$total_stok = 0;
$total_aktif = 0;
$total_rusak = 0;
$total_mutasi = 0;
$total_dipinjam = 0;
$total_barang_masuk = 0;

if (isset($con)) {
    // Fungsi bantuan untuk menjalankan query dan mengembalikan hasil (int)
    function execute_query($conn, $sql, $field_name) {
        $result = mysqli_query($conn, $sql);
        if ($result === false) {
            // Log error, tapi tetap kembalikan 0 agar tidak ada warning
            error_log("Query error: " . mysqli_error($conn));
            return 0;
        }
        $data = mysqli_fetch_assoc($result);
        return (int) ($data[$field_name] ?? 0);
    }
    
    // --- QUERY MENGGUNAKAN NAMA TABEL YANG BENAR ---

    // 1. Total Barang (stok) - SUM stok dari tabel 'barang'
    $sql_stok = "SELECT SUM(stok) AS total_stok FROM barang";
    $total_stok = execute_query($con, $sql_stok, 'total_stok');

    // 2. Barang Aktif - SUM aktif_qty dari tabel 'barang_aktif'
    // aktif_qty = stok - total_rusak - total_dipinjam
    $sql_aktif = "SELECT SUM(aktif_qty) AS total_aktif FROM barang_aktif";
    $total_aktif = execute_query($con, $sql_aktif, 'total_aktif');

    // 3. Barang Rusak - COUNT jumlah record di tabel 'barang_rusak'
    $sql_rusak = "SELECT COUNT(*) AS total_rusak FROM barang_rusak"; 
    $total_rusak = execute_query($con, $sql_rusak, 'total_rusak');
    
    // 4. Total Mutasi - COUNT(*) dari tabel 'mutasi'
    $sql_mutasi = "SELECT COUNT(*) AS total_mutasi FROM mutasi";
    $total_mutasi = execute_query($con, $sql_mutasi, 'total_mutasi');

    // 5. Barang Dipinjam - COUNT jumlah barang yang sedang dipinjam (status: Dipinjam, Hilang, Rusak)
    $sql_dipinjam = "SELECT COUNT(*) AS total_dipinjam 
                     FROM barang_dipinjam 
                     WHERE status IN ('Dipinjam', 'Hilang', 'Rusak')";
    $total_dipinjam = execute_query($con, $sql_dipinjam, 'total_dipinjam');

    // 6. Total Barang Masuk - SUM jumlah dari tabel 'barang_masuk'
    $sql_barang_masuk = "SELECT SUM(jumlah) AS total_barang_masuk FROM barang_masuk";
    $total_barang_masuk = execute_query($con, $sql_barang_masuk, 'total_barang_masuk');
}
// =================================================================
?>
<style>
  /* Simple modern card grid */
  .dashboard-header {
    margin-bottom: 1.25rem;
  }
  .dashboard-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(260px,1fr));
    gap: 1.25rem;
  }
  .dash-card {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 1px 2px rgba(16,24,40,0.04), 0 4px 8px rgba(16,24,40,0.06);
    display: flex;
    gap: 1rem;
    align-items: center;
    border: 1px solid rgba(15,23,42,0.04);
    min-height: 110px;
    transition: transform 0.2s, box-shadow 0.2s;
  }
  .dash-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 6px rgba(16,24,40,0.08), 0 8px 16px rgba(16,24,40,0.1);
  }
  .dash-icon {
    width: 64px;
    height: 64px;
    border-radius: 12px;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
  }
  .dash-title { color:#6b7280; font-size:0.95rem; margin-bottom:6px; }
  .dash-value { font-size:28px; font-weight:700; color:#0f172a; }
  /* icon backgrounds */
  .bg-blue { background: linear-gradient(180deg, rgba(59,130,246,0.12), rgba(59,130,246,0.08)); color:#2563eb; }
  .bg-green { background: linear-gradient(180deg, rgba(16,185,129,0.12), rgba(16,185,129,0.08)); color:#059669; }
  .bg-red { background: linear-gradient(180deg, rgba(239,68,68,0.12), rgba(239,68,68,0.08)); color:#dc2626; }
  .bg-orange { background: linear-gradient(180deg, rgba(249,115,22,0.12), rgba(249,115,22,0.08)); color:#f97316; }
  .bg-indigo { background: linear-gradient(180deg, rgba(99,102,241,0.12), rgba(99,102,241,0.08)); color:#7c3aed; }
  .bg-purple { background: linear-gradient(180deg, rgba(168,85,247,0.12), rgba(168,85,247,0.08)); color:#9333ea; }

  .dashboard-cta { display:flex; gap:.5rem; align-items:center; }
  .small-muted { color:#6b7280; font-size:0.95rem; }

  @media (max-width:575px){
    .dash-card { padding:14px; gap:.75rem; min-height:100px; }
    .dash-value { font-size:22px; }
    .dashboard-cta { flex-direction: column; width: 100%; }
    .dashboard-cta .btn { width: 100%; }
  }
</style>

<div class="container-fluid">
  <div class="dashboard-header d-sm-flex align-items-start justify-content-between mb-4">
    <div>
      <h1 class="h3 mb-1 text-gray-800">Dashboard</h1>
      <div class="small-muted">Selamat Datang, <?= htmlspecialchars($_SESSION['nama'] ?? 'Admin') ?>!</div>
    </div>
    <div class="dashboard-cta">
      <a class="btn btn-primary btn-sm" href="<?= base_url() ?>?mutasi"><i class="fas fa-random"></i> Mutasi</a>
      <a class="btn btn-success btn-sm" href="<?= base_url() ?>?barang_aktif"><i class="fas fa-check-circle"></i> Barang Aktif</a>
    </div>
  </div>

  <div class="dashboard-grid">

    <div class="dash-card">
      <div class="dash-icon bg-blue">
        <i class="fas fa-boxes fa-lg" aria-hidden="true"></i>
      </div>
      <div>
        <div class="dash-title">Total Barang (Stok)</div>
        <div class="dash-value" id="totalBarang"><?= fmt($total_stok); ?></div>
      </div>
    </div>

    <div class="dash-card">
      <div class="dash-icon bg-green">
        <i class="fas fa-check-circle fa-lg" aria-hidden="true"></i>
      </div>
      <div>
        <div class="dash-title">Barang Aktif</div>
        <div class="dash-value" id="barangAktif"><?= fmt($total_aktif); ?></div>
      </div>
    </div>

    <div class="dash-card">
      <div class="dash-icon bg-purple">
        <i class="fas fa-arrow-down fa-lg" aria-hidden="true"></i>
      </div>
      <div>
        <div class="dash-title">Total Barang Masuk</div>
        <div class="dash-value" id="totalBarangMasuk"><?= fmt($total_barang_masuk); ?></div>
      </div>
    </div>

    <div class="dash-card">
      <div class="dash-icon bg-red">
        <i class="fas fa-exclamation-circle fa-lg" aria-hidden="true"></i>
      </div>
      <div>
        <div class="dash-title">Barang Rusak</div>
        <div class="dash-value" id="barangRusak"><?= fmt($total_rusak); ?></div>
      </div>
    </div>

    <div class="dash-card">
      <div class="dash-icon bg-indigo">
        <i class="fas fa-truck-loading fa-lg" aria-hidden="true"></i>
      </div>
      <div>
        <div class="dash-title">Barang Dipinjam</div>
        <div class="dash-value" id="barangDipinjam"><?= fmt($total_dipinjam); ?></div>
      </div>
    </div>

    <div class="dash-card">
      <div class="dash-icon bg-orange">
        <i class="fas fa-exchange-alt fa-lg" aria-hidden="true"></i>
      </div>
      <div>
        <div class="dash-title">Total Mutasi</div>
        <div class="dash-value" id="totalMutasi"><?= fmt($total_mutasi); ?></div>
      </div>
    </div>

  </div>

  <div class="mt-4 text-muted small" id="updatedAt">
    <i class="fas fa-clock"></i> Terakhir diperbarui: <?= date('d M Y H:i:s'); ?>
  </div>
</div>