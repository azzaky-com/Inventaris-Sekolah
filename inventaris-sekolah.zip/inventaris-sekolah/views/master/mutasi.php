<?php
hakAkses(['admin']);
?>

<!-- views/mutasi.php -->
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Mutasi Barang</h1>
        <div>
            <a id="btnRefresh" class="btn btn-sm btn-secondary"><i class="fas fa-sync"></i> Refresh</a>
            <button id="printBtn" class="btn btn-sm btn-primary"><i class="fas fa-print"></i> Print</button>
            <button id="exportCsvBtn" class="btn btn-sm btn-success"><i class="fas fa-file-csv"></i> Export CSV</button>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <!-- <strong>Filter Mutasi</strong> -->
        </div>
        <div class="card-body">
            <form id="filterForm" class="form-inline">
                <div class="form-group mr-2">
                    <label class="mr-2"></label>
                    <!-- <select name="jenis" class="form-control form-control-sm">
                        <option value="">Semua</option>
                        <option value="masuk">Masuk</option>
                        <option value="keluar">Keluar</option>
                        <option value="dipinjam">Dipinjam</option>
                        <option value="dikembalikan">Dikembalikan</option>
                        <option value="rusak">Rusak</option>
                        <option value="perbaikan">Perbaikan</option>
                    </select> -->
                </div>

                <!-- <div class="form-group mr-2">
                    <label class="mr-2">Dari</label>
                    <input type="date" name="from" class="form-control form-control-sm">
                </div>

                <div class="form-group mr-2">
                    <label class="mr-2">Sampai</label>
                    <input type="date" name="to" class="form-control form-control-sm">
                </div> -->

                <!-- <button class="btn btn-sm btn-primary" type="submit"><i class="fas fa-filter"></i> Terapkan</button> -->
            </form>
        </div>
    </div>

    <div class="card shadow">
        <div class="card-header py-3 d-flex align-items-center justify-content-between">
            <strong>Daftar Mutasi</strong>
            <small class="text-muted">Tabel menyajikan semua event mutasi (masuk/keluar/dipinjam/..) terbaru</small>
        </div>
        <div class="card-body">
            <div class="table-responsive" id="tableContainer">
                <table class="table table-bordered table-hover" id="mutasiTable" width="100%">
                    <thead class="thead-light">
                        <tr>
                            <th>#</th>
                            <th>Tanggal</th>
                            <th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Jenis</th>
                            <th>Jumlah</th>
                            <th>Keterangan</th>
                            <th>Ref</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // default load recent 200 mutasi
                        $sql = "SELECT m.*, b.nama_barang 
                                FROM mutasi m
                                LEFT JOIN barang b ON b.idbarang = m.barang_id
                                ORDER BY m.tanggal DESC, m.id DESC
                                LIMIT 500";
                        $res = mysqli_query($con, $sql);
                        $no = 1;
                        if ($res) {
                            while ($row = mysqli_fetch_assoc($res)) {
                                $ref = '';
                                if (!empty($row['barang_masuk_id'])) $ref = 'Masuk#' . $row['barang_masuk_id'];
                                elseif (!empty($row['barang_keluar_id'])) $ref = 'Keluar#' . $row['barang_keluar_id'];
                                elseif (!empty($row['barang_dipinjam_id'])) $ref = 'Pjm#' . $row['barang_dipinjam_id'];
                                elseif (!empty($row['barang_rusak_id'])) $ref = 'Rusak#' . $row['barang_rusak_id'];

                                echo '<tr>';
                                echo '<td>' . $no++ . '</td>';
                                echo '<td>' . htmlspecialchars(date('d-m-Y', strtotime($row['tanggal']))) . '</td>';
                                echo '<td>' . htmlspecialchars($row['kode_barang']) . '</td>';
                                echo '<td>' . htmlspecialchars($row['nama_barang']) . '</td>';
                                echo '<td>' . htmlspecialchars(ucfirst($row['jenis'])) . '</td>';
                                echo '<td>' . htmlspecialchars((int)$row['jumlah']) . '</td>';
                                echo '<td>' . htmlspecialchars($row['keterangan']) . '</td>';
                                echo '<td>' . htmlspecialchars($ref) . '</td>';
                                echo '</tr>';
                            }
                        } else {
                            echo '<tr><td colspan="8" class="text-center text-muted">Tidak ada data mutasi</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    if (window.jQuery && $.fn.dataTable) {
        $('#mutasiTable').DataTable({
            pageLength: 25,
            order: [[1, 'desc']],
            dom: 'Bfrtip',
            buttons: []
        });
    }

    // filter form: simple client request reload with querystring
    document.getElementById('filterForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var params = new URLSearchParams(new FormData(this));
        // request server-side filtered? For simplicity reload page with params and let PHP handle (not implemented server-side filter here)
        // We'll build client-side filter: simply reload and let user edit code to support server filtering if required.
        location.search = '?mutasi&' + params.toString();
    });

    document.getElementById('printBtn').addEventListener('click', function () {
        var container = document.getElementById('tableContainer');
        var w = window.open('', '_blank');
        var css = '<link rel="stylesheet" href="<?= base_url(); ?>assets/css/sb-admin-2.min.css">';
        w.document.write('<html><head><title>Print Mutasi</title>' + css + '</head><body>');
        w.document.write('<h3>Daftar Mutasi - ' + new Date().toLocaleString() + '</h3>');
        w.document.write(container.innerHTML);
        w.document.write('</body></html>');
        w.document.close();
        setTimeout(function () { w.print(); }, 300);
    });

    document.getElementById('exportCsvBtn').addEventListener('click', function () {
        // simple CSV export from table
        var rows = Array.from(document.querySelectorAll('#mutasiTable tr')).map(tr => {
            return Array.from(tr.querySelectorAll('th,td')).map(td => '"' + td.innerText.replace(/"/g, '""') + '"').join(',');
        }).join('\n');
        var blob = new Blob([rows], { type: 'text/csv;charset=utf-8;' });
        var link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'mutasi_export_' + (new Date()).toISOString().slice(0,10) + '.csv';
        link.click();
    });

    document.getElementById('btnRefresh').addEventListener('click', function () {
        location.reload();
    });
});
</script>