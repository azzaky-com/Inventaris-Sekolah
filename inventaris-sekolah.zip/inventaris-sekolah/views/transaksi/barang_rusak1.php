<?php 
hakAkses(['admin']); 
$now = date('Y-m-d'); 

// Status configuration for cards and badges
$statuses = [
    'Menunggu Pemeriksaan' => 'warning',
    'Dalam Pemeriksaan' => 'info',
    'Menunggu Persetujuan Perbaikan' => 'warning',
    'Sedang Diperbaiki' => 'primary',
    'Menunggu Anggaran' => 'warning',
    'Selesai Diperbaiki' => 'success',
    'Aset Aktif Kembali' => 'success',
    'Rusak Permanen' => 'danger',
    'Destruksi Asset' => 'dark'
];

// Function Badge Status Color
function getBadgeColor($status) {
    global $statuses;
    return isset($statuses[$status]) ? $statuses[$status] : 'secondary';
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manajemen Barang Rusak</h1>
        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahModal">
            <i class="fas fa-plus"></i> Lapor Barang Rusak
        </button>
    </div>

    <!-- STATISTICS -->
    <div class="row">
        <? php foreach($statuses as $status => $color): 
            $count_query = mysqli_query($con, "SELECT COUNT(*) AS total FROM barang_rusak WHERE status='$status'");
            $count_data = mysqli_fetch_assoc($count_query) ?: ['total' => 0];
        ?>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-<? php echo $color; ?> shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs text-<? php echo $color; ?> font-weight-bold text-uppercase mb-1">
                                    <? php echo $status; ?>
                                </div>
                                <div class="h5 mb-0 text-gray-800 font-weight-bold">
                                    <?= $count_data['total']; ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-tools fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- FILTER STATUS -->
    <div class="card shadow mb-4">
        <div class="card-header py-3"><strong>Filter Status</strong></div>
        <div class="card-body">
            <select id="filterStatus" class="form-control col-md-4">
                <option value="">Semua Status</option>
                <?php foreach($statuses as $st => $c){ ?>
                    <option value="<?= $st ? >"><? = $st ?></option>
                <?php } ?>
            </select>
        </div>
    </div>

    <!-- TABLE DATA -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <strong>Daftar Barang Rusak</strong>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="dataTable" width="100%">
                    <thead class="bg-light">
                        <tr style="white-space:nowrap">
                            <th>NO</th>
                            <th>KODE</th>
                            <th>NAMA BARANG</th>
                            <th>MEREK</th>
                            <th>KATEGORI</th>
                            <th>TGL LAPOR</th>
                            <th>STATUS</th>
                            <th>PELAPOR</th>
                            <th>KETERANGAN</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        $data = mysqli_query($con, "
                            SELECT br.*, b.nama_barang, b.kode_barang, 
                                   m.nama_merek, k.nama_kategori 
                            FROM barang_rusak br
                            JOIN barang b ON b.idbarang = br.barang_id
                            JOIN merek m ON m.idmerek = b.merek_id
                            JOIN kategori k ON k.idkategori = b.kategori_id
                            ORDER BY br.idbarang_rusak DESC
                        ");

                        if(mysqli_num_rows($data) > 0):
                            while($d = mysqli_fetch_assoc($data)):
                                $badge_color = getBadgeColor($d['status']);
                        ?>

                        <tr data-status="<? php echo $d['status']; ?>">
                            <td><? = $no++; ?></td>
                            <td><span class="badge badge-primary"><?= $d['kode_barang']; ?></span></td>
                            <td><strong><? = $d['nama_barang']; ?></strong></td>
                            <td><? = $d['nama_merek']; ?></td>
                            <td><?= $d['nama_kategori']; ?></td>
                            <td><? = date('d-m-Y', strtotime($d['tanggal_laporan'])); ?></td>
                            <td>
                                <span class="badge badge-<?= $badge_color; ?>">
                                    <?= $d['status']; ?>
                                </span>
                            </td>
                            <td><? = $d['pelapor']; ?></td>
                            <td><small><?= substr($d['keterangan_kerusakan'],0,45) ?>...</small></td>
                            <td class="text-center">
                                <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#detailModal<? = $d['idbarang_rusak']; ? >" title="Lihat Detail">
                                    <i class="fas fa-eye"></i>
                                </button>

                                <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#updateModal<?= $d['idbarang_rusak']; ?>" title="Update Status">
                                    <i class="fas fa-edit"></i>
                                </button>

                                <a href="process/hapus_barang_rusak. php? id=<?= $d['idbarang_rusak']; ? >" class="btn btn-danger btn-sm" onclick="return confirm('Hapus data ini?')" title="Hapus">
                                   <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>

                        <!-- MODAL DETAIL -->
                        <div class="modal fade" id="detailModal<?= $d['idbarang_rusak']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                    <div class="modal-header bg-info text-white">
                                        <h5 class="modal-title">Detail Barang Rusak</h5>
                                        <button type="button" class="close text-white" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <h6 class="font-weight-bold text-primary mb-3">Informasi Barang</h6>
                                                <table class="table table-sm table-borderless">
                                                    <tr>
                                                        <td width="150"><strong>Kode Barang</strong></td>
                                                        <td><?= $d['kode_barang']; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><strong>Nama Barang</strong></td>
                                                        <td><?= $d['nama_barang']; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><strong>Merek</strong></td>
                                                        <td><?= $d['nama_merek']; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><strong>Kategori</strong></td>
                                                        <td><?= $d['nama_kategori']; ?></td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="font-weight-bold text-primary mb-3">Informasi Kerusakan</h6>
                                                <table class="table table-sm table-borderless">
                                                    <tr>
                                                        <td width="150"><strong>Tanggal Laporan</strong></td>
                                                        <td><?= date('d-m-Y', strtotime($d['tanggal_laporan'])); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><strong>Status</strong></td>
                                                        <td><span class="badge badge-<? = $badge_color; ? >"><?= $d['status']; ?></span></td>
                                                    </tr>
                                                    <tr>
                                                        <td><strong>Pelapor</strong></td>
                                                        <td><?= $d['pelapor']; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><strong>Teknisi</strong></td>
                                                        <td><?= ! empty($d['teknisi']) ? $d['teknisi'] : '<span class="text-muted">-</span>'; ?></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>

                                        <hr>

                                        <div class="row mb-3">
                                            <div class="col-md-12">
                                                <h6 class="font-weight-bold text-primary mb-2">Keterangan Kerusakan</h6>
                                                <p class="text-justify"><?= nl2br($d['keterangan_kerusakan']); ?></p>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <h6 class="font-weight-bold text-primary">Estimasi Biaya</h6>
                                                <p class="h5 text-success">Rp <?= number_format($d['estimasi_biaya'], 0, ',', '. '); ?></p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="font-weight-bold text-primary">Biaya Aktual</h6>
                                                <p class="h5 text-success">Rp <?= number_format($d['biaya_aktual'], 0, ',', '. '); ?></p>
                                            </div>
                                        </div>

                                        <hr>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <h6 class="font-weight-bold text-primary mb-3">Riwayat Status</h6>
                                                <div class="timeline">
                                                    <? php
                                                    $history_query = mysqli_query($con, "SELECT * FROM barang_rusak_history WHERE barang_rusak_id='{$d['idbarang_rusak']}' ORDER BY created_at DESC");
                                                    if(mysqli_num_rows($history_query) > 0):
                                                        while($history = mysqli_fetch_array($history_query)):
                                                    ?>
                                                    <div class="timeline-item">
                                                        <span class="badge badge-info"><?= date('d/m/Y H:i', strtotime($history['created_at'])); ?></span>
                                                        <p class="mb-1"><strong><? = $history['status_baru']; ?></strong></p>
                                                        <small class="text-muted"><?= $history['keterangan']; ?> (<? = $history['user']; ?>)</small>
                                                    </div>
                                                    <?php 
                                                        endwhile;
                                                    else:
                                                    ?>
                                                    <p class="text-muted text-center">Belum ada riwayat</p>
                                                    <? php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- MODAL UPDATE STATUS -->
                        <div class="modal fade" id="updateModal<? = $d['idbarang_rusak']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <form action="process/update_status_barang_rusak.php" method="POST">
                                        <div class="modal-header bg-warning text-dark">
                                            <h5 class="modal-title">Update Status Barang Rusak</h5>
                                            <button type="button" class="close" data-dismiss="modal">
                                                <span>&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <input type="hidden" name="id" value="<?= $d['idbarang_rusak']; ?>">
                                            <input type="hidden" name="status_lama" value="<?= $d['status']; ?>">

                                            <div class="form-group">
                                                <label><strong>Status Saat Ini</strong></label>
                                                <input type="text" class="form-control" value="<?= $d['status']; ?>" readonly>
                                            </div>

                                            <div class="form-group">
                                                <label><strong>Status Baru</strong> <span class="text-danger">*</span></label>
                                                <select name="status_baru" class="form-control" required>
                                                    <option value="">-- Pilih Status --</option>
                                                    <? php foreach($statuses as $st => $col): ?>
                                                        <option value="<?= $st ? >"><? = $st ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label><strong>Teknisi</strong></label>
                                                <input type="text" name="teknisi" class="form-control" value="<?= ! empty($d['teknisi']) ?  $d['teknisi'] : ''; ?>" placeholder="Nama Teknisi">
                                            </div>

                                            <div class="form-group">
                                                <label><strong>Estimasi Biaya</strong></label>
                                                <input type="number" name="estimasi_biaya" class="form-control" value="<?= $d['estimasi_biaya']; ?>" placeholder="0" min="0">
                                            </div>

                                            <div class="form-group">
                                                <label><strong>Biaya Aktual</strong></label>
                                                <input type="number" name="biaya_aktual" class="form-control" value="<?= $d['biaya_aktual']; ?>" placeholder="0" min="0">
                                            </div>

                                            <div class="form-group">
                                                <label><strong>Keterangan</strong> <span class="text-danger">*</span></label>
                                                <textarea name="keterangan" class="form-control" rows="3" placeholder="Tuliskan keterangan perubahan status..." required></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                            <button type="submit" name="update" class="btn btn-warning">Update Status</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <? php 
                            endwhile;
                        else: 
                        ?>
                            <tr>
                                <td colspan="10" class="text-center text-muted py-4">
                                    <i class="fas fa-inbox"></i> Belum ada data
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- MODAL TAMBAH BARANG RUSAK -->
<div class="modal fade" id="tambahModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="process/tambah_barang_rusak. php" method="POST" enctype="multipart/form-data">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-plus-circle"></i> Lapor Barang Rusak</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label><strong>Barang</strong> <span class="text-danger">*</span></label>
                        <select name="barang_id" class="form-control select2" required>
                            <option value="">-- Pilih Barang --</option>
                            <?php
                            $barang_query = mysqli_query($con, "SELECT b.*, m.nama_merek, k.nama_kategori FROM barang b 
                                                                   JOIN merek m ON b.merek_id = m.idmerek 
                                                                   JOIN kategori k ON b. kategori_id = k.idkategori 
                                                                   ORDER BY b.nama_barang ASC");
                            while($barang = mysqli_fetch_array($barang_query)):
                            ?>
                            <option value="<?= $barang['idbarang']; ?>">
                                <? = $barang['kode_barang']; ? > - <?= $barang['nama_barang']; ? > (<?= $barang['nama_merek']; ?> / <?= $barang['nama_kategori']; ?>)
                            </option>
                            <? php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label><strong>Tanggal Laporan</strong> <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal_laporan" class="form-control" value="<?= $now; ?>" required>
                    </div>

                    <div class="form-group">
                        <label><strong>Pelapor</strong> <span class="text-danger">*</span></label>
                        <input type="text" name="pelapor" class="form-control" placeholder="Nama Pelapor" required>
                    </div>

                    <div class="form-group">
                        <label><strong>Keterangan Kerusakan</strong> <span class="text-danger">*</span></label>
                        <textarea name="keterangan_kerusakan" class="form-control" rows="4" placeholder="Jelaskan detail kerusakan..." required></textarea>
                    </div>

                    <div class="form-group">
                        <label><strong>Foto Kerusakan</strong></label>
                        <div class="custom-file">
                            <input type="file" name="foto_kerusakan" class="custom-file-input" id="fotoKerusakan" accept="image/*">
                            <label class="custom-file-label" for="fotoKerusakan">Pilih file... </label>
                        </div>
                        <small class="form-text text-muted">Format: JPG, PNG, GIF.  Maksimal: 5MB</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" name="tambah" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- STYLES -->
<style>
    . badge-lg {
        font-size: 0.9rem;
        padding: 0.45rem 0.75rem;
    }

    .timeline {
        position: relative;
        padding-left: 20px;
    }

    . timeline-item {
        margin-bottom: 20px;
        padding-bottom: 20px;
        border-left: 3px solid #e3e6f0;
        padding-left: 20px;
        position: relative;
    }

    .timeline-item::before {
        content: '';
        position: absolute;
        left: -8px;
        top: 5px;
        width: 12px;
        height: 12px;
        background-color: #4e73df;
        border: 2px solid #fff;
        border-radius: 50%;
    }

    .timeline-item:last-child {
        border-left: 3px solid #e3e6f0;
        padding-bottom: 0;
    }

    .modal-body table td {
        padding: 8px 0;
        border: none;
    }

    .custom-file-label::after {
        content: "Pilih file";
    }
</style>

<!-- SCRIPTS -->
<script>
    $(document).ready(function() {
        // Initialize DataTable
        var table = $('#dataTable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Indonesian.json"
            },
            "order": [[0, "desc"]],
            "columnDefs": [
                { "orderable": false, "targets": 9 } // Disable sort on action column
            ]
        });

        // Filter Status
        $('#filterStatus').change(function() {
            var status = $(this).val();
            if(status) {
                table.column(6).search(status). draw();
            } else {
                table.column(6).search('').draw();
            }
        });

        // Initialize Select2
        $('. select2').select2({
            theme: 'bootstrap4',
            placeholder: '-- Pilih Barang --'
        });

        // Custom file input label
        $('#fotoKerusakan').on('change', function() {
            var fileName = $(this).val(). split('\\').pop();
            $(this).next('.custom-file-label').html(fileName);
        });
    });
</script>