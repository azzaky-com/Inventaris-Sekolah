<?php
hakAkses(['admin']);
$now = date('Y-m-d');
?>

<!-- Compact modal + stacking fixes -->
<style>
  .modal-backdrop { z-index: 1240 !important; }
  .modal { z-index: 1250 !important; }
  .modal[id^="detailModal"],
  .modal[id^="updateModal"],
  .modal[id^="kembalikanModal"] { z-index: 1250 !important; }

  .modal[id^="detailModal"] .modal-dialog,
  .modal[id^="updateModal"] .modal-dialog,
  .modal[id^="kembalikanModal"] .modal-dialog {
    max-width: 560px !important;
    margin: 1.25rem auto !important;
  }

  .modal[id^="detailModal"] .modal-dialog.modal-lg,
  .modal[id^="updateModal"] .modal-dialog.modal-lg {
    max-width: 760px !important;
  }

  .modal[id^="detailModal"] .modal-content,
  .modal[id^="updateModal"] .modal-content,
  .modal[id^="kembalikanModal"] .modal-content {
    border-radius: 10px;
    overflow: hidden;
  }

  .modal[id^="detailModal"] .modal-header,
  .modal[id^="updateModal"] .modal-header,
  .modal[id^="kembalikanModal"] .modal-header {
    padding: 0.5rem 0.85rem;
    min-height: 44px;
  }

  .modal[id^="detailModal"] .modal-body,
  .modal[id^="updateModal"] .modal-body,
  .modal[id^="kembalikanModal"] .modal-body {
    padding: 0.8rem 0.95rem;
  }

  .modal[id^="detailModal"] .modal-footer,
  .modal[id^="updateModal"] .modal-footer,
  .modal[id^="kembalikanModal"] .modal-footer {
    padding: 0.5rem 0.75rem;
  }

  .modal .table-responsive {
    max-height: 55vh;
    overflow: auto;
  }

  @media (max-width: 575.98px) {
    .modal[id^="detailModal"] .modal-dialog,
    .modal[id^="updateModal"] .modal-dialog,
    .modal[id^="kembalikanModal"] .modal-dialog {
      max-width: calc(100% - 1.5rem) !important;
      margin: 0.5rem auto !important;
    }
  }

  

  .badge-lg {
    font-size: 0.9rem;
    padding: 0.45rem 0.75rem;
  }

  .custom-file-label::after {
    content: "Browse";
  }

  #exportPdfBtn { margin-left: 0.5rem; }
  #printBtn { margin-left: 0.5rem; }
</style>

<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Manajemen Barang Dipinjam</h1>
    <button class="btn btn-primary btn-sm shadow-sm" data-toggle="modal" data-target="#tambahModal">
      <i class="fas fa-plus"></i> Tambah Peminjaman
    </button>
  </div>

  <!-- STATISTICS -->
  <div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-info shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Peminjaman</div>
              <?php
              $count_total = mysqli_query($con, "SELECT COUNT(*) AS total FROM barang_dipinjam");
              $total = $count_total ? mysqli_fetch_assoc($count_total)['total'] : 0;
              ?>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?= htmlspecialchars($total) ?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-handshake fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-warning shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Sedang Dipinjam</div>
              <?php
              $count_aktif = mysqli_query($con, "SELECT COUNT(*) AS total FROM barang_dipinjam WHERE status='Dipinjam'");
              $aktif = $count_aktif ? mysqli_fetch_assoc($count_aktif)['total'] : 0;
              ?>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?= htmlspecialchars($aktif) ?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-clock fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Sudah Dikembalikan</div>
              <?php
              $count_kembali = mysqli_query($con, "SELECT COUNT(*) AS total FROM barang_dipinjam WHERE status='Dikembalikan'");
              $kembali = $count_kembali ? mysqli_fetch_assoc($count_kembali)['total'] : 0;
              ?>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?= htmlspecialchars($kembali) ?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-check-circle fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-danger shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Hilang/Rusak</div>
              <?php
              $count_hilang = mysqli_query($con, "SELECT COUNT(*) AS total FROM barang_dipinjam WHERE status='Hilang' OR status='Rusak'");
              $hilang = $count_hilang ? mysqli_fetch_assoc($count_hilang)['total'] : 0;
              ?>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?= htmlspecialchars($hilang) ?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-exclamation-circle fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- TABLE DATA -->
  <div class="card shadow mb-4">
    <div class="card-header py-3 d-flex align-items-center justify-content-between">
      <strong>Daftar Barang Dipinjam</strong>
      <div>
        <!-- <button id="exportPdfBtn" class="btn btn-sm btn-success" title="Export ke PDF">
          <i class="fas fa-file-pdf"></i> Export PDF
        </button> -->
        <button id="printBtn" class="btn btn-sm btn-secondary" title="Print">
          <i class="fas fa-print"></i> Print
        </button>
      </div>
    </div>
    <div class="card-body">
      <div class="table-responsive" id="tableContainer">
        <table class="table table-bordered table-hover" id="dataTable" width="100%">
          <thead class="bg-light">
            <tr style="white-space: nowrap">
              <th>NO</th>
              <th>KODE</th>
              <th>NAMA BARANG</th>
              <th>MEREK</th>
              <th>PEMINJAM</th>
              <th>TGL PINJAM</th>
              <th>TGL KEMBALI</th>
              <th>STATUS</th>
              <th>KONDISI</th>
              <th>AKSI</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $rows = [];
            $data_q = mysqli_query($con, "
              SELECT bd.*, b.nama_barang, b.kode_barang, m.nama_merek
              FROM barang_dipinjam bd
              JOIN barang b ON b.idbarang = bd.barang_id
              JOIN merek m ON m.idmerek = b.merek_id
              ORDER BY bd.idbarang_dipinjam DESC
            ");

            if ($data_q) {
              while ($r = mysqli_fetch_assoc($data_q)) {
                $rows[] = $r;
              }
            }

            if (count($rows) > 0):
              $no = 1;
              foreach ($rows as $d):
                // Tentukan badge status (kompatibel PHP 5/7/8)
                $status_badge = 'secondary';
                switch ($d['status']) {
                  case 'Dipinjam':
                    $status_badge = 'warning';
                    break;
                  case 'Dikembalikan':
                    $status_badge = 'success';
                    break;
                  case 'Hilang':
                  case 'Rusak':
                    $status_badge = 'danger';
                    break;
                }
            ?>
            <tr data-status="<?= htmlspecialchars($d['status']) ?>">
              <td><?= $no++ ?></td>
              <td><span class="badge badge-primary"><?= htmlspecialchars($d['kode_barang']) ?></span></td>
              <td><strong><?= htmlspecialchars($d['nama_barang']) ?></strong></td>
              <td><?= htmlspecialchars($d['nama_merek']) ?></td>
              <td><?= htmlspecialchars($d['peminjam']) ?></td>
              <td><?= date('d-m-Y', strtotime($d['tanggal_pinjam'])) ?></td>
              <td><?= !empty($d['tanggal_kembali']) ? date('d-m-Y', strtotime($d['tanggal_kembali'])) : '-' ?></td>
              <td><span class="badge badge-<?= $status_badge ?>"><?= htmlspecialchars($d['status']) ?></span></td>
              <td><small><?= htmlspecialchars($d['kondisi_pinjam']) ?></small></td>
              <td class="text-center">
                <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#detailModal<?= $d['idbarang_dipinjam'] ?>" title="Lihat Detail">
                  <i class="fas fa-eye"></i>
                </button>
                <?php if ($d['status'] === 'Dipinjam'): ?>
                <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#kembalikanModal<?= $d['idbarang_dipinjam'] ?>" title="Kembalikan">
                  <i class="fas fa-undo"></i>
                </button>
                <?php endif; ?>
                <a href="process/hapus_barang_dipinjam.php?id=<?= urlencode($d['idbarang_dipinjam']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus data ini?')" title="Hapus">
                  <i class="fas fa-trash"></i>
                </a>
              </td>
            </tr>
            <?php
              endforeach;
            else:
            ?>
            <tr>
              <td colspan="10" class="text-center text-muted py-4">
                <i class="fas fa-inbox"></i> Belum ada data
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div> <!-- /.container-fluid -->

<?php
// RENDER MODALS
if (count($rows) > 0):
  foreach ($rows as $d):
    // Tentukan badge status
    $status_badge = 'secondary';
    switch ($d['status']) {
      case 'Dipinjam':
        $status_badge = 'warning';
        break;
      case 'Dikembalikan':
        $status_badge = 'success';
        break;
      case 'Hilang':
      case 'Rusak':
        $status_badge = 'danger';
        break;
    }
?>

<!-- MODAL DETAIL -->
<div class="modal fade" id="detailModal<?= $d['idbarang_dipinjam'] ?>" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-info text-white">
        <h5 class="modal-title">Detail Peminjaman Barang</h5>
        <button class="close text-white" data-dismiss="modal" aria-label="Close"><span>&times;</span></button>
      </div>
      <div class="modal-body">
        <div class="row mb-3">
          <div class="col-md-6">
            <h6 class="font-weight-bold text-primary mb-3">Informasi Barang</h6>
            <table class="table table-sm table-borderless">
              <tr>
                <td width="150"><strong>Kode Barang</strong></td>
                <td><?= htmlspecialchars($d['kode_barang']) ?></td>
              </tr>
              <tr>
                <td><strong>Nama Barang</strong></td>
                <td><?= htmlspecialchars($d['nama_barang']) ?></td>
              </tr>
              <tr>
                <td><strong>Merek</strong></td>
                <td><?= htmlspecialchars($d['nama_merek']) ?></td>
              </tr>
            </table>
          </div>
          <div class="col-md-6">
            <h6 class="font-weight-bold text-primary mb-3">Informasi Peminjaman</h6>
            <table class="table table-sm table-borderless">
              <tr>
                <td width="150"><strong>Peminjam</strong></td>
                <td><?= htmlspecialchars($d['peminjam']) ?></td>
              </tr>
              <tr>
                <td><strong>Tanggal Pinjam</strong></td>
                <td><?= date('d-m-Y', strtotime($d['tanggal_pinjam'])) ?></td>
              </tr>
              <tr>
                <td><strong>Status</strong></td>
                <td><span class="badge badge-<?= $status_badge ?>"><?= htmlspecialchars($d['status']) ?></span></td>
              </tr>
            </table>
          </div>
        </div>
        <hr>
        <div class="row mb-3">
          <div class="col-md-12">
            <h6 class="font-weight-bold text-primary mb-2">Kondisi Saat Dipinjam</h6>
            <p><?= nl2br(htmlspecialchars($d['kondisi_pinjam'])) ?></p>
          </div>
        </div>
        <div class="row mb-3">
          <div class="col-md-6">
            <h6 class="font-weight-bold text-primary">Tanggal Kembali</h6>
            <p><?= !empty($d['tanggal_kembali']) ? date('d-m-Y', strtotime($d['tanggal_kembali'])) : '<span class="text-muted">Belum dikembalikan</span>' ?></p>
          </div>
          <div class="col-md-6">
            <h6 class="font-weight-bold text-primary">Kondisi Saat Dikembalikan</h6>
            <p><?= !empty($d['kondisi_kembali']) ? nl2br(htmlspecialchars($d['kondisi_kembali'])) : '<span class="text-muted">-</span>' ?></p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <h6 class="font-weight-bold text-primary">Keterangan</h6>
            <p><?= !empty($d['keterangan']) ? nl2br(htmlspecialchars($d['keterangan'])) : '<span class="text-muted">-</span>' ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL KEMBALIKAN -->
<?php if ($d['status'] === 'Dipinjam'): ?>
<div class="modal fade" id="kembalikanModal<?= $d['idbarang_dipinjam'] ?>" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form action="process/kembalikan_barang_dipinjam.php" method="POST">
        <div class="modal-header bg-success text-white">
          <h5 class="modal-title">Kembalikan Barang</h5>
          <button class="close text-white" data-dismiss="modal" aria-label="Close"><span>&times;</span></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" value="<?= htmlspecialchars($d['idbarang_dipinjam']) ?>">

          <div class="form-group">
            <label><strong>Barang</strong></label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($d['nama_barang']) ?>" readonly>
          </div>

          <div class="form-group">
            <label><strong>Peminjam</strong></label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($d['peminjam']) ?>" readonly>
          </div>

          <div class="form-group">
            <label><strong>Tanggal Kembali</strong> <span class="text-danger">*</span></label>
            <input type="date" name="tanggal_kembali" class="form-control" value="<?= $now ?>" required>
          </div>

          <div class="form-group">
            <label><strong>Kondisi Saat Dikembalikan</strong> <span class="text-danger">*</span></label>
            <select name="kondisi_kembali" class="form-control" required>
              <option value="">-- Pilih Kondisi --</option>
              <option value="Baik">Baik</option>
              <option value="Sedikit Lecet">Sedikit Lecet</option>
              <option value="Cukup Rusak">Cukup Rusak</option>
              <option value="Rusak">Rusak</option>
            </select>
          </div>

          <div class="form-group">
            <label><strong>Status Peminjaman</strong> <span class="text-danger">*</span></label>
            <select name="status" class="form-control" required>
              <option value="Dikembalikan">Dikembalikan</option>
              <option value="Hilang">Hilang</option>
              <option value="Rusak">Rusak</option>
            </select>
          </div>

          <div class="form-group">
            <label><strong>Keterangan</strong></label>
            <textarea name="keterangan" class="form-control" rows="3" placeholder="Keterangan tambahan (opsional)"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
          <button class="btn btn-success" name="kembalikan">Simpan Pengembalian</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<?php
  endforeach;
endif;
?>

<!-- MODAL TAMBAH -->
<div class="modal fade" id="tambahModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form action="process/tambah_barang_dipinjam.php" method="POST">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title"><i class="fas fa-plus-circle"></i> Tambah Peminjaman Barang</h5>
          <button class="close text-white" data-dismiss="modal" aria-label="Close"><span>&times;</span></button>
        </div>
  <form method="POST" action="process/tambah_barang_rusak.php" enctype="multipart/form-data">
    <div class="modal-body">
        <div class="form-group">
            <label>Pilih Barang <span class="text-danger">*</span></label>
            <select name="barang_id" class="form-control" required>
                <option value="">-- Pilih Barang --</option>
                <?= list_barang(); ?>
            </select>
        </div>

          <div class="form-group">
            <label><strong>Peminjam</strong> <span class="text-danger">*</span></label>
            <input type="text" name="peminjam" class="form-control" placeholder="Masukkan nama peminjam" required>
          </div>

          <div class="form-group">
            <label><strong>Tanggal Pinjam</strong> <span class="text-danger">*</span></label>
            <input type="date" name="tanggal_pinjam" class="form-control" value="<?= $now ?>" required>
          </div>

          <div class="form-group">
            <label><strong>Kondisi Saat Dipinjam</strong> <span class="text-danger">*</span></label>
            <select name="kondisi_pinjam" class="form-control" required>
              <option value="">-- Pilih Kondisi --</option>
              <option value="Baik">Baik</option>
              <option value="Sedikit Lecet">Sedikit Lecet</option>
              <option value="Cukup Rusak">Cukup Rusak</option>
            </select>
          </div>

          <div class="form-group">
            <label><strong>Keterangan</strong></label>
            <textarea name="keterangan" class="form-control" rows="3" placeholder="Informasi tambahan (opsional)"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
          <button class="btn btn-primary" name="tambah"><i class="fas fa-save"></i> Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- SCRIPTS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
  // DataTable init (requires DataTables JS/CSS included elsewhere)
  if (window.jQuery && $.fn.dataTable) {
    $('#dataTable').DataTable({
      language: { url: "//cdn.datatables.net/plug-ins/1.10.16/i18n/Indonesian.json" },
      order: [[0, "desc"]],
      columnDefs: [{ orderable: false, targets: 9 }]
    });
  }

  // Select2 init (requires select2 included)
  if (window.jQuery && $.fn.select2) {
    $('.select2').select2({
      theme: 'bootstrap4',
      placeholder: '-- Pilih Barang --',
      width: '100%'
    });
  }

  // custom file input label update
  if (window.jQuery) {
    $(document).on('change', '.custom-file-input', function () {
      var fileName = $(this).val().split("\\").pop();
      $(this).siblings('.custom-file-label').addClass('selected').html(fileName);
    });
  }

  // Print
  document.getElementById('printBtn').addEventListener('click', function () {
    var printWindow = window.open('', '_blank');
    var css = '<link rel="stylesheet" href="<?= base_url(); ?>assets/css/sb-admin-2.min.css">';
    css += '<link rel="stylesheet" href="<?= base_url(); ?>assets/css/theme-overrides.css">';
    var html = '<html><head><title>Daftar Barang Dipinjam</title>' + css + '</head><body>';
    var container = document.querySelector('#tableContainer');
    html += container ? container.outerHTML : '';
    html += '</body></html>';
    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
    setTimeout(function () { printWindow.print(); }, 600);
  });

  // Export PDF
  document.getElementById('exportPdfBtn').addEventListener('click', function () {
    var btn = this;
    btn.disabled = true;
    var oldHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menghasilkan PDF...';

    var container = document.querySelector('#tableContainer');
    if (!container) {
      alert('Tabel tidak ditemukan.');
      btn.disabled = false;
      btn.innerHTML = oldHtml;
      return;
    }

    var clone = container.cloneNode(true);
    clone.style.width = 'auto';
    clone.style.maxWidth = 'none';
    clone.style.overflow = 'visible';

    var off = document.createElement('div');
    off.id = 'pdf-export-clone';
    off.style.position = 'fixed';
    off.style.left = '-9999px';
    off.style.top = '0';
    off.style.width = 'auto';
    off.style.background = '#fff';
    off.style.padding = '20px';
    off.style.boxSizing = 'border-box';
    off.style.zIndex = 99999;
    document.body.appendChild(off);
    off.appendChild(clone);

    var clonedTable = clone.querySelector('table');
    if (!clonedTable) {
      alert('Gagal menemukan elemen tabel di clone.');
      document.body.removeChild(off);
      btn.disabled = false;
      btn.innerHTML = oldHtml;
      return;
    }

    // remove action column before capture
    var ths = clonedTable.querySelectorAll('thead th');
    var skipIdx = -1;
    ths.forEach(function (th, i) {
      var txt = (th.innerText || th.textContent || '').trim().toLowerCase();
      if (txt === 'aksi') skipIdx = i;
    });

    if (skipIdx >= 0) {
      clonedTable.querySelectorAll('thead tr').forEach(function (hr) {
        var cell = hr.children[skipIdx];
        if (cell) cell.remove();
      });
      clonedTable.querySelectorAll('tbody tr').forEach(function (tr) {
        var cell = tr.children[skipIdx];
        if (cell) cell.remove();
      });
    }

    clonedTable.classList.add('table', 'table-bordered');
    clonedTable.style.borderCollapse = 'collapse';
    clonedTable.querySelectorAll('th, td').forEach(function (cell) {
      cell.style.border = '1px solid #ddd';
      cell.style.padding = '6px 8px';
      cell.style.fontSize = '11px';
    });

    setTimeout(function () {
      html2canvas(off, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff'
      }).then(function (canvas) {
        try {
          var jsPDFConstructor = window.jsPDF || (window.jspdf && window.jspdf.jsPDF);
          if (!jsPDFConstructor) throw new Error('jsPDF tidak ditemukan.');

          var pdf = new jsPDFConstructor('p', 'mm', 'a4');
          var pageWidth = pdf.internal.pageSize.getWidth();
          var pageHeight = pdf.internal.pageSize.getHeight();
          var margin = 10;

          var imgWidthPx = canvas.width;
          var imgHeightPx = canvas.height;
          var printableWidthMm = pageWidth - margin * 2;
          var pxPerMm = imgWidthPx / printableWidthMm;
          var imgHeightMm = imgHeightPx / pxPerMm;

          if (imgHeightMm <= (pageHeight - margin * 2)) {
            pdf.addImage(canvas.toDataURL('image/png'), 'PNG', margin, margin, printableWidthMm, imgHeightMm);
          } else {
            var sliceHeightPx = Math.floor(pxPerMm * (pageHeight - margin * 2));
            var remainingHeightPx = imgHeightPx;
            var y = 0;
            var page = 0;
            while (remainingHeightPx > 0) {
              var h = Math.min(sliceHeightPx, remainingHeightPx);
              var tmpCanvas = document.createElement('canvas');
              tmpCanvas.width = imgWidthPx;
              tmpCanvas.height = h;
              var ctx = tmpCanvas.getContext('2d');
              ctx.drawImage(canvas, 0, y, imgWidthPx, h, 0, 0, imgWidthPx, h);
              var imgData = tmpCanvas.toDataURL('image/png');
              var imgH_mm = h / pxPerMm;
              if (page > 0) pdf.addPage();
              pdf.addImage(imgData, 'PNG', margin, margin, printableWidthMm, imgH_mm);
              remainingHeightPx -= h;
              y += h;
              page++;
            }
          }

          try { pdf.autoPrint && pdf.autoPrint(); } catch (e) { /* ignore */ }
          var dataUrl = pdf.output('dataurlstring');
          var win = window.open(dataUrl, '_blank');
          setTimeout(function () {
            try { win.focus(); win.print(); } catch (e) { /* ignore */ }
          }, 800);

        } catch (err) {
          console.error(err);
          alert('Gagal membuat PDF: ' + (err.message || err));
        } finally {
          if (document.body.contains(off)) document.body.removeChild(off);
          btn.disabled = false;
          btn.innerHTML = oldHtml;
        }
      }).catch(function (err) {
        console.error(err);
        alert('Gagal capture tabel: ' + (err.message || err));
        if (document.body.contains(off)) document.body.removeChild(off);
        btn.disabled = false;
        btn.innerHTML = oldHtml;
      });
    }, 250);
  });
});
</script>