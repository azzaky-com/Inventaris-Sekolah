<?php
// export.php — unduh data sebagai CSV (dibuka di Excel dengan pemisah titik koma).
require_once __DIR__ . '/config/bootstrap.php';
require_login();

/** Kirim CSV dengan BOM UTF-8 agar Excel membaca karakter Indonesia dengan benar. */
function csv_kirim(string $nama, array $header, array $rows): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nama . '"');
    header('Cache-Control: no-store');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, $header, ';');
    foreach ($rows as $r) fputcsv($out, $r, ';');
    fclose($out);
    exit;
}

$t = get_str('t', 30);
$con = db();
$stamp = date('Ymd_His');

if ($t === 'template_barang') {
    require_perm('barang.kelola');
    csv_kirim('template_impor_barang.csv',
        ['nama_barang', 'kategori', 'merek', 'lokasi', 'satuan', 'stok_minimum', 'harga_perolehan', 'sumber_dana', 'tahun_perolehan', 'stok_awal', 'keterangan'],
        [['Laptop Guru Lenovo ThinkPad E14', 'ELK', 'Lenovo', 'Ruang Guru', 'unit', '2', '9500000', 'BOS', '2024', '6', 'Contoh baris — hapus sebelum impor']]);
}

require_perm('laporan.lihat');
if ($t === 'aset') require_perm('nilai.lihat');

if ($t === 'barang') {
    $rows = db_all($con,
        "SELECT b.kode_barang, b.nama_barang, k.nama AS kategori, COALESCE(m.nama,'') AS merek, COALESCE(l.nama,'') AS lokasi,
                b.satuan, b.stok_total, b.stok_minimum, b.harga_perolehan, b.sumber_dana, b.tahun_perolehan,
                b.keterangan, IF(b.aktif = 1, 'Aktif', 'Diarsipkan') AS status
         FROM barang b JOIN kategori k ON k.id = b.kategori_id LEFT JOIN merek m ON m.id = b.merek_id LEFT JOIN lokasi l ON l.id = b.lokasi_id
         ORDER BY b.kode_barang");
    $data = [];
    foreach ($rows as $r) $data[] = array_values($r);
    csv_kirim("data_barang_{$stamp}.csv",
        ['Kode', 'Nama Barang', 'Kategori', 'Merek', 'Lokasi', 'Satuan', 'Total unit', 'Jumlah Minimum', 'Harga/Unit', 'Sumber Dana', 'Tahun', 'Keterangan', 'Status'], $data);
}

if ($t === 'log') {
    require_perm('log.lihat');
    $sebelum = tanggal_valid($_GET['sebelum'] ?? '');
    $rows = $sebelum
        ? db_all($con, "SELECT l.created_at, COALESCE(u.nama, l.username) AS nama, l.aksi, l.modul, l.deskripsi, l.ip
                        FROM log_aktivitas l LEFT JOIN users u ON u.id = l.user_id WHERE l.created_at < ? ORDER BY l.id ASC", 's', [$sebelum . ' 00:00:00'])
        : db_all($con, "SELECT l.created_at, COALESCE(u.nama, l.username) AS nama, l.aksi, l.modul, l.deskripsi, l.ip
                        FROM log_aktivitas l LEFT JOIN users u ON u.id = l.user_id ORDER BY l.id DESC LIMIT 20000");
    $data = [];
    foreach ($rows as $r) $data[] = array_values($r);
    csv_kirim("log_aktivitas_{$stamp}.csv", ['Waktu', 'Pengguna', 'Aksi', 'Modul', 'Deskripsi', 'IP'], $data);
}

if (isset(JENIS_LAPORAN[$t])) {
    $data = laporan_data($t, laporan_filter_request());
    $header = array_map(function ($k) { return $k[0]; }, $data['kolom']);
    $rows = [];
    foreach ($data['rows'] as $r) {
        $line = [];
        foreach ($data['kolom'] as [$label, $key, $fmt]) $line[] = fmt_csv($r[$key] ?? null, $fmt);
        $rows[] = $line;
    }
    csv_kirim("{$t}_{$stamp}.csv", $header, $rows);
}

http_response_code(400);
echo 'Jenis ekspor tidak dikenal.';
