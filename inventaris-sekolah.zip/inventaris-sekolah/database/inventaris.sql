-- =====================================================================
-- Inventaris Sekolah v4 — skema + data dummy (instalasi baru)
-- Cara pasang:
--   1. Buat database kosong bernama "inventaris" (utf8mb4_unicode_ci)
--   2. Impor file ini (phpMyAdmin > Import, atau: mysql -u root inventaris < inventaris.sql)
--      Semua tabel dibuat ulang dan diisi data contoh.
-- Akun contoh (ganti password setelah login pertama):
--   admin    / admin12345     (Administrator)
--   operator / operator123    (Operator)
--   kepsek   / kepsek12345    (Kepala Sekolah)
-- Data contoh bersifat fiktif. Nama sekolah & pejabat dapat diubah di menu Pengaturan.
-- =====================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS tutup_buku, tahun_ajaran, penghapusan, kerusakan_riwayat, kerusakan, pemindahan, mutasi,
    stok_opname_item, stok_opname, peminjaman, barang_keluar, barang_masuk, stok_lokasi, barang, lokasi, merek, kategori,
    log_aktivitas, pengaturan, login_throttle, users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  no_hp VARCHAR(20) NULL,
  username VARCHAR(30) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','operator','kepala_sekolah') NOT NULL DEFAULT 'operator',
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  last_login DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE kategori (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode_prefix VARCHAR(5) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL UNIQUE,
  keterangan VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE merek (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL UNIQUE,
  keterangan VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE lokasi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL UNIQUE,
  penanggung_jawab VARCHAR(100) NULL,
  keterangan VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE barang (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode_barang VARCHAR(20) NOT NULL UNIQUE,
  kode_bmn VARCHAR(40) NULL,
  nama_barang VARCHAR(150) NOT NULL,
  kategori_id INT NOT NULL,
  merek_id INT NULL,
  lokasi_id INT NULL,
  satuan VARCHAR(20) NOT NULL DEFAULT 'unit',
  stok_total INT NOT NULL DEFAULT 0,
  stok_minimum INT NOT NULL DEFAULT 2,
  harga_perolehan DECIMAL(15,2) NOT NULL DEFAULT 0,
  sumber_dana VARCHAR(30) NOT NULL DEFAULT 'BOS',
  tahun_perolehan SMALLINT NULL,
  jenis_barang ENUM('habis_pakai','aset') NOT NULL DEFAULT 'aset',
  tanggal_perolehan DATE NULL,
  masa_manfaat_tahun TINYINT UNSIGNED NULL,
  nilai_residu_persen DECIMAL(5,2) NOT NULL DEFAULT 0,
  keterangan VARCHAR(500) NULL,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_barang_kategori (kategori_id),
  INDEX idx_barang_lokasi (lokasi_id),
  INDEX idx_barang_jenis (jenis_barang),
  CONSTRAINT fk_barang_kategori FOREIGN KEY (kategori_id) REFERENCES kategori(id) ON DELETE RESTRICT,
  CONSTRAINT fk_barang_merek FOREIGN KEY (merek_id) REFERENCES merek(id) ON DELETE SET NULL,
  CONSTRAINT fk_barang_lokasi FOREIGN KEY (lokasi_id) REFERENCES lokasi(id) ON DELETE SET NULL,
  CONSTRAINT chk_stok_total CHECK (stok_total >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jumlah unit per ruangan. Jumlah seluruh ruangan = stok_total.
CREATE TABLE stok_lokasi (
  barang_id INT NOT NULL,
  lokasi_id INT NOT NULL,
  jumlah INT NOT NULL DEFAULT 0,
  PRIMARY KEY (barang_id, lokasi_id),
  CONSTRAINT chk_stok_lokasi CHECK (jumlah >= 0),
  CONSTRAINT fk_sl_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT,
  CONSTRAINT fk_sl_lokasi FOREIGN KEY (lokasi_id) REFERENCES lokasi(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE barang_masuk (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tanggal DATE NOT NULL,
  barang_id INT NOT NULL,
  lokasi_id INT NULL,
  jumlah INT NOT NULL,
  harga_satuan DECIMAL(15,2) NOT NULL DEFAULT 0,
  sumber_dana VARCHAR(30) NOT NULL DEFAULT '',
  nomor_dokumen VARCHAR(60) NOT NULL DEFAULT '',
  keterangan VARCHAR(255) NOT NULL DEFAULT '',
  status ENUM('Disetujui','Menunggu','Ditolak') NOT NULL DEFAULT 'Disetujui',
  disetujui_oleh VARCHAR(100) NULL,
  tanggal_setujui DATETIME NULL,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_masuk_tgl (tanggal),
  CONSTRAINT chk_masuk_jumlah CHECK (jumlah > 0),
  CONSTRAINT fk_masuk_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT,
  CONSTRAINT fk_masuk_lokasi FOREIGN KEY (lokasi_id) REFERENCES lokasi(id) ON DELETE SET NULL,
  CONSTRAINT fk_masuk_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE barang_keluar (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tanggal DATE NOT NULL,
  barang_id INT NOT NULL,
  lokasi_id INT NULL,
  jumlah INT NOT NULL,
  alasan VARCHAR(60) NOT NULL,
  penerima VARCHAR(100) NOT NULL DEFAULT '',
  keterangan VARCHAR(255) NOT NULL DEFAULT '',
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_keluar_tgl (tanggal),
  CONSTRAINT chk_keluar_jumlah CHECK (jumlah > 0),
  CONSTRAINT fk_keluar_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT,
  CONSTRAINT fk_keluar_lokasi FOREIGN KEY (lokasi_id) REFERENCES lokasi(id) ON DELETE SET NULL,
  CONSTRAINT fk_keluar_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE pemindahan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  barang_id INT NOT NULL,
  lokasi_asal_id INT NOT NULL,
  lokasi_tujuan_id INT NOT NULL,
  jumlah INT NOT NULL,
  tanggal DATE NOT NULL,
  keterangan VARCHAR(255) NOT NULL DEFAULT '',
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pindah_tgl (tanggal),
  CONSTRAINT chk_pindah_jumlah CHECK (jumlah > 0),
  CONSTRAINT fk_pindah_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT,
  CONSTRAINT fk_pindah_asal FOREIGN KEY (lokasi_asal_id) REFERENCES lokasi(id) ON DELETE RESTRICT,
  CONSTRAINT fk_pindah_tujuan FOREIGN KEY (lokasi_tujuan_id) REFERENCES lokasi(id) ON DELETE RESTRICT,
  CONSTRAINT fk_pindah_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE peminjaman (
  id INT AUTO_INCREMENT PRIMARY KEY,
  barang_id INT NOT NULL,
  lokasi_asal_id INT NULL,
  jumlah INT NOT NULL,
  dikembalikan INT NOT NULL DEFAULT 0,
  hilang INT NOT NULL DEFAULT 0,
  sisa INT AS (jumlah - dikembalikan - hilang) STORED,
  peminjam VARCHAR(100) NOT NULL,
  kontak VARCHAR(20) NULL,
  tipe_peminjam VARCHAR(30) NOT NULL DEFAULT 'Guru',
  unit VARCHAR(100) NOT NULL DEFAULT '',
  tanggal_pinjam DATE NOT NULL,
  tanggal_rencana_kembali DATE NOT NULL,
  tanggal_kembali DATE NULL,
  kondisi_pinjam VARCHAR(30) NOT NULL DEFAULT 'Baik',
  kondisi_kembali VARCHAR(30) NULL,
  status ENUM('Dipinjam','Dikembalikan','Hilang') NOT NULL DEFAULT 'Dipinjam',
  keterangan TEXT NULL,
  pengingat_terakhir DATETIME NULL,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_pinjam_status (status, tanggal_rencana_kembali),
  INDEX idx_pinjam_barang (barang_id),
  CONSTRAINT chk_pinjam_jumlah CHECK (jumlah > 0),
  CONSTRAINT chk_pinjam_sisa CHECK (dikembalikan >= 0 AND hilang >= 0 AND dikembalikan + hilang <= jumlah),
  CONSTRAINT fk_pinjam_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT,
  CONSTRAINT fk_pinjam_lokasi FOREIGN KEY (lokasi_asal_id) REFERENCES lokasi(id) ON DELETE SET NULL,
  CONSTRAINT fk_pinjam_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE kerusakan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  barang_id INT NOT NULL,
  lokasi_id INT NULL,
  jumlah INT NOT NULL,
  tanggal_lapor DATE NOT NULL,
  pelapor VARCHAR(100) NOT NULL,
  deskripsi TEXT NOT NULL,
  foto VARCHAR(255) NULL,
  status ENUM('Dilaporkan','Diperiksa','Menunggu Persetujuan','Dalam Perbaikan','Selesai','Rusak Permanen') NOT NULL DEFAULT 'Dilaporkan',
  teknisi VARCHAR(100) NULL,
  estimasi_biaya DECIMAL(15,2) NULL,
  biaya_aktual DECIMAL(15,2) NULL,
  tanggal_selesai DATE NULL,
  catatan_persetujuan TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_rusak_status (status),
  INDEX idx_rusak_barang (barang_id),
  CONSTRAINT chk_rusak_jumlah CHECK (jumlah > 0),
  CONSTRAINT fk_rusak_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT,
  CONSTRAINT fk_rusak_lokasi FOREIGN KEY (lokasi_id) REFERENCES lokasi(id) ON DELETE SET NULL,
  CONSTRAINT fk_rusak_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE kerusakan_riwayat (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kerusakan_id INT NOT NULL,
  status_lama VARCHAR(30) NULL,
  status_baru VARCHAR(30) NOT NULL,
  catatan TEXT NULL,
  user_nama VARCHAR(100) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_riwayat_rusak (kerusakan_id),
  CONSTRAINT fk_riwayat_rusak FOREIGN KEY (kerusakan_id) REFERENCES kerusakan(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usulan & berita acara penghapusan aset
CREATE TABLE penghapusan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nomor_ba VARCHAR(40) NULL UNIQUE,
  barang_id INT NOT NULL,
  lokasi_id INT NOT NULL,
  jumlah INT NOT NULL,
  alasan VARCHAR(60) NOT NULL,
  tanggal_usul DATE NOT NULL,
  tanggal_setujui DATE NULL,
  nilai_buku_unit DECIMAL(15,2) NULL,
  keterangan VARCHAR(500) NOT NULL DEFAULT '',
  status ENUM('Diusulkan','Disetujui','Ditolak') NOT NULL DEFAULT 'Diusulkan',
  sumber ENUM('Manual','Kerusakan') NOT NULL DEFAULT 'Manual',
  kerusakan_id INT NULL,
  diusulkan_oleh VARCHAR(100) NOT NULL DEFAULT '',
  disetujui_oleh VARCHAR(100) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_hapus_jumlah CHECK (jumlah > 0),
  CONSTRAINT fk_hapus_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT,
  CONSTRAINT fk_hapus_lokasi FOREIGN KEY (lokasi_id) REFERENCES lokasi(id) ON DELETE RESTRICT,
  CONSTRAINT fk_hapus_rusak FOREIGN KEY (kerusakan_id) REFERENCES kerusakan(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE stok_opname (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(30) NOT NULL UNIQUE,
  judul VARCHAR(150) NOT NULL,
  tanggal DATE NOT NULL,
  lokasi_id INT NULL,
  status ENUM('Draft','Selesai') NOT NULL DEFAULT 'Draft',
  catatan TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  finalized_at DATETIME NULL,
  finalized_by INT NULL,
  CONSTRAINT fk_opname_lokasi FOREIGN KEY (lokasi_id) REFERENCES lokasi(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE stok_opname_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  opname_id INT NOT NULL,
  barang_id INT NOT NULL,
  stok_sistem INT NOT NULL,
  stok_fisik INT NULL,
  selisih INT NULL,
  keterangan VARCHAR(255) NULL,
  UNIQUE KEY uq_opname_barang (opname_id, barang_id),
  CONSTRAINT fk_opitem_opname FOREIGN KEY (opname_id) REFERENCES stok_opname(id) ON DELETE CASCADE,
  CONSTRAINT fk_opitem_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Kartu persediaan: yang disimpan adalah PERUBAHAN; saldo berjalan dihitung saat dibaca
CREATE TABLE mutasi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  barang_id INT NOT NULL,
  tanggal DATETIME NOT NULL,
  jenis VARCHAR(30) NOT NULL,
  jumlah INT NOT NULL,
  perubahan_total INT NOT NULL DEFAULT 0,
  perubahan_tersedia INT NOT NULL DEFAULT 0,
  saldo_total INT NOT NULL,
  saldo_tersedia INT NOT NULL,
  referensi VARCHAR(50) NOT NULL DEFAULT '',
  keterangan VARCHAR(255) NOT NULL DEFAULT '',
  user_nama VARCHAR(100) NOT NULL DEFAULT '',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_mutasi_barang (barang_id, tanggal),
  INDEX idx_mutasi_tanggal (tanggal),
  CONSTRAINT fk_mutasi_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE tahun_ajaran (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(20) NOT NULL UNIQUE,
  tanggal_mulai DATE NOT NULL,
  tanggal_selesai DATE NOT NULL,
  status ENUM('Aktif','Ditutup') NOT NULL DEFAULT 'Aktif',
  ditutup_pada DATETIME NULL,
  ditutup_oleh VARCHAR(100) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Snapshot posisi aset saat tahun ajaran ditutup
CREATE TABLE tutup_buku (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tahun_ajaran_id INT NOT NULL,
  barang_id INT NOT NULL,
  stok_total INT NOT NULL,
  tersedia INT NOT NULL,
  perolehan DECIMAL(15,2) NOT NULL DEFAULT 0,
  akumulasi DECIMAL(15,2) NOT NULL DEFAULT 0,
  nilai_buku DECIMAL(15,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_tutup (tahun_ajaran_id, barang_id),
  CONSTRAINT fk_tutup_tahun FOREIGN KEY (tahun_ajaran_id) REFERENCES tahun_ajaran(id) ON DELETE RESTRICT,
  CONSTRAINT fk_tutup_barang FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE log_aktivitas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  username VARCHAR(50) NOT NULL DEFAULT '',
  aksi VARCHAR(30) NOT NULL,
  modul VARCHAR(30) NOT NULL,
  deskripsi VARCHAR(255) NOT NULL,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_log_waktu (created_at),
  CONSTRAINT fk_log_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE pengaturan (
  kunci VARCHAR(60) PRIMARY KEY,
  nilai VARCHAR(500) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE login_throttle (
  ip VARCHAR(45) PRIMARY KEY,
  gagal INT NOT NULL DEFAULT 0,
  terkunci_sampai DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*!40000 ALTER TABLE `barang` DISABLE KEYS */;
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (1,'ELK-0001','3.05.03.01.001','Laptop Guru Lenovo ThinkPad E14',1,3,3,'unit',6,2,9500000.00,'BOS',2024,'aset','2025-01-08',4,10.00,'Untuk administrasi & presentasi guru',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (2,'ELK-0002',NULL,'Laptop Siswa Lenovo IdeaPad Slim 3',1,3,4,'unit',27,3,7300000.00,'BOS',2024,'aset','2025-01-08',4,10.00,'Laptop praktik siswa kelas IX',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (3,'ELK-0003',NULL,'PC Desktop Lab Dell OptiPlex 3080',1,4,4,'unit',36,5,8300000.00,'BOS',2023,'aset','2024-11-15',4,10.00,'Unit PC laboratorium komputer',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (4,'ELK-0004',NULL,'Monitor Dell 22 Inch',1,4,4,'unit',36,5,1600000.00,'BOS',2023,'aset','2024-11-16',4,10.00,'Monitor pasangan PC lab',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (5,'ELK-0005','3.05.03.02.004','Proyektor BenQ MS536',1,5,7,'unit',6,2,6200000.00,'APBD',2024,'aset','2024-09-10',5,10.00,'Proyektor ruang kelas',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (6,'ELK-0006',NULL,'Televisi Sharp 43 Inch',1,13,6,'unit',1,1,4100000.00,'BOS',2023,'aset','2025-02-10',5,10.00,'Multimedia perpustakaan',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (7,'ELK-0007',NULL,'Speaker Aktif Polytron',1,6,11,'unit',1,1,1850000.00,'BOS',2025,'aset','2025-03-02',4,0.00,'Untuk upacara dan acara sekolah',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (8,'ELK-0008',NULL,'Printer Epson L3110',1,2,2,'unit',2,1,2650000.00,'BOS',2025,'aset','2025-03-03',4,10.00,'Printer tinta untuk administrasi',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (9,'ELK-0009',NULL,'Scanner Canon ScanLide 120',1,1,2,'unit',1,1,1900000.00,'BOS',2025,'aset','2025-03-15',4,10.00,'Scanner dokumen',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (10,'ELK-0010',NULL,'Proyektor Epson EB-X06 (Lama)',1,2,10,'unit',2,1,4800000.00,'BOS',2019,'aset','2021-07-12',5,10.00,'Tidak lagi digunakan, sudah diarsipkan',0,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (11,'TIK-0001',NULL,'Router Cisco RV260',5,11,2,'unit',1,1,6800000.00,'APBD',2023,'aset','2024-06-01',4,10.00,'Router utama sekolah',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (12,'TIK-0002',NULL,'Access Point TP-Link EAP225',5,10,9,'unit',10,2,1080000.00,'BOS',2024,'aset','2025-06-05',4,10.00,'Access point area kelas',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (13,'TIK-0003',NULL,'Switch 16 Port TP-Link',5,10,4,'unit',6,1,650000.00,'BOS',2024,'aset','2025-03-02',4,10.00,'Switch jaringan laboratorium',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (14,'FUR-0001',NULL,'Meja Siswa Standar 120x45',2,14,10,'unit',150,30,350000.00,'BOS',2024,'aset','2025-01-03',8,0.00,'Meja siswa, ukuran 120x45 cm',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (15,'FUR-0002',NULL,'Kursi Siswa Plastik',2,14,10,'unit',150,30,185000.00,'BOS',2024,'aset','2025-01-03',8,0.00,'Kursi siswa ergonomis',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (16,'FUR-0003',NULL,'Meja Guru Besar',2,14,1,'unit',2,1,2100000.00,'BOS',2022,'aset','2023-02-01',8,0.00,'Meja kerja kepala sekolah',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (17,'FUR-0004',NULL,'Kursi Guru Deluxe',2,14,3,'unit',18,3,780000.00,'BOS',2023,'aset','2024-07-20',8,0.00,'Kursi kantor guru',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (18,'FUR-0005',NULL,'Lemari Arsip 2 Pintu',2,14,2,'unit',8,1,1450000.00,'BOS',2022,'aset','2025-01-18',8,0.00,'Lemari dokumen kantor',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (19,'FUR-0006',NULL,'Papan Tulis Whiteboard 120x90',2,15,8,'unit',24,2,480000.00,'BOS',2024,'aset','2025-01-20',5,0.00,'Whiteboard magnetik',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (20,'ATK-0001',NULL,'Spidol Whiteboard Snowman (Hitam)',3,7,10,'dus (12 pcs)',154,40,62000.00,'BOS',2026,'habis_pakai','2026-02-10',NULL,0.00,'Spidol isi 12 pcs per dus',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (21,'ATK-0002',NULL,'Pulpen Pilot V5 (Hitam)',3,8,10,'pak (12 pcs)',15,50,74000.00,'BOS',2026,'habis_pakai','2026-02-11',NULL,0.00,'Pulpen gel untuk administrasi',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (22,'ATK-0003',NULL,'Kertas HVS A4 70 gr',3,15,2,'rim',167,20,56000.00,'BOS',2026,'habis_pakai','2026-03-07',NULL,0.00,'Kertas percetakan & fotokopi',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (23,'ATK-0004',NULL,'Pensil Faber-Castell 2B',3,9,10,'lusin',36,10,42000.00,'BOS',2026,'habis_pakai','2026-01-20',NULL,0.00,'Pensil ujian',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (24,'ATK-0005',NULL,'Gunting Kantor',3,15,2,'buah',25,5,18000.00,'BOS',2025,'aset','2025-02-20',2,0.00,'Gunting kertas 8 inci',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (25,'ATK-0006',NULL,'Stapler Heavy Duty',3,15,2,'buah',6,3,165000.00,'BOS',2025,'aset','2025-02-20',2,0.00,'Stapler kantor',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (26,'LAB-0001',NULL,'Tabung Reaksi (Set 50)',4,15,5,'set',17,5,210000.00,'BOS',2025,'aset','2025-01-15',5,0.00,'Peralatan praktikum kimia',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (27,'LAB-0002',NULL,'Bunsen Burner',4,15,5,'buah',15,4,185000.00,'BOS',2025,'aset','2025-02-02',3,0.00,'Alat pemanas praktikum',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (28,'LAB-0003',NULL,'Mikroskop Olympus CX23',4,12,5,'unit',8,2,14500000.00,'APBD',2024,'aset','2024-10-05',8,0.00,'Mikroskop binokuler laboratorium IPA',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (29,'OLG-0001',NULL,'Bola Sepak Latihan',6,15,11,'buah',12,5,225000.00,'BOS',2025,'aset','2025-03-05',1,0.00,'Bola latihan sekolah',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (30,'KBS-0001',NULL,'Tempat Sampah 60 Liter',7,15,10,'buah',12,4,150000.00,'BOS',2025,'aset','2025-01-05',3,0.00,'Tempat sampah koridor',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (31,'KBS-0002',NULL,'Sapu Lantai Serat Sintetis',7,15,10,'buah',20,5,38000.00,'BOS',2025,'aset','2025-01-05',1,0.00,'Sapu untuk lantai kelas',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (32,'BUK-0001',NULL,'Buku Matematika Kelas VII (Kurikulum Merdeka)',8,15,6,'eksemplar',160,20,85000.00,'BOS',2025,'aset','2025-07-10',4,0.00,'Buku teks pelajaran',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (33,'BUK-0002',NULL,'Kamus Besar Bahasa Indonesia',8,15,6,'eksemplar',12,5,210000.00,'BOS',2024,'aset','2024-08-01',4,0.00,'Referensi perpustakaan',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (34,'ATK-0007',NULL,'Tinta Printer Epson 003 (Black)',3,2,2,'botol 65 ml',4,10,95000.00,'BOS',2026,'habis_pakai','2026-02-01',NULL,0.00,'Tinta untuk printer L3110',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (35,'ATK-0008',NULL,'Tinta Refill Spidol Whiteboard',3,7,10,'botol 60 ml',20,10,25000.00,'BOS',2026,'habis_pakai','2026-02-11',NULL,0.00,'Refill spidol whiteboard',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (36,'KBS-0003',NULL,'Pembersih Lantai Cairan',7,15,10,'botol 1 L',5,8,22000.00,'BOS',2026,'habis_pakai','2026-01-10',NULL,0.00,'Pembersih lantai kelas',1,'2026-11-06 22:59:23','2026-11-06 22:59:24');
INSERT INTO `barang` (`id`, `kode_barang`, `kode_bmn`, `nama_barang`, `kategori_id`, `merek_id`, `lokasi_id`, `satuan`, `stok_total`, `stok_minimum`, `harga_perolehan`, `sumber_dana`, `tahun_perolehan`, `jenis_barang`, `tanggal_perolehan`, `masa_manfaat_tahun`, `nilai_residu_persen`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES (37,'KBS-0004',NULL,'Alat Pel Lantai Kain',7,15,10,'buah',6,2,85000.00,'BOS',2025,'aset','2025-01-05',1,0.00,'Pel lantai, diganti bila rusak',1,'2026-11-06 22:59:23','2026-11-06 22:59:23');
/*!40000 ALTER TABLE `barang` ENABLE KEYS */;

/*!40000 ALTER TABLE `barang_keluar` DISABLE KEYS */;
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (1,'2026-03-12',22,2,40,'Distribusi ke Unit/Kelas','Ruang Guru','Kebutuhan ujian tengah semester',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (2,'2026-02-17',26,5,3,'Distribusi ke Unit/Kelas','Laboratorium IPA','Pengganti tabung pecah',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (3,'2026-09-03',21,10,15,'Distribusi ke Unit/Kelas','Ruang Guru','Distribusi awal semester ganjil',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (4,'2026-08-04',2,4,1,'Distribusi ke Unit/Kelas','Ruang Kelas IX A','Dipindahkan untuk kelas simulasi',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (5,'2026-01-28',23,10,20,'Dipindahkan ke Lokasi Lain','Ruang Kelas VII A','Persediaan ujian kelas',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (6,'2026-08-08',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (7,'2026-08-11',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (8,'2026-08-14',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (9,'2026-08-17',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (10,'2026-08-20',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (11,'2026-08-23',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (12,'2026-08-26',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (13,'2026-08-29',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (14,'2026-09-01',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (15,'2026-09-04',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (16,'2026-09-07',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (17,'2026-09-10',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (18,'2026-09-13',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (19,'2026-09-16',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (20,'2026-09-19',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (21,'2026-09-22',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (22,'2026-09-25',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (23,'2026-09-28',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (24,'2026-10-01',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (25,'2026-10-04',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (26,'2026-10-07',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (27,'2026-10-10',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (28,'2026-10-13',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (29,'2026-10-16',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (30,'2026-10-19',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (31,'2026-10-22',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (32,'2026-10-25',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (33,'2026-10-28',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (34,'2026-10-31',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (35,'2026-11-03',21,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (36,'2026-08-08',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (37,'2026-08-12',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (38,'2026-08-16',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (39,'2026-08-20',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (40,'2026-08-24',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (41,'2026-08-28',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (42,'2026-09-01',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (43,'2026-09-05',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (44,'2026-09-09',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (45,'2026-09-13',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (46,'2026-09-17',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (47,'2026-09-21',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (48,'2026-09-25',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (49,'2026-09-29',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (50,'2026-10-03',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (51,'2026-10-07',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (52,'2026-10-11',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (53,'2026-10-15',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:23');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (54,'2026-10-19',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (55,'2026-10-23',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (56,'2026-10-27',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (57,'2026-10-31',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (58,'2026-11-04',22,2,4,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (59,'2026-08-08',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (60,'2026-08-15',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (61,'2026-08-22',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (62,'2026-08-29',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (63,'2026-09-05',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (64,'2026-09-12',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (65,'2026-09-19',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (66,'2026-09-26',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (67,'2026-10-03',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (68,'2026-10-10',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (69,'2026-10-17',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (70,'2026-10-24',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (71,'2026-10-31',20,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (72,'2026-08-08',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (73,'2026-08-13',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (74,'2026-08-18',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (75,'2026-08-23',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (76,'2026-08-28',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (77,'2026-09-02',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (78,'2026-09-07',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (79,'2026-09-12',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (80,'2026-09-17',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (81,'2026-09-22',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (82,'2026-09-27',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (83,'2026-10-02',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (84,'2026-10-07',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (85,'2026-10-12',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (86,'2026-10-17',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (87,'2026-10-22',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (88,'2026-10-27',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (89,'2026-11-01',34,2,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (90,'2026-08-08',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (91,'2026-08-16',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (92,'2026-08-24',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (93,'2026-09-01',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (94,'2026-09-09',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (95,'2026-09-17',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (96,'2026-09-25',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (97,'2026-10-03',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (98,'2026-10-11',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (99,'2026-10-19',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (100,'2026-10-27',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (101,'2026-11-04',23,10,2,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (102,'2026-08-08',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (103,'2026-08-17',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (104,'2026-08-26',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (105,'2026-09-04',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (106,'2026-09-13',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (107,'2026-09-22',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (108,'2026-10-01',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (109,'2026-10-10',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (110,'2026-10-19',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (111,'2026-10-28',35,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (112,'2026-08-08',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (113,'2026-08-14',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (114,'2026-08-20',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (115,'2026-08-26',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (116,'2026-09-01',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (117,'2026-09-07',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (118,'2026-09-13',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (119,'2026-09-19',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (120,'2026-09-25',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (121,'2026-10-01',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (122,'2026-10-07',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (123,'2026-10-13',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (124,'2026-10-19',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (125,'2026-10-25',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
INSERT INTO `barang_keluar` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `penerima`, `keterangan`, `created_by`, `created_at`) VALUES (126,'2026-10-31',36,10,1,'Pemakaian Operasional','Unit operasional','Pemakaian harian',1,'2026-11-06 22:59:24');
/*!40000 ALTER TABLE `barang_keluar` ENABLE KEYS */;

/*!40000 ALTER TABLE `barang_masuk` DISABLE KEYS */;
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (1,'2025-01-08',1,3,6,9500000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (2,'2025-01-08',2,4,24,7200000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (3,'2024-11-15',3,4,36,8300000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (4,'2024-11-16',4,4,36,1600000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (5,'2024-09-10',5,7,6,6200000.00,'APBD','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (6,'2025-02-10',6,6,1,4100000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (7,'2025-03-02',7,11,2,1850000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (8,'2025-03-03',8,2,2,2650000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (9,'2025-03-15',9,2,1,1900000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (10,'2021-07-12',10,10,2,4800000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (11,'2024-06-01',11,2,1,6800000.00,'APBD','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (12,'2025-06-05',12,9,8,1100000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (13,'2025-03-02',13,4,6,650000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (14,'2025-01-03',14,10,150,350000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (15,'2025-01-03',15,10,150,185000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (16,'2023-02-01',16,1,2,2100000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (17,'2024-07-20',17,3,18,780000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (18,'2025-01-18',18,2,8,1450000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (19,'2025-01-20',19,8,25,480000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (20,'2026-02-10',20,10,120,62000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (21,'2026-02-11',21,10,60,74000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (22,'2026-03-07',22,2,200,56000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (23,'2026-01-20',23,10,80,42000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (24,'2025-02-20',24,2,25,18000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (25,'2025-02-20',25,2,4,165000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (26,'2025-01-15',26,5,20,210000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (27,'2025-02-02',27,5,15,185000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (28,'2024-10-05',28,5,8,14500000.00,'APBD','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (29,'2025-03-05',29,11,12,225000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (30,'2025-01-05',30,10,12,150000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (31,'2025-01-05',31,10,20,38000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (32,'2025-07-10',32,6,120,85000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (33,'2024-08-01',33,6,12,210000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (34,'2026-02-01',34,2,40,95000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (35,'2026-02-11',35,10,30,25000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (36,'2026-01-10',36,10,20,22000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (37,'2025-01-05',37,10,6,85000.00,'BOS','SALDO AWAL','Saldo awal pendataan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (38,'2026-04-22',2,4,4,7300000.00,'BOS','BAST/2026/041','Tambahan laptop praktik','Disetujui','Administrator','2026-11-07 05:59:24',1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (39,'2026-06-03',22,2,100,56000.00,'BOS','FAK/0458','Pembelian rutin semester genap','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (40,'2026-08-18',20,10,60,62000.00,'BOS','FAK/0612','Pengadaan rutin awal semester','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (41,'2026-09-22',32,6,40,0.00,'Hibah','BAST-HIBAH/12','Hibah dari Dinas Pendidikan','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (42,'2026-05-14',12,9,2,1080000.00,'BOS','FAK/0377','Penambahan titik Wi-Fi','Disetujui',NULL,NULL,1,'2026-11-06 22:59:23');
INSERT INTO `barang_masuk` (`id`, `tanggal`, `barang_id`, `lokasi_id`, `jumlah`, `harga_satuan`, `sumber_dana`, `nomor_dokumen`, `keterangan`, `status`, `disetujui_oleh`, `tanggal_setujui`, `created_by`, `created_at`) VALUES (43,'2026-11-05',28,5,2,14500000.00,'APBD','FAK/0701','Penambahan mikroskop praktikum','Menunggu',NULL,NULL,1,'2026-11-06 22:59:24');
/*!40000 ALTER TABLE `barang_masuk` ENABLE KEYS */;

/*!40000 ALTER TABLE `kategori` DISABLE KEYS */;
INSERT INTO `kategori` (`id`, `kode_prefix`, `nama`, `keterangan`) VALUES (1,'ELK','Elektronik','Perangkat elektronik & multimedia');
INSERT INTO `kategori` (`id`, `kode_prefix`, `nama`, `keterangan`) VALUES (2,'FUR','Furnitur','Meja, kursi, lemari, papan tulis');
INSERT INTO `kategori` (`id`, `kode_prefix`, `nama`, `keterangan`) VALUES (3,'ATK','Alat Tulis Kantor','Persediaan administrasi & kelas');
INSERT INTO `kategori` (`id`, `kode_prefix`, `nama`, `keterangan`) VALUES (4,'LAB','Laboratorium','Alat praktikum IPA');
INSERT INTO `kategori` (`id`, `kode_prefix`, `nama`, `keterangan`) VALUES (5,'TIK','Jaringan & TIK','Perangkat jaringan internet sekolah');
INSERT INTO `kategori` (`id`, `kode_prefix`, `nama`, `keterangan`) VALUES (6,'OLG','Olahraga','Peralatan olahraga');
INSERT INTO `kategori` (`id`, `kode_prefix`, `nama`, `keterangan`) VALUES (7,'KBS','Kebersihan','Peralatan kebersihan lingkungan');
INSERT INTO `kategori` (`id`, `kode_prefix`, `nama`, `keterangan`) VALUES (8,'BUK','Buku & Media','Buku pelajaran & perpustakaan');
/*!40000 ALTER TABLE `kategori` ENABLE KEYS */;

/*!40000 ALTER TABLE `kerusakan` DISABLE KEYS */;
INSERT INTO `kerusakan` (`id`, `barang_id`, `lokasi_id`, `jumlah`, `tanggal_lapor`, `pelapor`, `deskripsi`, `foto`, `status`, `teknisi`, `estimasi_biaya`, `biaya_aktual`, `tanggal_selesai`, `catatan_persetujuan`, `created_by`, `created_at`, `updated_at`) VALUES (1,2,4,1,'2026-11-03','Dedi Pratama, S.Kom.','Laptop sering overheating lalu mati mendadak saat praktik.',NULL,'Dilaporkan',NULL,NULL,NULL,NULL,NULL,1,'2026-11-03 02:00:00','2026-11-06 22:59:24');
INSERT INTO `kerusakan` (`id`, `barang_id`, `lokasi_id`, `jumlah`, `tanggal_lapor`, `pelapor`, `deskripsi`, `foto`, `status`, `teknisi`, `estimasi_biaya`, `biaya_aktual`, `tanggal_selesai`, `catatan_persetujuan`, `created_by`, `created_at`, `updated_at`) VALUES (2,4,4,2,'2026-10-20','Dedi Pratama, S.Kom.','Layar berkedip lalu mati setelah 1 jam pemakaian.',NULL,'Menunggu Persetujuan','Fahmi (Teknisi)',600000.00,NULL,NULL,'Mohon persetujuan penggantian panel',1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `kerusakan` (`id`, `barang_id`, `lokasi_id`, `jumlah`, `tanggal_lapor`, `pelapor`, `deskripsi`, `foto`, `status`, `teknisi`, `estimasi_biaya`, `biaya_aktual`, `tanggal_selesai`, `catatan_persetujuan`, `created_by`, `created_at`, `updated_at`) VALUES (3,5,7,1,'2026-09-14','Rina Hartati, S.Pd.','Lampu proyektor mati, gambar gelap.',NULL,'Dalam Perbaikan','Fahmi (Teknisi)',900000.00,NULL,NULL,'Disetujui, pesan lampu ke vendor',1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `kerusakan` (`id`, `barang_id`, `lokasi_id`, `jumlah`, `tanggal_lapor`, `pelapor`, `deskripsi`, `foto`, `status`, `teknisi`, `estimasi_biaya`, `biaya_aktual`, `tanggal_selesai`, `catatan_persetujuan`, `created_by`, `created_at`, `updated_at`) VALUES (4,8,2,1,'2026-08-01','Sari Wulandari, S.Pd.','Head cetak tidak merata, hasil cetak bergaris.',NULL,'Selesai','Fahmi (Teknisi)',200000.00,150000.00,'2026-08-20','Head dibersihkan dan kabel diganti, sudah diuji',1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `kerusakan` (`id`, `barang_id`, `lokasi_id`, `jumlah`, `tanggal_lapor`, `pelapor`, `deskripsi`, `foto`, `status`, `teknisi`, `estimasi_biaya`, `biaya_aktual`, `tanggal_selesai`, `catatan_persetujuan`, `created_by`, `created_at`, `updated_at`) VALUES (5,19,8,1,'2026-04-14','Guru Kelas VIII B','Papan retak besar dan rangka patah.',NULL,'Rusak Permanen','Team Gudang',NULL,NULL,NULL,'Tidak ekonomis untuk diperbaiki, dihapus dari aset',1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `kerusakan` (`id`, `barang_id`, `lokasi_id`, `jumlah`, `tanggal_lapor`, `pelapor`, `deskripsi`, `foto`, `status`, `teknisi`, `estimasi_biaya`, `biaya_aktual`, `tanggal_selesai`, `catatan_persetujuan`, `created_by`, `created_at`, `updated_at`) VALUES (6,11,2,1,'2026-07-03','Sari Wulandari, S.Pd.','Router tidak menyala setelah listrik padam.',NULL,'Diperiksa','Fahmi (Teknisi)',NULL,NULL,NULL,'Menunggu pengecekan catu daya',1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `kerusakan` (`id`, `barang_id`, `lokasi_id`, `jumlah`, `tanggal_lapor`, `pelapor`, `deskripsi`, `foto`, `status`, `teknisi`, `estimasi_biaya`, `biaya_aktual`, `tanggal_selesai`, `catatan_persetujuan`, `created_by`, `created_at`, `updated_at`) VALUES (7,17,3,2,'2026-02-10','Rina Hartati, S.Pd.','Kaki kursi patah.',NULL,'Selesai','Team Gudang',120000.00,120000.00,'2026-02-25',NULL,1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
/*!40000 ALTER TABLE `kerusakan` ENABLE KEYS */;

/*!40000 ALTER TABLE `kerusakan_riwayat` DISABLE KEYS */;
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (1,1,NULL,'Dilaporkan','Laporan kerusakan dibuat oleh Dedi Pratama, S.Kom.','Administrator','2026-11-03 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (2,2,NULL,'Dilaporkan','Laporan kerusakan dibuat oleh Dedi Pratama, S.Kom.','Administrator','2026-10-20 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (3,2,'Dilaporkan','Diperiksa','Sudah diperiksa, perlu panel baru','Administrator','2026-10-20 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (4,2,'Diperiksa','Menunggu Persetujuan','Mohon persetujuan penggantian panel','Administrator','2026-10-20 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (5,3,NULL,'Dilaporkan','Laporan kerusakan dibuat oleh Rina Hartati, S.Pd.','Administrator','2026-09-14 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (6,3,'Dilaporkan','Diperiksa','','Administrator','2026-09-14 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (7,3,'Diperiksa','Menunggu Persetujuan','Penggantian lampu UHP','Administrator','2026-09-14 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (8,3,'Menunggu Persetujuan','Dalam Perbaikan','Disetujui, pesan lampu ke vendor','Administrator','2026-09-14 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (9,4,NULL,'Dilaporkan','Laporan kerusakan dibuat oleh Sari Wulandari, S.Pd.','Administrator','2026-08-01 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (10,4,'Dilaporkan','Diperiksa','','Administrator','2026-08-01 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (11,4,'Diperiksa','Menunggu Persetujuan','','Administrator','2026-08-01 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (12,4,'Menunggu Persetujuan','Dalam Perbaikan','','Administrator','2026-08-01 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (13,4,'Dalam Perbaikan','Selesai','Head dibersihkan dan kabel diganti, sudah diuji','Administrator','2026-08-01 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (14,5,NULL,'Dilaporkan','Laporan kerusakan dibuat oleh Guru Kelas VIII B','Administrator','2026-04-14 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (15,5,'Dilaporkan','Diperiksa','','Administrator','2026-04-14 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (16,5,'Diperiksa','Rusak Permanen','Tidak ekonomis untuk diperbaiki, dihapus dari aset','Administrator','2026-04-14 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (17,6,NULL,'Dilaporkan','Laporan kerusakan dibuat oleh Sari Wulandari, S.Pd.','Administrator','2026-07-03 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (18,6,'Dilaporkan','Diperiksa','Menunggu pengecekan catu daya','Administrator','2026-07-03 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (19,7,NULL,'Dilaporkan','Laporan kerusakan dibuat oleh Rina Hartati, S.Pd.','Administrator','2026-02-10 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (20,7,'Dilaporkan','Diperiksa','','Administrator','2026-02-10 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (21,7,'Diperiksa','Menunggu Persetujuan','','Administrator','2026-02-10 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (22,7,'Menunggu Persetujuan','Dalam Perbaikan','','Administrator','2026-02-10 02:00:00');
INSERT INTO `kerusakan_riwayat` (`id`, `kerusakan_id`, `status_lama`, `status_baru`, `catatan`, `user_nama`, `created_at`) VALUES (23,7,'Dalam Perbaikan','Selesai','','Administrator','2026-02-10 02:00:00');
/*!40000 ALTER TABLE `kerusakan_riwayat` ENABLE KEYS */;

/*!40000 ALTER TABLE `log_aktivitas` DISABLE KEYS */;
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (1,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-1: 6 unit','127.0.0.1','2026-11-07 05:58:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (2,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-2: 24 unit','127.0.0.1','2026-11-07 05:57:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (3,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-3: 36 unit','127.0.0.1','2026-11-07 05:56:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (4,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-4: 36 unit','127.0.0.1','2026-11-07 05:55:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (5,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-5: 6 unit','127.0.0.1','2026-11-07 05:54:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (6,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-6: 1 unit','127.0.0.1','2026-11-07 05:53:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (7,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-7: 2 unit','127.0.0.1','2026-11-07 05:52:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (8,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-8: 2 unit','127.0.0.1','2026-11-07 05:51:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (9,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-9: 1 unit','127.0.0.1','2026-11-07 05:50:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (10,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-10: 2 unit','127.0.0.1','2026-11-07 05:49:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (11,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-11: 1 unit','127.0.0.1','2026-11-07 05:48:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (12,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-12: 8 unit','127.0.0.1','2026-11-07 05:47:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (13,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-13: 6 unit','127.0.0.1','2026-11-07 05:46:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (14,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-14: 150 unit','127.0.0.1','2026-11-07 05:45:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (15,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-15: 150 unit','127.0.0.1','2026-11-07 05:44:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (16,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-16: 2 unit','127.0.0.1','2026-11-07 05:43:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (17,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-17: 18 unit','127.0.0.1','2026-11-07 05:42:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (18,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-18: 8 unit','127.0.0.1','2026-11-07 05:41:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (19,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-19: 25 unit','127.0.0.1','2026-11-07 05:40:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (20,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-20: 120 unit','127.0.0.1','2026-11-07 05:39:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (21,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-21: 60 unit','127.0.0.1','2026-11-07 05:38:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (22,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-22: 200 unit','127.0.0.1','2026-11-07 05:37:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (23,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-23: 80 unit','127.0.0.1','2026-11-07 05:36:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (24,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-24: 25 unit','127.0.0.1','2026-11-07 05:35:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (25,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-25: 4 unit','127.0.0.1','2026-11-07 05:34:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (26,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-26: 20 unit','127.0.0.1','2026-11-07 05:33:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (27,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-27: 15 unit','127.0.0.1','2026-11-07 05:32:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (28,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-28: 8 unit','127.0.0.1','2026-11-07 05:31:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (29,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-29: 12 unit','127.0.0.1','2026-11-07 05:30:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (30,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-30: 12 unit','127.0.0.1','2026-11-07 05:29:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (31,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-31: 20 unit','127.0.0.1','2026-11-07 05:28:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (32,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-32: 120 unit','127.0.0.1','2026-11-07 05:27:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (33,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-33: 12 unit','127.0.0.1','2026-11-07 05:26:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (34,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-34: 40 unit','127.0.0.1','2026-11-07 05:25:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (35,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-35: 30 unit','127.0.0.1','2026-11-07 05:24:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (36,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-36: 20 unit','127.0.0.1','2026-11-07 05:23:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (37,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-37: 6 unit','127.0.0.1','2026-11-07 05:22:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (38,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-38: 4 unit (menunggu persetujuan)','127.0.0.1','2026-11-07 05:21:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (39,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-39: 100 unit','127.0.0.1','2026-11-07 05:20:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (40,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-40: 60 unit','127.0.0.1','2026-11-07 05:19:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (41,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-41: 40 unit','127.0.0.1','2026-11-07 05:18:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (42,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-42: 2 unit','127.0.0.1','2026-11-07 05:17:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (43,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-1: 40 unit','127.0.0.1','2026-11-07 05:16:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (44,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-2: 3 unit','127.0.0.1','2026-11-07 05:15:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (45,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-3: 15 unit','127.0.0.1','2026-11-07 05:14:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (46,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-4: 1 unit','127.0.0.1','2026-11-07 05:13:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (47,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-5: 20 unit','127.0.0.1','2026-11-07 05:12:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (48,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-6: 1 unit','127.0.0.1','2026-11-07 05:11:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (49,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-7: 1 unit','127.0.0.1','2026-11-07 05:10:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (50,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-8: 1 unit','127.0.0.1','2026-11-07 05:09:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (51,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-9: 1 unit','127.0.0.1','2026-11-07 05:08:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (52,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-10: 1 unit','127.0.0.1','2026-11-07 05:07:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (53,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-11: 1 unit','127.0.0.1','2026-11-07 05:06:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (54,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-12: 1 unit','127.0.0.1','2026-11-07 05:05:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (55,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-13: 1 unit','127.0.0.1','2026-11-07 05:04:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (56,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-14: 1 unit','127.0.0.1','2026-11-07 05:03:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (57,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-15: 1 unit','127.0.0.1','2026-11-07 05:02:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (58,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-16: 1 unit','127.0.0.1','2026-11-07 05:01:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (59,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-17: 1 unit','127.0.0.1','2026-11-07 05:00:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (60,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-18: 1 unit','127.0.0.1','2026-11-07 04:59:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (61,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-19: 1 unit','127.0.0.1','2026-11-07 04:58:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (62,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-20: 1 unit','127.0.0.1','2026-11-07 04:57:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (63,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-21: 1 unit','127.0.0.1','2026-11-07 04:56:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (64,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-22: 1 unit','127.0.0.1','2026-11-07 04:55:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (65,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-23: 1 unit','127.0.0.1','2026-11-07 04:54:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (66,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-24: 1 unit','127.0.0.1','2026-11-07 04:53:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (67,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-25: 1 unit','127.0.0.1','2026-11-07 04:52:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (68,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-26: 1 unit','127.0.0.1','2026-11-07 04:51:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (69,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-27: 1 unit','127.0.0.1','2026-11-07 04:50:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (70,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-28: 1 unit','127.0.0.1','2026-11-07 04:49:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (71,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-29: 1 unit','127.0.0.1','2026-11-07 04:48:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (72,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-30: 1 unit','127.0.0.1','2026-11-07 04:47:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (73,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-31: 1 unit','127.0.0.1','2026-11-07 04:46:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (74,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-32: 1 unit','127.0.0.1','2026-11-07 04:45:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (75,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-33: 1 unit','127.0.0.1','2026-11-07 04:44:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (76,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-34: 1 unit','127.0.0.1','2026-11-07 04:43:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (77,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-35: 1 unit','127.0.0.1','2026-11-07 04:42:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (78,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-36: 4 unit','127.0.0.1','2026-11-07 04:41:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (79,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-37: 4 unit','127.0.0.1','2026-11-07 04:40:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (80,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-38: 4 unit','127.0.0.1','2026-11-07 04:39:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (81,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-39: 4 unit','127.0.0.1','2026-11-07 04:38:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (82,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-40: 4 unit','127.0.0.1','2026-11-07 04:37:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (83,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-41: 4 unit','127.0.0.1','2026-11-07 04:36:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (84,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-42: 4 unit','127.0.0.1','2026-11-07 04:35:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (85,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-43: 4 unit','127.0.0.1','2026-11-07 04:34:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (86,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-44: 4 unit','127.0.0.1','2026-11-07 04:33:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (87,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-45: 4 unit','127.0.0.1','2026-11-07 04:32:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (88,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-46: 4 unit','127.0.0.1','2026-11-07 04:31:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (89,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-47: 4 unit','127.0.0.1','2026-11-07 04:30:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (90,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-48: 4 unit','127.0.0.1','2026-11-07 04:29:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (91,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-49: 4 unit','127.0.0.1','2026-11-07 04:28:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (92,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-50: 4 unit','127.0.0.1','2026-11-07 04:27:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (93,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-51: 4 unit','127.0.0.1','2026-11-07 04:26:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (94,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-52: 4 unit','127.0.0.1','2026-11-07 04:25:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (95,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-53: 4 unit','127.0.0.1','2026-11-07 04:24:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (96,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-54: 4 unit','127.0.0.1','2026-11-07 04:23:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (97,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-55: 4 unit','127.0.0.1','2026-11-07 04:22:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (98,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-56: 4 unit','127.0.0.1','2026-11-07 04:21:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (99,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-57: 4 unit','127.0.0.1','2026-11-07 04:20:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (100,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-58: 4 unit','127.0.0.1','2026-11-07 04:19:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (101,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-59: 2 unit','127.0.0.1','2026-11-07 04:18:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (102,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-60: 2 unit','127.0.0.1','2026-11-07 04:17:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (103,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-61: 2 unit','127.0.0.1','2026-11-07 04:16:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (104,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-62: 2 unit','127.0.0.1','2026-11-07 04:15:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (105,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-63: 2 unit','127.0.0.1','2026-11-07 04:14:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (106,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-64: 2 unit','127.0.0.1','2026-11-07 04:13:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (107,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-65: 2 unit','127.0.0.1','2026-11-07 04:12:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (108,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-66: 2 unit','127.0.0.1','2026-11-07 04:11:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (109,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-67: 2 unit','127.0.0.1','2026-11-07 04:10:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (110,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-68: 2 unit','127.0.0.1','2026-11-07 04:09:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (111,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-69: 2 unit','127.0.0.1','2026-11-07 04:08:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (112,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-70: 2 unit','127.0.0.1','2026-11-07 04:07:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (113,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-71: 2 unit','127.0.0.1','2026-11-07 04:06:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (114,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-72: 2 unit','127.0.0.1','2026-11-07 04:05:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (115,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-73: 2 unit','127.0.0.1','2026-11-07 04:04:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (116,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-74: 2 unit','127.0.0.1','2026-11-07 04:03:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (117,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-75: 2 unit','127.0.0.1','2026-11-07 04:02:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (118,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-76: 2 unit','127.0.0.1','2026-11-07 04:01:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (119,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-77: 2 unit','127.0.0.1','2026-11-07 04:00:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (120,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-78: 2 unit','127.0.0.1','2026-11-07 03:59:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (121,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-79: 2 unit','127.0.0.1','2026-11-07 03:58:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (122,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-80: 2 unit','127.0.0.1','2026-11-07 03:57:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (123,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-81: 2 unit','127.0.0.1','2026-11-07 03:56:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (124,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-82: 2 unit','127.0.0.1','2026-11-07 03:55:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (125,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-83: 2 unit','127.0.0.1','2026-11-07 03:54:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (126,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-84: 2 unit','127.0.0.1','2026-11-07 03:53:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (127,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-85: 2 unit','127.0.0.1','2026-11-07 03:52:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (128,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-86: 2 unit','127.0.0.1','2026-11-07 03:51:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (129,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-87: 2 unit','127.0.0.1','2026-11-07 03:50:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (130,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-88: 2 unit','127.0.0.1','2026-11-07 03:49:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (131,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-89: 2 unit','127.0.0.1','2026-11-07 03:48:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (132,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-90: 2 unit','127.0.0.1','2026-11-07 03:47:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (133,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-91: 2 unit','127.0.0.1','2026-11-07 03:46:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (134,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-92: 2 unit','127.0.0.1','2026-11-07 03:45:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (135,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-93: 2 unit','127.0.0.1','2026-11-07 03:44:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (136,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-94: 2 unit','127.0.0.1','2026-11-07 03:43:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (137,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-95: 2 unit','127.0.0.1','2026-11-07 03:42:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (138,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-96: 2 unit','127.0.0.1','2026-11-07 03:41:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (139,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-97: 2 unit','127.0.0.1','2026-11-07 03:40:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (140,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-98: 2 unit','127.0.0.1','2026-11-07 03:39:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (141,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-99: 2 unit','127.0.0.1','2026-11-07 03:38:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (142,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-100: 2 unit','127.0.0.1','2026-11-07 03:37:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (143,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-101: 2 unit','127.0.0.1','2026-11-07 03:36:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (144,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-102: 1 unit','127.0.0.1','2026-11-07 03:35:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (145,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-103: 1 unit','127.0.0.1','2026-11-07 03:34:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (146,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-104: 1 unit','127.0.0.1','2026-11-07 03:33:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (147,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-105: 1 unit','127.0.0.1','2026-11-07 03:32:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (148,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-106: 1 unit','127.0.0.1','2026-11-07 03:31:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (149,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-107: 1 unit','127.0.0.1','2026-11-07 03:30:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (150,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-108: 1 unit','127.0.0.1','2026-11-07 03:29:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (151,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-109: 1 unit','127.0.0.1','2026-11-07 03:28:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (152,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-110: 1 unit','127.0.0.1','2026-11-07 03:27:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (153,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-111: 1 unit','127.0.0.1','2026-11-07 03:26:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (154,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-112: 1 unit','127.0.0.1','2026-11-07 03:25:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (155,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-113: 1 unit','127.0.0.1','2026-11-07 03:24:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (156,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-114: 1 unit','127.0.0.1','2026-11-07 03:23:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (157,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-115: 1 unit','127.0.0.1','2026-11-07 03:22:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (158,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-116: 1 unit','127.0.0.1','2026-11-07 03:21:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (159,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-117: 1 unit','127.0.0.1','2026-11-07 03:20:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (160,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-118: 1 unit','127.0.0.1','2026-11-07 03:19:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (161,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-119: 1 unit','127.0.0.1','2026-11-07 03:18:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (162,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-120: 1 unit','127.0.0.1','2026-11-07 03:17:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (163,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-121: 1 unit','127.0.0.1','2026-11-07 03:16:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (164,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-122: 1 unit','127.0.0.1','2026-11-07 03:15:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (165,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-123: 1 unit','127.0.0.1','2026-11-07 03:14:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (166,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-124: 1 unit','127.0.0.1','2026-11-07 03:13:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (167,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-125: 1 unit','127.0.0.1','2026-11-07 03:12:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (168,1,'admin','TAMBAH','barang_keluar','Pemakaian/keluar BK-126: 1 unit','127.0.0.1','2026-11-07 03:11:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (169,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-1: 1 unit oleh Rina Hartati, S.Pd.','127.0.0.1','2026-11-07 03:10:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (170,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-2: 1 unit oleh Dedi Pratama, S.Kom.','127.0.0.1','2026-11-07 03:09:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (171,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-3: 1 unit oleh OSIS SMP Negeri 8','127.0.0.1','2026-11-07 03:08:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (172,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-4: 1 unit oleh Yuni Lestari, S.Pd.','127.0.0.1','2026-11-07 03:07:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (173,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-5: 2 unit oleh Kelas IX A (simulasi)','127.0.0.1','2026-11-07 03:06:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (174,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-6: 1 unit oleh Panitia Pameran Sains','127.0.0.1','2026-11-07 03:05:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (175,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-7: 1 unit oleh Maya Sari, S.IP.','127.0.0.1','2026-11-07 03:04:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (176,1,'admin','UBAH','peminjaman','Pengembalian PJ-7: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 03:03:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (177,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-8: 1 unit oleh Panitia Porsenijar','127.0.0.1','2026-11-07 03:02:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (178,1,'admin','UBAH','peminjaman','Pengembalian PJ-8: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 03:01:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (179,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-9: 1 unit oleh Wali Kelas IX A','127.0.0.1','2026-11-07 03:00:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (180,1,'admin','UBAH','peminjaman','Pengembalian PJ-9: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 02:59:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (181,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-10: 1 unit oleh Guru Penjas','127.0.0.1','2026-11-07 02:58:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (182,1,'admin','UBAH','peminjaman','Pengembalian PJ-10: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 02:57:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (183,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-11: 1 unit oleh Sari Wulandari, S.Pd.','127.0.0.1','2026-11-07 02:56:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (184,1,'admin','UBAH','peminjaman','Pengembalian PJ-11: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 02:55:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (185,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-12: 1 unit oleh Dedi Pratama, S.Kom.','127.0.0.1','2026-11-07 02:54:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (186,1,'admin','UBAH','peminjaman','Pengembalian PJ-12: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 02:53:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (187,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-13: 1 unit oleh Rina Hartati, S.Pd.','127.0.0.1','2026-11-07 02:52:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (188,1,'admin','UBAH','peminjaman','Pengembalian PJ-13: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 02:51:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (189,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-14: 1 unit oleh Yuni Lestari, S.Pd.','127.0.0.1','2026-11-07 02:50:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (190,1,'admin','UBAH','peminjaman','Pengembalian PJ-14: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 02:49:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (191,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-15: 1 unit oleh Siswa Kelas VII B','127.0.0.1','2026-11-07 02:48:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (192,1,'admin','UBAH','peminjaman','Pengembalian PJ-15: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 02:47:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (193,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-16: 1 unit oleh Maya Sari, S.IP.','127.0.0.1','2026-11-07 02:46:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (194,1,'admin','UBAH','peminjaman','Pengembalian PJ-16: kembali 1, hilang 0, status Dikembalikan','127.0.0.1','2026-11-07 02:45:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (195,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-17: 1 unit oleh Panitia Lomba Pramuka','127.0.0.1','2026-11-07 02:44:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (196,1,'admin','UBAH','peminjaman','Pengembalian PJ-17: kembali 0, hilang 1, status Hilang','127.0.0.1','2026-11-07 02:43:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (197,1,'admin','TAMBAH','peminjaman','Peminjaman PJ-18: 3 unit oleh Kelas IX B (praktik)','127.0.0.1','2026-11-07 02:42:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (198,1,'admin','UBAH','peminjaman','Pengembalian PJ-18: kembali 2, hilang 0, status Dipinjam','127.0.0.1','2026-11-07 02:41:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (199,1,'admin','TAMBAH','pemindahan','Pindah PD-1: 20 unit dari Gudang Sekolah ke Ruang Kelas VII A','127.0.0.1','2026-11-07 02:40:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (200,1,'admin','TAMBAH','barang_masuk','Barang masuk BM-43: 2 unit (menunggu persetujuan)','127.0.0.1','2026-11-07 02:39:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (201,1,'admin','TAMBAH','kerusakan','Laporan kerusakan KR-1: 1 unit','127.0.0.1','2026-11-07 02:38:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (202,1,'admin','TAMBAH','kerusakan','Laporan kerusakan KR-2: 2 unit','127.0.0.1','2026-11-07 02:37:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (203,1,'admin','UBAH','kerusakan','KR-2: status Dilaporkan → Diperiksa','127.0.0.1','2026-11-07 02:36:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (204,1,'admin','UBAH','kerusakan','KR-2: status Diperiksa → Menunggu Persetujuan','127.0.0.1','2026-11-07 02:35:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (205,1,'admin','TAMBAH','kerusakan','Laporan kerusakan KR-3: 1 unit','127.0.0.1','2026-11-07 02:34:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (206,1,'admin','UBAH','kerusakan','KR-3: status Dilaporkan → Diperiksa','127.0.0.1','2026-11-07 02:33:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (207,1,'admin','UBAH','kerusakan','KR-3: status Diperiksa → Menunggu Persetujuan','127.0.0.1','2026-11-07 02:32:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (208,1,'admin','UBAH','kerusakan','KR-3: status Menunggu Persetujuan → Dalam Perbaikan','127.0.0.1','2026-11-07 02:31:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (209,1,'admin','TAMBAH','kerusakan','Laporan kerusakan KR-4: 1 unit','127.0.0.1','2026-11-07 02:30:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (210,1,'admin','UBAH','kerusakan','KR-4: status Dilaporkan → Diperiksa','127.0.0.1','2026-11-07 02:29:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (211,1,'admin','UBAH','kerusakan','KR-4: status Diperiksa → Menunggu Persetujuan','127.0.0.1','2026-11-07 02:28:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (212,1,'admin','UBAH','kerusakan','KR-4: status Menunggu Persetujuan → Dalam Perbaikan','127.0.0.1','2026-11-07 02:27:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (213,1,'admin','UBAH','kerusakan','KR-4: status Dalam Perbaikan → Selesai','127.0.0.1','2026-11-07 02:26:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (214,1,'admin','TAMBAH','kerusakan','Laporan kerusakan KR-5: 1 unit','127.0.0.1','2026-11-07 02:25:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (215,1,'admin','UBAH','kerusakan','KR-5: status Dilaporkan → Diperiksa','127.0.0.1','2026-11-07 02:24:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (216,1,'admin','UBAH','kerusakan','KR-5: status Diperiksa → Rusak Permanen','127.0.0.1','2026-11-07 02:23:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (217,1,'admin','TAMBAH','kerusakan','Laporan kerusakan KR-6: 1 unit','127.0.0.1','2026-11-07 02:22:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (218,1,'admin','UBAH','kerusakan','KR-6: status Dilaporkan → Diperiksa','127.0.0.1','2026-11-07 02:21:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (219,1,'admin','TAMBAH','kerusakan','Laporan kerusakan KR-7: 2 unit','127.0.0.1','2026-11-07 02:20:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (220,1,'admin','UBAH','kerusakan','KR-7: status Dilaporkan → Diperiksa','127.0.0.1','2026-11-07 02:19:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (221,1,'admin','UBAH','kerusakan','KR-7: status Diperiksa → Menunggu Persetujuan','127.0.0.1','2026-11-07 02:18:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (222,1,'admin','UBAH','kerusakan','KR-7: status Menunggu Persetujuan → Dalam Perbaikan','127.0.0.1','2026-11-07 02:17:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (223,1,'admin','UBAH','kerusakan','KR-7: status Dalam Perbaikan → Selesai','127.0.0.1','2026-11-07 02:16:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (224,1,'admin','TAMBAH','opname','Membuat sesi opname barang OPN-2026-001','127.0.0.1','2026-11-07 02:15:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (225,1,'admin','UBAH','opname','Finalisasi OPN-2026-001: 6 sesuai, 2 disesuaikan','127.0.0.1','2026-11-07 02:14:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (226,1,'admin','TAMBAH','opname','Membuat sesi opname barang OPN-2026-002','127.0.0.1','2026-11-07 02:13:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (227,1,'admin','UBAH','barang_masuk','Menyetujui barang masuk BM-38','127.0.0.1','2026-11-07 05:59:24');
INSERT INTO `log_aktivitas` (`id`, `user_id`, `username`, `aksi`, `modul`, `deskripsi`, `ip`, `created_at`) VALUES (228,1,'admin','UBAH','tahun','Menutup tahun ajaran 2025/2026; tahun berjalan 2026/2027','127.0.0.1','2026-11-07 05:59:24');
/*!40000 ALTER TABLE `log_aktivitas` ENABLE KEYS */;

/*!40000 ALTER TABLE `login_throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_throttle` ENABLE KEYS */;

/*!40000 ALTER TABLE `lokasi` DISABLE KEYS */;
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (1,'Ruang Kepala Sekolah','Drs. Ahmad Syahputra, M.Pd.',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (2,'Ruang Tata Usaha','Sari Wulandari, S.Pd.',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (3,'Ruang Guru','Rina Hartati, S.Pd.',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (4,'Laboratorium Komputer','Dedi Pratama, S.Kom.',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (5,'Laboratorium IPA','Yuni Lestari, S.Pd.',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (6,'Perpustakaan','Maya Sari, S.IP.',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (7,'Ruang Kelas VII A','Wali Kelas VII A',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (8,'Ruang Kelas VIII B','Wali Kelas VIII B',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (9,'Ruang Kelas IX A','Wali Kelas IX A',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (10,'Gudang Sekolah','Joko Susilo',NULL);
INSERT INTO `lokasi` (`id`, `nama`, `penanggung_jawab`, `keterangan`) VALUES (11,'Lapangan Olahraga','Guru Penjas',NULL);
/*!40000 ALTER TABLE `lokasi` ENABLE KEYS */;

/*!40000 ALTER TABLE `merek` DISABLE KEYS */;
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (1,'Canon',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (2,'Epson',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (3,'Lenovo',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (4,'Dell',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (5,'BenQ',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (6,'Polytron',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (7,'Snowman',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (8,'Pilot',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (9,'Faber-Castell',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (10,'TP-Link',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (11,'Cisco',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (12,'Olympus',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (13,'Sharp',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (14,'Mitra Furniture',NULL);
INSERT INTO `merek` (`id`, `nama`, `keterangan`) VALUES (15,'Generik',NULL);
/*!40000 ALTER TABLE `merek` ENABLE KEYS */;

/*!40000 ALTER TABLE `mutasi` DISABLE KEYS */;
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (1,1,'2025-01-08 05:59:23','masuk',6,6,6,6,6,'BM-1','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (2,2,'2025-01-08 05:59:23','masuk',24,24,24,24,24,'BM-2','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (3,3,'2024-11-15 05:59:23','masuk',36,36,36,36,36,'BM-3','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (4,4,'2024-11-16 05:59:23','masuk',36,36,36,36,36,'BM-4','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (5,5,'2024-09-10 05:59:23','masuk',6,6,6,6,6,'BM-5','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (6,6,'2025-02-10 05:59:23','masuk',1,1,1,1,1,'BM-6','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (7,7,'2025-03-02 05:59:23','masuk',2,2,2,2,2,'BM-7','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (8,8,'2025-03-03 05:59:23','masuk',2,2,2,2,2,'BM-8','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (9,9,'2025-03-15 05:59:23','masuk',1,1,1,1,1,'BM-9','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (10,10,'2021-07-12 05:59:23','masuk',2,2,2,2,2,'BM-10','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (11,11,'2024-06-01 05:59:23','masuk',1,1,1,1,1,'BM-11','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (12,12,'2025-06-05 05:59:23','masuk',8,8,8,8,8,'BM-12','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (13,13,'2025-03-02 05:59:23','masuk',6,6,6,6,6,'BM-13','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (14,14,'2025-01-03 05:59:23','masuk',150,150,150,150,150,'BM-14','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (15,15,'2025-01-03 05:59:23','masuk',150,150,150,150,150,'BM-15','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (16,16,'2023-02-01 05:59:23','masuk',2,2,2,2,2,'BM-16','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (17,17,'2024-07-20 05:59:23','masuk',18,18,18,18,18,'BM-17','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (18,18,'2025-01-18 05:59:23','masuk',8,8,8,8,8,'BM-18','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (19,19,'2025-01-20 05:59:23','masuk',25,25,25,25,25,'BM-19','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (20,20,'2026-02-10 05:59:23','masuk',120,120,120,120,120,'BM-20','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (21,21,'2026-02-11 05:59:23','masuk',60,60,60,60,60,'BM-21','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (22,22,'2026-03-07 05:59:23','masuk',200,200,200,200,200,'BM-22','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (23,23,'2026-01-20 05:59:23','masuk',80,80,80,80,80,'BM-23','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (24,24,'2025-02-20 05:59:23','masuk',25,25,25,25,25,'BM-24','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (25,25,'2025-02-20 05:59:23','masuk',4,4,4,4,4,'BM-25','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (26,26,'2025-01-15 05:59:23','masuk',20,20,20,20,20,'BM-26','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (27,27,'2025-02-02 05:59:23','masuk',15,15,15,15,15,'BM-27','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (28,28,'2024-10-05 05:59:23','masuk',8,8,8,8,8,'BM-28','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (29,29,'2025-03-05 05:59:23','masuk',12,12,12,12,12,'BM-29','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (30,30,'2025-01-05 05:59:23','masuk',12,12,12,12,12,'BM-30','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (31,31,'2025-01-05 05:59:23','masuk',20,20,20,20,20,'BM-31','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (32,32,'2025-07-10 05:59:23','masuk',120,120,120,120,120,'BM-32','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (33,33,'2024-08-01 05:59:23','masuk',12,12,12,12,12,'BM-33','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (34,34,'2026-02-01 05:59:23','masuk',40,40,40,40,40,'BM-34','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (35,35,'2026-02-11 05:59:23','masuk',30,30,30,30,30,'BM-35','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (36,36,'2026-01-10 05:59:23','masuk',20,20,20,20,20,'BM-36','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (37,37,'2025-01-05 05:59:23','masuk',6,6,6,6,6,'BM-37','Saldo awal pendataan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (38,22,'2026-06-03 05:59:23','masuk',100,100,100,300,300,'BM-39','Pembelian rutin semester genap','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (39,20,'2026-08-18 05:59:23','masuk',60,60,60,180,180,'BM-40','Pengadaan rutin awal semester','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (40,32,'2026-09-22 05:59:23','masuk',40,40,40,160,160,'BM-41','Hibah dari Dinas Pendidikan','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (41,12,'2026-05-14 05:59:23','masuk',2,2,2,10,10,'BM-42','Penambahan titik Wi-Fi','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (42,22,'2026-03-12 05:59:23','keluar',40,-40,-40,260,260,'BK-1','Distribusi ke Unit/Kelas — Ruang Guru','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (43,26,'2026-02-17 05:59:23','keluar',3,-3,-3,17,17,'BK-2','Distribusi ke Unit/Kelas — Laboratorium IPA','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (44,21,'2026-09-03 05:59:23','keluar',15,-15,-15,45,45,'BK-3','Distribusi ke Unit/Kelas — Ruang Guru','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (45,2,'2026-08-04 05:59:23','keluar',1,-1,-1,23,23,'BK-4','Distribusi ke Unit/Kelas — Ruang Kelas IX A','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (46,23,'2026-01-28 05:59:23','keluar',20,-20,-20,60,60,'BK-5','Dipindahkan ke Lokasi Lain — Ruang Kelas VII A','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (47,21,'2026-08-08 05:59:23','keluar',1,-1,-1,44,44,'BK-6','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (48,21,'2026-08-11 05:59:23','keluar',1,-1,-1,43,43,'BK-7','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (49,21,'2026-08-14 05:59:23','keluar',1,-1,-1,42,42,'BK-8','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (50,21,'2026-08-17 05:59:23','keluar',1,-1,-1,41,41,'BK-9','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (51,21,'2026-08-20 05:59:23','keluar',1,-1,-1,40,40,'BK-10','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (52,21,'2026-08-23 05:59:23','keluar',1,-1,-1,39,39,'BK-11','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (53,21,'2026-08-26 05:59:23','keluar',1,-1,-1,38,38,'BK-12','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (54,21,'2026-08-29 05:59:23','keluar',1,-1,-1,37,37,'BK-13','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (55,21,'2026-09-01 05:59:23','keluar',1,-1,-1,36,36,'BK-14','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (56,21,'2026-09-04 05:59:23','keluar',1,-1,-1,35,35,'BK-15','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (57,21,'2026-09-07 05:59:23','keluar',1,-1,-1,34,34,'BK-16','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (58,21,'2026-09-10 05:59:23','keluar',1,-1,-1,33,33,'BK-17','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (59,21,'2026-09-13 05:59:23','keluar',1,-1,-1,32,32,'BK-18','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (60,21,'2026-09-16 05:59:23','keluar',1,-1,-1,31,31,'BK-19','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (61,21,'2026-09-19 05:59:23','keluar',1,-1,-1,30,30,'BK-20','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (62,21,'2026-09-22 05:59:23','keluar',1,-1,-1,29,29,'BK-21','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (63,21,'2026-09-25 05:59:23','keluar',1,-1,-1,28,28,'BK-22','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (64,21,'2026-09-28 05:59:23','keluar',1,-1,-1,27,27,'BK-23','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (65,21,'2026-10-01 05:59:23','keluar',1,-1,-1,26,26,'BK-24','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (66,21,'2026-10-04 05:59:23','keluar',1,-1,-1,25,25,'BK-25','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (67,21,'2026-10-07 05:59:23','keluar',1,-1,-1,24,24,'BK-26','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (68,21,'2026-10-10 05:59:23','keluar',1,-1,-1,23,23,'BK-27','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (69,21,'2026-10-13 05:59:23','keluar',1,-1,-1,22,22,'BK-28','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (70,21,'2026-10-16 05:59:23','keluar',1,-1,-1,21,21,'BK-29','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (71,21,'2026-10-19 05:59:23','keluar',1,-1,-1,20,20,'BK-30','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (72,21,'2026-10-22 05:59:23','keluar',1,-1,-1,19,19,'BK-31','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (73,21,'2026-10-25 05:59:23','keluar',1,-1,-1,18,18,'BK-32','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (74,21,'2026-10-28 05:59:23','keluar',1,-1,-1,17,17,'BK-33','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (75,21,'2026-10-31 05:59:23','keluar',1,-1,-1,16,16,'BK-34','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (76,21,'2026-11-03 05:59:23','keluar',1,-1,-1,15,15,'BK-35','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (77,22,'2026-08-08 05:59:23','keluar',4,-4,-4,256,256,'BK-36','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (78,22,'2026-08-12 05:59:23','keluar',4,-4,-4,252,252,'BK-37','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (79,22,'2026-08-16 05:59:23','keluar',4,-4,-4,248,248,'BK-38','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (80,22,'2026-08-20 05:59:23','keluar',4,-4,-4,244,244,'BK-39','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (81,22,'2026-08-24 05:59:23','keluar',4,-4,-4,240,240,'BK-40','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (82,22,'2026-08-28 05:59:23','keluar',4,-4,-4,236,236,'BK-41','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (83,22,'2026-09-01 05:59:23','keluar',4,-4,-4,232,232,'BK-42','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (84,22,'2026-09-05 05:59:23','keluar',4,-4,-4,228,228,'BK-43','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (85,22,'2026-09-09 05:59:23','keluar',4,-4,-4,224,224,'BK-44','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (86,22,'2026-09-13 05:59:23','keluar',4,-4,-4,220,220,'BK-45','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (87,22,'2026-09-17 05:59:23','keluar',4,-4,-4,216,216,'BK-46','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (88,22,'2026-09-21 05:59:23','keluar',4,-4,-4,212,212,'BK-47','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (89,22,'2026-09-25 05:59:23','keluar',4,-4,-4,208,208,'BK-48','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (90,22,'2026-09-29 05:59:23','keluar',4,-4,-4,204,204,'BK-49','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (91,22,'2026-10-03 05:59:23','keluar',4,-4,-4,200,200,'BK-50','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (92,22,'2026-10-07 05:59:23','keluar',4,-4,-4,196,196,'BK-51','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (93,22,'2026-10-11 05:59:23','keluar',4,-4,-4,192,192,'BK-52','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (94,22,'2026-10-15 05:59:23','keluar',4,-4,-4,188,188,'BK-53','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:23');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (95,22,'2026-10-19 05:59:24','keluar',4,-4,-4,184,184,'BK-54','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (96,22,'2026-10-23 05:59:24','keluar',4,-4,-4,180,180,'BK-55','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (97,22,'2026-10-27 05:59:24','keluar',4,-4,-4,176,176,'BK-56','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (98,22,'2026-10-31 05:59:24','keluar',4,-4,-4,172,172,'BK-57','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (99,22,'2026-11-04 05:59:24','keluar',4,-4,-4,168,168,'BK-58','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (100,20,'2026-08-08 05:59:24','keluar',2,-2,-2,178,178,'BK-59','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (101,20,'2026-08-15 05:59:24','keluar',2,-2,-2,176,176,'BK-60','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (102,20,'2026-08-22 05:59:24','keluar',2,-2,-2,174,174,'BK-61','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (103,20,'2026-08-29 05:59:24','keluar',2,-2,-2,172,172,'BK-62','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (104,20,'2026-09-05 05:59:24','keluar',2,-2,-2,170,170,'BK-63','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (105,20,'2026-09-12 05:59:24','keluar',2,-2,-2,168,168,'BK-64','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (106,20,'2026-09-19 05:59:24','keluar',2,-2,-2,166,166,'BK-65','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (107,20,'2026-09-26 05:59:24','keluar',2,-2,-2,164,164,'BK-66','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (108,20,'2026-10-03 05:59:24','keluar',2,-2,-2,162,162,'BK-67','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (109,20,'2026-10-10 05:59:24','keluar',2,-2,-2,160,160,'BK-68','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (110,20,'2026-10-17 05:59:24','keluar',2,-2,-2,158,158,'BK-69','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (111,20,'2026-10-24 05:59:24','keluar',2,-2,-2,156,156,'BK-70','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (112,20,'2026-10-31 05:59:24','keluar',2,-2,-2,154,154,'BK-71','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (113,34,'2026-08-08 05:59:24','keluar',2,-2,-2,38,38,'BK-72','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (114,34,'2026-08-13 05:59:24','keluar',2,-2,-2,36,36,'BK-73','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (115,34,'2026-08-18 05:59:24','keluar',2,-2,-2,34,34,'BK-74','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (116,34,'2026-08-23 05:59:24','keluar',2,-2,-2,32,32,'BK-75','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (117,34,'2026-08-28 05:59:24','keluar',2,-2,-2,30,30,'BK-76','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (118,34,'2026-09-02 05:59:24','keluar',2,-2,-2,28,28,'BK-77','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (119,34,'2026-09-07 05:59:24','keluar',2,-2,-2,26,26,'BK-78','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (120,34,'2026-09-12 05:59:24','keluar',2,-2,-2,24,24,'BK-79','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (121,34,'2026-09-17 05:59:24','keluar',2,-2,-2,22,22,'BK-80','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (122,34,'2026-09-22 05:59:24','keluar',2,-2,-2,20,20,'BK-81','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (123,34,'2026-09-27 05:59:24','keluar',2,-2,-2,18,18,'BK-82','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (124,34,'2026-10-02 05:59:24','keluar',2,-2,-2,16,16,'BK-83','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (125,34,'2026-10-07 05:59:24','keluar',2,-2,-2,14,14,'BK-84','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (126,34,'2026-10-12 05:59:24','keluar',2,-2,-2,12,12,'BK-85','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (127,34,'2026-10-17 05:59:24','keluar',2,-2,-2,10,10,'BK-86','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (128,34,'2026-10-22 05:59:24','keluar',2,-2,-2,8,8,'BK-87','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (129,34,'2026-10-27 05:59:24','keluar',2,-2,-2,6,6,'BK-88','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (130,34,'2026-11-01 05:59:24','keluar',2,-2,-2,4,4,'BK-89','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (131,23,'2026-08-08 05:59:24','keluar',2,-2,-2,58,58,'BK-90','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (132,23,'2026-08-16 05:59:24','keluar',2,-2,-2,56,56,'BK-91','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (133,23,'2026-08-24 05:59:24','keluar',2,-2,-2,54,54,'BK-92','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (134,23,'2026-09-01 05:59:24','keluar',2,-2,-2,52,52,'BK-93','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (135,23,'2026-09-09 05:59:24','keluar',2,-2,-2,50,50,'BK-94','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (136,23,'2026-09-17 05:59:24','keluar',2,-2,-2,48,48,'BK-95','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (137,23,'2026-09-25 05:59:24','keluar',2,-2,-2,46,46,'BK-96','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (138,23,'2026-10-03 05:59:24','keluar',2,-2,-2,44,44,'BK-97','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (139,23,'2026-10-11 05:59:24','keluar',2,-2,-2,42,42,'BK-98','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (140,23,'2026-10-19 05:59:24','keluar',2,-2,-2,40,40,'BK-99','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (141,23,'2026-10-27 05:59:24','keluar',2,-2,-2,38,38,'BK-100','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (142,23,'2026-11-04 05:59:24','keluar',2,-2,-2,36,36,'BK-101','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (143,35,'2026-08-08 05:59:24','keluar',1,-1,-1,29,29,'BK-102','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (144,35,'2026-08-17 05:59:24','keluar',1,-1,-1,28,28,'BK-103','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (145,35,'2026-08-26 05:59:24','keluar',1,-1,-1,27,27,'BK-104','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (146,35,'2026-09-04 05:59:24','keluar',1,-1,-1,26,26,'BK-105','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (147,35,'2026-09-13 05:59:24','keluar',1,-1,-1,25,25,'BK-106','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (148,35,'2026-09-22 05:59:24','keluar',1,-1,-1,24,24,'BK-107','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (149,35,'2026-10-01 05:59:24','keluar',1,-1,-1,23,23,'BK-108','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (150,35,'2026-10-10 05:59:24','keluar',1,-1,-1,22,22,'BK-109','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (151,35,'2026-10-19 05:59:24','keluar',1,-1,-1,21,21,'BK-110','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (152,35,'2026-10-28 05:59:24','keluar',1,-1,-1,20,20,'BK-111','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (153,36,'2026-08-08 05:59:24','keluar',1,-1,-1,19,19,'BK-112','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (154,36,'2026-08-14 05:59:24','keluar',1,-1,-1,18,18,'BK-113','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (155,36,'2026-08-20 05:59:24','keluar',1,-1,-1,17,17,'BK-114','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (156,36,'2026-08-26 05:59:24','keluar',1,-1,-1,16,16,'BK-115','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (157,36,'2026-09-01 05:59:24','keluar',1,-1,-1,15,15,'BK-116','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (158,36,'2026-09-07 05:59:24','keluar',1,-1,-1,14,14,'BK-117','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (159,36,'2026-09-13 05:59:24','keluar',1,-1,-1,13,13,'BK-118','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (160,36,'2026-09-19 05:59:24','keluar',1,-1,-1,12,12,'BK-119','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (161,36,'2026-09-25 05:59:24','keluar',1,-1,-1,11,11,'BK-120','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (162,36,'2026-10-01 05:59:24','keluar',1,-1,-1,10,10,'BK-121','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (163,36,'2026-10-07 05:59:24','keluar',1,-1,-1,9,9,'BK-122','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (164,36,'2026-10-13 05:59:24','keluar',1,-1,-1,8,8,'BK-123','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (165,36,'2026-10-19 05:59:24','keluar',1,-1,-1,7,7,'BK-124','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (166,36,'2026-10-25 05:59:24','keluar',1,-1,-1,6,6,'BK-125','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (167,36,'2026-10-31 05:59:24','keluar',1,-1,-1,5,5,'BK-126','Pemakaian Operasional — Unit operasional','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (168,1,'2026-10-28 05:59:24','pinjam',1,0,-1,6,5,'PJ-1','Dipinjam oleh Rina Hartati, S.Pd. (Kelas VIII B (presentasi))','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (169,5,'2026-11-02 05:59:24','pinjam',1,0,-1,6,5,'PJ-2','Dipinjam oleh Dedi Pratama, S.Kom. (Laboratorium Komputer (pelatihan))','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (170,7,'2026-11-04 05:59:24','pinjam',1,0,-1,2,1,'PJ-3','Dipinjam oleh OSIS SMP Negeri 8 (Persiapan Hari Anak Nasional)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (171,28,'2026-10-02 05:59:24','pinjam',1,0,-1,8,7,'PJ-4','Dipinjam oleh Yuni Lestari, S.Pd. (Praktikum tambahan kelas IX)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (172,2,'2026-10-10 05:59:24','pinjam',2,0,-2,23,21,'PJ-5','Dipinjam oleh Kelas IX A (simulasi) (Simulasi ujian berbasis komputer)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (173,26,'2026-09-28 05:59:24','pinjam',1,0,-1,17,16,'PJ-6','Dipinjam oleh Panitia Pameran Sains (Pameran sains tingkat sekolah)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (174,5,'2026-01-14 05:59:24','pinjam',1,0,-1,6,4,'PJ-7','Dipinjam oleh Maya Sari, S.IP. (Perpustakaan)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (175,5,'2026-01-16 05:59:24','kembali',1,0,1,6,5,'PJ-7','Dikembalikan Maya Sari, S.IP. — kondisi: Baik','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (176,17,'2026-02-02 05:59:24','pinjam',1,0,-1,18,17,'PJ-8','Dipinjam oleh Panitia Porsenijar (Lapangan Olahraga)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (177,17,'2026-02-06 05:59:24','kembali',1,0,1,18,18,'PJ-8','Dikembalikan Panitia Porsenijar — kondisi: Ada Lecet','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (178,1,'2026-03-10 05:59:24','pinjam',1,0,-1,6,4,'PJ-9','Dipinjam oleh Wali Kelas IX A (Ruang Kelas IX A)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (179,1,'2026-03-12 05:59:24','kembali',1,0,1,6,5,'PJ-9','Dikembalikan Wali Kelas IX A — kondisi: Baik','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (180,7,'2026-04-05 05:59:24','pinjam',1,0,-1,2,0,'PJ-10','Dipinjam oleh Guru Penjas (Lapangan Olahraga)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (181,7,'2026-04-05 05:59:24','kembali',1,0,1,2,1,'PJ-10','Dikembalikan Guru Penjas — kondisi: Baik','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (182,8,'2026-05-20 05:59:24','pinjam',1,0,-1,2,1,'PJ-11','Dipinjam oleh Sari Wulandari, S.Pd. (Ruang Tata Usaha)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (183,8,'2026-05-27 05:59:24','kembali',1,0,1,2,2,'PJ-11','Dikembalikan Sari Wulandari, S.Pd. — kondisi: Baik','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (184,2,'2026-06-08 05:59:24','pinjam',1,0,-1,23,20,'PJ-12','Dipinjam oleh Dedi Pratama, S.Kom. (Laboratorium Komputer)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (185,2,'2026-06-15 05:59:24','kembali',1,0,1,23,21,'PJ-12','Dikembalikan Dedi Pratama, S.Kom. — kondisi: Baik','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (186,5,'2026-07-01 05:59:24','pinjam',1,0,-1,6,4,'PJ-13','Dipinjam oleh Rina Hartati, S.Pd. (Ruang Kelas VIII B)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (187,5,'2026-07-03 05:59:24','kembali',1,0,1,6,5,'PJ-13','Dikembalikan Rina Hartati, S.Pd. — kondisi: Perlu Perhatian','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (188,28,'2026-07-14 05:59:24','pinjam',1,0,-1,8,6,'PJ-14','Dipinjam oleh Yuni Lestari, S.Pd. (Laboratorium IPA)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (189,28,'2026-07-18 05:59:24','kembali',1,0,1,8,7,'PJ-14','Dikembalikan Yuni Lestari, S.Pd. — kondisi: Baik','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (190,33,'2026-08-10 05:59:24','pinjam',1,0,-1,12,11,'PJ-15','Dipinjam oleh Siswa Kelas VII B (Perpustakaan)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (191,33,'2026-08-17 05:59:24','kembali',1,0,1,12,12,'PJ-15','Dikembalikan Siswa Kelas VII B — kondisi: Baik','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (192,6,'2026-09-07 05:59:24','pinjam',1,0,-1,1,0,'PJ-16','Dipinjam oleh Maya Sari, S.IP. (Perpustakaan)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (193,6,'2026-09-09 05:59:24','kembali',1,0,1,1,1,'PJ-16','Dikembalikan Maya Sari, S.IP. — kondisi: Baik','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (194,7,'2026-06-15 05:59:24','pinjam',1,0,-1,2,0,'PJ-17','Dipinjam oleh Panitia Lomba Pramuka (Kegiatan Pramuka)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (195,7,'2026-07-02 05:59:24','hilang',1,-1,0,1,0,'PJ-17','Hilang saat dipinjam Panitia Lomba Pramuka','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (196,2,'2026-06-01 05:59:24','pinjam',3,0,-3,23,18,'PJ-18','Dipinjam oleh Kelas IX B (praktik) (Praktik komputer)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (197,2,'2026-06-10 05:59:24','kembali',2,0,2,23,20,'PJ-18','Dikembalikan Kelas IX B (praktik) — kondisi: Baik','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (198,15,'2026-09-01 05:59:24','pindah',20,0,0,150,150,'PD-1','Pindah dari Gudang Sekolah ke Ruang Kelas VII A — Penambahan kursi kelas VII A','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (199,2,'2026-11-03 05:59:24','rusak',1,0,-1,23,19,'KR-1','Dilaporkan rusak: Laptop sering overheating lalu mati mendadak saat praktik.','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (200,4,'2026-10-20 05:59:24','rusak',2,0,-2,36,34,'KR-2','Dilaporkan rusak: Layar berkedip lalu mati setelah 1 jam pemakaian.','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (201,5,'2026-09-14 05:59:24','rusak',1,0,-1,6,4,'KR-3','Dilaporkan rusak: Lampu proyektor mati, gambar gelap.','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (202,8,'2026-08-01 05:59:24','rusak',1,0,-1,2,1,'KR-4','Dilaporkan rusak: Head cetak tidak merata, hasil cetak bergaris.','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (203,8,'2026-11-07 05:59:24','selesai_perbaikan',1,0,1,2,2,'KR-4','Perbaikan selesai, unit kembali tersedia','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (204,19,'2026-04-14 05:59:24','rusak',1,0,-1,25,24,'KR-5','Dilaporkan rusak: Papan retak besar dan rangka patah.','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (205,19,'2026-11-07 05:59:24','rusak_permanen',1,-1,0,24,24,'KR-5','Dihapus dari aset (rusak permanen)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (206,11,'2026-07-03 05:59:24','rusak',1,0,-1,1,0,'KR-6','Dilaporkan rusak: Router tidak menyala setelah listrik padam.','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (207,17,'2026-02-10 05:59:24','rusak',2,0,-2,18,16,'KR-7','Dilaporkan rusak: Kaki kursi patah.','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (208,17,'2026-11-07 05:59:24','selesai_perbaikan',2,0,2,18,18,'KR-7','Perbaikan selesai, unit kembali tersedia','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (209,22,'2026-06-22 15:00:00','opname',1,-1,-1,167,167,'OP-1','Penyesuaian opname OPN-2026-001 di ruangan (fisik 167)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (210,25,'2026-06-22 15:00:00','opname',2,2,2,6,6,'OP-1','Penyesuaian opname OPN-2026-001 di ruangan (fisik 6)','Administrator','2026-11-06 22:59:24');
INSERT INTO `mutasi` (`id`, `barang_id`, `tanggal`, `jenis`, `jumlah`, `perubahan_total`, `perubahan_tersedia`, `saldo_total`, `saldo_tersedia`, `referensi`, `keterangan`, `user_nama`, `created_at`) VALUES (211,2,'2026-04-22 05:59:24','masuk',4,4,4,27,23,'BM-38','Tambahan laptop praktik','Administrator','2026-11-06 22:59:24');
/*!40000 ALTER TABLE `mutasi` ENABLE KEYS */;

/*!40000 ALTER TABLE `pemindahan` DISABLE KEYS */;
INSERT INTO `pemindahan` (`id`, `barang_id`, `lokasi_asal_id`, `lokasi_tujuan_id`, `jumlah`, `tanggal`, `keterangan`, `created_by`, `created_at`) VALUES (1,15,10,7,20,'2026-09-01','Penambahan kursi kelas VII A',1,'2026-11-06 22:59:24');
/*!40000 ALTER TABLE `pemindahan` ENABLE KEYS */;

/*!40000 ALTER TABLE `peminjaman` DISABLE KEYS */;
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (1,1,3,1,0,0,1,'Rina Hartati, S.Pd.','','Guru','Kelas VIII B (presentasi)','2026-10-28','2026-11-12',NULL,'Baik',NULL,'Dipinjam','',NULL,1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (2,5,7,1,0,0,1,'Dedi Pratama, S.Kom.','','Guru','Laboratorium Komputer (pelatihan)','2026-11-02','2026-11-09',NULL,'Baik',NULL,'Dipinjam','',NULL,1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (3,7,11,1,0,0,1,'OSIS SMP Negeri 8','','Unit / Kelas','Persiapan Hari Anak Nasional','2026-11-04','2026-11-07',NULL,'Baik',NULL,'Dipinjam','',NULL,1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (4,28,5,1,0,0,1,'Yuni Lestari, S.Pd.','','Guru','Praktikum tambahan kelas IX','2026-10-02','2026-10-16',NULL,'Baik',NULL,'Dipinjam','',NULL,1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (5,2,4,2,0,0,2,'Kelas IX A (simulasi)','','Unit / Kelas','Simulasi ujian berbasis komputer','2026-10-10','2026-10-24',NULL,'Baik',NULL,'Dipinjam','',NULL,1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (6,26,5,1,0,0,1,'Panitia Pameran Sains','','Unit / Kelas','Pameran sains tingkat sekolah','2026-09-28','2026-10-05',NULL,'Baik',NULL,'Dipinjam','',NULL,1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (7,5,7,1,1,0,0,'Maya Sari, S.IP.','','Guru','Perpustakaan','2026-01-14','2026-01-16','2026-01-16','Baik','Baik','Dikembalikan','',NULL,1,'2026-01-14 01:00:00','2026-01-16 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (8,17,3,1,1,0,0,'Panitia Porsenijar','','Unit / Kelas','Lapangan Olahraga','2026-02-02','2026-02-06','2026-02-06','Baik','Ada Lecet','Dikembalikan','',NULL,1,'2026-02-02 01:00:00','2026-02-06 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (9,1,3,1,1,0,0,'Wali Kelas IX A','','Guru','Ruang Kelas IX A','2026-03-10','2026-03-12','2026-03-12','Baik','Baik','Dikembalikan','',NULL,1,'2026-03-10 01:00:00','2026-03-12 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (10,7,11,1,1,0,0,'Guru Penjas','','Guru','Lapangan Olahraga','2026-04-05','2026-04-05','2026-04-05','Baik','Baik','Dikembalikan','',NULL,1,'2026-04-05 01:00:00','2026-04-05 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (11,8,2,1,1,0,0,'Sari Wulandari, S.Pd.','','Guru','Ruang Tata Usaha','2026-05-20','2026-05-27','2026-05-27','Baik','Baik','Dikembalikan','',NULL,1,'2026-05-20 01:00:00','2026-05-27 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (12,2,4,1,1,0,0,'Dedi Pratama, S.Kom.','','Guru','Laboratorium Komputer','2026-06-08','2026-06-15','2026-06-15','Baik','Baik','Dikembalikan','',NULL,1,'2026-06-08 01:00:00','2026-06-15 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (13,5,7,1,1,0,0,'Rina Hartati, S.Pd.','','Guru','Ruang Kelas VIII B','2026-07-01','2026-07-03','2026-07-03','Baik','Perlu Perhatian','Dikembalikan','',NULL,1,'2026-07-01 01:00:00','2026-07-03 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (14,28,5,1,1,0,0,'Yuni Lestari, S.Pd.','','Guru','Laboratorium IPA','2026-07-14','2026-07-18','2026-07-18','Baik','Baik','Dikembalikan','',NULL,1,'2026-07-14 01:00:00','2026-07-18 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (15,33,6,1,1,0,0,'Siswa Kelas VII B','','Siswa','Perpustakaan','2026-08-10','2026-08-17','2026-08-17','Baik','Baik','Dikembalikan','',NULL,1,'2026-08-10 01:00:00','2026-08-17 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (16,6,6,1,1,0,0,'Maya Sari, S.IP.','','Guru','Perpustakaan','2026-09-07','2026-09-09','2026-09-09','Baik','Baik','Dikembalikan','',NULL,1,'2026-09-07 01:00:00','2026-09-09 07:00:00');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (17,7,11,1,0,1,0,'Panitia Lomba Pramuka','','Unit / Kelas','Kegiatan Pramuka','2026-06-15','2026-06-20','2026-07-02','Baik','Rusak','Hilang','[Pengembalian 02 Jul 2026] Tidak ditemukan setelah kegiatan',NULL,1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
INSERT INTO `peminjaman` (`id`, `barang_id`, `lokasi_asal_id`, `jumlah`, `dikembalikan`, `hilang`, `sisa`, `peminjam`, `kontak`, `tipe_peminjam`, `unit`, `tanggal_pinjam`, `tanggal_rencana_kembali`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `pengingat_terakhir`, `created_by`, `created_at`, `updated_at`) VALUES (18,2,4,3,2,0,1,'Kelas IX B (praktik)','','Unit / Kelas','Praktik komputer','2026-06-01','2026-06-20','2026-06-10','Baik','Baik','Dipinjam','[Pengembalian 10 Jun 2026] Sebagian dikembalikan',NULL,1,'2026-11-06 22:59:24','2026-11-06 22:59:24');
/*!40000 ALTER TABLE `peminjaman` ENABLE KEYS */;

/*!40000 ALTER TABLE `pengaturan` DISABLE KEYS */;
INSERT INTO `pengaturan` (`kunci`, `nilai`) VALUES ('alamat','Jl. Contoh Pendidikan No. 8, Medan, Sumatera Utara');
INSERT INTO `pengaturan` (`kunci`, `nilai`) VALUES ('ambang_persetujuan_masuk','10000000');
INSERT INTO `pengaturan` (`kunci`, `nilai`) VALUES ('kepala_sekolah','Drs. Ahmad Syahputra, M.Pd.');
INSERT INTO `pengaturan` (`kunci`, `nilai`) VALUES ('nama_instansi','UPT SMP Negeri 8 Medan');
INSERT INTO `pengaturan` (`kunci`, `nilai`) VALUES ('nip_kepala','197001011998031001');
INSERT INTO `pengaturan` (`kunci`, `nilai`) VALUES ('nip_pjbmn','198505152010012003');
INSERT INTO `pengaturan` (`kunci`, `nilai`) VALUES ('penanggung_jawab_bmn','Sari Wulandari, S.Pd.');
INSERT INTO `pengaturan` (`kunci`, `nilai`) VALUES ('tahun_ajaran','2026/2027');
/*!40000 ALTER TABLE `pengaturan` ENABLE KEYS */;

/*!40000 ALTER TABLE `penghapusan` DISABLE KEYS */;
INSERT INTO `penghapusan` (`id`, `nomor_ba`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `tanggal_usul`, `tanggal_setujui`, `nilai_buku_unit`, `keterangan`, `status`, `sumber`, `kerusakan_id`, `diusulkan_oleh`, `disetujui_oleh`, `created_at`) VALUES (1,NULL,30,10,1,'Dimusnahkan','2026-11-05',NULL,NULL,'Rangka patah, tidak layak pakai','Diusulkan','Manual',NULL,'Administrator',NULL,'2026-11-06 22:59:24');
INSERT INTO `penghapusan` (`id`, `nomor_ba`, `barang_id`, `lokasi_id`, `jumlah`, `alasan`, `tanggal_usul`, `tanggal_setujui`, `nilai_buku_unit`, `keterangan`, `status`, `sumber`, `kerusakan_id`, `diusulkan_oleh`, `disetujui_oleh`, `created_at`) VALUES (2,'BA-HAPUS/2026/001',19,8,1,'Rusak permanen','2026-11-07','2026-11-07',312000.00,'Dari laporan KR-0005','Disetujui','Kerusakan',5,'Guru Kelas VIII B','Administrator','2026-11-06 22:59:24');
/*!40000 ALTER TABLE `penghapusan` ENABLE KEYS */;

/*!40000 ALTER TABLE `stok_lokasi` DISABLE KEYS */;
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (1,3,6);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (2,4,27);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (3,4,36);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (4,4,36);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (5,7,6);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (6,6,1);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (7,11,1);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (8,2,2);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (9,2,1);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (10,10,2);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (11,2,1);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (12,9,10);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (13,4,6);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (14,10,150);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (15,7,20);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (15,10,130);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (16,1,2);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (17,3,18);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (18,2,8);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (19,8,24);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (20,10,154);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (21,10,15);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (22,2,167);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (23,10,36);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (24,2,25);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (25,2,6);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (26,5,17);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (27,5,15);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (28,5,8);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (29,11,12);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (30,10,12);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (31,10,20);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (32,6,160);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (33,6,12);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (34,2,4);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (35,10,20);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (36,10,5);
INSERT INTO `stok_lokasi` (`barang_id`, `lokasi_id`, `jumlah`) VALUES (37,10,6);
/*!40000 ALTER TABLE `stok_lokasi` ENABLE KEYS */;

/*!40000 ALTER TABLE `stok_opname` DISABLE KEYS */;
INSERT INTO `stok_opname` (`id`, `kode`, `judul`, `tanggal`, `lokasi_id`, `status`, `catatan`, `created_by`, `created_at`, `finalized_at`, `finalized_by`) VALUES (1,'OPN-2026-001','Inventarisasi Akhir Semester Genap','2026-06-22',2,'Selesai','Pencacahan ruang tata usaha',1,'2026-06-22 01:00:00','2026-06-22 16:00:00',1);
INSERT INTO `stok_opname` (`id`, `kode`, `judul`, `tanggal`, `lokasi_id`, `status`, `catatan`, `created_by`, `created_at`, `finalized_at`, `finalized_by`) VALUES (2,'OPN-2026-002','Opname Bulanan Laboratorium IPA','2026-11-05',5,'Draft','Pencacahan bulanan laboratorium',1,'2026-11-06 22:59:24',NULL,NULL);
/*!40000 ALTER TABLE `stok_opname` ENABLE KEYS */;

/*!40000 ALTER TABLE `stok_opname_item` DISABLE KEYS */;
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (1,1,8,2,2,0,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (2,1,9,1,1,0,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (3,1,11,1,1,0,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (4,1,18,8,8,0,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (5,1,22,168,167,-1,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (6,1,24,25,25,0,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (7,1,25,4,6,2,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (8,1,34,4,4,0,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (16,2,26,17,17,NULL,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (17,2,27,15,15,NULL,NULL);
INSERT INTO `stok_opname_item` (`id`, `opname_id`, `barang_id`, `stok_sistem`, `stok_fisik`, `selisih`, `keterangan`) VALUES (18,2,28,8,NULL,NULL,NULL);
/*!40000 ALTER TABLE `stok_opname_item` ENABLE KEYS */;

/*!40000 ALTER TABLE `tahun_ajaran` DISABLE KEYS */;
INSERT INTO `tahun_ajaran` (`id`, `nama`, `tanggal_mulai`, `tanggal_selesai`, `status`, `ditutup_pada`, `ditutup_oleh`) VALUES (1,'2025/2026','2025-07-15','2026-07-14','Ditutup','2026-11-07 05:59:24','Administrator');
INSERT INTO `tahun_ajaran` (`id`, `nama`, `tanggal_mulai`, `tanggal_selesai`, `status`, `ditutup_pada`, `ditutup_oleh`) VALUES (2,'2026/2027','2026-07-15','2027-07-14','Aktif',NULL,NULL);
/*!40000 ALTER TABLE `tahun_ajaran` ENABLE KEYS */;

/*!40000 ALTER TABLE `tutup_buku` DISABLE KEYS */;
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (1,1,1,6,6,57000000.00,19237500.00,37762500.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (2,1,2,28,27,202000000.00,59415000.00,142585000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (3,1,3,36,36,298800000.00,106447500.00,192352500.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (4,1,4,36,36,57600000.00,20520000.00,37080000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (5,1,5,6,6,37200000.00,12276000.00,24924000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (6,1,6,1,1,4100000.00,1045500.00,3054500.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (7,1,7,1,1,1850000.00,616666.67,1233333.33,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (8,1,8,2,2,5300000.00,1590000.00,3710000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (9,1,9,1,1,1900000.00,534375.00,1365625.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (10,1,10,2,2,9600000.00,8640000.00,960000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (11,1,11,1,0,6800000.00,3187500.00,3612500.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (12,1,12,10,10,10960000.00,2226000.00,8734000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (13,1,13,6,6,3900000.00,1170000.00,2730000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (14,1,14,150,150,52500000.00,9843750.00,42656250.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (15,1,15,150,150,27750000.00,5203125.00,22546875.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (16,1,16,2,2,4200000.00,1793750.00,2406250.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (17,1,17,18,16,14040000.00,3363750.00,10676250.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (18,1,18,8,8,11600000.00,2054166.67,9545833.33,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (19,1,19,25,24,12000000.00,3400000.00,8600000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (20,1,20,120,120,0.00,0.00,0.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (21,1,21,60,60,0.00,0.00,0.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (22,1,22,259,259,0.00,0.00,0.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (23,1,23,60,60,0.00,0.00,0.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (24,1,24,25,25,450000.00,300000.00,150000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (25,1,25,6,6,990000.00,440000.00,550000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (26,1,26,17,17,3570000.00,1011500.00,2558500.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (27,1,27,15,15,2775000.00,1310416.67,1464583.33,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (28,1,28,8,7,116000000.00,25375000.00,90625000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (29,1,29,12,12,2700000.00,2700000.00,0.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (30,1,30,12,12,1800000.00,900000.00,900000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (31,1,31,20,20,760000.00,760000.00,0.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (32,1,32,120,120,10200000.00,2550000.00,7650000.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (33,1,33,12,12,2520000.00,1207500.00,1312500.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (34,1,34,40,40,0.00,0.00,0.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (35,1,35,30,30,0.00,0.00,0.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (36,1,36,20,20,0.00,0.00,0.00,'2026-11-06 22:59:24');
INSERT INTO `tutup_buku` (`id`, `tahun_ajaran_id`, `barang_id`, `stok_total`, `tersedia`, `perolehan`, `akumulasi`, `nilai_buku`, `created_at`) VALUES (37,1,37,6,6,510000.00,510000.00,0.00,'2026-11-06 22:59:24');
/*!40000 ALTER TABLE `tutup_buku` ENABLE KEYS */;

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `nama`, `no_hp`, `username`, `password`, `role`, `aktif`, `last_login`, `created_at`) VALUES (1,'Administrator','081000000001','admin','$2y$10$gJmLJBxlldawn9omsbwDYuGtEG6ughUHH3FfEF5zyq4xEkwL8/VUC','admin',1,NULL,'2026-11-06 22:59:23');
INSERT INTO `users` (`id`, `nama`, `no_hp`, `username`, `password`, `role`, `aktif`, `last_login`, `created_at`) VALUES (2,'Sari Wulandari, S.Pd.','081200000002','operator','$2y$10$aMabB52n6TLp3vXxbMfvJ.ubBIxXVpBujCWNy9R9.wmBSG1Ice9Oa','operator',1,NULL,'2026-11-06 22:59:23');
INSERT INTO `users` (`id`, `nama`, `no_hp`, `username`, `password`, `role`, `aktif`, `last_login`, `created_at`) VALUES (3,'Drs. Ahmad Syahputra, M.Pd.','081300000003','kepsek','$2y$10$7oNZsdEwv9hDjhlJeerBR.0kOdvyPvkGWVjKr0efW/2FQQSW95ot6','kepala_sekolah',1,NULL,'2026-11-06 22:59:23');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

