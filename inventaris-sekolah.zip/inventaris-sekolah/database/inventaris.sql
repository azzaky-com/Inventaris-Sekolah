-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2025 at 12:04 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventaris`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `recompute_barang_aktif` (IN `p_barang_id` INT)  BEGIN
  DECLARE v_total_masuk INT DEFAULT 0;
  DECLARE v_total_rusak INT DEFAULT 0;
  DECLARE v_total_dipinjam INT DEFAULT 0;
  DECLARE v_aktif_qty INT DEFAULT 0;
  DECLARE v_kode VARCHAR(50);
  DECLARE v_nama VARCHAR(128);

  SELECT COALESCE(SUM(jumlah),0) INTO v_total_masuk FROM barang_masuk WHERE barang_id = p_barang_id;
  SELECT COALESCE(COUNT(*),0) INTO v_total_rusak FROM barang_rusak WHERE barang_id = p_barang_id;
  SELECT COALESCE(COUNT(*),0) INTO v_total_dipinjam FROM barang_dipinjam WHERE barang_id = p_barang_id AND status IN ('Dipinjam','Hilang','Rusak');

  SET v_aktif_qty = GREATEST(0, v_total_masuk - v_total_rusak - v_total_dipinjam);

  SELECT kode_barang, nama_barang INTO v_kode, v_nama FROM barang WHERE idbarang = p_barang_id LIMIT 1;

  IF EXISTS (SELECT 1 FROM barang_aktif WHERE barang_id = p_barang_id) THEN
    UPDATE barang_aktif
    SET total_masuk = v_total_masuk,
        total_rusak = v_total_rusak,
        total_dipinjam = v_total_dipinjam,
        aktif_qty = v_aktif_qty,
        updated_at = NOW()
    WHERE barang_id = p_barang_id;
  ELSE
    INSERT INTO barang_aktif (barang_id, kode_barang, nama_barang, total_masuk, total_rusak, total_dipinjam, aktif_qty)
    VALUES (p_barang_id, v_kode, v_nama, v_total_masuk, v_total_rusak, v_total_dipinjam, v_aktif_qty);
  END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `idbarang` int(11) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `merek_id` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `nama_barang` varchar(128) NOT NULL,
  `keterangan` varchar(256) DEFAULT '',
  `stok` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`idbarang`, `kode_barang`, `merek_id`, `kategori_id`, `nama_barang`, `keterangan`, `stok`, `created_at`, `updated_at`) VALUES
(1, 'BRG-001', 1, 1, 'Printer Canon MF244', 'Printer kelas tata usaha', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(2, 'BRG-002', 2, 1, 'Printer Epson L3110', 'Printer lab & administrasi', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(3, 'BRG-003', 19, 1, 'Printer Brother HL-L2370', 'Printer ruang guru', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(4, 'BRG-004', 5, 1, 'PC Desktop Lab A', 'Unit PC untuk laboratorium komputer', 17, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(5, 'BRG-005', 4, 1, 'Laptop Guru X1', 'Laptop guru untuk administrasi', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(6, 'BRG-006', 6, 1, 'Proyektor BenQ MS536', 'Proyektor ruang kelas', 4, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(7, 'BRG-007', 20, 1, 'Televisi Sharp 43\"', 'TV untuk multimedia', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(8, 'BRG-008', 12, 5, 'Router Cisco RV260', 'Router utama sekolah', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(9, 'BRG-009', 13, 5, 'Access Point TP-Link EAP225', 'Access point area kelas', 7, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(10, 'BRG-010', 14, 6, 'Mikroskop Olympus CX23', 'Mikroskop laboratorium IPA', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(11, 'BRG-011', 9, 2, 'Meja Siswa Standard', 'Meja untuk siswa ukuran 120x45cm', 149, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(12, 'BRG-012', 10, 2, 'Kursi Siswa Plastik', 'Kursi siswa ergonomis', 149, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(13, 'BRG-013', 9, 2, 'Meja Guru Besar', 'Meja guru kepala sekolah', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(14, 'BRG-014', 11, 2, 'Lemari Arsip 2 Pintu', 'Lemari dokumen kantor', 7, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(15, 'BRG-015', 8, 4, 'Spidol Whiteboard Snowman (Hitam)', 'Spidol whiteboard isi 12', 119, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(16, 'BRG-016', 8, 4, 'Pulpen Snowman Gel', 'Pulpen gel 0.5mm paket 50', 300, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(17, 'BRG-017', 17, 4, 'Pulpen Pilot V5', 'Pulpen terbaik untuk administrasi', 199, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(18, 'BRG-018', 18, 4, 'Pensil FaberCastell HB', 'Pensil ujian dan alat gambar', 799, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(19, 'BRG-019', 16, 7, 'Sapu Lantai CleanPro', 'Sapu serat sintetis', 19, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(20, 'BRG-020', 16, 7, 'Tempat Sampah 60L', 'Tempat sampah plastik besar', 12, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(21, 'BRG-021', 15, 8, 'Bola Sepak AdidasSchool', 'Bola latihan sekolah', 9, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(22, 'BRG-022', 22, 9, 'Stapler Heavy Duty', 'Stapler kantor', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(23, 'BRG-023', 22, 9, 'Kertas A4 70gr (Rim)', 'Kertas percetakan', 200, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(24, 'BRG-024', 3, 1, 'Laptop Siswa Model L14', 'Laptop praktek siswa kelas IT', 11, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(25, 'BRG-025', 21, 6, 'Tabung Reaksi (set 50)', 'Peralatan praktikum kimia', 99, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(26, 'BRG-026', 21, 6, 'Bunsen Burner', 'Alat pemanasan praktikum', 14, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(27, 'BRG-027', 11, 2, 'Papan Tulis Putih 120x90', 'Whiteboard magnetik', 25, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(28, 'BRG-028', 10, 2, 'Kursi Guru Deluxe', 'Kursi kantor guru', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(29, 'BRG-029', 22, 4, 'Penghapus Whiteboard', 'Kain penghapus paket', 39, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(30, 'BRG-030', 22, 4, 'Spidol Permanent Generic', 'Spidol permanen berbagai warna', 59, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(31, 'BRG-031', 5, 1, 'Monitor Dell 22 Inch', 'Monitor lab komputer', 23, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(32, 'BRG-032', 1, 1, 'Scanner Canon ScanLide', 'Scanner dokumen', 2, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(33, 'BRG-033', 2, 1, 'Printer Epson Tinta Continuous', 'Printer gamblang', 1, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(34, 'BRG-034', 22, 9, 'Label Printer Mini', 'Label maker untuk arsip', 4, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(35, 'BRG-035', 16, 7, 'Sabun Cuci CleanPro (Galon)', 'Sabun cuci piring/gudang', 6, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(36, 'BRG-036', 11, 2, 'Rak Sepatu Sekolah', 'Rak sepatu untuk lorong', 3, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(37, 'BRG-037', 22, 9, 'Gunting Kantor', 'Gunting kertas ukuran 8\"', 25, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(38, 'BRG-038', 15, 1, 'Speaker Aktiv Polytron', 'Speaker untuk acara besar', 1, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(39, 'BRG-039', 6, 1, 'Lampu Proyektor Cadangan', 'Lampu proyektor UHP', 0, '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(40, 'BRG-040', 12, 5, 'Switch 16 Port Generic', 'Switch untuk jaringan lab', 6, '2025-11-30 17:16:05', '2025-11-30 17:16:05');

-- --------------------------------------------------------

--
-- Table structure for table `barang_aktif`
--

CREATE TABLE `barang_aktif` (
  `id` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `nama_barang` varchar(128) NOT NULL,
  `total_masuk` int(11) NOT NULL DEFAULT 0,
  `total_rusak` int(11) NOT NULL DEFAULT 0,
  `total_dipinjam` int(11) NOT NULL DEFAULT 0,
  `aktif_qty` int(11) NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang_aktif`
--

INSERT INTO `barang_aktif` (`id`, `barang_id`, `kode_barang`, `nama_barang`, `total_masuk`, `total_rusak`, `total_dipinjam`, `aktif_qty`, `updated_at`) VALUES
(1, 1, 'BRG-001', 'Printer Canon MF244', 0, 0, 0, 0, '2025-11-30 21:13:07'),
(2, 2, 'BRG-002', 'Printer Epson L3110', 0, 0, 0, 0, '2025-11-30 21:13:07'),
(3, 3, 'BRG-003', 'Printer Brother HL-L2370', 0, 0, 0, 0, '2025-11-30 21:13:07'),
(4, 4, 'BRG-004', 'PC Desktop Lab A', 17, 0, 1, 16, '2025-11-30 21:13:07'),
(5, 5, 'BRG-005', 'Laptop Guru X1', 0, 0, 0, 0, '2025-11-30 22:43:42'),
(6, 6, 'BRG-006', 'Proyektor BenQ MS536', 4, 0, 0, 4, '2025-11-30 21:13:07'),
(7, 7, 'BRG-007', 'Televisi Sharp 43\"', 0, 0, 0, 0, '2025-11-30 21:13:07'),
(8, 8, 'BRG-008', 'Router Cisco RV260', 0, 0, 1, 0, '2025-11-30 21:13:07'),
(9, 9, 'BRG-009', 'Access Point TP-Link EAP225', 7, 0, 1, 6, '2025-11-30 21:13:07'),
(10, 10, 'BRG-010', 'Mikroskop Olympus CX23', 0, 0, 0, 0, '2025-11-30 21:13:07'),
(11, 11, 'BRG-011', 'Meja Siswa Standard', 149, 0, 1, 148, '2025-11-30 21:13:07'),
(12, 12, 'BRG-012', 'Kursi Siswa Plastik', 149, 0, 1, 148, '2025-11-30 21:13:07'),
(13, 13, 'BRG-013', 'Meja Guru Besar', 0, 0, 0, 0, '2025-11-30 21:13:07'),
(14, 14, 'BRG-014', 'Lemari Arsip 2 Pintu', 7, 0, 1, 6, '2025-11-30 21:13:07'),
(15, 15, 'BRG-015', 'Spidol Whiteboard Snowman (Hitam)', 119, 0, 1, 118, '2025-11-30 21:13:07'),
(16, 16, 'BRG-016', 'Pulpen Snowman Gel', 300, 0, 0, 300, '2025-11-30 21:13:07'),
(17, 17, 'BRG-017', 'Pulpen Pilot V5', 199, 0, 1, 198, '2025-11-30 21:13:07'),
(18, 18, 'BRG-018', 'Pensil FaberCastell HB', 799, 0, 1, 798, '2025-11-30 21:13:07'),
(19, 19, 'BRG-019', 'Sapu Lantai CleanPro', 19, 0, 1, 18, '2025-11-30 21:13:07'),
(20, 20, 'BRG-020', 'Tempat Sampah 60L', 12, 0, 0, 12, '2025-11-30 21:13:07'),
(21, 21, 'BRG-021', 'Bola Sepak AdidasSchool', 9, 0, 1, 8, '2025-11-30 21:13:07'),
(22, 22, 'BRG-022', 'Stapler Heavy Duty', 0, 0, 0, 0, '2025-11-30 21:13:07'),
(23, 23, 'BRG-023', 'Kertas A4 70gr (Rim)', 200, 0, 0, 200, '2025-11-30 21:13:07'),
(24, 24, 'BRG-024', 'Laptop Siswa Model L14', 11, 1, 1, 9, '2025-11-30 21:13:07'),
(25, 25, 'BRG-025', 'Tabung Reaksi (set 50)', 99, 0, 1, 98, '2025-11-30 21:13:07'),
(26, 26, 'BRG-026', 'Bunsen Burner', 14, 0, 1, 13, '2025-11-30 21:13:07'),
(27, 27, 'BRG-027', 'Papan Tulis Putih 120x90', 25, 1, 0, 24, '2025-11-30 21:13:07'),
(28, 28, 'BRG-028', 'Kursi Guru Deluxe', 0, 0, 0, 0, '2025-11-30 21:13:07'),
(29, 29, 'BRG-029', 'Penghapus Whiteboard', 39, 0, 1, 38, '2025-11-30 21:13:07'),
(30, 30, 'BRG-030', 'Spidol Permanent Generic', 59, 0, 1, 58, '2025-11-30 21:13:07'),
(31, 31, 'BRG-031', 'Monitor Dell 22 Inch', 23, 1, 1, 21, '2025-11-30 21:13:07'),
(32, 32, 'BRG-032', 'Scanner Canon ScanLide', 2, 0, 0, 2, '2025-11-30 21:13:07'),
(33, 33, 'BRG-033', 'Printer Epson Tinta Continuous', 1, 0, 1, 0, '2025-11-30 21:13:07'),
(34, 34, 'BRG-034', 'Label Printer Mini', 4, 0, 0, 4, '2025-11-30 21:13:07'),
(35, 35, 'BRG-035', 'Sabun Cuci CleanPro (Galon)', 6, 0, 0, 6, '2025-11-30 21:13:07'),
(36, 36, 'BRG-036', 'Rak Sepatu Sekolah', 3, 0, 0, 3, '2025-11-30 21:13:07'),
(37, 37, 'BRG-037', 'Gunting Kantor', 25, 0, 0, 25, '2025-11-30 23:02:49'),
(38, 38, 'BRG-038', 'Speaker Aktiv Polytron', 1, 0, 1, 0, '2025-11-30 21:13:07'),
(39, 39, 'BRG-039', 'Lampu Proyektor Cadangan', 0, 0, 0, 0, '2025-11-30 21:13:07'),
(40, 40, 'BRG-040', 'Switch 16 Port Generic', 6, 0, 0, 6, '2025-11-30 21:13:07');

-- --------------------------------------------------------

--
-- Table structure for table `barang_dipinjam`
--

CREATE TABLE `barang_dipinjam` (
  `idbarang_dipinjam` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `peminjam` varchar(100) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `tanggal_kembali` date DEFAULT NULL,
  `kondisi_pinjam` varchar(100) DEFAULT '',
  `kondisi_kembali` varchar(100) DEFAULT NULL,
  `status` enum('Dipinjam','Dikembalikan','Hilang','Rusak') NOT NULL DEFAULT 'Dipinjam',
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang_dipinjam`
--

INSERT INTO `barang_dipinjam` (`idbarang_dipinjam`, `barang_id`, `kode_barang`, `peminjam`, `tanggal_pinjam`, `tanggal_kembali`, `kondisi_pinjam`, `kondisi_kembali`, `status`, `keterangan`, `created_at`, `updated_at`) VALUES
(1, 11, 'BRG-011', 'Sampel Peminjam 001', '2025-01-08', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=1', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(2, 12, 'BRG-012', 'Sampel Peminjam 002', '2025-01-08', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=2', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(3, 15, 'BRG-015', 'Sampel Peminjam 003', '2025-02-15', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=3', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(4, 16, 'BRG-016', 'Sampel Peminjam 004', '2025-02-16', '2025-02-23', 'Baik', 'Baik', 'Dikembalikan', 'Generated from barang_masuk id=4', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(5, 17, 'BRG-017', 'Sampel Peminjam 005', '2025-02-16', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=5', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(6, 18, 'BRG-018', 'Sampel Peminjam 006', '2024-12-20', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=6', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(7, 21, 'BRG-021', 'Sampel Peminjam 007', '2025-03-10', NULL, 'Baik', NULL, 'Rusak', 'Generated from barang_masuk id=7', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(8, 23, 'BRG-023', 'Sampel Peminjam 008', '2025-03-12', '2025-03-19', 'Baik', 'Baik', 'Dikembalikan', 'Generated from barang_masuk id=8', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(9, 24, 'BRG-024', 'Sampel Peminjam 009', '2025-03-25', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=9', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(10, 4, 'BRG-004', 'Sampel Peminjam 010', '2024-11-20', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=10', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(11, 31, 'BRG-031', 'Sampel Peminjam 011', '2024-11-21', NULL, 'Baik', NULL, 'Hilang', 'Generated from barang_masuk id=11', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(12, 27, 'BRG-027', 'Sampel Peminjam 012', '2025-01-25', '2025-02-01', 'Baik', 'Baik', 'Dikembalikan', 'Generated from barang_masuk id=12', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(13, 14, 'BRG-014', 'Sampel Peminjam 013', '2025-01-23', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=13', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(14, 25, 'BRG-025', 'Sampel Peminjam 014', '2025-02-06', NULL, 'Baik', NULL, 'Rusak', 'Generated from barang_masuk id=14', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(15, 26, 'BRG-026', 'Sampel Peminjam 015', '2025-02-07', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=15', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(16, 6, 'BRG-006', 'Sampel Peminjam 016', '2024-09-15', '2024-09-22', 'Baik', 'Baik', 'Dikembalikan', 'Generated from barang_masuk id=16', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(17, 38, 'BRG-038', 'Sampel Peminjam 017', '2025-04-15', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=17', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(18, 8, 'BRG-008', 'Sampel Peminjam 018', '2025-06-06', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=18', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(19, 9, 'BRG-009', 'Sampel Peminjam 019', '2025-06-10', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=19', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(20, 20, 'BRG-020', 'Sampel Peminjam 020', '2025-01-10', '2025-01-17', 'Baik', 'Baik', 'Dikembalikan', 'Generated from barang_masuk id=20', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(21, 19, 'BRG-019', 'Sampel Peminjam 021', '2025-01-10', NULL, 'Baik', NULL, 'Rusak', 'Generated from barang_masuk id=21', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(22, 29, 'BRG-029', 'Sampel Peminjam 022', '2025-02-17', NULL, 'Baik', NULL, 'Hilang', 'Generated from barang_masuk id=22', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(23, 30, 'BRG-030', 'Sampel Peminjam 023', '2025-02-17', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=23', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(24, 32, 'BRG-032', 'Sampel Peminjam 024', '2025-03-20', '2025-03-27', 'Baik', 'Baik', 'Dikembalikan', 'Generated from barang_masuk id=24', '2025-11-30 17:16:05', '2025-11-30 17:16:05'),
(25, 33, 'BRG-033', 'Sampel Peminjam 025', '2025-03-20', NULL, 'Baik', NULL, 'Dipinjam', 'Generated from barang_masuk id=25', '2025-11-30 17:16:05', '2025-11-30 17:16:05');

--
-- Triggers `barang_dipinjam`
--
DELIMITER $$
CREATE TRIGGER `trig_delete_dipinjam` AFTER DELETE ON `barang_dipinjam` FOR EACH ROW BEGIN
  IF OLD.status IN ('Dipinjam','Hilang','Rusak') THEN
    UPDATE barang SET stok = stok + 1 WHERE idbarang = OLD.barang_id;
  END IF;
  CALL recompute_barang_aktif(OLD.barang_id);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trig_insert_dipinjam` AFTER INSERT ON `barang_dipinjam` FOR EACH ROW BEGIN
  UPDATE barang SET stok = GREATEST(0, stok - 1) WHERE idbarang = NEW.barang_id;
  CALL recompute_barang_aktif(NEW.barang_id);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trig_update_dipinjam` AFTER UPDATE ON `barang_dipinjam` FOR EACH ROW BEGIN
  -- if status changed to Dikembalikan and old was Dipinjam/Hilang/Rusak -> increment stock by 1
  IF OLD.status IN ('Dipinjam','Hilang','Rusak') AND NEW.status = 'Dikembalikan' THEN
    UPDATE barang SET stok = stok + 1 WHERE idbarang = NEW.barang_id;
  END IF;

  -- if status changed from Dikembalikan to Dipinjam/Hilang/Rusak -> decrement stock by 1
  IF OLD.status = 'Dikembalikan' AND NEW.status IN ('Dipinjam','Hilang','Rusak') THEN
    UPDATE barang SET stok = GREATEST(0, stok - 1) WHERE idbarang = NEW.barang_id;
  END IF;

  -- recompute for both old and new barang_id if changed
  IF OLD.barang_id <> NEW.barang_id THEN
    CALL recompute_barang_aktif(OLD.barang_id);
    CALL recompute_barang_aktif(NEW.barang_id);
  ELSE
    CALL recompute_barang_aktif(NEW.barang_id);
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `barang_keluar`
--

CREATE TABLE `barang_keluar` (
  `idbarang_keluar` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL DEFAULT 0,
  `keterangan` varchar(256) DEFAULT '',
  `tanggal` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang_keluar`
--

INSERT INTO `barang_keluar` (`idbarang_keluar`, `barang_id`, `kode_barang`, `jumlah`, `keterangan`, `tanggal`, `created_at`) VALUES
(1, 1, 'BRG-001', 1, 'Dipinjam ke administrasi luar kota', '2025-04-02', '2025-04-02 02:00:00'),
(2, 2, 'BRG-002', 1, 'Dipinjam untuk uji cetak proyek', '2025-04-05', '2025-04-05 03:00:00'),
(3, 3, 'BRG-003', 2, 'Distribusi kecil ke ruang guru', '2025-02-15', '2025-02-15 02:30:00'),
(4, 4, 'BRG-004', 2, 'Peminjaman PC untuk pelatihan', '2025-05-01', '2025-05-01 01:30:00'),
(5, 6, 'BRG-006', 1, 'Dikirim service center (lampu mati)', '2025-10-08', '2025-10-08 00:00:00');

--
-- Triggers `barang_keluar`
--
DELIMITER $$
CREATE TRIGGER `trig_delete_keluar` AFTER DELETE ON `barang_keluar` FOR EACH ROW BEGIN
  UPDATE barang SET stok = stok + OLD.jumlah WHERE idbarang = OLD.barang_id;
  CALL recompute_barang_aktif(OLD.barang_id);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trig_insert_keluar` AFTER INSERT ON `barang_keluar` FOR EACH ROW BEGIN
  UPDATE barang SET stok = GREATEST(0, stok - NEW.jumlah) WHERE idbarang = NEW.barang_id;
  -- barang_keluar does not change barang_aktif definition directly (we defined aktf = masuk - rusak - dipinjam),
  -- but if you want keluar to reduce aktif_qty, include logic here. For now, only stok is adjusted.
  CALL recompute_barang_aktif(NEW.barang_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `barang_masuk`
--

CREATE TABLE `barang_masuk` (
  `idbarang_masuk` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL DEFAULT 0,
  `keterangan` varchar(256) DEFAULT '',
  `tanggal` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang_masuk`
--

INSERT INTO `barang_masuk` (`idbarang_masuk`, `barang_id`, `kode_barang`, `jumlah`, `keterangan`, `tanggal`, `created_at`) VALUES
(1, 11, 'BRG-011', 150, 'Pengadaan awal tahun - Meja Siswa', '2025-01-03', '2025-01-03 03:00:00'),
(2, 12, 'BRG-012', 150, 'Pengadaan awal tahun - Kursi Siswa', '2025-01-03', '2025-01-03 03:05:00'),
(3, 15, 'BRG-015', 120, 'Pembelian paket spidol untuk guru', '2025-02-10', '2025-02-10 02:00:00'),
(4, 16, 'BRG-016', 300, 'Pengadaan pulpen administrasi', '2025-02-11', '2025-02-11 02:00:00'),
(5, 17, 'BRG-017', 200, 'Stok pulpen Pilot', '2025-02-11', '2025-02-11 02:10:00'),
(6, 18, 'BRG-018', 800, 'Pensil untuk ujian', '2024-12-15', '2024-12-15 01:30:00'),
(7, 21, 'BRG-021', 10, 'Perlengkapan olahraga semester ganjil', '2025-03-05', '2025-03-05 01:00:00'),
(8, 23, 'BRG-023', 200, 'Kertas A4 untuk kantor', '2025-03-07', '2025-03-07 04:00:00'),
(9, 24, 'BRG-024', 12, 'Pembelian laptop siswa (lab praktek)', '2025-03-20', '2025-03-20 05:00:00'),
(10, 4, 'BRG-004', 20, 'Pengadaan PC lab tambahan', '2024-11-15', '2024-11-15 02:00:00'),
(11, 31, 'BRG-031', 24, 'Monitor lab tambahan', '2024-11-16', '2024-11-16 02:00:00'),
(12, 27, 'BRG-027', 25, 'Whiteboard kelas', '2025-01-20', '2025-01-20 03:00:00'),
(13, 14, 'BRG-014', 8, 'Lemari arsip unit', '2025-01-18', '2025-01-18 02:00:00'),
(14, 25, 'BRG-025', 100, 'Tabung reaksi set', '2025-02-01', '2025-02-01 03:00:00'),
(15, 26, 'BRG-026', 15, 'Bunsen burner', '2025-02-02', '2025-02-02 03:00:00'),
(16, 6, 'BRG-006', 5, 'Proyektor pengganti & cadangan', '2024-09-10', '2024-09-10 02:00:00'),
(17, 38, 'BRG-038', 2, 'Speaker acara sekolah', '2025-04-10', '2025-04-10 05:00:00'),
(18, 8, 'BRG-008', 1, 'Router utama (pengganti)', '2025-06-01', '2025-06-01 01:00:00'),
(19, 9, 'BRG-009', 8, 'Access point area kelas', '2025-06-05', '2025-06-05 01:30:00'),
(20, 20, 'BRG-020', 12, 'Tempat sampah koridor', '2025-01-05', '2025-01-05 02:00:00'),
(21, 19, 'BRG-019', 20, 'Sapu lantai', '2025-01-05', '2025-01-05 02:05:00'),
(22, 29, 'BRG-029', 40, 'Penghapus whiteboard', '2025-02-12', '2025-02-12 02:00:00'),
(23, 30, 'BRG-030', 60, 'Spidol permanent', '2025-02-12', '2025-02-12 02:10:00'),
(24, 32, 'BRG-032', 2, 'Scanner untuk tata usaha', '2025-03-15', '2025-03-15 03:00:00'),
(25, 33, 'BRG-033', 2, 'Printer Epson cadangan', '2025-03-15', '2025-03-15 03:10:00'),
(26, 34, 'BRG-034', 4, 'Label printer untuk arsip', '2025-03-16', '2025-03-16 03:00:00'),
(27, 35, 'BRG-035', 6, 'Sabun cuci galon', '2025-01-10', '2025-01-10 01:00:00'),
(28, 36, 'BRG-036', 3, 'Rak sepatu lorong', '2025-01-08', '2025-01-08 02:00:00'),
(29, 37, 'BRG-037', 25, 'Gunting kantor', '2025-02-20', '2025-02-20 02:30:00'),
(30, 40, 'BRG-040', 6, 'Switch 16 port untuk lab', '2025-03-02', '2025-03-02 01:30:00');

--
-- Triggers `barang_masuk`
--
DELIMITER $$
CREATE TRIGGER `trig_delete_masuk` AFTER DELETE ON `barang_masuk` FOR EACH ROW BEGIN
  UPDATE barang SET stok = GREATEST(0, stok - OLD.jumlah) WHERE idbarang = OLD.barang_id;
  CALL recompute_barang_aktif(OLD.barang_id);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trig_insert_masuk` AFTER INSERT ON `barang_masuk` FOR EACH ROW BEGIN
  UPDATE barang SET stok = stok + NEW.jumlah WHERE idbarang = NEW.barang_id;
  CALL recompute_barang_aktif(NEW.barang_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `barang_rusak`
--

CREATE TABLE `barang_rusak` (
  `idbarang_rusak` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `tanggal_laporan` date NOT NULL,
  `status` enum('Menunggu Pemeriksaan','Dalam Pemeriksaan','Menunggu Persetujuan Perbaikan','Sedang Diperbaiki','Menunggu Anggaran','Selesai Diperbaiki','Aset Aktif Kembali','Rusak Permanen','Destruksi Asset') NOT NULL DEFAULT 'Menunggu Pemeriksaan',
  `keterangan_kerusakan` text NOT NULL,
  `estimasi_biaya` decimal(15,2) DEFAULT NULL,
  `biaya_aktual` decimal(15,2) DEFAULT NULL,
  `pelapor` varchar(100) NOT NULL,
  `teknisi` varchar(100) DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `foto_kerusakan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang_rusak`
--

INSERT INTO `barang_rusak` (`idbarang_rusak`, `barang_id`, `kode_barang`, `tanggal_laporan`, `status`, `keterangan_kerusakan`, `estimasi_biaya`, `biaya_aktual`, `pelapor`, `teknisi`, `tanggal_selesai`, `foto_kerusakan`, `created_at`, `updated_at`) VALUES
(1, 24, 'BRG-024', '2025-11-07', 'Menunggu Pemeriksaan', 'Laptop siswa overheating dan shutdown mendadak', '400000.00', NULL, 'Rosa', NULL, NULL, 'laptop_nov.jpg', '2025-11-07 02:00:00', '2025-11-07 02:00:00'),
(2, 31, 'BRG-031', '2025-09-09', 'Aset Aktif Kembali', 'Monitor sering berkedip lalu mati', '180000.00', '150000.00', 'Anton', 'Fahmi', '2025-09-12', 'monitor_sep.jpg', '2025-09-09 02:30:00', '2025-09-12 03:30:00'),
(3, 27, 'BRG-027', '2025-04-14', 'Rusak Permanen', 'Papan tulis retak besar dan rangka patah', NULL, NULL, 'Guru Kelas 5', 'Team Gudang', NULL, 'papan_apr.jpg', '2025-04-14 04:00:00', '2025-04-16 02:10:00');

--
-- Triggers `barang_rusak`
--
DELIMITER $$
CREATE TRIGGER `trig_delete_rusak` AFTER DELETE ON `barang_rusak` FOR EACH ROW BEGIN
  CALL recompute_barang_aktif(OLD.barang_id);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trig_insert_rusak` AFTER INSERT ON `barang_rusak` FOR EACH ROW BEGIN
  -- Depending on business rule, you might reduce stok when a new 'rusak' is confirmed.
  -- Here we simply recompute barang_aktif (which uses barang_rusak count).
  CALL recompute_barang_aktif(NEW.barang_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `barang_rusak_history`
--

CREATE TABLE `barang_rusak_history` (
  `id` int(11) NOT NULL,
  `barang_rusak_id` int(11) NOT NULL,
  `status_lama` varchar(50) DEFAULT NULL,
  `status_baru` varchar(50) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `user` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `barang_rusak_perbaikan`
--

CREATE TABLE `barang_rusak_perbaikan` (
  `id` int(11) NOT NULL,
  `barang_rusak_id` int(11) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `tanggal_perbaikan` date NOT NULL,
  `jenis_perbaikan` varchar(100) NOT NULL,
  `spare_part` text DEFAULT NULL,
  `biaya` decimal(15,2) DEFAULT NULL,
  `teknisi` varchar(100) NOT NULL,
  `catatan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `idkategori` int(11) NOT NULL,
  `nama_kategori` varchar(128) NOT NULL,
  `keterangan` varchar(256) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`idkategori`, `nama_kategori`, `keterangan`) VALUES
(1, 'Elektronik', 'Barang Elektronik'),
(2, 'Furniture', 'Meja, kursi, lemari'),
(3, 'Dokumentasi', ''),
(4, 'Alat Tulis', ''),
(5, 'Jaringan & IT', ''),
(6, 'Laboratorium', ''),
(7, 'Kebersihan', ''),
(8, 'Olahraga', ''),
(9, 'Alat Kantor', ''),
(10, 'Pelindung & Keamanan', '');

-- --------------------------------------------------------

--
-- Table structure for table `merek`
--

CREATE TABLE `merek` (
  `idmerek` int(11) NOT NULL,
  `nama_merek` varchar(128) NOT NULL,
  `keterangan` varchar(256) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `merek`
--

INSERT INTO `merek` (`idmerek`, `nama_merek`, `keterangan`) VALUES
(1, 'Canon', ''),
(2, 'Epson', ''),
(3, 'HP', ''),
(4, 'Lenovo', ''),
(5, 'Dell', ''),
(6, 'BenQ', ''),
(7, 'Polytron', ''),
(8, 'Snowman', ''),
(9, 'SnowDesk', ''),
(10, 'UltraSeat', ''),
(11, 'IvyOffice', ''),
(12, 'Cisco', ''),
(13, 'TP-Link', ''),
(14, 'Olympus', ''),
(15, 'AdidasSchool', ''),
(16, 'CleanPro', ''),
(17, 'Pilot', ''),
(18, 'FaberCastell', ''),
(19, 'Brother', ''),
(20, 'Sharp', ''),
(21, 'BrotherLab', ''),
(22, 'Generic', '');

-- --------------------------------------------------------

--
-- Table structure for table `mutasi`
--

CREATE TABLE `mutasi` (
  `id` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `jenis` enum('masuk','keluar','dipinjam','dikembalikan','rusak','perbaikan') NOT NULL,
  `jumlah` int(11) NOT NULL DEFAULT 1,
  `keterangan` text DEFAULT NULL,
  `barang_masuk_id` int(11) DEFAULT NULL,
  `barang_keluar_id` int(11) DEFAULT NULL,
  `barang_dipinjam_id` int(11) DEFAULT NULL,
  `barang_rusak_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mutasi`
--

INSERT INTO `mutasi` (`id`, `barang_id`, `kode_barang`, `tanggal`, `jenis`, `jumlah`, `keterangan`, `barang_masuk_id`, `barang_keluar_id`, `barang_dipinjam_id`, `barang_rusak_id`, `created_at`) VALUES
(1, 11, 'BRG-011', '2025-01-03', 'masuk', 150, 'Pengadaan awal tahun - Meja Siswa', 1, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(2, 12, 'BRG-012', '2025-01-03', 'masuk', 150, 'Pengadaan awal tahun - Kursi Siswa', 2, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(3, 15, 'BRG-015', '2025-02-10', 'masuk', 120, 'Pembelian paket spidol untuk guru', 3, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(4, 16, 'BRG-016', '2025-02-11', 'masuk', 300, 'Pengadaan pulpen administrasi', 4, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(5, 17, 'BRG-017', '2025-02-11', 'masuk', 200, 'Stok pulpen Pilot', 5, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(6, 18, 'BRG-018', '2024-12-15', 'masuk', 800, 'Pensil untuk ujian', 6, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(7, 21, 'BRG-021', '2025-03-05', 'masuk', 10, 'Perlengkapan olahraga semester ganjil', 7, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(8, 23, 'BRG-023', '2025-03-07', 'masuk', 200, 'Kertas A4 untuk kantor', 8, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(9, 24, 'BRG-024', '2025-03-20', 'masuk', 12, 'Pembelian laptop siswa (lab praktek)', 9, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(10, 4, 'BRG-004', '2024-11-15', 'masuk', 20, 'Pengadaan PC lab tambahan', 10, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(11, 31, 'BRG-031', '2024-11-16', 'masuk', 24, 'Monitor lab tambahan', 11, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(12, 27, 'BRG-027', '2025-01-20', 'masuk', 25, 'Whiteboard kelas', 12, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(13, 14, 'BRG-014', '2025-01-18', 'masuk', 8, 'Lemari arsip unit', 13, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(14, 25, 'BRG-025', '2025-02-01', 'masuk', 100, 'Tabung reaksi set', 14, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(15, 26, 'BRG-026', '2025-02-02', 'masuk', 15, 'Bunsen burner', 15, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(16, 6, 'BRG-006', '2024-09-10', 'masuk', 5, 'Proyektor pengganti & cadangan', 16, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(17, 38, 'BRG-038', '2025-04-10', 'masuk', 2, 'Speaker acara sekolah', 17, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(18, 8, 'BRG-008', '2025-06-01', 'masuk', 1, 'Router utama (pengganti)', 18, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(19, 9, 'BRG-009', '2025-06-05', 'masuk', 8, 'Access point area kelas', 19, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(20, 20, 'BRG-020', '2025-01-05', 'masuk', 12, 'Tempat sampah koridor', 20, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(21, 19, 'BRG-019', '2025-01-05', 'masuk', 20, 'Sapu lantai', 21, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(22, 29, 'BRG-029', '2025-02-12', 'masuk', 40, 'Penghapus whiteboard', 22, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(23, 30, 'BRG-030', '2025-02-12', 'masuk', 60, 'Spidol permanent', 23, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(24, 32, 'BRG-032', '2025-03-15', 'masuk', 2, 'Scanner untuk tata usaha', 24, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(25, 33, 'BRG-033', '2025-03-15', 'masuk', 2, 'Printer Epson cadangan', 25, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(26, 34, 'BRG-034', '2025-03-16', 'masuk', 4, 'Label printer untuk arsip', 26, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(27, 35, 'BRG-035', '2025-01-10', 'masuk', 6, 'Sabun cuci galon', 27, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(28, 36, 'BRG-036', '2025-01-08', 'masuk', 3, 'Rak sepatu lorong', 28, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(29, 37, 'BRG-037', '2025-02-20', 'masuk', 25, 'Gunting kantor', 29, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(30, 40, 'BRG-040', '2025-03-02', 'masuk', 6, 'Switch 16 port untuk lab', 30, NULL, NULL, NULL, '2025-11-30 17:16:05'),
(32, 1, 'BRG-001', '2025-04-02', 'keluar', 1, 'Dipinjam ke administrasi luar kota', NULL, 1, NULL, NULL, '2025-11-30 17:16:05'),
(33, 2, 'BRG-002', '2025-04-05', 'keluar', 1, 'Dipinjam untuk uji cetak proyek', NULL, 2, NULL, NULL, '2025-11-30 17:16:05'),
(34, 3, 'BRG-003', '2025-02-15', 'keluar', 2, 'Distribusi kecil ke ruang guru', NULL, 3, NULL, NULL, '2025-11-30 17:16:05'),
(35, 4, 'BRG-004', '2025-05-01', 'keluar', 2, 'Peminjaman PC untuk pelatihan', NULL, 4, NULL, NULL, '2025-11-30 17:16:05'),
(36, 6, 'BRG-006', '2025-10-08', 'keluar', 1, 'Dikirim service center (lampu mati)', NULL, 5, NULL, NULL, '2025-11-30 17:16:05'),
(39, 11, 'BRG-011', '2025-01-08', 'dipinjam', 1, 'Generated from barang_masuk id=1', NULL, NULL, 1, NULL, '2025-11-30 17:16:05'),
(40, 12, 'BRG-012', '2025-01-08', 'dipinjam', 1, 'Generated from barang_masuk id=2', NULL, NULL, 2, NULL, '2025-11-30 17:16:05'),
(41, 15, 'BRG-015', '2025-02-15', 'dipinjam', 1, 'Generated from barang_masuk id=3', NULL, NULL, 3, NULL, '2025-11-30 17:16:05'),
(42, 16, 'BRG-016', '2025-02-16', 'dipinjam', 1, 'Generated from barang_masuk id=4', NULL, NULL, 4, NULL, '2025-11-30 17:16:05'),
(43, 17, 'BRG-017', '2025-02-16', 'dipinjam', 1, 'Generated from barang_masuk id=5', NULL, NULL, 5, NULL, '2025-11-30 17:16:05'),
(44, 18, 'BRG-018', '2024-12-20', 'dipinjam', 1, 'Generated from barang_masuk id=6', NULL, NULL, 6, NULL, '2025-11-30 17:16:05'),
(45, 21, 'BRG-021', '2025-03-10', 'dipinjam', 1, 'Generated from barang_masuk id=7', NULL, NULL, 7, NULL, '2025-11-30 17:16:05'),
(46, 23, 'BRG-023', '2025-03-12', 'dipinjam', 1, 'Generated from barang_masuk id=8', NULL, NULL, 8, NULL, '2025-11-30 17:16:05'),
(47, 24, 'BRG-024', '2025-03-25', 'dipinjam', 1, 'Generated from barang_masuk id=9', NULL, NULL, 9, NULL, '2025-11-30 17:16:05'),
(48, 4, 'BRG-004', '2024-11-20', 'dipinjam', 1, 'Generated from barang_masuk id=10', NULL, NULL, 10, NULL, '2025-11-30 17:16:05'),
(49, 31, 'BRG-031', '2024-11-21', 'dipinjam', 1, 'Generated from barang_masuk id=11', NULL, NULL, 11, NULL, '2025-11-30 17:16:05'),
(50, 27, 'BRG-027', '2025-01-25', 'dipinjam', 1, 'Generated from barang_masuk id=12', NULL, NULL, 12, NULL, '2025-11-30 17:16:05'),
(51, 14, 'BRG-014', '2025-01-23', 'dipinjam', 1, 'Generated from barang_masuk id=13', NULL, NULL, 13, NULL, '2025-11-30 17:16:05'),
(52, 25, 'BRG-025', '2025-02-06', 'dipinjam', 1, 'Generated from barang_masuk id=14', NULL, NULL, 14, NULL, '2025-11-30 17:16:05'),
(53, 26, 'BRG-026', '2025-02-07', 'dipinjam', 1, 'Generated from barang_masuk id=15', NULL, NULL, 15, NULL, '2025-11-30 17:16:05'),
(54, 6, 'BRG-006', '2024-09-15', 'dipinjam', 1, 'Generated from barang_masuk id=16', NULL, NULL, 16, NULL, '2025-11-30 17:16:05'),
(55, 38, 'BRG-038', '2025-04-15', 'dipinjam', 1, 'Generated from barang_masuk id=17', NULL, NULL, 17, NULL, '2025-11-30 17:16:05'),
(56, 8, 'BRG-008', '2025-06-06', 'dipinjam', 1, 'Generated from barang_masuk id=18', NULL, NULL, 18, NULL, '2025-11-30 17:16:05'),
(57, 9, 'BRG-009', '2025-06-10', 'dipinjam', 1, 'Generated from barang_masuk id=19', NULL, NULL, 19, NULL, '2025-11-30 17:16:05'),
(58, 20, 'BRG-020', '2025-01-10', 'dipinjam', 1, 'Generated from barang_masuk id=20', NULL, NULL, 20, NULL, '2025-11-30 17:16:05'),
(59, 19, 'BRG-019', '2025-01-10', 'dipinjam', 1, 'Generated from barang_masuk id=21', NULL, NULL, 21, NULL, '2025-11-30 17:16:05'),
(60, 29, 'BRG-029', '2025-02-17', 'dipinjam', 1, 'Generated from barang_masuk id=22', NULL, NULL, 22, NULL, '2025-11-30 17:16:05'),
(61, 30, 'BRG-030', '2025-02-17', 'dipinjam', 1, 'Generated from barang_masuk id=23', NULL, NULL, 23, NULL, '2025-11-30 17:16:05'),
(62, 32, 'BRG-032', '2025-03-20', 'dipinjam', 1, 'Generated from barang_masuk id=24', NULL, NULL, 24, NULL, '2025-11-30 17:16:05'),
(63, 33, 'BRG-033', '2025-03-20', 'dipinjam', 1, 'Generated from barang_masuk id=25', NULL, NULL, 25, NULL, '2025-11-30 17:16:05'),
(70, 16, 'BRG-016', '2025-02-23', 'dikembalikan', 1, 'Generated from barang_masuk id=4', NULL, NULL, 4, NULL, '2025-11-30 17:16:05'),
(71, 23, 'BRG-023', '2025-03-19', 'dikembalikan', 1, 'Generated from barang_masuk id=8', NULL, NULL, 8, NULL, '2025-11-30 17:16:05'),
(72, 27, 'BRG-027', '2025-02-01', 'dikembalikan', 1, 'Generated from barang_masuk id=12', NULL, NULL, 12, NULL, '2025-11-30 17:16:05'),
(73, 6, 'BRG-006', '2024-09-22', 'dikembalikan', 1, 'Generated from barang_masuk id=16', NULL, NULL, 16, NULL, '2025-11-30 17:16:05'),
(74, 20, 'BRG-020', '2025-01-17', 'dikembalikan', 1, 'Generated from barang_masuk id=20', NULL, NULL, 20, NULL, '2025-11-30 17:16:05'),
(75, 32, 'BRG-032', '2025-03-27', 'dikembalikan', 1, 'Generated from barang_masuk id=24', NULL, NULL, 24, NULL, '2025-11-30 17:16:05'),
(77, 21, 'BRG-021', '2025-03-10', 'rusak', 1, 'Dari peminjaman: Generated from barang_masuk id=7', NULL, NULL, 7, NULL, '2025-11-30 17:16:05'),
(78, 31, 'BRG-031', '2024-11-21', 'rusak', 1, 'Dari peminjaman: Generated from barang_masuk id=11', NULL, NULL, 11, NULL, '2025-11-30 17:16:05'),
(79, 25, 'BRG-025', '2025-02-06', 'rusak', 1, 'Dari peminjaman: Generated from barang_masuk id=14', NULL, NULL, 14, NULL, '2025-11-30 17:16:05'),
(80, 19, 'BRG-019', '2025-01-10', 'rusak', 1, 'Dari peminjaman: Generated from barang_masuk id=21', NULL, NULL, 21, NULL, '2025-11-30 17:16:05'),
(81, 29, 'BRG-029', '2025-02-17', 'rusak', 1, 'Dari peminjaman: Generated from barang_masuk id=22', NULL, NULL, 22, NULL, '2025-11-30 17:16:05'),
(84, 24, 'BRG-024', '2025-11-07', 'rusak', 1, 'Laptop siswa overheating dan shutdown mendadak', NULL, NULL, NULL, 1, '2025-11-30 17:16:05'),
(85, 31, 'BRG-031', '2025-09-09', 'rusak', 1, 'Monitor sering berkedip lalu mati', NULL, NULL, NULL, 2, '2025-11-30 17:16:05'),
(86, 27, 'BRG-027', '2025-04-14', 'rusak', 1, 'Papan tulis retak besar dan rangka patah', NULL, NULL, NULL, 3, '2025-11-30 17:16:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_users` int(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` enum('admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_users`, `nama`, `no_hp`, `username`, `password`, `level`) VALUES
(3, 'Administrator', '081000111000', 'admin', '$2y$10$a.ut/GXeyQjVzjF1UZgb3.pygeAu6l6ayzwb6RblKDzTZhwv03dO2', 'admin');

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_barang_aktif_summary`
-- (See below for the actual view)
--
CREATE TABLE `vw_barang_aktif_summary` (
`barang_id` int(11)
,`kode_barang` varchar(50)
,`nama_barang` varchar(128)
,`total_masuk` int(11)
,`total_rusak` int(11)
,`total_dipinjam` int(11)
,`aktif_qty` int(11)
,`stok_table_barang` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `vw_barang_aktif_summary`
--
DROP TABLE IF EXISTS `vw_barang_aktif_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_barang_aktif_summary`  AS SELECT `ba`.`barang_id` AS `barang_id`, `ba`.`kode_barang` AS `kode_barang`, `ba`.`nama_barang` AS `nama_barang`, `ba`.`total_masuk` AS `total_masuk`, `ba`.`total_rusak` AS `total_rusak`, `ba`.`total_dipinjam` AS `total_dipinjam`, `ba`.`aktif_qty` AS `aktif_qty`, `b`.`stok` AS `stok_table_barang` FROM (`barang_aktif` `ba` join `barang` `b` on(`b`.`idbarang` = `ba`.`barang_id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`idbarang`),
  ADD UNIQUE KEY `kode_barang` (`kode_barang`),
  ADD KEY `fk_barang_merek` (`merek_id`),
  ADD KEY `fk_barang_kategori` (`kategori_id`);

--
-- Indexes for table `barang_aktif`
--
ALTER TABLE `barang_aktif`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `barang_id` (`barang_id`);

--
-- Indexes for table `barang_dipinjam`
--
ALTER TABLE `barang_dipinjam`
  ADD PRIMARY KEY (`idbarang_dipinjam`),
  ADD KEY `idx_dipinjam_barang` (`barang_id`);

--
-- Indexes for table `barang_keluar`
--
ALTER TABLE `barang_keluar`
  ADD PRIMARY KEY (`idbarang_keluar`),
  ADD KEY `idx_keluar_barang` (`barang_id`);

--
-- Indexes for table `barang_masuk`
--
ALTER TABLE `barang_masuk`
  ADD PRIMARY KEY (`idbarang_masuk`),
  ADD KEY `idx_masuk_barang` (`barang_id`);

--
-- Indexes for table `barang_rusak`
--
ALTER TABLE `barang_rusak`
  ADD PRIMARY KEY (`idbarang_rusak`),
  ADD KEY `idx_rusak_barang` (`barang_id`);

--
-- Indexes for table `barang_rusak_history`
--
ALTER TABLE `barang_rusak_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_history_rusak` (`barang_rusak_id`);

--
-- Indexes for table `barang_rusak_perbaikan`
--
ALTER TABLE `barang_rusak_perbaikan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_perbaikan_rusak` (`barang_rusak_id`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`idkategori`);

--
-- Indexes for table `merek`
--
ALTER TABLE `merek`
  ADD PRIMARY KEY (`idmerek`);

--
-- Indexes for table `mutasi`
--
ALTER TABLE `mutasi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_mutasi_barang` (`barang_id`),
  ADD KEY `idx_mutasi_tanggal` (`tanggal`),
  ADD KEY `fk_mutasi_masuk` (`barang_masuk_id`),
  ADD KEY `fk_mutasi_keluar` (`barang_keluar_id`),
  ADD KEY `fk_mutasi_dipinjam` (`barang_dipinjam_id`),
  ADD KEY `fk_mutasi_rusak` (`barang_rusak_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_users`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `idbarang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `barang_aktif`
--
ALTER TABLE `barang_aktif`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `barang_dipinjam`
--
ALTER TABLE `barang_dipinjam`
  MODIFY `idbarang_dipinjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `barang_keluar`
--
ALTER TABLE `barang_keluar`
  MODIFY `idbarang_keluar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `barang_masuk`
--
ALTER TABLE `barang_masuk`
  MODIFY `idbarang_masuk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `barang_rusak`
--
ALTER TABLE `barang_rusak`
  MODIFY `idbarang_rusak` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `barang_rusak_history`
--
ALTER TABLE `barang_rusak_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `barang_rusak_perbaikan`
--
ALTER TABLE `barang_rusak_perbaikan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `idkategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `merek`
--
ALTER TABLE `merek`
  MODIFY `idmerek` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `mutasi`
--
ALTER TABLE `mutasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_users` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `fk_barang_kategori` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`idkategori`),
  ADD CONSTRAINT `fk_barang_merek` FOREIGN KEY (`merek_id`) REFERENCES `merek` (`idmerek`);

--
-- Constraints for table `barang_aktif`
--
ALTER TABLE `barang_aktif`
  ADD CONSTRAINT `fk_barang_aktif_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`idbarang`) ON DELETE CASCADE;

--
-- Constraints for table `barang_dipinjam`
--
ALTER TABLE `barang_dipinjam`
  ADD CONSTRAINT `fk_dipinjam_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`idbarang`) ON DELETE CASCADE;

--
-- Constraints for table `barang_keluar`
--
ALTER TABLE `barang_keluar`
  ADD CONSTRAINT `fk_keluar_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`idbarang`) ON DELETE CASCADE;

--
-- Constraints for table `barang_masuk`
--
ALTER TABLE `barang_masuk`
  ADD CONSTRAINT `fk_masuk_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`idbarang`) ON DELETE CASCADE;

--
-- Constraints for table `barang_rusak`
--
ALTER TABLE `barang_rusak`
  ADD CONSTRAINT `fk_rusak_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`idbarang`) ON DELETE CASCADE;

--
-- Constraints for table `barang_rusak_history`
--
ALTER TABLE `barang_rusak_history`
  ADD CONSTRAINT `fk_history_rusak` FOREIGN KEY (`barang_rusak_id`) REFERENCES `barang_rusak` (`idbarang_rusak`) ON DELETE CASCADE;

--
-- Constraints for table `barang_rusak_perbaikan`
--
ALTER TABLE `barang_rusak_perbaikan`
  ADD CONSTRAINT `fk_perbaikan_rusak` FOREIGN KEY (`barang_rusak_id`) REFERENCES `barang_rusak` (`idbarang_rusak`) ON DELETE CASCADE;

--
-- Constraints for table `mutasi`
--
ALTER TABLE `mutasi`
  ADD CONSTRAINT `fk_mutasi_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`idbarang`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_mutasi_dipinjam` FOREIGN KEY (`barang_dipinjam_id`) REFERENCES `barang_dipinjam` (`idbarang_dipinjam`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_mutasi_keluar` FOREIGN KEY (`barang_keluar_id`) REFERENCES `barang_keluar` (`idbarang_keluar`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_mutasi_masuk` FOREIGN KEY (`barang_masuk_id`) REFERENCES `barang_masuk` (`idbarang_masuk`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_mutasi_rusak` FOREIGN KEY (`barang_rusak_id`) REFERENCES `barang_rusak` (`idbarang_rusak`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
