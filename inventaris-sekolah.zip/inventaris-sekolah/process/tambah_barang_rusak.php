<?php
// process/tambah_barang_rusak.php
require_once '../config/conn.php';
session_start();

if(isset($_POST['tambah'])) {
    $barang_id = mysqli_real_escape_string($con, $_POST['barang_id']);
    $tanggal_laporan = mysqli_real_escape_string($con, $_POST['tanggal_laporan']);
    $pelapor = mysqli_real_escape_string($con, $_POST['pelapor']);
    $keterangan_kerusakan = mysqli_real_escape_string($con, $_POST['keterangan_kerusakan']);
    $user = isset($_SESSION['nama']) ? $_SESSION['nama'] : 'Admin';
    
    // Upload foto jika ada
    $foto_kerusakan = null;
    if(isset($_FILES['foto_kerusakan']) && $_FILES['foto_kerusakan']['error'] == 0) {
        $target_dir = "../uploads/barang_rusak/";
        
        // Buat folder jika belum ada
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES["foto_kerusakan"]["name"], PATHINFO_EXTENSION));
        $new_filename = "rusak_" . time() . "_" . rand(1000, 9999) . "." . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        $allowed_types = array('jpg', 'jpeg', 'png', 'gif');
        
        if(in_array($file_extension, $allowed_types)) {
            if(move_uploaded_file($_FILES["foto_kerusakan"]["tmp_name"], $target_file)) {
                $foto_kerusakan = $new_filename;
            }
        }
    }
    
    // Insert ke tabel barang_rusak (Prepared Statement)
    $query = "INSERT INTO barang_rusak (barang_id, tanggal_laporan, status, keterangan_kerusakan, pelapor, foto_kerusakan) 
              VALUES (?, ?, 'Menunggu Pemeriksaan', ?, ?, ?)";
    
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "issss", $barang_id, $tanggal_laporan, $keterangan_kerusakan, $pelapor, $foto_kerusakan);
    
    if(mysqli_stmt_execute($stmt)) {
        $last_id = mysqli_insert_id($con);
        
        // Insert history (Prepared Statement)
        $history_query = "INSERT INTO barang_rusak_history (barang_rusak_id, status_baru, keterangan, user) 
                          VALUES (?, 'Menunggu Pemeriksaan', 'Barang dilaporkan rusak', ?)";
        
        $stmt_history = mysqli_prepare($con, $history_query);
        mysqli_stmt_bind_param($stmt_history, "is", $last_id, $user);
        mysqli_stmt_execute($stmt_history);
        
        $_SESSION['success'] = 'Laporan barang rusak berhasil ditambahkan';
    } else {
        $_SESSION['error'] = 'Gagal menambahkan laporan: ' . mysqli_error($con);
    }
    
    // Redirect ke index.php dengan parameter barang_rusak
    header('Location: ../index.php?barang_rusak');
    exit();
}
?>