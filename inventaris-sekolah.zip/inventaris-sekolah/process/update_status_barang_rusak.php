<?php
// process/update_status_barang_rusak.php
require_once '../config/conn.php';
session_start();

if(isset($_POST['update'])) {
    $id = mysqli_real_escape_string($con, $_POST['id']);
    $status_lama = mysqli_real_escape_string($con, $_POST['status_lama']);
    $status_baru = mysqli_real_escape_string($con, $_POST['status_baru']);
    $keterangan = mysqli_real_escape_string($con, $_POST['keterangan']);
    $teknisi = isset($_POST['teknisi']) ? mysqli_real_escape_string($con, $_POST['teknisi']) : '';
    $estimasi_biaya = isset($_POST['estimasi_biaya']) ? mysqli_real_escape_string($con, $_POST['estimasi_biaya']) : 0;
    $biaya_aktual = isset($_POST['biaya_aktual']) ? mysqli_real_escape_string($con, $_POST['biaya_aktual']) : 0;
    $user = isset($_SESSION['nama']) ? $_SESSION['nama'] : 'Admin';
    
    // Jika status selesai, update tanggal selesai
    $tanggal_selesai = null;
    if($status_baru == 'Selesai Diperbaiki' || $status_baru == 'Aset Aktif Kembali' || $status_baru == 'Destruksi Asset') {
        $tanggal_selesai = date('Y-m-d H:i:s');
    }
    
    // Update status (Prepared Statement)
    $update_query = "UPDATE barang_rusak 
                     SET status = ?, teknisi = ?, estimasi_biaya = ?, biaya_aktual = ?, tanggal_selesai = ?  
                     WHERE idbarang_rusak = ?";
    
    $stmt = mysqli_prepare($con, $update_query);
    mysqli_stmt_bind_param($stmt, "sssssi", $status_baru, $teknisi, $estimasi_biaya, $biaya_aktual, $tanggal_selesai, $id);
    
    if(mysqli_stmt_execute($stmt)) {
        // Insert history (Prepared Statement)
        $history_query = "INSERT INTO barang_rusak_history (barang_rusak_id, status_lama, status_baru, keterangan, user) 
                          VALUES (?, ?, ?, ?, ?)";
        
        $stmt_history = mysqli_prepare($con, $history_query);
        mysqli_stmt_bind_param($stmt_history, "issss", $id, $status_lama, $status_baru, $keterangan, $user);
        mysqli_stmt_execute($stmt_history);
        
        $_SESSION['success'] = 'Status berhasil diupdate';
    } else {
        $_SESSION['error'] = 'Gagal update status: ' . mysqli_error($con);
    }
    
    // Redirect ke index.php dengan parameter barang_rusak
    header('Location: ../index.php?barang_rusak');
    exit();
}
?>