<?php
// process/hapus_barang_rusak.php
require_once '../config/conn.php';
session_start();

if(isset($_GET['id'])) {
    $id = mysqli_real_escape_string($con, $_GET['id']);
    
    // Hapus history terlebih dahulu
    $delete_history = mysqli_query($con, "DELETE FROM barang_rusak_history WHERE barang_rusak_id = '$id'");
    
    // Hapus data barang rusak
    $delete_query = mysqli_query($con, "DELETE FROM barang_rusak WHERE idbarang_rusak = '$id'");
    
    if($delete_query) {
        $_SESSION['success'] = 'Data barang rusak berhasil dihapus';
    } else {
        $_SESSION['error'] = 'Gagal menghapus data: ' . mysqli_error($con);
    }
    
    header('Location: ../index.php?barang_rusak');
    exit();
}
?>