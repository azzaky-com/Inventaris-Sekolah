<?php
session_start();
include('../config/conn.php');
include('../config/function.php');

hakAkses(['admin']);

if(isset($_GET['id'])){
    $id = $_GET['id'];

    $query = mysqli_query($con, "DELETE FROM barang_dipinjam WHERE idbarang_dipinjam='$id'");

    if($query){
        $_SESSION['success'] = 'Data peminjaman berhasil dihapus!';
    } else {
        $_SESSION['error'] = 'Gagal menghapus data: '.mysqli_error($con);
    }

    header("Location: ".base_url()."? barang_dipinjam");
    exit;
}
?>