<?php
session_start();
include('../config/conn.php');
include('../config/function.php');

hakAkses(['admin']);

if(isset($_POST['kembalikan'])){
    $id = $_POST['id'];
    $tanggal_kembali = $_POST['tanggal_kembali'];
    $kondisi_kembali = $_POST['kondisi_kembali'];
    $status = $_POST['status'];
    $keterangan = $_POST['keterangan'];

    // Validasi input
    if(empty($id) || empty($tanggal_kembali) || empty($kondisi_kembali) || empty($status)){
        $_SESSION['error'] = 'Semua field yang wajib harus diisi!';
        header("Location: ".base_url()."?barang_dipinjam");
        exit;
    }

    // Update database
    $query = mysqli_query($con, "
        UPDATE barang_dipinjam 
        SET tanggal_kembali='$tanggal_kembali', 
            kondisi_kembali='". mysqli_real_escape_string($con, $kondisi_kembali)."',
            status='". mysqli_real_escape_string($con, $status)."',
            keterangan='".mysqli_real_escape_string($con, $keterangan)."'
        WHERE idbarang_dipinjam='$id'
    ");

    if($query){
        $_SESSION['success'] = 'Pengembalian barang berhasil dicatat!';
    } else {
        $_SESSION['error'] = 'Gagal mencatat pengembalian: '. mysqli_error($con);
    }

    header("Location: ". base_url()."?barang_dipinjam");
    exit;
}
?>