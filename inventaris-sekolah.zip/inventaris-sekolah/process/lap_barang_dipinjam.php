<?php 
hakAkses(['admin']); 
?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Laporan Barang Rusak</h1>
    </div>

    <!-- Filter -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filter Laporan</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="">
                <input type="hidden" name="page" value="laporan_barang_rusak">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Tanggal Dari</label>
                            <input type="date" name="dari" class="form-control" value="<?= isset($_GET['dari']) ? $_GET['dari'] : ''; ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Tanggal Sampai</label>
                            <input type="date" name="sampai" class="form-control" value="<?= isset($_GET['sampai']) ? $_GET['sampai'] : ''; ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status" class="form-control">
                                <option value="">Semua Status</option>
                                <option value="Menunggu Pemeriksaan" <?= (isset($_GET['status']) && $_GET['status']=='Menunggu Pemeriksaan') ? 'selected' : ''; ?>>Menunggu Pemeriksaan</option>
                                <option value="Dalam Pemeriksaan" <?= (isset($_GET['status']) && $_GET['status']=='Dalam Pemeriksaan') ? 'selected' : ''; ?>>Dalam Pemeriksaan</option>
                                <option value="Menunggu Persetujuan Perbaikan" <?= (isset($_GET['status']) && $_GET['status']=='Menunggu Persetujuan Perbaikan') ? 'selected' : ''; ?>>Menunggu Persetujuan Perbaikan</option>
                                <option value="Sedang Diperbaiki" <?= (isset($_GET['status']) && $_GET['status']=='Sedang Diperbaiki') ? 'selected' : ''; ?>>Sedang Diperbaiki</option>
                                <option value="Menunggu Anggaran" <?= (isset($_GET['status']) && $_GET['status']=='Menunggu Anggaran') ? 'selected' : ''; ?>>Menunggu Anggaran</option>
                                <option value="Selesai Diperbaiki" <?= (isset($_GET['status']) && $_GET['status']=='Selesai Diperbaiki') ? 'selected' : ''; ?>>Selesai Diperbaiki</option>
                                <option value="Aset Aktif Kembali" <?= (isset($_GET['status']) && $_GET['status']=='Aset Aktif Kembali') ? 'selected' : ''; ?>>Aset Aktif Kembali</option>
                                <option value="Rusak Permanen" <?= (isset($_GET['status']) && $_GET['status']=='Rusak Permanen') ? 'selected' : ''; ?>>Rusak Permanen</option>
                                <option value="Destruksi Asset" <?= (isset($_GET['status']) && $_GET['status']=='Destruksi Asset') ? 'selected' : ''; ?>>Destruksi Asset</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label>&nbsp;</label>
                        <div>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i> Filter
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row">
        <?php
        $where = "1=1";
        if(isset($_GET['dari']) && $_GET['dari'] != '') {
            $where .= " AND tanggal_laporan >= '{$_GET['dari']}'";
        }
        if(isset($_GET['sampai']) && $_GET['sampai'] != '') {
            $where .= " AND tanggal_laporan <= '{$_GET['sampai']}'";
        }
        if(isset($_GET['status']) && $_GET['status'] != '') {
            $where .= " AND status = '{$_GET['status']}'";
        }

        // Total Laporan
        $total_query = mysqli_query($con, "SELECT COUNT(*) as total FROM barang_rusak WHERE $where");
        $total = mysqli_fetch_array($total_query)['total'];

        // Total Biaya
        $biaya_query = mysqli_query($con, "SELECT SUM(biaya_aktual) as total FROM barang_rusak WHERE $where AND biaya_aktual IS NOT NULL");
        $total_biaya = mysqli_fetch_array($biaya_query)['total'];

        // Selesai Diperbaiki
        $selesai_query = mysqli_query($con, "SELECT COUNT(*) as total FROM barang_rusak WHERE $where AND status IN ('Selesai Diperbaiki', 'Aset Aktif Kembali')");
        $total_selesai = mysqli_fetch_array($selesai_query)['total'];

        // Rusak Permanen
        $rusak_query = mysqli_query($con, "SELECT COUNT(*) as total FROM barang_rusak WHERE $where AND status IN ('Rusak Permanen', 'Destruksi Asset')");
        $total_rusak = mysqli_fetch_array($rusak_query)['total'];
        ?>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Laporan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Biaya</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Rp <?= number_format($total_biaya, 0, ',', '.'); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Selesai</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_selesai; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Rusak Permanen</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_rusak; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Data Laporan</h6>
            <a href="process/cetak_laporan_barang_rusak.php?<?= http_build_query($_GET); ?>" target="_blank" class="btn btn-success btn-sm">
                <i class="fas fa-print"></i> Cetak Laporan
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>TANGGAL</th>
                            <th>KODE</th>
                            <th>NAMA BARANG</th>
                            <th>STATUS</th>
                            <th>PELAPOR</th>
                            <th>TEKNISI</th>
                            <th>BIAYA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $n=1;
                        $query = mysqli_query($con,"SELECT br.*, b.nama_barang, b.kode_barang, m.nama_merek 
                                                    FROM barang_rusak br 
                                                    JOIN barang b ON b.idbarang=br.barang_id 
                                                    JOIN merek m ON m.idmerek=b.merek_id 
                                                    WHERE $where 
                                                    ORDER BY br.tanggal_laporan DESC")or die(mysqli_error($con));
                        while($row = mysqli_fetch_array($query)):
                        ?>
                        <tr>
                            <td><?= $n++; ?></td>
                            <td><?= date('d-m-Y',strtotime($row['tanggal_laporan'])); ?></td>
                            <td><?= $row['kode_barang']; ?></td>
                            <td><?= $row['nama_barang']; ?> (<?= $row['nama_merek']; ?>)</td>
                            <td><?= $row['status']; ?></td>
                            <td><?= $row['pelapor']; ?></td>
                            <td><?= $row['teknisi'] ? $row['teknisi'] : '-'; ?></td>
                            <td>Rp <?= number_format($row['biaya_aktual'], 0, ',', '.'); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>