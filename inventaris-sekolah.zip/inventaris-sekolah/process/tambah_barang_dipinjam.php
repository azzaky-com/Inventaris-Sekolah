<?php
session_start();
include('../config/conn.php');
include('../config/function.php');

hakAkses(['admin']);

if(isset($_POST['tambah'])){
    $barang_id = mysqli_real_escape_string($con, $_POST['barang_id']);
    $peminjam = mysqli_real_escape_string($con, $_POST['peminjam']);
    $tanggal_pinjam = mysqli_real_escape_string($con, $_POST['tanggal_pinjam']);
    $kondisi_pinjam = mysqli_real_escape_string($con, $_POST['kondisi_pinjam']);
    $keterangan = mysqli_real_escape_string($con, $_POST['keterangan']);

    // Validasi input
    if(empty($barang_id) || empty($peminjam) || empty($tanggal_pinjam) || empty($kondisi_pinjam)){
        $_SESSION['error'] = 'Semua field yang wajib harus diisi!';
        header("Location: ../index.php?barang_dipinjam");
        exit;
    }

    // Ambil kode barang dan cek stok
    $barang_query = mysqli_query($con, "SELECT kode_barang, stok FROM barang WHERE idbarang='$barang_id'");
    $barang = mysqli_fetch_assoc($barang_query);
    
    if(!$barang){
        $_SESSION['error'] = 'Barang tidak ditemukan!';
        header("Location: ../index.php?barang_dipinjam");
        exit;
    }

    // Cek stok barang
    if($barang['stok'] <= 0){
        $_SESSION['error'] = 'Stok barang tidak tersedia atau habis!';
        header("Location: ../index.php?barang_dipinjam");
        exit;
    }

    $kode_barang = $barang['kode_barang'];

    // Insert ke database
    $query = mysqli_query($con, "
        INSERT INTO barang_dipinjam (barang_id, kode_barang, peminjam, tanggal_pinjam, kondisi_pinjam, keterangan, status)
        VALUES ('$barang_id', '$kode_barang', '$peminjam', '$tanggal_pinjam', '$kondisi_pinjam', '$keterangan', 'Dipinjam')
    ");

    if($query){
        $_SESSION['success'] = 'Peminjaman barang berhasil ditambahkan!';
    } else {
        $_SESSION['error'] = 'Gagal menambahkan peminjaman: '. mysqli_error($con);
    }

    header("Location: ../index.php?barang_dipinjam");
    exit;
}
?>