<?php
session_start();
include('../config/conn.php');
include('../config/function.php');

hakAkses(['admin']);

// Get current timestamp for print
$print_time = date('d-m-Y H:i:s');

// Get all data
$data_query = mysqli_query($con, "
    SELECT bd.*, b.nama_barang, b. kode_barang, m.nama_merek, k.nama_kategori
    FROM barang_dipinjam bd
    JOIN barang b ON b. idbarang = bd.barang_id
    JOIN merek m ON m.idmerek = b.merek_id
    JOIN kategori k ON k.idkategori = b.kategori_id
    ORDER BY bd.idbarang_dipinjam DESC
");
?>
<! DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Laporan Barang Dipinjam</title>
    <link rel="stylesheet" href="<? =base_url();?>assets/css/sb-admin-2.min.css">
    <link rel="stylesheet" href="<?=base_url();?>assets/css/theme-overrides.css">
    <style>
        @media print {
            body { margin: 0; padding: 10px; }
            .no-print { display: none; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #000; padding: 6px 8px; text-align: left; }
            th { background-color: #f0f0f0; font-weight: bold; }
        }
        body { font-family: Arial, sans-serif; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h2 { margin: 0; }
        .header p { margin: 5px 0; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 11px; }
        th { background-color: #f9f9f9; font-weight: bold; }
        .text-center { text-align: center; }
        .print-btn { margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="no-print print-btn">
        <button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Cetak</button>
        <button onclick="window.history.back()" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Kembali</button>
    </div>

    <div class="header">
        <h2>LAPORAN BARANG DIPINJAM</h2>
        <p>UPT SMP NEGERI 8 MEDAN</p>
        <p>Dicetak: <?= $print_time ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th class="text-center" width="5%">NO</th>
                <th width="8%">KODE</th>
                <th width="15%">NAMA BARANG</th>
                <th width="10%">MEREK</th>
                <th width="12%">PEMINJAM</th>
                <th width="10%">TGL PINJAM</th>
                <th width="10%">TGL KEMBALI</th>
                <th width="10%">STATUS</th>
                <th width="10%">KONDISI</th>
            </tr>
        </thead>
        <tbody>
            <? php
            $no = 1;
            if($data_query && mysqli_num_rows($data_query) > 0):
                while($row = mysqli_fetch_assoc($data_query)):
            ?>
            <tr>
                <td class="text-center"><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                <td><?= htmlspecialchars($row['nama_merek']) ?></td>
                <td><?= htmlspecialchars($row['peminjam']) ?></td>
                <td><?= date('d-m-Y', strtotime($row['tanggal_pinjam'])) ?></td>
                <td><?= ! empty($row['tanggal_kembali']) ?  date('d-m-Y', strtotime($row['tanggal_kembali'])) : '-' ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
                <td><?= htmlspecialchars($row['kondisi_pinjam']) ?></td>
            </tr>
            <?php
                endwhile;
            else:
            ?>
            <tr>
                <td colspan="9" class="text-center">Belum ada data peminjaman</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>