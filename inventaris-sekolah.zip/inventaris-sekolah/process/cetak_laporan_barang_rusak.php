<?php
// process/cetak_laporan_barang_rusak.php
require_once '../config/conn.php';

$where = "1=1";
if(isset($_GET['dari']) && $_GET['dari'] != '') {
    $where .= " AND tanggal_laporan >= '{$_GET['dari']}'";
}
if(isset($_GET['sampai']) && $_GET['sampai'] != '') {
    $where .= " AND tanggal_laporan <= '{$_GET['sampai']}'";
}
if(isset($_GET['status']) && $_GET['status'] != '') {
    $where .= " AND status = '{$_GET['status']}'";
}

$periode = "Semua Periode";
if(isset($_GET['dari']) && isset($_GET['sampai'])) {
    $periode = date('d-m-Y', strtotime($_GET['dari'])) . " s/d " . date('d-m-Y', strtotime($_GET['sampai']));
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Barang Rusak</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 3px solid #000;
            padding-bottom: 10px;
        }
        .header h2 {
            margin: 5px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #000;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
        .footer {
            margin-top: 30px;
            text-align: right;
        }
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 10px;">
        <button onclick="window.print()">Cetak</button>
        <button onclick="window.close()">Tutup</button>
    </div>

    <div class="header">
        <h2>LAPORAN BARANG RUSAK</h2>
          <h3>UPT SMPN 8 MEDAN</h3>
        <p>Periode: <?= $periode; ?></p>
        <?php if(isset($_GET['status']) && $_GET['status'] != ''): ?>
        <p>Status: <?= $_GET['status']; ?></p>
        <?php endif; ?>
    </div>

    <table>
        <thead>
            <tr>
                <th width="30">NO</th>
                <th>TANGGAL</th>
                <th>KODE</th>
                <th>NAMA BARANG</th>
                <th>STATUS</th>
                <th>PELAPOR</th>
                <th>TEKNISI</th>
                <th>BIAYA</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $n=1;
            $total_biaya = 0;
            $query = mysqli_query($con,"SELECT br.*, b.nama_barang, b.kode_barang, m.nama_merek 
                                        FROM barang_rusak br 
                                        JOIN barang b ON b.idbarang=br.barang_id 
                                        JOIN merek m ON m.idmerek=b.merek_id 
                                        WHERE $where 
                                        ORDER BY br.tanggal_laporan DESC")or die(mysqli_error($con));
            while($row = mysqli_fetch_array($query)):
                $total_biaya += $row['biaya_aktual'];
            ?>
            <tr>
                <td><?= $n++; ?></td>
                <td><?= date('d-m-Y',strtotime($row['tanggal_laporan'])); ?></td>
                <td><?= $row['kode_barang']; ?></td>
                <td><?= $row['nama_barang']; ?> (<?= $row['nama_merek']; ?>)</td>
                <td><?= $row['status']; ?></td>
                <td><?= $row['pelapor']; ?></td>
                <td><?= $row['teknisi'] ? $row['teknisi'] : '-'; ?></td>
                <td>Rp <?= number_format($row['biaya_aktual'], 0, ',', '.'); ?></td>
            </tr>
            <?php endwhile; ?>
            <tr>
                <td colspan="7" style="text-align: right;"><strong>TOTAL BIAYA:</strong></td>
                <td><strong>Rp <?= number_format($total_biaya, 0, ',', '.'); ?></strong></td>
            </tr>
        </tbody>
    </table>

    <div class="footer">
        <p>Dicetak pada: <?= date('d-m-Y H:i:s'); ?></p>
        <br><br>
        <p>_________________________</p>
        <p>Penanggung Jawab</p>
    </div>

    <script>
        window.onload = function() {
            // window.print();
        }
    </script>
</body>
</html>