<?php
// modules/aset.php — nilai aset & penyusutan (garis lurus) per barang aset tetap.

function aset_render(array $r): void
{
    $con = db();
    $kat = get_int('kategori_id') ?: null;
    $lok = get_int('lokasi_id') ?: null;
    $status = get_str('status', 20);
    $rows = aset_daftar($con, $kat, $lok);
    $t = aset_ringkas($rows);
    if ($status === 'segera') $rows = array_values(array_filter($rows, function ($x) { return $x['p']['ok'] && $x['p']['status'] !== 'berjalan'; }));

    echo ui_head('Nilai Aset & Penyusutan', 'Dihitung otomatis dengan metode garis lurus. Nilai buku = perolehan − akumulasi penyusutan.',
        '<a class="btn btn-light btn-sm" target="_blank" href="' . e(base_url() . 'print/cetak.php?' . http_build_query(['jenis' => 'aset', 'kategori_id' => $kat, 'lokasi_id' => $lok])) . '"><i class="fas fa-print mr-1"></i> Cetak</a>'
        . '<a class="btn btn-light btn-sm" href="' . e(base_url() . 'export.php?' . http_build_query(['t' => 'aset', 'kategori_id' => $kat, 'lokasi_id' => $lok])) . '"><i class="fas fa-file-excel mr-1"></i> Excel</a>');
    ?>
    <div class="row">
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('blue', 'fa-file-invoice-dollar', 'Nilai perolehan', rupiah($t['perolehan']), angka($t['unit']) . ' unit') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('violet', 'fa-chart-line', 'Penyusutan per tahun', rupiah($t['per_tahun']), 'Perkiraan') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('amber', 'fa-minus-circle', 'Akumulasi penyusutan', rupiah($t['akum']), 'Sampai hari ini') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('green', 'fa-coins', 'Nilai buku', rupiah($t['buku']), $t['habis'] . ' aset sudah habis masa manfaat') ?></div>
    </div>

    <div class="card mb-4"><div class="card-body pb-2">
        <div class="d-flex flex-wrap mb-3" style="gap:10px"><?= ui_pills([
            '' => ['Semua aset', null],
            'segera' => ['Segera habis / sudah habis', $t['habis'] + $t['segera']],
        ], $status, 'status', ['m' => 'aset', 'kategori_id' => $kat, 'lokasi_id' => $lok]) ?></div>
        <form class="toolbar mb-3" method="get" action="<?= e(base_url()) ?>">
            <input type="hidden" name="m" value="aset"><input type="hidden" name="status" value="<?= e($status) ?>">
            <div style="min-width:220px"><select class="custom-select" name="kategori_id"><?= ui_opsi_tabel('kategori', 'nama', (string)$kat, 'Semua kategori') ?></select></div>
            <div style="min-width:220px"><select class="custom-select" name="lokasi_id"><?= ui_opsi_tabel('lokasi', 'nama', (string)$lok, 'Semua lokasi') ?></select></div>
            <button class="btn btn-primary" type="submit">Terapkan</button>
        </form>
    </div></div>

    <div class="card"><div class="table-responsive">
        <table class="table table-hover datatable" data-order="1:asc" data-nosort="8">
            <thead><tr>
                <th>Barang</th><th>Lokasi</th><th class="text-right">Unit</th><th class="text-right">Perolehan</th>
                <th class="text-right">Penyusutan / tahun</th><th class="text-right">Nilai buku</th><th style="min-width:160px">Umur pakai</th>
                <th>Sisa masa manfaat</th><th class="text-center">Detail</th>
            </tr></thead>
            <tbody>
            <?php foreach ($rows as $x): ?>
                <tr>
                    <td><strong><?= e($x['nama_barang']) ?></strong><span class="sub"><span class="code-chip" style="font-size:11px"><?= e($x['kode_barang']) ?></span> · <?= e($x['kategori']) ?></span></td>
                    <td><?= e($x['lokasi']) ?></td>
                    <td class="text-right"><?= angka($x['stok_total']) ?></td>
                    <?php if ($x['p']['ok']): ?>
                        <td class="text-right"><?= rupiah($x['p']['perolehan_total']) ?></td>
                        <td class="text-right"><?= rupiah($x['p']['per_tahun_total']) ?></td>
                        <td class="text-right font-weight-bold"><?= rupiah($x['p']['nilai_buku_total']) ?></td>
                        <td>
                            <div class="progress" style="height:6px"><div class="progress-bar" style="width:<?= number_format($x['p']['persen_pakai'], 2, '.', '') ?>%;<?= $x['p']['status'] === 'habis' ? 'background:#dc2626' : ($x['p']['status'] === 'segera' ? 'background:#d97706' : '') ?>"></div></div>
                            <span class="sub"><?= number_format($x['p']['persen_pakai'], 0) ?>% dari <?= (int)$x['masa_manfaat_tahun'] ?> tahun</span>
                        </td>
                        <td><?= $x['p']['status'] === 'habis' ? badge('Habis', 'danger') : ($x['p']['status'] === 'segera' ? badge(label_sisa_bulan($x['p']['sisa_bulan']), 'warning') : badge(label_sisa_bulan($x['p']['sisa_bulan']), 'info')) ?>
                            <span class="sub">s.d. <?= tgl_indo($x['p']['tgl_habis']) ?></span></td>
                    <?php else: ?>
                        <td colspan="4"><span class="text-muted small">Lengkapi harga, tanggal perolehan, dan masa manfaat untuk menghitung penyusutan.</span></td>
                    <?php endif; ?>
                    <td class="text-center"><?= ui_btn_link(url('barang', ['aksi' => 'detail', 'id' => $x['id']]), 'fa-eye', 'light', 'Detail') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div></div>
    <p class="small text-muted mt-3">Catatan: semua unit dalam satu barang dianggap diperoleh pada tanggal perolehan yang sama. Batch pembelian yang berbeda tanggal dapat dicatat sebagai barang baru agar perhitungannya lebih akurat.</p>
    <?php
}
