<?php
// modules/referensi.php — master kategori, merek, dan lokasi (satu modul, konfigurasi per tipe).

function referensi_cfg(string $tipe): array
{
    $cfg = [
        'kategori' => [
            'judul' => 'Kategori Barang', 'tabel' => 'kategori', 'fk' => 'kategori_id', 'label_pakai' => 'barang',
            'fields' => [
                'nama'        => ['label' => 'Nama Kategori', 'wajib' => true, 'maks' => 100],
                'kode_prefix' => ['label' => 'Kode Prefiks (2–5 huruf kapital)', 'wajib' => true, 'maks' => 5,
                                  'pola' => '/^[A-Z]{2,5}$/', 'pesan' => 'Kode prefiks harus 2–5 huruf (A–Z) tanpa spasi.'],
                'keterangan'  => ['label' => 'Keterangan', 'wajib' => false, 'maks' => 255],
            ],
            'kolom' => ['Kode', 'Nama Kategori', 'Keterangan'],
            'ikon' => 'fa-tags',
        ],
        'merek' => [
            'judul' => 'Merek', 'tabel' => 'merek', 'fk' => 'merek_id', 'label_pakai' => 'barang',
            'fields' => [
                'nama'       => ['label' => 'Nama Merek', 'wajib' => true, 'maks' => 100],
                'keterangan' => ['label' => 'Keterangan', 'wajib' => false, 'maks' => 255],
            ],
            'kolom' => ['Nama Merek', 'Keterangan'],
            'ikon' => 'fa-copyright',
        ],
        'lokasi' => [
            'judul' => 'Lokasi / Ruangan', 'tabel' => 'lokasi', 'fk' => 'lokasi_id', 'label_pakai' => 'barang',
            'fields' => [
                'nama'             => ['label' => 'Nama Ruangan', 'wajib' => true, 'maks' => 100],
                'penanggung_jawab' => ['label' => 'Penanggung Jawab', 'wajib' => false, 'maks' => 100],
                'keterangan'       => ['label' => 'Keterangan', 'wajib' => false, 'maks' => 255],
            ],
            'kolom' => ['Nama Ruangan', 'Penanggung Jawab', 'Keterangan'],
            'ikon' => 'fa-door-open',
        ],
    ];
    if (!isset($cfg[$tipe])) throw new AppException('Jenis referensi tidak dikenal.');
    return $cfg[$tipe];
}

function referensi_render(array $r): void
{
    $tipe = $r['tipe'];
    $cfg = referensi_cfg($tipe);
    $con = db();
    $aksi = get_str('aksi', 20);
    $editId = $aksi === 'edit' ? get_int('id') : 0;
    $t = $cfg['tabel']; $fk = $cfg['fk'];

    $rows = db_all($con, "SELECT x.*, (SELECT COUNT(*) FROM barang b WHERE b.$fk = x.id) AS pakai FROM $t x ORDER BY x.nama ASC");
    $jumlah = count($rows);
    $unitPakai = array_sum(array_column($rows, 'pakai'));

    $aksiHtml = '<a class="btn btn-primary btn-sm" href="' . e(url($tipe)) . '"><i class="fas fa-plus mr-1"></i> Tambah Baru</a>';
    echo ui_head($cfg['judul'], "Total {$jumlah} data · dipakai oleh {$unitPakai} barang", $aksiHtml);

    $edit = null;
    if ($editId) {
        $edit = db_row($con, "SELECT * FROM $t WHERE id = ?", 'i', [$editId]);
        if (!$edit) { flash('error', 'Data tidak ditemukan.'); redirect(url($tipe)); }
    }
    $v = function ($k) use ($edit) { return old($k, $edit[$k] ?? ''); };
    ?>
    <div class="row">
        <div class="col-lg-8 mb-4">
            <div class="card">
                <div class="table-responsive">
                    <table class="table table-hover datatable" data-order="1:asc" data-nosort="<?= count($cfg['kolom']) + 1 ?>">
                        <thead><tr>
                            <?php if ($tipe === 'kategori'): ?><th>Kode</th><?php endif; ?>
                            <?php foreach ($cfg['kolom'] as $k) { if ($tipe === 'kategori' && $k === 'Kode') continue; echo '<th>' . e($k) . '</th>'; } ?>
                            <th class="text-center">Dipakai</th>
                            <th class="text-center">Aksi</th>
                        </tr></thead>
                        <tbody>
                        <?php foreach ($rows as $x): ?>
                        <tr>
                            <?php if ($tipe === 'kategori'): ?><td><span class="code-chip"><?= e($x['kode_prefix']) ?></span></td><?php endif; ?>
                            <td><strong><?= e($x['nama']) ?></strong></td>
                            <?php if ($tipe === 'lokasi'): ?><td><?= e($x['penanggung_jawab'] ?: '-') ?></td><?php endif; ?>
                            <td class="text-muted"><?= e($x['keterangan'] ?: '-') ?></td>
                            <td class="text-center"><?= badge((int)$x['pakai'] . ' barang', (int)$x['pakai'] ? 'primary' : 'secondary') ?></td>
                            <td class="text-center text-nowrap">
                                <?= ui_btn_link(url($tipe, ['aksi' => 'edit', 'id' => $x['id']]), 'fa-pen', 'light', 'Ubah') ?>
                                <form method="post" action="<?= e(url($tipe)) ?>" class="d-inline"
                                      data-confirm="<?= (int)$x['pakai'] ? 'Data ini masih dipakai barang sehingga tidak dapat dihapus.' : 'Hapus data ini?' ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="aksi" value="hapus">
                                    <input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
                                    <button class="btn btn-sm btn-icon btn-light text-danger" type="submit" title="Hapus" data-toggle="tooltip"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-header"><?= $edit ? 'Ubah ' . e($cfg['judul']) : 'Tambah ' . e($cfg['judul']) ?></div>
                <div class="card-body">
                    <form method="post" action="<?= e(url($tipe)) ?>" class="needs-validation" novalidate>
                        <?= csrf_field() ?>
                        <input type="hidden" name="aksi" value="simpan">
                        <input type="hidden" name="id" value="<?= (int)$editId ?>">
                        <?php foreach ($cfg['fields'] as $name => $f): ?>
                        <div class="form-group">
                            <label for="f_<?= e($name) ?>"><?= e($f['label']) ?><?= $f['wajib'] ? ' <span class="req">*</span>' : '' ?></label>
                            <input class="form-control" id="f_<?= e($name) ?>" name="<?= e($name) ?>" maxlength="<?= (int)$f['maks'] ?>"
                                   value="<?= e($v($name)) ?>" <?= $f['wajib'] ? 'required' : '' ?>
                                   <?= $name === 'kode_prefix' ? 'style="text-transform:uppercase"' : '' ?>>
                            <div class="invalid-feedback"><?= e($f['label']) ?> wajib diisi.</div>
                        </div>
                        <?php endforeach; ?>
                        <div class="d-flex gap-2">
                            <button class="btn btn-primary" type="submit"><i class="fas fa-save mr-1"></i> Simpan</button>
                            <?php if ($edit): ?><a class="btn btn-light" href="<?= e(url($tipe)) ?>">Batal</a><?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php
    $GLOBALS['page_js'] = '$("#f_kode_prefix").on("input", function(){ this.value = this.value.toUpperCase(); });';
}

function referensi_post(array $r): void
{
    require_perm('referensi.kelola');
    $tipe = $r['tipe'];
    $cfg = referensi_cfg($tipe);
    $con = db();
    $t = $cfg['tabel'];
    $aksi = post_str('aksi', 20);
    $id = post_int('id');

    if ($aksi === 'hapus') {
        $nama = db_value($con, "SELECT nama FROM $t WHERE id = ?", 'i', [$id]);
        try {
            db_exec($con, "DELETE FROM $t WHERE id = ?", 'i', [$id]);
        } catch (mysqli_sql_exception $ex) {
            $pesan = db_pesan($ex);
            if ($pesan === null) throw $ex;
            throw new AppException($pesan);
        }
        log_aktivitas('HAPUS', $tipe, "Menghapus {$tipe}: {$nama}");
        flash('success', ucfirst($tipe) . ' berhasil dihapus.');
        redirect(url($tipe));
    }

    if ($aksi !== 'simpan') throw new AppException('Aksi tidak dikenali.');

    $data = [];
    foreach ($cfg['fields'] as $name => $f) {
        $val = str_bersih($_POST[$name] ?? '', $f['maks']);
        if ($name === 'kode_prefix') $val = strtoupper($val);
        if ($f['wajib'] && $val === '') throw new AppException($f['label'] . ' wajib diisi.');
        if (isset($f['pola']) && $val !== '' && !preg_match($f['pola'], $val)) throw new AppException($f['pesan']);
        $data[$name] = $val === '' ? null : $val;
    }

    try {
        if ($id) {
            $sets = []; $vals = [];
            foreach ($data as $k => $val) { $sets[] = "$k = ?"; $vals[] = $val; }
            $vals[] = $id;
            db_exec($con, "UPDATE $t SET " . implode(', ', $sets) . " WHERE id = ?", str_repeat('s', count($data)) . 'i', $vals);
            log_aktivitas('UBAH', $tipe, "Mengubah {$tipe}: {$data['nama']}");
            flash('success', 'Data berhasil diperbarui.');
        } else {
            $cols = array_keys($data);
            db_exec($con,
                "INSERT INTO $t (" . implode(', ', $cols) . ") VALUES (" . implode(', ', array_fill(0, count($cols), '?')) . ")",
                str_repeat('s', count($cols)), array_values($data));
            log_aktivitas('TAMBAH', $tipe, "Menambah {$tipe}: {$data['nama']}");
            flash('success', 'Data berhasil ditambahkan.');
        }
    } catch (mysqli_sql_exception $ex) {
        $pesan = db_pesan($ex);
        if ($pesan === null) throw $ex;
        throw new AppException($pesan);
    }
    redirect(url($tipe));
}
