<?php
// modules/barang.php — master barang. Dua jenis: habis pakai (jumlah berkurang saat dipakai) dan aset tetap (disusutkan).

/** Buat barang baru. Jumlah awal (jika ada) dicatat sebagai barang masuk "Saldo awal". */
function barang_buat(mysqli $con, array $d): int
{
    return db_tx($con, function (mysqli $con) use ($d) {
        $kode = kode_barang_baru($con, (int)$d['kategori_id']);
        $tipe = 'sss' . 'iii' . 's' . 'i' . 'd' . 's' . 'i' . 'sss' . 'i' . 'd';
        $id = db_exec($con,
            "INSERT INTO barang (kode_barang, kode_bmn, nama_barang, kategori_id, merek_id, lokasi_id, satuan, stok_total, stok_minimum,
                                 harga_perolehan, sumber_dana, tahun_perolehan, keterangan, jenis_barang, tanggal_perolehan,
                                 masa_manfaat_tahun, nilai_residu_persen, aktif)
             VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)",
            $tipe,
            [$kode, $d['kode_bmn'], $d['nama_barang'], $d['kategori_id'], $d['merek_id'], $d['lokasi_id'], $d['satuan'],
             $d['stok_minimum'], $d['harga_perolehan'], $d['sumber_dana'], $d['tahun_perolehan'], $d['keterangan'],
             $d['jenis'], $d['tanggal'], $d['masa'], $d['residu']])['insert_id'];
        if ((int)$d['stok_awal'] > 0) {
            transaksi_masuk_tambah($con, [
                'tanggal' => $d['tanggal'] ?: date('Y-m-d'), 'barang_id' => $id, 'jumlah' => (int)$d['stok_awal'],
                'lokasi_id' => $d['lokasi_id'], 'harga_satuan' => $d['harga_perolehan'], 'sumber_dana' => $d['sumber_dana'],
                'nomor_dokumen' => 'SALDO AWAL', 'keterangan' => 'Saldo awal pendataan', 'saldo_awal' => true,
            ]);
        }
        log_aktivitas('TAMBAH', 'barang', "Menambah barang {$kode} — {$d['nama_barang']} (" . JENIS_BARANG[$d['jenis']] . ")");
        return $id;
    });
}

/** Validasi input barang. Mengembalikan data bersih. */
function barang_validasi(array $p, bool $baru): array
{
    $con = db();
    $nama = str_bersih($p['nama_barang'] ?? '', 150);
    if (mb_strlen($nama) < 3) throw new AppException('Nama barang minimal 3 karakter.');

    $jenis = ($p['jenis_barang'] ?? '') === 'habis_pakai' ? 'habis_pakai' : 'aset';

    $kategori = angka_bersih($p['kategori_id'] ?? '');
    if (!$kategori || !db_value($con, "SELECT id FROM kategori WHERE id = ?", 'i', [$kategori])) {
        throw new AppException('Pilih kategori barang.');
    }
    $merek = angka_bersih($p['merek_id'] ?? '') ?: null;
    if ($merek !== null && !db_value($con, "SELECT id FROM merek WHERE id = ?", 'i', [$merek])) {
        throw new AppException('Merek yang dipilih tidak valid.');
    }
    $lokasi = angka_bersih($p['lokasi_id'] ?? '') ?: null;
    if ($lokasi !== null && !db_value($con, "SELECT id FROM lokasi WHERE id = ?", 'i', [$lokasi])) {
        throw new AppException('Lokasi yang dipilih tidak valid.');
    }

    $tglRaw = trim((string)($p['tanggal_perolehan'] ?? ''));
    $tgl = $tglRaw === '' ? null : tanggal_valid($tglRaw);
    if ($tglRaw !== '' && !$tgl) throw new AppException('Tanggal perolehan tidak valid.');
    if ($tgl && $tgl > date('Y-m-d')) throw new AppException('Tanggal perolehan tidak boleh di masa depan.');

    $masa = null; $residu = 0.0;
    if ($jenis === 'aset') {
        if (!$tgl) throw new AppException('Tanggal perolehan wajib diisi untuk aset tetap (dipakai untuk menghitung penyusutan).');
        $masa = angka_bersih($p['masa_manfaat_tahun'] ?? 0);
        if ($masa < 1 || $masa > 50) throw new AppException('Masa manfaat aset harus antara 1 dan 50 tahun.');
        $residu = (float)min(90, angka_bersih($p['nilai_residu_persen'] ?? 0));
    }

    $satuan = str_bersih($p['satuan'] ?? 'unit', 20) ?: 'unit';
    $minimum = angka_bersih($p['stok_minimum'] ?? 2);
    if ($minimum > 100000) throw new AppException('Batas minimum terlalu besar.');
    $harga = angka_bersih($p['harga_perolehan'] ?? 0);
    $sumber = in_array($p['sumber_dana'] ?? '', SUMBER_DANA, true) ? $p['sumber_dana'] : 'Lainnya';
    $tahun = $tgl ? (int)substr($tgl, 0, 4) : (angka_bersih($p['tahun_perolehan'] ?? '') ?: null);
    $ket = str_bersih($p['keterangan'] ?? '', 500);

    $awal = 0;
    if ($baru) {
        $awal = angka_bersih($p['stok_awal'] ?? 0);
        if ($awal > 1000000) throw new AppException('Jumlah awal terlalu besar.');
    }
    return [
        'nama_barang' => $nama, 'jenis' => $jenis, 'kategori_id' => $kategori, 'merek_id' => $merek, 'lokasi_id' => $lokasi,
        'satuan' => $satuan, 'stok_minimum' => $minimum, 'harga_perolehan' => $harga, 'sumber_dana' => $sumber,
        'tahun_perolehan' => $tahun, 'tanggal' => $tgl, 'masa' => $masa, 'residu' => $residu,
        'keterangan' => $ket, 'stok_awal' => $awal, 'kode_bmn' => str_bersih($p['kode_bmn'] ?? '', 40) ?: null,
    ];
}

function barang_render(array $r): void
{
    $aksi = get_str('aksi', 20);
    if ($aksi === 'tambah' || $aksi === 'edit') barang_render_form($aksi, get_int('id'));
    elseif ($aksi === 'detail') barang_render_detail(get_int('id'));
    else barang_render_list();
}

/** Teks perkiraan untuk satu baris (habis pakai: sisa hari; aset: sisa masa manfaat). */
function barang_perkiraan_html(array $b, int $tersedia, ?array $est, ?array $pen): string
{
    if ($b['jenis_barang'] === 'habis_pakai') {
        $e = estimasi_sisa_pakai($est, $tersedia);
        if (!$e['ok']) return '<span class="text-muted small">Belum ada pemakaian</span>';
        $cls = ['darurat' => 'danger', 'segera' => 'warning', 'aman' => 'success'][$e['status']];
        return badge('±' . angka($e['sisa_hari']) . ' hari', $cls) . '<span class="sub">' . angka_rate($e['rata']) . ' ' . e($b['satuan']) . '/hari</span>';
    }
    if (!$pen || !$pen['ok']) return '<span class="text-muted small">Atur masa manfaat</span>';
    $cls = ['habis' => 'danger', 'segera' => 'warning', 'berjalan' => 'info'][$pen['status']];
    return badge(label_sisa_bulan($pen['sisa_bulan']), $cls) . (can('nilai.lihat') ? '<span class="sub">Nilai buku ' . rupiah($pen['nilai_buku_total']) . '</span>' : '');
}

function barang_render_list(): void
{
    $con = db();
    $q = get_str('q', 80);
    $kat = get_int('kategori_id') ?: null;
    $lok = get_int('lokasi_id') ?: null;
    $jenis = get_str('jenis', 20);
    $stok = get_str('stok', 20) ?: get_str('filter', 20);
    $arsip = $stok === 'arsip';

    $where = [$arsip ? 'b.aktif = 0' : 'b.aktif = 1']; $tipe = ''; $par = [];
    if ($q !== '') { $where[] = '(b.kode_barang LIKE ? OR b.nama_barang LIKE ?)'; $tipe .= 'ss'; $par[] = '%' . $q . '%'; $par[] = '%' . $q . '%'; }
    if ($kat) { $where[] = 'b.kategori_id = ?'; $tipe .= 'i'; $par[] = $kat; }
    if ($lok) { $where[] = 'b.lokasi_id = ?'; $tipe .= 'i'; $par[] = $lok; }
    if (isset(JENIS_BARANG[$jenis])) { $where[] = 'b.jenis_barang = ?'; $tipe .= 's'; $par[] = $jenis; }

    $rows = db_all($con,
        "SELECT b.*, k.nama AS kategori, COALESCE(m.nama, '-') AS merek, COALESCE(l.nama, '-') AS lokasi,
                (SELECT COALESCE(SUM(p.sisa),0) FROM peminjaman p WHERE p.barang_id = b.id AND p.status = 'Dipinjam') AS dipinjam,
                (SELECT COALESCE(SUM(x.jumlah),0) FROM kerusakan x WHERE x.barang_id = b.id AND x.status NOT IN ('Selesai','Rusak Permanen')) AS rusak
         FROM barang b JOIN kategori k ON k.id = b.kategori_id LEFT JOIN merek m ON m.id = b.merek_id LEFT JOIN lokasi l ON l.id = b.lokasi_id
         WHERE " . implode(' AND ', $where) . " ORDER BY b.nama_barang", $tipe, $par);

    $est = estimasi_pemakaian_semua($con);
    $nHabis = 0; $nAset = 0; $perluPesan = 0; $nilaiBuku = 0.0; $habisCount = 0; $menipisCount = 0;
    foreach ($rows as &$b) {
        $b['tersedia'] = (int)$b['stok_total'] - (int)$b['dipinjam'] - (int)$b['rusak'];
        $b['pen'] = $b['jenis_barang'] === 'aset' ? penyusutan_batch($con, $b) : null;
        $b['est'] = $b['jenis_barang'] === 'habis_pakai' ? estimasi_sisa_pakai($est[(int)$b['id']] ?? null, $b['tersedia']) : null;
        if ($b['jenis_barang'] === 'habis_pakai') $nHabis++; else $nAset++;
        if ($b['tersedia'] <= 0) $habisCount++;
        if ($b['tersedia'] <= (int)$b['stok_minimum']) $menipisCount++;
        if ($b['est'] && $b['est']['ok'] && $b['est']['status'] !== 'aman') $perluPesan++;
        if ($b['pen'] && $b['pen']['ok']) $nilaiBuku += $b['pen']['nilai_buku_total'];
    }
    unset($b);
    if ($stok === 'menipis') $rows = array_values(array_filter($rows, function ($x) { return $x['tersedia'] <= (int)$x['stok_minimum']; }));
    if ($stok === 'habis') $rows = array_values(array_filter($rows, function ($x) { return $x['tersedia'] <= 0; }));

    $aktifCount = (int)db_value($con, "SELECT COUNT(*) FROM barang WHERE aktif = 1");
    $arsipCount = (int)db_value($con, "SELECT COUNT(*) FROM barang WHERE aktif = 0");

    $aksiHtml = '';
    if (can('barang.kelola')) {
        $aksiHtml .= '<a class="btn btn-primary btn-sm" href="' . e(url('barang', ['aksi' => 'tambah'])) . '"><i class="fas fa-plus mr-1"></i> Tambah Barang</a>';
        $aksiHtml .= '<button class="btn btn-light btn-sm" type="button" data-toggle="modal" data-target="#modalImport"><i class="fas fa-file-import mr-1"></i> Impor</button>';
    }
    $aksiHtml .= '<a class="btn btn-light btn-sm" href="' . e(base_url() . 'export.php?t=barang') . '"><i class="fas fa-file-export mr-1"></i> Ekspor</a>';
    echo ui_head('Data Barang', 'Barang habis pakai dipantau sisa jumlahnya. Aset tetap dipantau penyusutan dan kondisinya.', $aksiHtml);
    ?>
    <div class="row">
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('teal', 'fa-tint', 'Habis Pakai', angka($nHabis), 'Pulpen, kertas, tinta, dll.') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('blue', 'fa-couch', 'Aset Tetap', angka($nAset), 'Elektronik, furnitur, peralatan') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('amber', 'fa-hourglass-half', 'Perlu Dipesan / Diganti', angka($perluPesan), 'Habis pakai segera habis') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?php if (can('nilai.lihat')): ?><?= can('nilai.lihat') ? ui_kpi('violet', 'fa-coins', 'Nilai Buku Aset', rupiah($nilaiBuku), 'Perkiraan setelah penyusutan') : ui_kpi('violet', 'fa-cubes', 'Unit terdaftar', angka(array_sum(array_column($rows, 'stok_total'))), 'Daftar ini') ?><?php else: ?><?= ui_kpi('violet', 'fa-cubes', 'Total Unit', angka(array_sum(array_column($rows, 'stok_total'))), 'Seluruh barang (daftar ini)') ?><?php endif; ?></div>
    </div>

    <div class="card mb-4"><div class="card-body pb-2">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-3" style="gap:10px">
            <?= ui_pills([
                '' => ['Semua jenis', $aktifCount],
                'habis_pakai' => ['Habis pakai', $nHabis],
                'aset' => ['Aset tetap', $nAset],
            ], $jenis, 'jenis', ['m' => 'barang', 'stok' => $stok, 'q' => $q]) ?>
            <?= ui_pills([
                '' => ['Semua status', null],
                'menipis' => ['Menipis / habis', $menipisCount],
                'habis' => ['Habis', $habisCount],
                'arsip' => ['Diarsipkan', $arsipCount],
            ], $arsip ? 'arsip' : ($stok === 'menipis' ? 'menipis' : ($stok === 'habis' ? 'habis' : '')), 'stok', ['m' => 'barang', 'jenis' => $jenis, 'q' => $q]) ?>
        </div>
        <form class="toolbar mb-3" method="get" action="<?= e(base_url()) ?>">
            <input type="hidden" name="m" value="barang"><input type="hidden" name="stok" value="<?= e($stok) ?>"><input type="hidden" name="jenis" value="<?= e($jenis) ?>">
            <div style="min-width:240px;flex:1"><input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Cari kode atau nama barang…"></div>
            <div style="min-width:190px"><select class="custom-select" name="kategori_id"><?= ui_opsi_tabel('kategori', 'nama', (string)$kat, 'Semua kategori') ?></select></div>
            <div style="min-width:190px"><select class="custom-select" name="lokasi_id"><?= ui_opsi_tabel('lokasi', 'nama', (string)$lok, 'Semua lokasi') ?></select></div>
            <button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i> Terapkan</button>
            <a class="btn btn-light" href="<?= e(url('barang')) ?>">Reset</a>
        </form>
    </div></div>

    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover datatable" data-order="1:asc" data-nosort="6">
                <thead><tr>
                    <th>Kode</th><th>Barang</th><th class="d-none d-lg-table-cell">Kategori &amp; Lokasi</th><th class="text-right">Jumlah (tersedia / total)</th>
                    <th>Status</th><th>Perkiraan</th><th class="text-center">Aksi</th>
                </tr></thead>
                <tbody>
                <?php foreach ($rows as $b): ?>
                <tr>
                    <td><span class="code-chip"><?= e($b['kode_barang']) ?></span></td>
                    <td>
                        <strong><?= e($b['nama_barang']) ?></strong>
                        <span class="sub"><?= e($b['merek']) ?> ·
                            <?= $b['jenis_barang'] === 'habis_pakai' ? badge('Habis pakai', 'info') : badge('Aset tetap', 'primary') ?></span>
                    </td>
                    <td class="d-none d-lg-table-cell"><?= e($b['kategori']) ?><span class="sub"><?= e($b['lokasi']) ?></span></td>
                    <td class="text-right text-nowrap"><strong><?= angka($b['tersedia']) ?></strong> <span class="text-muted">/ <?= angka($b['stok_total']) ?></span>
                        <span class="sub"><?= e($b['satuan']) ?> · min <?= angka($b['stok_minimum']) ?></span></td>
                    <td><?= ui_badge_stok((int)$b['tersedia'], (int)$b['stok_minimum'], (int)$b['aktif']) ?></td>
                    <td><?= barang_perkiraan_html($b, (int)$b['tersedia'], $b['est'] ? $est[(int)$b['id']] ?? null : null, $b['pen']) ?></td>
                    <td class="text-center text-nowrap">
                        <?= ui_btn_link(url('barang', ['aksi' => 'detail', 'id' => $b['id']]), 'fa-eye', 'light', 'Lihat detail') ?>
                        <?php if (can('barang.kelola')): ?>
                            <?= ui_btn_link(url('barang', ['aksi' => 'edit', 'id' => $b['id']]), 'fa-pen', 'light', 'Ubah') ?>
                            <form method="post" action="<?= e(url('barang')) ?>" class="d-inline">
                                <?= csrf_field() ?><input type="hidden" name="aksi" value="arsipkan"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                                <button class="btn btn-sm btn-icon btn-light" type="submit" title="<?= $b['aktif'] ? 'Arsipkan' : 'Aktifkan kembali' ?>" data-toggle="tooltip">
                                    <i class="fas <?= $b['aktif'] ? 'fa-archive' : 'fa-undo' ?>"></i></button>
                            </form>
                        <?php endif; ?>
                        <?php if (can('barang.hapus')): ?>
                            <form method="post" action="<?= e(url('barang')) ?>" class="d-inline" data-confirm="Barang tanpa riwayat transaksi akan dihapus permanen. Lanjutkan?">
                                <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                                <button class="btn btn-sm btn-icon btn-light text-danger" type="submit" title="Hapus" data-toggle="tooltip"><i class="fas fa-trash"></i></button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (can('barang.kelola')): ?>
    <div class="modal fade" id="modalImport" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document"><div class="modal-content">
            <form method="post" action="<?= e(url('barang')) ?>" enctype="multipart/form-data">
                <?= csrf_field() ?><input type="hidden" name="aksi" value="import">
                <div class="modal-header"><h5 class="modal-title">Impor Barang dari CSV</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Tutup"><span>&times;</span></button></div>
                <div class="modal-body">
                    <p class="small text-muted">Baris pertama berisi judul kolom. Pemisah boleh koma atau titik koma. Unduh template agar kolomnya benar.</p>
                    <p class="mono small mb-3" style="word-break:break-word">nama_barang; jenis (habis_pakai / aset); kategori; merek; lokasi; satuan; stok_minimum; harga_perolehan; sumber_dana; tanggal_perolehan; masa_manfaat_tahun; nilai_residu_persen; stok_awal; keterangan</p>
                    <div class="form-group"><label for="berkas">Berkas CSV <span class="req">*</span></label>
                        <input class="form-control" type="file" id="berkas" name="berkas" accept=".csv,text/csv" required>
                        <small class="help">Maksimal 2 MB, hingga 500 baris.</small></div>
                    <a class="small" href="<?= e(base_url() . 'export.php?t=template_barang') ?>"><i class="fas fa-download mr-1"></i> Unduh template CSV</a>
                </div>
                <div class="modal-footer"><button class="btn btn-light" type="button" data-dismiss="modal">Batal</button>
                    <button class="btn btn-primary" type="submit"><i class="fas fa-file-import mr-1"></i> Impor</button></div>
            </form>
        </div></div>
    </div>
    <?php endif; ?>
    <?php
}

function barang_render_form(string $aksi, int $id): void
{
    require_perm('barang.kelola');
    $con = db();
    $b = null;
    if ($id) {
        $b = barang_detail($con, $id);
        if (!$b) { echo ui_kosong('fa-search', 'Barang tidak ditemukan'); return; }
    }
    $v = function ($k, $def = '') use ($b) { return old($k, $b[$k] ?? $def); };
    $jenisSel = (string)$v('jenis_barang', 'habis_pakai');
    if (!$b && old('jenis_barang') === '') $jenisSel = 'habis_pakai';
    $harga = old('harga_perolehan', $b ? angka((int)$b['harga_perolehan']) : '');

    echo ui_head($b ? 'Ubah Barang' : 'Tambah Barang',
        $b ? 'Kode barang tetap. Jumlah diubah lewat menu transaksi, bukan dari sini.' : 'Kode barang dibuat otomatis berdasarkan kategori.',
        '<a class="btn btn-light btn-sm" href="' . e(url('barang')) . '"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('barang', $b ? ['aksi' => 'edit', 'id' => $id] : ['aksi' => 'tambah'])) ?>" novalidate>
        <?= csrf_field() ?>
        <input type="hidden" name="aksi" value="simpan"><input type="hidden" name="id" value="<?= (int)$id ?>">

        <div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold mb-3">1. Jenis barang</h6>
            <div class="jenis-grid">
                <label class="jenis-card">
                    <input type="radio" name="jenis_barang" value="habis_pakai" <?= $jenisSel === 'habis_pakai' ? 'checked' : '' ?>>
                    <span class="jc-body">
                        <i class="fas fa-tint"></i>
                        <strong>Habis pakai</strong>
                        <small>Pulpen, kertas, tinta, pembersih. Jumlah berkurang setiap dipakai. Dipantau sisa hari.</small>
                    </span>
                </label>
                <label class="jenis-card">
                    <input type="radio" name="jenis_barang" value="aset" <?= $jenisSel === 'aset' ? 'checked' : '' ?>>
                    <span class="jc-body">
                        <i class="fas fa-couch"></i>
                        <strong>Aset tetap</strong>
                        <small>Elektronik, furnitur, peralatan. Disusutkan dan dipantau kondisinya.</small>
                    </span>
                </label>
            </div>
        </div></div>

        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold mb-3">2. Identitas barang</h6>
            <div class="form-group">
                <label for="nama_barang">Nama barang <span class="req">*</span></label>
                <input class="form-control" id="nama_barang" name="nama_barang" maxlength="150" required value="<?= e($v('nama_barang')) ?>" placeholder="Contoh: Pulpen Pilot V5 Hitam">
                <div class="invalid-feedback">Nama barang wajib diisi (minimal 3 karakter).</div>
            </div>
            <div class="form-group"><label for="kode_bmn">Kode BMN (opsional)</label>
                <input class="form-control" id="kode_bmn" name="kode_bmn" maxlength="40" value="<?= e($v('kode_bmn')) ?>" placeholder="Kode barang milik negara, bila ada"></div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="kategori_id">Kategori <span class="req">*</span></label>
                    <select class="custom-select select2" id="kategori_id" name="kategori_id" required data-placeholder="Pilih kategori"><?= ui_opsi_tabel('kategori', 'nama', (string)$v('kategori_id'), '') ?></select></div>
                <div class="form-group col-md-6"><label for="merek_id">Merek</label>
                    <select class="custom-select select2" id="merek_id" name="merek_id" data-placeholder="Tanpa merek" data-allow-clear="1"><?= ui_opsi_tabel('merek', 'nama', (string)$v('merek_id'), '') ?></select></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="lokasi_id">Lokasi / ruangan</label>
                    <select class="custom-select select2" id="lokasi_id" name="lokasi_id" data-placeholder="Belum ditentukan" data-allow-clear="1"><?= ui_opsi_tabel('lokasi', 'nama', (string)$v('lokasi_id'), '') ?></select></div>
                <div class="form-group col-md-3"><label for="satuan">Satuan</label>
                    <input class="form-control" id="satuan" name="satuan" maxlength="20" list="daftarSatuan" value="<?= e($v('satuan', 'unit')) ?>">
                    <datalist id="daftarSatuan"><option>unit</option><option>buah</option><option>botol</option><option>pak</option><option>dus</option><option>rim</option><option>lusin</option><option>set</option></datalist></div>
                <div class="form-group col-md-3"><label for="stok_minimum">Batas minimum</label>
                    <input class="form-control" type="number" id="stok_minimum" name="stok_minimum" min="0" value="<?= e($v('stok_minimum', 2)) ?>">
                    <small class="help">Peringatan bila tersedia ≤ angka ini</small></div>
            </div>
            <div class="form-group mb-0"><label for="keterangan">Keterangan / spesifikasi</label>
                <textarea class="form-control" id="keterangan" name="keterangan" maxlength="500" rows="2"><?= e($v('keterangan')) ?></textarea></div>
        </div></div></div>

        <div class="col-lg-4"><div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold mb-3">3. Perolehan</h6>
            <div class="form-group"><label for="harga_perolehan">Harga per unit (Rp)</label>
                <input class="form-control" id="harga_perolehan" name="harga_perolehan" inputmode="numeric" data-mask="rupiah" value="<?= e($harga) ?>" placeholder="0"></div>
            <div class="form-group"><label for="tanggal_perolehan">Tanggal perolehan</label>
                <input class="form-control" type="date" id="tanggal_perolehan" name="tanggal_perolehan" max="<?= date('Y-m-d') ?>" value="<?= e($v('tanggal_perolehan')) ?>">
                <small class="help">Wajib untuk aset tetap.</small></div>
            <div class="form-group"><label for="sumber_dana">Sumber dana</label>
                <select class="custom-select" id="sumber_dana" name="sumber_dana"><?= opsi_html(array_combine(SUMBER_DANA, SUMBER_DANA), (string)$v('sumber_dana', 'BOS')) ?></select></div>
            <div class="fld-aset">
                <div class="form-group"><label for="masa_manfaat_tahun">Masa manfaat (tahun) <span class="req">*</span></label>
                    <input class="form-control" type="number" id="masa_manfaat_tahun" name="masa_manfaat_tahun" min="1" max="50" value="<?= e($v('masa_manfaat_tahun', 4)) ?>">
                    <small class="help">Contoh: elektronik 4–5 tahun, furnitur 8 tahun, alat kebersihan 1 tahun.</small></div>
                <div class="form-group mb-0"><label for="nilai_residu_persen">Nilai sisa (%)</label>
                    <input class="form-control" type="number" id="nilai_residu_persen" name="nilai_residu_persen" min="0" max="90" value="<?= e($v('nilai_residu_persen', 0)) ?>">
                    <small class="help">Persentase harga yang tidak disusutkan.</small></div>
            </div>
            <?php if (!$b): ?>
            <div class="form-group mt-3 mb-0"><label for="stok_awal">Jumlah awal (unit)</label>
                <input class="form-control" type="number" id="stok_awal" name="stok_awal" min="0" max="1000000" value="<?= e(old('stok_awal', 0)) ?>">
                <small class="help">Dicatat sebagai barang masuk "Saldo awal".</small></div>
            <?php endif; ?>
        </div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-save mr-1"></i> Simpan</button></div>
        </div>
    </form>
    <?php
    $GLOBALS['page_js'] = '
    (function(){
      function sesuaiJenis(){
        var aset = $("input[name=jenis_barang]:checked").val() === "aset";
        $(".fld-aset").toggle(aset);
        $("#masa_manfaat_tahun").prop("required", aset);
        $("#tanggal_perolehan").prop("required", aset);
      }
      $("input[name=jenis_barang]").on("change", sesuaiJenis); sesuaiJenis();
    })();';
}

function barang_render_detail(int $id): void
{
    $con = db();
    $b = barang_detail($con, $id);
    if (!$b) { echo ui_kosong('fa-search', 'Barang tidak ditemukan'); return; }
    $s = saldo_barang($con, $id);
    $habis = $b['jenis_barang'] === 'habis_pakai';
    $mutasi = array_reverse(array_slice(mutasi_berjalan($con, $id)['rows'], -15));
    $aktifPinjam = db_all($con, "SELECT * FROM peminjaman WHERE barang_id = ? AND status = 'Dipinjam' ORDER BY tanggal_rencana_kembali ASC", 'i', [$id]);
    $aktifRusak = db_all($con, "SELECT * FROM kerusakan WHERE barang_id = ? AND status NOT IN ('Selesai','Rusak Permanen') ORDER BY tanggal_lapor DESC", 'i', [$id]);

    $aksiHtml = '<a class="btn btn-light btn-sm" href="' . e(url('barang')) . '"><i class="fas fa-arrow-left mr-1"></i> Daftar</a>';
    if (can('barang.kelola')) $aksiHtml .= '<a class="btn btn-light btn-sm" href="' . e(url('barang', ['aksi' => 'edit', 'id' => $id])) . '"><i class="fas fa-pen mr-1"></i> Ubah</a>';
    $aksiHtml .= '<a class="btn btn-light btn-sm" href="' . e(url('laporan', ['jenis' => 'kartu', 'barang_id' => $id])) . '"><i class="fas fa-book mr-1"></i> Kartu Persediaan</a>';
    $aksiHtml .= '<a class="btn btn-light btn-sm" target="_blank" href="' . e(base_url() . 'print/cetak.php?jenis=kib&id=' . $id) . '"><i class="fas fa-id-card mr-1"></i> KIB</a>';
    $aksiHtml .= '<a class="btn btn-primary btn-sm" target="_blank" href="' . e(base_url() . 'print/cetak.php?jenis=label&barang_id=' . $id) . '"><i class="fas fa-print mr-1"></i> Cetak Label</a>';
    echo ui_head($b['nama_barang'], $b['kode_barang'] . ' · ' . $b['kategori'] . ' · ' . JENIS_BARANG[$b['jenis_barang']], $aksiHtml);

    $pen = $habis ? null : penyusutan_batch($con, $b);
    $est = $habis ? (estimasi_pemakaian_semua($con)[$id] ?? null) : null;
    $e = $habis ? estimasi_sisa_pakai($est, $s['tersedia']) : null;
    ?>
    <div class="row">
        <div class="col-lg-4 mb-4"><div class="card h-100"><div class="card-body">
            <div class="text-center mb-3">
                <div id="qrBox" class="d-inline-block p-2" style="background:#fff;border-radius:14px;border:1px solid var(--border)"></div>
                <div class="small text-muted mt-2">Pindai untuk membuka detail barang</div>
            </div>
            <dl class="kv">
                <dt>Kode</dt><dd><span class="code-chip"><?= e($b['kode_barang']) ?></span></dd>
                <dt>Jenis</dt><dd><?= $habis ? badge('Habis pakai', 'info') : badge('Aset tetap', 'primary') ?></dd>
                <dt>Kategori</dt><dd><?= e($b['kategori']) ?></dd>
                <dt>Merek</dt><dd><?= e($b['merek'] ?? '-') ?></dd>
                <dt>Lokasi</dt><dd><?= e($b['lokasi'] ?? 'Belum ditentukan') ?><?= $b['penanggung_jawab'] ? '<br><small class="text-muted">PJ: ' . e($b['penanggung_jawab']) . '</small>' : '' ?></dd>
                <dt>Perolehan</dt><dd><?= $b['tanggal_perolehan'] ? tgl_indo($b['tanggal_perolehan'], true) : '-' ?> · <?= e($b['sumber_dana']) ?></dd>
                <?php if (can('nilai.lihat')): ?><dt>Harga/unit</dt><dd><?= rupiah($b['harga_perolehan']) ?></dd><?php endif; ?>
                <dt>Keterangan</dt><dd><?= nl2br(e($b['keterangan'] ?: '-')) ?></dd>
            </dl>
        </div></div></div>

        <div class="col-lg-8 mb-4">
            <div class="row">
                <div class="col-6 col-md-3 mb-3"><?= ui_kpi('blue', 'fa-cubes', 'Total', angka($s['total']), e($b['satuan'])) ?></div>
                <div class="col-6 col-md-3 mb-3"><?= ui_kpi('teal', 'fa-check-circle', 'Tersedia', angka($s['tersedia']), ui_badge_stok($s['tersedia'], (int)$b['stok_minimum'], (int)$b['aktif'])) ?></div>
                <div class="col-6 col-md-3 mb-3"><?= $habis
                    ? ui_kpi('violet', 'fa-hourglass-half', 'Perkiraan Habis', $e && $e['ok'] ? '±' . angka($e['sisa_hari']) . ' hari' : '-', $e && $e['ok'] ? 'Sekitar ' . tgl_indo($e['tgl_habis']) : 'Belum ada pemakaian')
                    : ui_kpi('violet', 'fa-hand-holding', 'Dipinjam', angka($s['dipinjam']), count($aktifPinjam) . ' peminjaman') ?></div>
                <div class="col-6 col-md-3 mb-3"><?= $habis
                    ? ui_kpi('amber', 'fa-shopping-basket', 'Saran Pesan', angka($e['saran_pesan'] ?? 0), 'cukup untuk 60 hari')
                    : ui_kpi('rose', 'fa-tools', 'Rusak', angka($s['rusak']), count($aktifRusak) . ' laporan aktif') ?></div>
            </div>

            <div class="card mb-4"><div class="card-header">Jumlah per ruangan
                <?php if (can('transaksi.input')): ?><a class="small" href="<?= e(url('pindah', ['aksi' => 'pindah'])) ?>">Pindahkan unit →</a><?php endif; ?></div>
                <div class="table-responsive"><table class="table table-sm mb-0">
                    <thead><tr><th>Ruangan</th><th>PJ</th><th class="text-right">Jumlah</th><th class="text-right">Dipinjam</th><th class="text-right">Rusak</th><th class="text-right">Tersedia</th></tr></thead>
                    <tbody>
                    <?php foreach (barang_per_lokasi($con, $id) as $lk): $tsd = (int)$lk['stok'] - (int)$lk['dipinjam'] - (int)$lk['rusak']; ?>
                        <tr><td><?= e($lk['nama']) ?></td><td class="small text-muted"><?= e($lk['penanggung_jawab'] ?? '-') ?></td>
                            <td class="text-right"><?= angka($lk['stok']) ?></td><td class="text-right"><?= angka($lk['dipinjam']) ?></td>
                            <td class="text-right"><?= angka($lk['rusak']) ?></td><td class="text-right font-weight-bold"><?= angka($tsd) ?></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            </div>
            <?php if (!$habis && !empty($pen['batches'])): ?>
            <div class="card mb-4"><div class="card-header">Batch pembelian <span class="small-caps">penyusutan FIFO</span></div>
                <div class="table-responsive"><table class="table table-sm mb-0">
                    <thead><tr><th>Tanggal</th><th class="text-right">Unit tersisa</th><th class="text-right">Harga/unit</th><th class="text-right">Akumulasi/unit</th><th class="text-right">Nilai buku/unit</th><th>Habis</th></tr></thead>
                    <tbody>
                    <?php foreach ($pen['batches'] as $bt): ?>
                        <tr><td><?= tgl_indo($bt['tgl']) ?></td><td class="text-right"><?= angka($bt['units']) ?></td><td class="text-right"><?= rupiah($bt['harga']) ?></td>
                            <td class="text-right"><?= rupiah($bt['akum_unit']) ?></td><td class="text-right"><?= rupiah($bt['nilai_buku_unit']) ?></td><td><?= tgl_indo($bt['tgl_habis']) ?></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            </div>
            <?php endif; ?>
            <?php if ($habis): ?>
            <div class="card mb-4"><div class="card-header">Pemakaian & perkiraan jumlah</div><div class="card-body">
                <?php if (!$e || !$e['ok']): ?>
                    <?= ui_kosong('fa-tint', 'Belum ada pemakaian tercatat', 'Catat pemakaian di menu Pemakaian & Keluar agar perkiraan sisa hari bisa dihitung.') ?>
                <?php else: ?>
                <dl class="kv">
                    <dt>Rata-rata pemakaian</dt><dd><?= angka_rate($e['rata']) ?> <?= e($b['satuan']) ?> per hari <span class="text-muted small">(90 hari terakhir)</span></dd>
                    <dt>Sisa perkiraan</dt><dd><strong>±<?= angka($e['sisa_hari']) ?> hari</strong>, kira-kira habis pada <?= tgl_indo($e['tgl_habis'], true) ?></dd>
                    <dt>Rekomendasi</dt><dd><?= $e['status'] === 'darurat' ? badge('Segera pesan', 'danger') : ($e['status'] === 'segera' ? badge('Rencanakan pemesanan', 'warning') : badge('Jumlah aman', 'success')) ?>
                        Saran pesan <?= angka($e['saran_pesan']) ?> <?= e($b['satuan']) ?></dd>
                </dl>
                <?php endif; ?>
            </div></div>
            <?php elseif (can('nilai.lihat')): ?>
            <div class="card mb-4"><div class="card-header">Penyusutan (garis lurus) <span class="small-caps"><?= (int)$b['masa_manfaat_tahun'] ?> tahun</span></div><div class="card-body">
                <?php if (!$pen['ok']): ?>
                    <?= ui_kosong('fa-calculator', 'Penyusutan belum bisa dihitung', 'Lengkapi harga perolehan, tanggal perolehan, dan masa manfaat.') ?>
                <?php else: ?>
                <div class="d-flex justify-content-between small mb-1"><span>Umur pakai</span><span><?= number_format($pen['persen_pakai'], 0) ?>%</span></div>
                <div class="progress mb-3"><div class="progress-bar" style="width:<?= number_format($pen['persen_pakai'], 2, '.', '') ?>%"></div></div>
                <div class="table-responsive"><table class="table table-sm mb-3">
                    <thead><tr><th></th><th class="text-right">Per unit</th><th class="text-right">Total (<?= angka($b['stok_total']) ?> unit)</th></tr></thead>
                    <tbody>
                        <tr><td>Nilai perolehan</td><td class="text-right"><?= rupiah($b['harga_perolehan']) ?></td><td class="text-right"><?= rupiah($pen['perolehan_total']) ?></td></tr>
                        <tr><td>Penyusutan per tahun</td><td class="text-right"><?= rupiah($pen['per_tahun_unit']) ?></td><td class="text-right"><?= rupiah($pen['per_tahun_total']) ?></td></tr>
                        <tr><td>Akumulasi penyusutan</td><td class="text-right"><?= rupiah($pen['akum_unit']) ?></td><td class="text-right"><?= rupiah($pen['akum_total']) ?></td></tr>
                        <tr class="font-weight-bold"><td>Nilai buku</td><td class="text-right"><?= rupiah($pen['nilai_buku_unit']) ?></td><td class="text-right"><?= rupiah($pen['nilai_buku_total']) ?></td></tr>
                    </tbody>
                </table></div>
                <p class="small mb-0">Sisa masa manfaat: <strong><?= e(label_sisa_bulan($pen['sisa_bulan'])) ?></strong>, habis sekitar <?= tgl_indo($pen['tgl_habis'], true) ?>.
                    <?= $pen['status'] === 'habis' ? badge('Sudah habis masa manfaat', 'danger') : ($pen['status'] === 'segera' ? badge('Segera habis', 'warning') : '') ?></p>
                <?php endif; ?>
            </div></div>
            <?php endif; ?>

            <?php if ($aktifPinjam): ?>
            <div class="card mb-4"><div class="card-header">Sedang dipinjam</div><div class="table-responsive"><table class="table table-sm mb-0">
                <thead><tr><th>Peminjam</th><th>Unit</th><th class="text-right">Jml</th><th>Rencana kembali</th></tr></thead><tbody>
                <?php foreach ($aktifPinjam as $p): ?>
                <tr><td><?= e($p['peminjam']) ?></td><td><?= e($p['unit']) ?></td><td class="text-right"><?= (int)$p['jumlah'] ?></td>
                    <td><?= tgl_indo($p['tanggal_rencana_kembali']) ?> <?= $p['tanggal_rencana_kembali'] < date('Y-m-d') ? badge('Terlambat', 'danger') : '' ?></td></tr>
                <?php endforeach; ?>
                </tbody></table></div></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">Riwayat terakhir <a class="small" href="<?= e(url('laporan', ['jenis' => 'kartu', 'barang_id' => $id])) ?>">Kartu persediaan lengkap →</a></div>
                <div class="table-responsive"><table class="table table-sm table-hover mb-0">
                    <thead><tr><th>Waktu</th><th>Jenis</th><th>Referensi</th><th class="text-right">Jml</th><th class="text-right">+/−</th><th class="text-right">Saldo tersedia</th></tr></thead>
                    <tbody>
                    <?php if (!$mutasi): ?><tr><td colspan="6"><?= ui_kosong('fa-stream', 'Belum ada riwayat') ?></td></tr><?php endif; ?>
                    <?php foreach ($mutasi as $m): ?>
                        <tr>
                            <td class="text-nowrap"><?= waktu_indo($m['tanggal']) ?></td>
                            <td><?= e(LABEL_MUTASI[$m['jenis']] ?? $m['jenis']) ?></td>
                            <td><span class="mono"><?= e($m['referensi']) ?></span></td>
                            <td class="text-right"><?= angka($m['jumlah']) ?></td>
                            <td class="text-right <?= $m['perubahan_total'] > 0 ? 'text-success' : ($m['perubahan_total'] < 0 ? 'text-danger' : 'text-muted') ?>"><?= fmt_sel((int)$m['perubahan_total'], 'ttl') ?></td>
                            <td class="text-right font-weight-bold"><?= angka($m['saldo_tersedia']) ?> <span class="text-muted small">/ <?= angka($m['saldo_total']) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            </div>
        </div>
    </div>
    <?php
    $GLOBALS['page_js_vendor'] = [base_url() . 'assets/vendor/qrcode/qrcode.js'];
    $urlDetail = url_absolut('?' . http_build_query(['m' => 'barang', 'aksi' => 'detail', 'id' => $id]));
    $GLOBALS['page_js'] = '(function(){ var qr = qrcode(0, "M"); qr.addData(' . ui_js($urlDetail) . '); qr.make();
      document.getElementById("qrBox").innerHTML = qr.createImgTag(4, 6); })();';
}

function barang_post(array $r): void
{
    $con = db();
    $aksi = post_str('aksi', 20);

    if ($aksi === 'simpan') {
        require_perm('barang.kelola');
        $id = post_int('id');
        $d = barang_validasi($_POST, $id === 0);
        if ($id === 0) {
            $baru = barang_buat($con, $d);
            flash('success', 'Barang tersimpan. Kode dan perkiraan sudah dihitung otomatis.');
            redirect(url('barang', ['aksi' => 'detail', 'id' => $baru]));
        }
        $ada = db_row($con, "SELECT kode_barang, jenis_barang FROM barang WHERE id = ?", 'i', [$id]);
        if (!$ada) throw new AppException('Barang tidak ditemukan.');
        if ($ada['jenis_barang'] !== $d['jenis']) {
            $aktifLain = (int)db_value($con,
                "SELECT (SELECT COUNT(*) FROM peminjaman WHERE barang_id = ? AND status = 'Dipinjam') + (SELECT COUNT(*) FROM kerusakan WHERE barang_id = ? AND status NOT IN ('Selesai','Rusak Permanen'))",
                'ii', [$id, $id]);
            if ($aktifLain > 0) throw new AppException('Jenis tidak dapat diubah selama masih ada peminjaman atau laporan kerusakan yang berjalan.');
        }
        $tipeUpd = 'ss' . 'iii' . 's' . 'i' . 'd' . 's' . 'i' . 's' . 's' . 's' . 'i' . 'd' . 'i';
        db_exec($con,
            "UPDATE barang SET nama_barang = ?, kode_bmn = ?, kategori_id = ?, merek_id = ?, lokasi_id = ?, satuan = ?, stok_minimum = ?,
                               harga_perolehan = ?, sumber_dana = ?, tahun_perolehan = ?, keterangan = ?, jenis_barang = ?,
                               tanggal_perolehan = ?, masa_manfaat_tahun = ?, nilai_residu_persen = ?
             WHERE id = ?",
            $tipeUpd,
            [$d['nama_barang'], $d['kode_bmn'], $d['kategori_id'], $d['merek_id'], $d['lokasi_id'], $d['satuan'], $d['stok_minimum'],
             $d['harga_perolehan'], $d['sumber_dana'], $d['tahun_perolehan'], $d['keterangan'], $d['jenis'],
             $d['tanggal'], $d['masa'], $d['residu'], $id]);
        log_aktivitas('UBAH', 'barang', "Mengubah data barang {$ada['kode_barang']}");
        flash('success', 'Data barang diperbarui.');
        redirect(url('barang', ['aksi' => 'detail', 'id' => $id]));
    }

    if ($aksi === 'arsipkan') {
        require_perm('barang.kelola');
        $id = post_int('id');
        $b = db_row($con, "SELECT kode_barang, aktif FROM barang WHERE id = ?", 'i', [$id]);
        if (!$b) throw new AppException('Barang tidak ditemukan.');
        $baru = $b['aktif'] ? 0 : 1;
        db_exec($con, "UPDATE barang SET aktif = ? WHERE id = ?", 'ii', [$baru, $id]);
        log_aktivitas('UBAH', 'barang', ($baru ? 'Mengaktifkan kembali ' : 'Mengarsipkan ') . $b['kode_barang']);
        flash('success', $baru ? 'Barang diaktifkan kembali.' : 'Barang diarsipkan. Riwayatnya tetap tersimpan.');
        redirect(url('barang'));
    }

    if ($aksi === 'hapus') {
        require_perm('barang.hapus');
        $id = post_int('id');
        $b = db_row($con, "SELECT kode_barang, nama_barang FROM barang WHERE id = ?", 'i', [$id]);
        if (!$b) throw new AppException('Barang tidak ditemukan.');
        if ((int)db_value($con, "SELECT COUNT(*) FROM mutasi WHERE barang_id = ?", 'i', [$id]) > 0) {
            throw new AppException('Barang sudah punya riwayat transaksi, jadi tidak dapat dihapus. Gunakan Arsipkan.');
        }
        db_exec($con, "DELETE FROM barang WHERE id = ?", 'i', [$id]);
        log_aktivitas('HAPUS', 'barang', "Menghapus barang {$b['kode_barang']} — {$b['nama_barang']}");
        flash('success', 'Barang dihapus.');
        redirect(url('barang'));
    }

    if ($aksi === 'import') {
        require_perm('barang.kelola');
        barang_import($con);
        redirect(url('barang'));
    }
    throw new AppException('Aksi tidak dikenali.');
}

function barang_import(mysqli $con): void
{
    $f = $_FILES['berkas'] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK) throw new AppException('Pilih berkas CSV terlebih dahulu.');
    if ($f['size'] > UPLOAD_MAKS_BYTES) throw new AppException('Berkas terlalu besar (maks 2 MB).');

    $isi = preg_replace('/^\xEF\xBB\xBF/', '', (string)file_get_contents($f['tmp_name']));
    $baris = array_values(array_filter(preg_split("/\r\n|\n|\r/", $isi), function ($l) { return trim($l) !== ''; }));
    if (count($baris) < 2) throw new AppException('Berkas kosong atau hanya berisi judul kolom.');
    $delim = substr_count($baris[0], ';') > substr_count($baris[0], ',') ? ';' : ',';
    $judul = array_map(function ($h) { return strtolower(trim($h)); }, str_getcsv($baris[0], $delim));
    if (!in_array('nama_barang', $judul, true) || !in_array('kategori', $judul, true)) {
        throw new AppException('Kolom wajib: nama_barang dan kategori.');
    }
    if (count($baris) - 1 > 500) throw new AppException('Maksimal 500 baris per impor.');

    $peta = function ($tabel) use ($con) {
        $out = [];
        foreach (db_all($con, "SELECT id, nama FROM $tabel") as $x) $out[mb_strtolower($x['nama'])] = (int)$x['id'];
        return $out;
    };
    $mapKat = $peta('kategori'); $mapMerek = $peta('merek'); $mapLokasi = $peta('lokasi');
    foreach (db_all($con, "SELECT id, kode_prefix FROM kategori") as $x) $mapKat[mb_strtolower($x['kode_prefix'])] = (int)$x['id'];

    $ok = 0; $errs = [];
    for ($i = 1; $i < count($baris); $i++) {
        $cols = str_getcsv($baris[$i], $delim);
        $row = [];
        foreach ($judul as $k => $name) $row[$name] = $cols[$k] ?? '';
        try {
            $katId = $mapKat[mb_strtolower(trim($row['kategori'] ?? ''))] ?? null;
            if ($katId === null) throw new AppException('kategori "' . ($row['kategori'] ?? '') . '" tidak ditemukan');
            $mer = trim($row['merek'] ?? '');
            $merekId = $mer !== '' ? ($mapMerek[mb_strtolower($mer)] ?? null) : null;
            if ($mer !== '' && $merekId === null) throw new AppException('merek "' . $mer . '" tidak ditemukan');
            $lok = trim($row['lokasi'] ?? '');
            $lokId = $lok !== '' ? ($mapLokasi[mb_strtolower($lok)] ?? null) : null;
            if ($lok !== '' && $lokId === null) throw new AppException('lokasi "' . $lok . '" tidak ditemukan');
            $jenisTeks = strtolower(trim($row['jenis_barang'] ?? ''));
            $jenis = strpos($jenisTeks, 'habis') !== false ? 'habis_pakai' : 'aset';

            $d = barang_validasi([
                'nama_barang' => $row['nama_barang'] ?? '', 'jenis_barang' => $jenis, 'kategori_id' => $katId,
                'merek_id' => $merekId, 'lokasi_id' => $lokId, 'satuan' => $row['satuan'] ?? 'unit',
                'stok_minimum' => $row['stok_minimum'] ?? 2, 'harga_perolehan' => $row['harga_perolehan'] ?? 0,
                'sumber_dana' => $row['sumber_dana'] ?? 'BOS', 'tanggal_perolehan' => $row['tanggal_perolehan'] ?? '',
                'masa_manfaat_tahun' => $row['masa_manfaat_tahun'] ?? '', 'nilai_residu_persen' => $row['nilai_residu_persen'] ?? 0,
                'stok_awal' => $row['stok_awal'] ?? 0, 'keterangan' => $row['keterangan'] ?? '',
            ], true);
            barang_buat($con, $d);
            $ok++;
        } catch (AppException $ex) {
            $errs[] = 'Baris ' . ($i + 1) . ': ' . $ex->getMessage();
        }
    }
    log_aktivitas('TAMBAH', 'barang', "Impor CSV: {$ok} barang berhasil, " . count($errs) . ' gagal');
    if ($errs) {
        flash('warning', "{$ok} barang diimpor, " . count($errs) . ' baris dilewati. ' . implode('; ', array_slice($errs, 0, 4)) . (count($errs) > 4 ? ' …' : ''));
    } else {
        flash('success', "{$ok} barang berhasil diimpor.");
    }
}
