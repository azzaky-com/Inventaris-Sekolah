<?php
// modules/kerusakan.php — laporan kerusakan & alur perbaikan dengan persetujuan Kepala Sekolah.

const FOTO_MIME = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];


function kerusakan_render(array $r): void
{
    $aksi = get_str('aksi', 20);
    if ($aksi === 'tambah') { kerusakan_render_form(); return; }
    if ($aksi === 'detail') { kerusakan_render_detail(get_int('id')); return; }
    kerusakan_render_list();
}

function kerusakan_render_list(): void
{
    $con = db();
    $status = get_str('status', 40) ?: 'aktif';
    $c = db_row($con,
        "SELECT
           COALESCE(SUM(CASE WHEN status NOT IN ('Selesai','Rusak Permanen') THEN jumlah END),0) AS aktif_qty,
           SUM(status = 'Menunggu Persetujuan') AS menunggu,
           SUM(status = 'Dalam Perbaikan') AS perbaikan,
           SUM(status = 'Selesai') AS selesai,
           SUM(status = 'Rusak Permanen') AS permanen,
           COUNT(*) AS semua,
           COALESCE(SUM(biaya_aktual),0) AS biaya
         FROM kerusakan");

    $where = '1=1'; $tipe = ''; $par = [];
    if ($status === 'aktif') { $where = "x.status NOT IN ('Selesai','Rusak Permanen')"; }
    elseif (in_array($status, STATUS_RUSAK, true)) { $where = 'x.status = ?'; $tipe = 's'; $par = [$status]; }

    $rows = db_all($con,
        "SELECT x.*, b.kode_barang, b.nama_barang, b.satuan FROM kerusakan x JOIN barang b ON b.id = x.barang_id
         WHERE $where ORDER BY FIELD(x.status,'Menunggu Persetujuan','Diperiksa','Dilaporkan','Dalam Perbaikan','Selesai','Rusak Permanen'), x.tanggal_lapor DESC LIMIT 500", $tipe, $par);

    $aksiHtml = can('transaksi.input')
        ? '<a class="btn btn-primary btn-sm" href="' . e(url('kerusakan', ['aksi' => 'tambah'])) . '"><i class="fas fa-plus mr-1"></i> Lapor Kerusakan</a>' : '';
    echo ui_head('Kerusakan & Perbaikan', 'Alur: dilaporkan → diperiksa → disetujui Kepala Sekolah → diperbaiki → selesai.', $aksiHtml);
    ?>
    <div class="row">
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('rose', 'fa-tools', 'Unit Rusak Aktif', angka($c['aktif_qty']), 'Belum selesai diperbaiki') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('amber', 'fa-file-signature', 'Menunggu Persetujuan', angka($c['menunggu']), 'Perlu tindakan kepala sekolah') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('violet', 'fa-wrench', 'Dalam Perbaikan', angka($c['perbaikan']), 'Sedang dikerjakan') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('green', 'fa-receipt', 'Biaya Perbaikan', rupiah($c['biaya']), angka($c['selesai']) . ' selesai diperbaiki') ?></div>
    </div>
    <div class="card">
        <div class="card-body pb-2">
            <?= ui_pills([
                'aktif' => ['Aktif', (int)$c['semua'] - (int)$c['selesai'] - (int)$c['permanen']],
                'Menunggu Persetujuan' => ['Menunggu persetujuan', $c['menunggu']],
                'Dalam Perbaikan' => ['Dalam perbaikan', $c['perbaikan']],
                'Selesai' => ['Selesai', $c['selesai']],
                'Rusak Permanen' => ['Rusak permanen', $c['permanen']],
                'semua' => ['Semua', $c['semua']],
            ], $status, 'status', ['m' => 'kerusakan']) ?>
            <hr class="my-3">
        </div>
        <div class="table-responsive">
            <table class="table table-hover datatable" data-order="1:desc" data-nosort="8">
                <thead><tr><th>No.</th><th>Tgl Lapor</th><th>Barang</th><th class="text-right">Jml</th><th>Pelapor</th><th>Kerusakan</th><th>Status</th><th class="text-right">Biaya</th><th class="text-center">Aksi</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $x): ?>
                <tr>
                    <td><span class="mono"><?= rusak_kode((int)$x['id']) ?></span></td>
                    <td class="text-nowrap" data-order="<?= e($x['tanggal_lapor']) ?>"><?= tgl_indo($x['tanggal_lapor']) ?></td>
                    <td><strong><?= e($x['nama_barang']) ?></strong><span class="sub"><?= e($x['kode_barang']) ?></span></td>
                    <td class="text-right"><?= angka($x['jumlah']) ?></td>
                    <td><?= e($x['pelapor']) ?></td>
                    <td><?= e(potong($x['deskripsi'], 60)) ?></td>
                    <td><?= badge_status($x['status']) ?></td>
                    <td class="text-right"><?= $x['biaya_aktual'] !== null ? rupiah($x['biaya_aktual']) : ($x['estimasi_biaya'] !== null ? '<span class="text-muted small">est. ' . rupiah($x['estimasi_biaya']) . '</span>' : '-') ?></td>
                    <td class="text-center"><?= ui_btn_link(url('kerusakan', ['aksi' => 'detail', 'id' => $x['id']]), 'fa-eye', 'light', 'Detail & tindakan') ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

function kerusakan_render_form(): void
{
    require_perm('transaksi.input');
    $con = db();
    $barang = daftar_barang_saldo($con);
    echo ui_head('Lapor Kerusakan', 'Unit yang dilaporkan rusak tidak dihitung sebagai unit tersedia sampai perbaikan selesai.',
        '<a class="btn btn-light btn-sm" href="' . e(url('kerusakan')) . '"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('kerusakan', ['aksi' => 'tambah'])) ?>" enctype="multipart/form-data" novalidate>
        <?= csrf_field() ?><input type="hidden" name="aksi" value="simpan">
        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <div class="form-group"><label for="barang_id">Barang <span class="req">*</span></label>
                <select class="custom-select select2" id="barang_id" name="barang_id" required data-placeholder="Cari aset…"><?= opsi_barang($barang, (int)old('barang_id'), false, 'aset') ?></select></div>
            <div class="form-group"><label for="lokasi_id">Ruangan tempat barang berada <span class="req">*</span></label>
                <select class="custom-select" id="lokasi_id" name="lokasi_id" required><option value="">-- Pilih aset dulu --</option></select>
                <small class="help" id="hintLokasi"></small></div>
            <div class="form-row">
                <div class="form-group col-md-4"><label for="jumlah">Jumlah Rusak <span class="req">*</span></label>
                    <input class="form-control" type="number" id="jumlah" name="jumlah" min="1" required value="<?= e(old('jumlah', 1)) ?>"></div>
                <div class="form-group col-md-4"><label for="tanggal_lapor">Tanggal Laporan <span class="req">*</span></label>
                    <input class="form-control" type="date" id="tanggal_lapor" name="tanggal_lapor" required max="<?= date('Y-m-d') ?>" value="<?= e(old('tanggal_lapor', date('Y-m-d'))) ?>"></div>
                <div class="form-group col-md-4"><label for="pelapor">Pelapor <span class="req">*</span></label>
                    <input class="form-control" id="pelapor" name="pelapor" maxlength="100" required value="<?= e(old('pelapor', user_nama())) ?>"></div>
            </div>
            <div class="form-group"><label for="deskripsi">Deskripsi Kerusakan <span class="req">*</span></label>
                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" maxlength="1000" required placeholder="Gejala, kapan terjadi, dan dugaan penyebab"><?= e(old('deskripsi')) ?></textarea></div>
            <div class="form-group mb-0"><label for="foto">Foto (opsional)</label>
                <input class="form-control-file" type="file" id="foto" name="foto" accept="image/jpeg,image/png,image/webp">
                <small class="help">JPG, PNG, atau WEBP, maksimal 2 MB.</small></div>
        </div></div></div>
        <div class="col-lg-4"><button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-paper-plane mr-1"></i> Kirim Laporan</button></div>
        </div>
    </form>
    <?php
}

function kerusakan_render_detail(int $id): void
{
    $con = db();
    $x = db_row($con,
        "SELECT x.*, b.kode_barang, b.nama_barang, b.satuan, b.id AS bid, l.nama AS lokasi
         FROM kerusakan x JOIN barang b ON b.id = x.barang_id LEFT JOIN lokasi l ON l.id = b.lokasi_id WHERE x.id = ?", 'i', [$id]);
    if (!$x) { echo ui_kosong('fa-search', 'Laporan tidak ditemukan'); return; }
    $riwayat = db_all($con, "SELECT * FROM kerusakan_riwayat WHERE kerusakan_id = ? ORDER BY id ASC", 'i', [$id]);

    echo ui_head(rusak_kode($id) . ' — ' . $x['nama_barang'], 'Status: ' . $x['status'],
        '<a class="btn btn-light btn-sm" href="' . e(url('kerusakan')) . '"><i class="fas fa-arrow-left mr-1"></i> Daftar</a>'
        . '<a class="btn btn-light btn-sm" href="' . e(url('barang', ['aksi' => 'detail', 'id' => $x['bid']])) . '"><i class="fas fa-box-open mr-1"></i> Barang</a>');

    // Tindakan yang tersedia untuk peran ini
    $tindakan = [];
    $perluApproval = false;
    foreach (RUSAK_TRANSISI[$x['status']] ?? [] as $ke) {
        if (rusak_butuh_persetujuan($x['status'], $ke) && !can('kerusakan.setujui')) { $perluApproval = true; continue; }
        if (!can('transaksi.input') && !can('kerusakan.setujui')) continue;
        $tindakan[$ke] = RUSAK_AKSI_LABEL[$ke] ?? $ke;
    }
    ?>
    <div class="row">
        <div class="col-lg-7 mb-4">
            <div class="card mb-4"><div class="card-body">
                <dl class="kv">
                    <dt>Barang</dt><dd><strong><?= e($x['nama_barang']) ?></strong> <span class="code-chip"><?= e($x['kode_barang']) ?></span></dd>
                    <dt>Lokasi</dt><dd><?= e($x['lokasi'] ?: '-') ?></dd>
                    <dt>Jumlah rusak</dt><dd><?= angka($x['jumlah']) ?> <?= e($x['satuan']) ?></dd>
                    <dt>Tanggal lapor</dt><dd><?= tgl_indo($x['tanggal_lapor'], true) ?></dd>
                    <dt>Pelapor</dt><dd><?= e($x['pelapor']) ?></dd>
                    <dt>Deskripsi</dt><dd><?= nl2br(e($x['deskripsi'])) ?></dd>
                    <dt>Teknisi</dt><dd><?= e($x['teknisi'] ?: '-') ?></dd>
                    <dt>Estimasi biaya</dt><dd><?= $x['estimasi_biaya'] !== null ? rupiah($x['estimasi_biaya']) : '-' ?></dd>
                    <dt>Biaya aktual</dt><dd><?= $x['biaya_aktual'] !== null ? rupiah($x['biaya_aktual']) : '-' ?></dd>
                    <dt>Tanggal selesai</dt><dd><?= $x['tanggal_selesai'] ? tgl_indo($x['tanggal_selesai'], true) : '-' ?></dd>
                    <?php if ($x['catatan_persetujuan']): ?><dt>Catatan terakhir</dt><dd><?= nl2br(e($x['catatan_persetujuan'])) ?></dd><?php endif; ?>
                </dl>
                <?php if ($x['foto']): ?>
                <div class="mt-3"><img class="foto-thumb" src="<?= e(base_url()) ?>uploads/barang_rusak/<?= e($x['foto']) ?>" alt="Foto kerusakan"></div>
                <?php endif; ?>
            </div></div>
            <div class="card"><div class="card-header">Riwayat Status</div><div class="card-body">
                <ul class="timeline">
                <?php foreach ($riwayat as $h): ?>
                    <li>
                        <div class="tl-title"><?= $h['status_lama'] ? e($h['status_lama']) . ' → ' : '' ?><?= e($h['status_baru']) ?></div>
                        <div class="tl-meta"><?= waktu_indo($h['created_at']) ?> · <?= e($h['user_nama']) ?></div>
                        <?php if ($h['catatan']): ?><div class="small mt-1"><?= e($h['catatan']) ?></div><?php endif; ?>
                    </li>
                <?php endforeach; ?>
                </ul>
            </div></div>
        </div>
        <div class="col-lg-5 mb-4">
            <div class="card"><div class="card-header">Tindak Lanjut</div><div class="card-body">
                <?php if (in_array($x['status'], ['Selesai', 'Rusak Permanen'], true)): ?>
                    <div class="alert alert-soft alert-success mb-0"><i class="fas fa-check-circle mr-1"></i>
                        Laporan ini sudah final (<?= e($x['status']) ?>). <?= $x['status'] === 'Rusak Permanen' ? 'Unit telah dihapus dari aset.' : 'Unit telah kembali tersedia.' ?></div>
                <?php elseif (!$tindakan): ?>
                    <div class="alert alert-soft alert-info mb-0"><i class="fas fa-hourglass-half mr-1"></i>
                        Menunggu tindakan dari Kepala Sekolah atau Administrator.</div>
                <?php else: ?>
                    <form method="post" action="<?= e(url('kerusakan')) ?>" class="needs-validation" novalidate>
                        <?= csrf_field() ?><input type="hidden" name="aksi" value="transisi"><input type="hidden" name="id" value="<?= (int)$id ?>">
                        <div class="form-group"><label for="status_baru">Tindakan <span class="req">*</span></label>
                            <select class="custom-select" id="status_baru" name="status_baru" required>
                                <?= opsi_html($tindakan, '', '-- Pilih tindakan --') ?>
                            </select></div>
                        <div class="fld" data-for="Menunggu Persetujuan">
                            <div class="form-group"><label for="estimasi">Estimasi biaya perbaikan (Rp) <span class="req">*</span></label>
                                <input class="form-control" id="estimasi" name="estimasi_biaya" data-mask="rupiah" inputmode="numeric" placeholder="0"></div>
                        </div>
                        <div class="fld" data-for="Dalam Perbaikan,Selesai">
                            <div class="form-group"><label for="teknisi">Teknisi / Pelaksana</label>
                                <input class="form-control" id="teknisi" name="teknisi" maxlength="100" value="<?= e($x['teknisi'] ?? '') ?>"></div>
                        </div>
                        <div class="fld" data-for="Selesai">
                            <div class="form-row">
                                <div class="form-group col-6"><label for="biaya_aktual">Biaya aktual (Rp)</label>
                                    <input class="form-control" id="biaya_aktual" name="biaya_aktual" data-mask="rupiah" inputmode="numeric" placeholder="0"></div>
                                <div class="form-group col-6"><label for="tgl_selesai">Tanggal selesai</label>
                                    <input class="form-control" type="date" id="tgl_selesai" name="tanggal_selesai" value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>"></div>
                            </div>
                        </div>
                        <div class="form-group"><label for="catatan">Catatan</label>
                            <textarea class="form-control" id="catatan" name="catatan" rows="2" maxlength="500" placeholder="Alasan atau keterangan tindakan"></textarea></div>
                        <button class="btn btn-primary btn-block" type="submit"><i class="fas fa-check mr-1"></i> Simpan Tindakan</button>
                    </form>
                    <?php if ($perluApproval): ?>
                        <p class="small text-muted mt-3 mb-0"><i class="fas fa-lock mr-1"></i> Beberapa tindakan (persetujuan perbaikan atau penghapusan) hanya dapat dilakukan oleh Kepala Sekolah atau Administrator.</p>
                    <?php endif; ?>
                <?php endif; ?>
            </div></div>
        </div>
    </div>
    <?php
    $GLOBALS['page_js'] = '
    (function(){
      function tampil(){
        var v = $("#status_baru").val() || "";
        $(".fld").each(function(){
          var list = String($(this).data("for")).split(",");
          $(this).toggle(list.indexOf(v) !== -1);
        });
      }
      $("#status_baru").on("change", tampil); tampil();
    })();';
}

function kerusakan_post(array $r): void
{
    $con = db();
    $aksi = post_str('aksi', 20);

    if ($aksi === 'simpan') {
        require_perm('transaksi.input');
        $barang = post_int('barang_id');
        if (!$barang) throw new AppException('Pilih barang yang rusak.');
        $jumlah = post_int('jumlah');
        if ($jumlah < 1) throw new AppException('Jumlah rusak minimal 1.');
        $tgl = tanggal_valid($_POST['tanggal_lapor'] ?? '');
        if (!$tgl || $tgl > date('Y-m-d')) throw new AppException('Tanggal laporan tidak valid.');
        $desk = post_str('deskripsi', 1000);
        if (mb_strlen($desk) < 5) throw new AppException('Deskripsi kerusakan wajib diisi.');

        $fotoNama = null; $fotoPath = null;
        $f = $_FILES['foto'] ?? null;
        if ($f && $f['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($f['error'] !== UPLOAD_ERR_OK) throw new AppException('Foto gagal diunggah.');
            if ($f['size'] > UPLOAD_MAKS_BYTES) throw new AppException('Ukuran foto maksimal 2 MB.');
            $info = @getimagesize($f['tmp_name']);
            if (!$info || !isset(FOTO_MIME[$info['mime']])) throw new AppException('Format foto harus JPG, PNG, atau WEBP.');
            $dir = __DIR__ . '/../uploads/barang_rusak/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $fotoNama = bin2hex(random_bytes(8)) . '.' . FOTO_MIME[$info['mime']];
            $fotoPath = $dir . $fotoNama;
            if (!move_uploaded_file($f['tmp_name'], $fotoPath)) throw new AppException('Foto tidak dapat disimpan.');
        }
        try {
            kerusakan_lapor($con, [
                'barang_id' => $barang, 'lokasi_id' => post_int('lokasi_id') ?: null, 'jumlah' => $jumlah, 'tanggal_lapor' => $tgl,
                'pelapor' => post_str('pelapor', 100) ?: user_nama(), 'deskripsi' => $desk, 'foto' => $fotoNama,
            ]);
        } catch (Throwable $ex) {
            if ($fotoPath && file_exists($fotoPath)) unlink($fotoPath);
            throw $ex;
        }
        flash('success', 'Laporan kerusakan tersimpan. Unit tersedia telah disesuaikan.');
        redirect(url('kerusakan'));
    }

    if ($aksi === 'transisi') {
        $id = post_int('id');
        $ke = post_str('status_baru', 40);
        $estimasi = angka_bersih($_POST['estimasi_biaya'] ?? '');
        $aktual = angka_bersih($_POST['biaya_aktual'] ?? '');
        $tglSelesai = tanggal_valid($_POST['tanggal_selesai'] ?? '');
        kerusakan_transisi($con, $id, $ke, [
            'teknisi' => post_str('teknisi', 100),
            'estimasi_biaya' => $estimasi ?: null,
            'biaya_aktual' => $aktual ?: null,
            'tanggal_selesai' => $tglSelesai,
            'catatan' => post_str('catatan', 500),
        ]);
        flash('success', 'Status laporan diperbarui menjadi "' . $ke . '".');
        redirect(url('kerusakan', ['aksi' => 'detail', 'id' => $id]));
    }

    throw new AppException('Aksi tidak dikenali.');
}
