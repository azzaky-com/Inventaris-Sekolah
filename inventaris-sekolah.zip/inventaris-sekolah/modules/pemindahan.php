<?php
// modules/pemindahan.php — pindah unit antar ruangan. Total unit tidak berubah; riwayat tercatat di kartu persediaan.

function pemindahan_render(array $r): void
{
    $con = db();
    if (get_str('aksi', 20) === 'pindah') { pemindahan_render_form(); return; }
    $rows = db_all($con,
        "SELECT p.*, b.kode_barang, b.nama_barang, la.nama AS asal, lt.nama AS tujuan
         FROM pemindahan p JOIN barang b ON b.id = p.barang_id
         JOIN lokasi la ON la.id = p.lokasi_asal_id JOIN lokasi lt ON lt.id = p.lokasi_tujuan_id
         ORDER BY p.tanggal DESC, p.id DESC LIMIT 300");
    echo ui_head('Pindah Ruangan', 'Pindahkan unit dari satu ruangan ke ruangan lain. Unit yang sedang dipinjam atau rusak tidak bisa dipindahkan.',
        can('transaksi.input') ? '<a class="btn btn-primary btn-sm" href="' . e(url('pindah', ['aksi' => 'pindah'])) . '"><i class="fas fa-exchange-alt mr-1"></i> Pindahkan Unit</a>' : '');
    ?>
    <div class="card"><div class="table-responsive">
        <table class="table table-hover datatable" data-order="0:desc">
            <thead><tr><th>Tanggal</th><th>Barang</th><th class="text-right">Jumlah</th><th>Dari</th><th>Ke</th><th>Keterangan</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $p): ?>
                <tr data-order="<?= e($p['tanggal']) ?>">
                    <td class="text-nowrap"><?= tgl_indo($p['tanggal']) ?></td>
                    <td><strong><?= e($p['nama_barang']) ?></strong><span class="sub mono"><?= e($p['kode_barang']) ?></span></td>
                    <td class="text-right"><?= angka($p['jumlah']) ?></td>
                    <td><?= e($p['asal']) ?></td>
                    <td><?= e($p['tujuan']) ?></td>
                    <td><?= e($p['keterangan'] ?: '-') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div></div>
    <?php
}

function pemindahan_render_form(): void
{
    require_perm('transaksi.input');
    $con = db();
    $barang = daftar_barang_saldo($con);
    echo ui_head('Pindahkan Unit', 'Pilih barang, lalu ruangan asal. Hanya unit yang tersedia di ruangan asal yang bisa dipindahkan.',
        '<a class="btn btn-light btn-sm" href="' . e(url('pindah')) . '"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('pindah', ['aksi' => 'pindah'])) ?>" novalidate>
        <?= csrf_field() ?><input type="hidden" name="aksi" value="simpan">
        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <div class="form-group"><label for="barang_id">Barang <span class="req">*</span></label>
                <select class="custom-select select2" id="barang_id" name="barang_id" required data-placeholder="Cari barang…"><?= opsi_barang($barang, (int)old('barang_id'), false) ?></select></div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="lokasi_asal_id">Dari ruangan <span class="req">*</span></label>
                    <select class="custom-select" id="lokasi_asal_id" name="lokasi_asal_id" required><option value="">-- Pilih barang dulu --</option></select>
                    <small class="help" id="hintLokasi"></small></div>
                <div class="form-group col-md-6"><label for="lokasi_tujuan_id">Ke ruangan <span class="req">*</span></label>
                    <select class="custom-select" id="lokasi_tujuan_id" name="lokasi_tujuan_id" required><?= ui_opsi_tabel('lokasi', 'nama', (string)old('lokasi_tujuan_id'), '-- Pilih ruangan tujuan --') ?></select></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-4"><label for="jumlah">Jumlah unit <span class="req">*</span></label>
                    <input class="form-control" type="number" id="jumlah" name="jumlah" min="1" required value="<?= e(old('jumlah', 1)) ?>"></div>
                <div class="form-group col-md-4"><label for="tanggal">Tanggal <span class="req">*</span></label>
                    <input class="form-control" type="date" id="tanggal" name="tanggal" required max="<?= date('Y-m-d') ?>" value="<?= e(old('tanggal', date('Y-m-d'))) ?>"></div>
                <div class="form-group col-md-4"><label for="keterangan">Keterangan</label>
                    <input class="form-control" id="keterangan" name="keterangan" maxlength="255" value="<?= e(old('keterangan')) ?>"></div>
            </div>
        </div></div></div>
        <div class="col-lg-4"><div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold">Catatan</h6>
            <p class="small text-muted mb-0">Pemindahan tidak mengubah total unit, hanya posisi ruangan. Kartu persediaan mencatat setiap pemindahan.</p>
        </div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-save mr-1"></i> Simpan Pemindahan</button></div>
        </div>
    </form>
    <?php
    $GLOBALS['page_js'] = '$("#barang_id").on("change", function(){ isiLokasi(this.value, "#lokasi_asal_id", "#hintLokasi"); }); if ($("#barang_id").val()) $("#barang_id").trigger("change");';
}

function pemindahan_post(array $r): void
{
    require_perm('transaksi.input');
    $con = db();
    if (post_str('aksi', 20) !== 'simpan') throw new AppException('Aksi tidak dikenali.');
    $tgl = tanggal_valid($_POST['tanggal'] ?? '');
    if (!$tgl || $tgl > date('Y-m-d')) throw new AppException('Tanggal tidak valid.');
    pemindahan_tambah($con, [
        'barang_id' => post_int('barang_id'), 'lokasi_asal_id' => post_int('lokasi_asal_id'),
        'lokasi_tujuan_id' => post_int('lokasi_tujuan_id'), 'jumlah' => post_int('jumlah'),
        'tanggal' => $tgl, 'keterangan' => post_str('keterangan', 255),
    ]);
    flash('success', 'Unit berhasil dipindahkan.');
    redirect(url('pindah'));
}
