<?php
// modules/laporan.php — layar laporan: pratinjau data, lalu cetak (PDF) atau unduh CSV.

function laporan_render(array $r): void
{
    $con = db();
    $jenis = get_str('jenis', 20) ?: 'inventaris';
    if (!isset(JENIS_LAPORAN[$jenis])) $jenis = 'inventaris';
    $f = laporan_filter_request();

    echo ui_head('Laporan & Cetak', 'Pilih jenis laporan, atur filter, lalu cetak atau unduh sebagai CSV.');
    ?>
    <div class="row">
        <div class="col-lg-3 mb-4">
            <div class="card"><div class="card-body p-2">
                <div class="nav flex-column">
                <?php
                $ikon = ['inventaris' => 'fa-boxes', 'masuk' => 'fa-truck-loading', 'keluar' => 'fa-dolly', 'pinjam' => 'fa-hand-holding',
                         'rusak' => 'fa-tools', 'kartu' => 'fa-book', 'mutasi' => 'fa-stream', 'aset' => 'fa-chart-line', 'lokasi' => 'fa-door-open', 'penghapusan' => 'fa-archive'];
                foreach (JENIS_LAPORAN as $k => $label): if ($k === 'aset' && !can('nilai.lihat')) continue; $aktif = $k === $jenis ? ' active' : ''; ?>
                    <a class="nav-link text-body<?= $aktif ?>" style="border-radius:11px;<?= $aktif ? 'background:var(--primary-soft);color:var(--primary)!important' : '' ?>" href="<?= e(url('laporan', ['jenis' => $k])) ?>">
                        <i class="fas <?= $ikon[$k] ?> fa-fw mr-2"></i><?= e($label) ?></a>
                <?php endforeach; ?>
                </div>
            </div></div>
            <div class="card mt-4"><div class="card-body">
                <h6 class="font-weight-bold mb-2">Label Aset (QR)</h6>
                <p class="small text-muted mb-3">Cetak stiker berisi kode QR untuk ditempel pada setiap barang.</p>
                <a class="btn btn-light btn-block btn-sm" target="_blank" href="<?= e(base_url() . 'print/cetak.php?jenis=label&' . http_build_query(['kategori_id' => $f['kategori_id'], 'lokasi_id' => $f['lokasi_id']])) ?>"><i class="fas fa-qrcode mr-1"></i> Cetak Label (sesuai filter)</a>
            </div></div>
            <div class="card mt-4"><div class="card-body">
                <h6 class="font-weight-bold mb-2">Berita Acara Opname</h6>
                <p class="small text-muted mb-0">Cetak dari halaman detail sesi opname yang sudah selesai.</p>
                <a class="small" href="<?= e(url('opname')) ?>">Buka daftar opname →</a>
            </div></div>
        </div>

        <div class="col-lg-9 mb-4">
            <div class="card mb-4"><div class="card-body">
                <form method="get" action="<?= e(base_url()) ?>" class="toolbar">
                    <input type="hidden" name="m" value="laporan"><input type="hidden" name="jenis" value="<?= e($jenis) ?>">
                    <?php if (in_array($jenis, ['masuk', 'keluar', 'pinjam', 'rusak', 'mutasi', 'kartu'], true)): ?>
                    <div><label class="small-caps d-block">Dari</label><input class="form-control" type="date" name="dari" value="<?= e($f['dari'] ?? '') ?>"></div>
                    <div><label class="small-caps d-block">Sampai</label><input class="form-control" type="date" name="sampai" value="<?= e($f['sampai'] ?? '') ?>"></div>
                    <?php endif; ?>
                    <?php if ($jenis === 'inventaris'): ?>
                    <div style="min-width:200px"><label class="small-caps d-block">Kategori</label><select class="custom-select" name="kategori_id"><?= ui_opsi_tabel('kategori', 'nama', (string)$f['kategori_id'], 'Semua kategori') ?></select></div>
                    <div style="min-width:200px"><label class="small-caps d-block">Lokasi</label><select class="custom-select" name="lokasi_id"><?= ui_opsi_tabel('lokasi', 'nama', (string)$f['lokasi_id'], 'Semua lokasi') ?></select></div>
                    <?php endif; ?>
                    <?php if (in_array($jenis, ['kartu', 'pinjam', 'rusak', 'inventaris'], true)): ?>
                    <div style="min-width:240px;flex:1"><label class="small-caps d-block"><?= $jenis === 'kartu' ? 'Barang (wajib)' : 'Barang' ?></label>
                        <select class="custom-select select2" name="barang_id" data-placeholder="Semua barang" data-allow-clear="1"><?= opsi_barang_semua($con, (int)$f['barang_id']) ?></select></div>
                    <?php endif; ?>
                    <?php if ($jenis === 'pinjam'): ?>
                    <div style="min-width:180px"><label class="small-caps d-block">Status</label><select class="custom-select" name="status">
                        <?= opsi_html(['' => 'Semua', 'Dipinjam' => 'Dipinjam', 'Terlambat' => 'Terlambat', 'Dikembalikan' => 'Dikembalikan', 'Hilang' => 'Hilang'], (string)$f['status']) ?></select></div>
                    <?php endif; ?>
                    <?php if ($jenis === 'rusak'): ?>
                    <div style="min-width:220px"><label class="small-caps d-block">Status</label><select class="custom-select" name="status">
                        <?= opsi_html(array_merge(['' => 'Semua'], array_combine(STATUS_RUSAK, STATUS_RUSAK)), (string)$f['status']) ?></select></div>
                    <?php endif; ?>
                    <?php if ($jenis === 'mutasi'): ?>
                    <div style="min-width:200px"><label class="small-caps d-block">Jenis mutasi</label><select class="custom-select" name="jenis_mutasi">
                        <?= opsi_html(array_merge(['' => 'Semua jenis'], LABEL_MUTASI), (string)$f['jenis']) ?></select></div>
                    <?php endif; ?>
                    <button class="btn btn-primary" type="submit" style="margin-top:20px"><i class="fas fa-filter mr-1"></i> Tampilkan</button>
                </form>
            </div></div>

            <?php
            $qs = $_GET; $qs['jenis'] = $jenis; unset($qs['m']);
            $query = http_build_query(array_filter($qs, function ($v) { return $v !== '' && $v !== null; }));
            $pratinjau = null; $error = null;
            try {
                if ($jenis === 'kartu' && !$f['barang_id']) {
                    $error = 'Pilih barang terlebih dahulu untuk melihat kartu persediaan.';
                } else {
                    $pratinjau = laporan_data($jenis, $f);
                }
            } catch (AppException $ex) { $error = $ex->getMessage(); }
            ?>
            <div class="card">
                <div class="card-header">
                    <span><?= e(JENIS_LAPORAN[$jenis]) ?></span>
                    <span class="d-flex gap-2">
                        <a class="btn btn-light btn-sm" href="<?= e(base_url() . 'export.php?' . $query) ?>"><i class="fas fa-file-excel mr-1"></i> CSV</a>
                        <a class="btn btn-primary btn-sm" target="_blank" href="<?= e(base_url() . 'print/cetak.php?' . $query) ?>"><i class="fas fa-print mr-1"></i> Cetak / PDF</a>
                    </span>
                </div>
                <?php if ($error): ?>
                    <div class="card-body"><div class="alert alert-soft alert-warning mb-0"><?= e($error) ?></div></div>
                <?php else: ?>
                    <div class="card-body pb-0">
                        <div class="small text-muted mb-3"><?= e($pratinjau['filter']) ?></div>
                        <div class="d-flex flex-wrap gap-2 mb-3">
                        <?php foreach ($pratinjau['ringkas'] as $lbl => $nilai): ?>
                            <span class="badge-soft badge-primary" style="font-size:12.5px;padding:6px 12px"><?= e($lbl) ?>: <strong><?= e((string)$nilai) ?></strong></span>
                        <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover mb-0">
                            <thead><tr>
                                <?php foreach ($pratinjau['kolom'] as [$label]): ?><th><?= e($label) ?></th><?php endforeach; ?>
                            </tr></thead>
                            <tbody>
                            <?php if (!$pratinjau['rows']): ?>
                                <tr><td colspan="<?= count($pratinjau['kolom']) ?>"><?= ui_kosong('fa-folder-open', 'Tidak ada data', 'Ubah filter untuk melihat data lain.') ?></td></tr>
                            <?php endif; ?>
                            <?php foreach (array_slice($pratinjau['rows'], 0, 300) as $row): ?>
                                <tr>
                                <?php foreach ($pratinjau['kolom'] as [$label, $key, $fmt]):
                                    $cls = in_array($fmt, ['int', 'rupiah', 'ttl'], true) ? ' class="text-right"' : '';
                                    $nilai = fmt_sel($row[$key] ?? null, $fmt);
                                    if ($key === 'kode_barang' || $key === 'kode') $nilai = '<span class="mono">' . e($row[$key]) . '</span>';
                                    else $nilai = e($nilai);
                                ?>
                                    <td<?= $cls ?>><?= $nilai ?></td>
                                <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if (count($pratinjau['rows']) > 300): ?>
                    <div class="card-body small text-muted">Pratinjau menampilkan 300 baris pertama. Unduh CSV atau cetak untuk seluruh data (<?= count($pratinjau['rows']) ?> baris).</div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}

function laporan_post(array $r): void
{
    throw new AppException('Aksi tidak dikenali.');
}
