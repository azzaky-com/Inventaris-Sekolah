<?php
// modules/peminjaman.php — peminjaman aset: pengembalian sebagian, hilang sebagian, pengingat, dan perpanjangan.

/** Nomor WhatsApp dalam format internasional (08… → 628…). Null bila kosong/tidak valid. */
function wa_nomor(?string $kontak): ?string
{
    $n = preg_replace('/\D/', '', (string)$kontak);
    if ($n === '' || strlen($n) < 8) return null;
    if (substr($n, 0, 1) === '0') $n = '62' . substr($n, 1);
    return $n;
}

function pinjam_input(): array
{
    $barang = post_int('barang_id');
    if (!$barang) throw new AppException('Pilih barang yang akan dipinjam.');
    $jumlah = post_int('jumlah');
    if ($jumlah < 1) throw new AppException('Jumlah pinjam minimal 1.');
    $peminjam = post_str('peminjam', 100);
    if (mb_strlen($peminjam) < 3) throw new AppException('Nama peminjam wajib diisi.');
    $tglPinjam = tanggal_valid($_POST['tanggal_pinjam'] ?? '');
    $tglRencana = tanggal_valid($_POST['tanggal_rencana_kembali'] ?? '');
    if (!$tglPinjam || !$tglRencana) throw new AppException('Tanggal pinjam dan rencana kembali wajib diisi dengan benar.');
    if ($tglRencana < $tglPinjam) throw new AppException('Rencana kembali tidak boleh sebelum tanggal pinjam.');
    if ((strtotime($tglRencana) - strtotime($tglPinjam)) / 86400 > 180) throw new AppException('Masa pinjam maksimal 180 hari.');
    $tipe = in_array($_POST['tipe_peminjam'] ?? '', TIPE_PEMINJAM, true) ? $_POST['tipe_peminjam'] : 'Lainnya';
    $kondisi = in_array($_POST['kondisi_pinjam'] ?? '', KONDISI_BARANG, true) ? $_POST['kondisi_pinjam'] : 'Baik';
    return [
        'barang_id' => $barang, 'lokasi_asal_id' => post_int('lokasi_asal_id') ?: null, 'jumlah' => $jumlah,
        'peminjam' => $peminjam, 'kontak' => (string)wa_nomor(post_str('kontak', 20)) ?: '',
        'tipe_peminjam' => $tipe, 'unit' => post_str('unit', 100), 'tanggal_pinjam' => $tglPinjam,
        'tanggal_rencana_kembali' => $tglRencana, 'kondisi_pinjam' => $kondisi, 'keterangan' => post_str('keterangan', 1000),
    ];
}

function peminjaman_render(array $r): void
{
    $con = db();
    if (get_str('aksi', 20) === 'tambah') { peminjaman_render_form(); return; }

    $status = get_str('status', 20) ?: 'aktif';
    $cnt = db_row($con,
        "SELECT SUM(status = 'Dipinjam') AS aktif,
                SUM(status = 'Dipinjam' AND tanggal_rencana_kembali < CURDATE()) AS terlambat,
                SUM(status = 'Dikembalikan') AS kembali, SUM(status = 'Hilang') AS hilang, COUNT(*) AS semua,
                COALESCE(SUM(CASE WHEN status = 'Dipinjam' THEN sisa END), 0) AS unit_dipinjam
         FROM peminjaman");
    $where = '1=1'; $tipe = ''; $par = [];
    if ($status === 'aktif') $where = "p.status = 'Dipinjam'";
    elseif ($status === 'Terlambat') $where = "p.status = 'Dipinjam' AND p.tanggal_rencana_kembali < CURDATE()";
    elseif (in_array($status, ['Dikembalikan', 'Hilang'], true)) { $where = 'p.status = ?'; $tipe = 's'; $par = [$status]; }

    $rows = db_all($con,
        "SELECT p.*, b.kode_barang, b.nama_barang, b.satuan, COALESCE(l.nama, '-') AS lokasi,
                CASE WHEN p.status = 'Dipinjam' AND p.tanggal_rencana_kembali < CURDATE() THEN 'Terlambat' ELSE p.status END AS status_tampil,
                DATEDIFF(CURDATE(), p.tanggal_rencana_kembali) AS telat
         FROM peminjaman p JOIN barang b ON b.id = p.barang_id LEFT JOIN lokasi l ON l.id = p.lokasi_asal_id
         WHERE $where ORDER BY p.status = 'Dipinjam' DESC, p.tanggal_rencana_kembali ASC, p.id DESC LIMIT 500", $tipe, $par);

    echo ui_head('Peminjaman Aset', 'Pantau aset yang sedang dipinjam, tenggat, dan pengembalian. Pengembalian bisa dicatat sebagian.',
        can('transaksi.input') ? '<a class="btn btn-primary btn-sm" href="' . e(url('peminjaman', ['aksi' => 'tambah'])) . '"><i class="fas fa-plus mr-1"></i> Catat Peminjaman</a>' : '');
    ?>
    <div class="row">
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('violet', 'fa-hand-holding', 'Unit sedang dipinjam', angka($cnt['unit_dipinjam']), angka($cnt['aktif']) . ' peminjaman') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('rose', 'fa-clock', 'Terlambat', angka($cnt['terlambat']), 'Perlu ditindaklanjuti') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('green', 'fa-undo', 'Selesai dikembalikan', angka($cnt['kembali']), 'Riwayat') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('amber', 'fa-search', 'Hilang', angka($cnt['hilang']), 'Mengurangi total unit') ?></div>
    </div>
    <div class="card">
        <div class="card-body pb-2">
            <?= ui_pills([
                'aktif' => ['Sedang dipinjam', $cnt['aktif']], 'Terlambat' => ['Terlambat', $cnt['terlambat']],
                'Dikembalikan' => ['Selesai', $cnt['kembali']], 'Hilang' => ['Hilang', $cnt['hilang']], 'semua' => ['Semua', $cnt['semua']],
            ], $status, 'status', ['m' => 'peminjaman']) ?>
            <hr class="my-3">
        </div>
        <div class="table-responsive">
            <table class="table table-hover datatable" data-order="5:asc" data-nosort="8">
                <thead><tr>
                    <th>Aset</th><th class="text-right">Sisa / pinjam</th><th>Peminjam</th><th class="d-none d-md-table-cell">Ruangan asal</th>
                    <th>Rencana kembali</th><th>Status</th><th class="text-center">Tgl kembali</th><th class="text-center">Aksi</th>
                </tr></thead>
                <tbody>
                <?php foreach ($rows as $x): $terlambat = $x['status_tampil'] === 'Terlambat'; $aktif = $x['status'] === 'Dipinjam'; $wa = wa_nomor($x['kontak']); ?>
                <tr>
                    <td><strong><?= e($x['nama_barang']) ?></strong><span class="sub mono"><?= e($x['kode_barang']) ?></span></td>
                    <td class="text-right"><strong><?= angka($x['sisa']) ?></strong> <span class="text-muted">/ <?= angka($x['jumlah']) ?></span>
                        <?php if ((int)$x['dikembalikan'] || (int)$x['hilang']): ?><span class="sub"><?= (int)$x['dikembalikan'] ?> kembali · <?= (int)$x['hilang'] ?> hilang</span><?php endif; ?></td>
                    <td><?= e($x['peminjam']) ?><span class="sub"><?= e($x['tipe_peminjam']) ?><?= $x['unit'] ? ' · ' . e($x['unit']) : '' ?></span></td>
                    <td class="d-none d-md-table-cell"><?= e($x['lokasi']) ?></td>
                    <td class="text-nowrap" data-order="<?= e($x['tanggal_rencana_kembali']) ?>">
                        <?= tgl_indo($x['tanggal_rencana_kembali']) ?>
                        <?php if ($terlambat): ?><span class="sub text-danger font-weight-bold">Terlambat <?= (int)$x['telat'] ?> hari</span><?php endif; ?>
                        <?php if ($x['pengingat_terakhir']): ?><span class="sub">Diingatkan <?= tgl_indo($x['pengingat_terakhir']) ?></span><?php endif; ?>
                    </td>
                    <td><?= badge_status($x['status_tampil'] === 'Terlambat' ? 'Terlambat' : ($x['status'] === 'Dipinjam' ? 'Dipinjam' : $x['status'])) ?></td>
                    <td class="text-center text-nowrap"><?= $x['tanggal_kembali'] ? tgl_indo($x['tanggal_kembali']) : '<span class="text-muted">-</span>' ?></td>
                    <td class="text-center text-nowrap">
                        <?php if ($aktif && can('transaksi.input')): ?>
                            <button class="btn btn-sm btn-success" type="button" data-toggle="modal" data-target="#modalKembali"
                                data-id="<?= (int)$x['id'] ?>" data-barang="<?= e($x['nama_barang']) ?>" data-sisa="<?= (int)$x['sisa'] ?>"
                                data-peminjam="<?= e($x['peminjam']) ?>" data-pinjam="<?= e($x['tanggal_pinjam']) ?>"
                                data-rencana="<?= e($x['tanggal_rencana_kembali']) ?>"><i class="fas fa-undo mr-1"></i> Kembalikan</button>
                            <button class="btn btn-sm btn-icon btn-light" type="button" title="Perpanjang" data-toggle="modal" data-target="#modalPerpanjang"
                                data-id="<?= (int)$x['id'] ?>" data-barang="<?= e($x['nama_barang']) ?>" data-rencana="<?= e($x['tanggal_rencana_kembali']) ?>"><i class="fas fa-calendar-plus"></i></button>
                            <?php if ($wa): $pesan = 'Assalamualaikum ' . $x['peminjam'] . ', mohon pengembalian ' . $x['nama_barang'] . ' (' . (int)$x['sisa'] . ' unit) yang dipinjam sejak ' . tgl_indo($x['tanggal_pinjam']) . '. Batas kembali: ' . tgl_indo($x['tanggal_rencana_kembali']) . '. Terima kasih. — Inventaris Sekolah'; ?>
                                <a class="btn btn-sm btn-icon btn-light text-success" target="_blank" rel="noopener" title="Kirim pengingat via WhatsApp" data-toggle="tooltip"
                                   href="https://wa.me/<?= e($wa) ?>?text=<?= rawurlencode($pesan) ?>" data-wa-ingat="<?= (int)$x['id'] ?>"><i class="fab fa-whatsapp"></i></a>
                            <?php endif; ?>
                            <form method="post" action="<?= e(url('peminjaman')) ?>" class="d-inline">
                                <?= csrf_field() ?><input type="hidden" name="aksi" value="ingatkan"><input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
                                <button class="btn btn-sm btn-icon btn-light" type="submit" title="Catat sudah diingatkan" data-toggle="tooltip"><i class="fas fa-bell"></i></button>
                            </form>
                            <a class="btn btn-sm btn-icon btn-light" target="_blank" title="Cetak surat pengingat" data-toggle="tooltip" href="<?= e(base_url() . 'print/cetak.php?jenis=surat&id=' . (int)$x['id']) ?>"><i class="fas fa-print"></i></a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (can('transaksi.input')): ?>
    <div class="modal fade" id="modalKembali" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document"><div class="modal-content">
            <form method="post" action="<?= e(url('peminjaman')) ?>" class="needs-validation" novalidate>
                <?= csrf_field() ?><input type="hidden" name="aksi" value="kembali"><input type="hidden" name="id" id="kembaliId">
                <div class="modal-header"><h5 class="modal-title">Catat pengembalian</h5><button class="close" type="button" data-dismiss="modal"><span>&times;</span></button></div>
                <div class="modal-body">
                    <p class="mb-3"><strong id="kembaliBarang"></strong><br><small class="text-muted" id="kembaliInfo"></small></p>
                    <div class="form-row">
                        <div class="form-group col-6"><label for="unit_kembali">Dikembalikan (unit)</label>
                            <input class="form-control" type="number" min="0" id="unit_kembali" name="kembali" value="0"><small class="help" id="hintSisa"></small></div>
                        <div class="form-group col-6"><label for="unit_hilang">Hilang (unit)</label>
                            <input class="form-control" type="number" min="0" id="unit_hilang" name="hilang" value="0"></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-6"><label for="tgl_kembali">Tanggal kembali <span class="req">*</span></label>
                            <input class="form-control" type="date" id="tgl_kembali" name="tanggal_kembali" required value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>"></div>
                        <div class="form-group col-6"><label for="kondisi_kembali">Kondisi saat kembali</label>
                            <select class="custom-select" id="kondisi_kembali" name="kondisi_kembali"><?= opsi_html(array_combine(KONDISI_KEMBALI, KONDISI_KEMBALI), 'Baik') ?></select></div>
                    </div>
                    <div class="form-group mb-0"><label for="ket_kembali">Catatan</label>
                        <input class="form-control" id="ket_kembali" name="keterangan" maxlength="255" placeholder="Opsional"></div>
                    <div class="alert alert-soft alert-info small mt-3 mb-0">Sisa yang belum kembali tetap tercatat sebagai pinjaman berjalan. Pinjaman selesai saat seluruh unit sudah kembali atau dinyatakan hilang.</div>
                </div>
                <div class="modal-footer"><button class="btn btn-light" type="button" data-dismiss="modal">Batal</button>
                    <button class="btn btn-success" type="submit"><i class="fas fa-check mr-1"></i> Simpan</button></div>
            </form>
        </div></div>
    </div>
    <div class="modal fade" id="modalPerpanjang" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document"><div class="modal-content">
            <form method="post" action="<?= e(url('peminjaman')) ?>" class="needs-validation" novalidate>
                <?= csrf_field() ?><input type="hidden" name="aksi" value="perpanjang"><input type="hidden" name="id" id="perpId">
                <div class="modal-header"><h5 class="modal-title">Perpanjang pinjaman</h5><button class="close" type="button" data-dismiss="modal"><span>&times;</span></button></div>
                <div class="modal-body">
                    <p class="small text-muted mb-2" id="perpInfo"></p>
                    <div class="form-group mb-0"><label for="tgl_baru">Rencana kembali baru <span class="req">*</span></label>
                        <input class="form-control" type="date" id="tgl_baru" name="tanggal_rencana_baru" required></div>
                </div>
                <div class="modal-footer"><button class="btn btn-light" type="button" data-dismiss="modal">Batal</button>
                    <button class="btn btn-primary" type="submit">Perpanjang</button></div>
            </form>
        </div></div>
    </div>
    <?php endif; ?>
    <?php
    $GLOBALS['page_js'] = '
    $("#modalKembali").on("show.bs.modal", function (ev) {
      var b = $(ev.relatedTarget), sisa = parseInt(b.data("sisa"), 10) || 0;
      $("#kembaliId").val(b.data("id"));
      $("#kembaliBarang").text(b.data("barang") + " — sisa " + sisa + " unit");
      $("#kembaliInfo").text("Dipinjam " + b.data("peminjam") + " sejak " + b.data("pinjam") + " · rencana " + b.data("rencana"));
      $("#unit_kembali").attr("max", sisa).val(sisa);
      $("#unit_hilang").attr("max", sisa).val(0);
      $("#hintSisa").text("Isi sesuai jumlah yang benar-benar kembali. Total kembali + hilang tidak boleh melebihi " + sisa + ".");
    });
    $("#modalPerpanjang").on("show.bs.modal", function (ev) {
      var b = $(ev.relatedTarget);
      $("#perpId").val(b.data("id"));
      $("#perpInfo").text(b.data("barang") + " — rencana kembali saat ini " + b.data("rencana"));
      var d = new Date(b.data("rencana")); d.setDate(d.getDate() + 7);
      $("#tgl_baru").attr("min", b.data("rencana")).val(d.toISOString().slice(0,10));
    });';
}

function peminjaman_render_form(): void
{
    require_perm('transaksi.input');
    $con = db();
    $barang = daftar_barang_saldo($con);
    echo ui_head('Catat Peminjaman', 'Hanya aset yang tersedia di ruangan terpilih yang dapat dipinjam.',
        '<a class="btn btn-light btn-sm" href="' . e(url('peminjaman')) . '"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('peminjaman', ['aksi' => 'tambah'])) ?>" novalidate>
        <?= csrf_field() ?><input type="hidden" name="aksi" value="simpan">
        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <div class="form-group"><label for="barang_id">Aset <span class="req">*</span></label>
                <select class="custom-select select2" id="barang_id" name="barang_id" required data-placeholder="Cari aset…"><?= opsi_barang($barang, (int)old('barang_id'), false, 'aset') ?></select></div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="lokasi_asal_id">Diambil dari ruangan <span class="req">*</span></label>
                    <select class="custom-select" id="lokasi_asal_id" name="lokasi_asal_id" required><option value="">-- Pilih aset dulu --</option></select>
                    <small class="help" id="hintLokasi"></small></div>
                <div class="form-group col-md-3"><label for="jumlah">Jumlah <span class="req">*</span></label>
                    <input class="form-control" type="number" id="jumlah" name="jumlah" min="1" required value="<?= e(old('jumlah', 1)) ?>"></div>
                <div class="form-group col-md-3"><label for="tipe_peminjam">Tipe</label>
                    <select class="custom-select" id="tipe_peminjam" name="tipe_peminjam"><?= opsi_html(array_combine(TIPE_PEMINJAM, TIPE_PEMINJAM), (string)old('tipe_peminjam', 'Guru')) ?></select></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="peminjam">Nama peminjam <span class="req">*</span></label>
                    <input class="form-control" id="peminjam" name="peminjam" maxlength="100" required value="<?= e(old('peminjam')) ?>"></div>
                <div class="form-group col-md-6"><label for="kontak">No. WhatsApp (opsional)</label>
                    <input class="form-control" id="kontak" name="kontak" maxlength="20" inputmode="tel" value="<?= e(old('kontak')) ?>" placeholder="08xxxxxxxxxx"><small class="help">Untuk mengirim pengingat lewat WhatsApp.</small></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="unit">Unit / keperluan</label>
                    <input class="form-control" id="unit" name="unit" maxlength="100" value="<?= e(old('unit')) ?>" placeholder="Contoh: Kelas VIII B — presentasi"></div>
                <div class="form-group col-md-3"><label for="tanggal_pinjam">Tanggal pinjam <span class="req">*</span></label>
                    <input class="form-control" type="date" id="tanggal_pinjam" name="tanggal_pinjam" required value="<?= e(old('tanggal_pinjam', date('Y-m-d'))) ?>"></div>
                <div class="form-group col-md-3"><label for="tanggal_rencana_kembali">Rencana kembali <span class="req">*</span></label>
                    <input class="form-control" type="date" id="tanggal_rencana_kembali" name="tanggal_rencana_kembali" required value="<?= e(old('tanggal_rencana_kembali', date('Y-m-d', strtotime('+7 days')))) ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="kondisi_pinjam">Kondisi saat dipinjam</label>
                    <select class="custom-select" id="kondisi_pinjam" name="kondisi_pinjam"><?= opsi_html(array_combine(KONDISI_BARANG, KONDISI_BARANG), (string)old('kondisi_pinjam', 'Baik')) ?></select></div>
                <div class="form-group col-md-6"><label for="keterangan">Catatan</label>
                    <input class="form-control" id="keterangan" name="keterangan" maxlength="1000" value="<?= e(old('keterangan')) ?>"></div>
            </div>
        </div></div></div>
        <div class="col-lg-4"><div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold">Pengingat</h6>
            <p class="small text-muted mb-0">Pinjaman yang lewat rencana kembali tampil <strong>Terlambat</strong> di beranda. Isi nomor WhatsApp untuk mengirim pengingat dengan satu klik.</p>
        </div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-save mr-1"></i> Simpan Peminjaman</button></div>
        </div>
    </form>
    <?php
    $GLOBALS['page_js'] = '$("#barang_id").on("change", function(){ isiLokasi(this.value, "#lokasi_asal_id", "#hintLokasi"); }); if ($("#barang_id").val()) $("#barang_id").trigger("change");';
}

function peminjaman_post(array $r): void
{
    require_perm('transaksi.input');
    $con = db();
    $aksi = post_str('aksi', 20);
    if ($aksi === 'simpan') {
        peminjaman_tambah($con, pinjam_input());
        flash('success', 'Peminjaman dicatat. Jumlah di ruangan telah diperbarui.');
        redirect(url('peminjaman'));
    }
    if ($aksi === 'kembali') {
        $tgl = tanggal_valid($_POST['tanggal_kembali'] ?? '');
        if (!$tgl) throw new AppException('Tanggal kembali tidak valid.');
        if ($tgl > date('Y-m-d')) throw new AppException('Tanggal kembali tidak boleh melebihi hari ini.');
        $kondisi = in_array($_POST['kondisi_kembali'] ?? '', KONDISI_KEMBALI, true) ? $_POST['kondisi_kembali'] : 'Baik';
        peminjaman_kembali($con, post_int('id'), [
            'kembali' => post_int('kembali'), 'hilang' => post_int('hilang'),
            'tanggal_kembali' => $tgl, 'kondisi_kembali' => $kondisi, 'keterangan' => post_str('keterangan', 255),
        ]);
        flash('success', 'Pengembalian dicatat.');
        redirect(url('peminjaman'));
    }
    if ($aksi === 'perpanjang') {
        $tgl = tanggal_valid($_POST['tanggal_rencana_baru'] ?? '');
        if (!$tgl) throw new AppException('Tanggal perpanjangan tidak valid.');
        peminjaman_perpanjang($con, post_int('id'), $tgl);
        flash('success', 'Masa pinjam diperpanjang.');
        redirect(url('peminjaman'));
    }
    if ($aksi === 'ingatkan') {
        peminjaman_ingatkan($con, post_int('id'));
        flash('success', 'Pengingat dicatat.');
        redirect(url('peminjaman'));
    }
    throw new AppException('Aksi tidak dikenali.');
}
