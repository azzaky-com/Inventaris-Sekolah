<?php
// modules/persetujuan.php — pusat keputusan Kepala Sekolah: barang masuk bernilai besar, usulan penghapusan,
// perbaikan kerusakan, dan finalisasi opname. Operator tidak memiliki halaman ini.

function persetujuan_render(array $r): void
{
    $con = db();
    $masuk = db_all($con,
        "SELECT t.*, b.kode_barang, b.nama_barang, COALESCE(l.nama, '-') AS lokasi
         FROM barang_masuk t JOIN barang b ON b.id = t.barang_id LEFT JOIN lokasi l ON l.id = t.lokasi_id
         WHERE t.status = 'Menunggu' ORDER BY t.tanggal ASC");
    $usul = db_all($con,
        "SELECT p.*, b.kode_barang, b.nama_barang, l.nama AS lokasi FROM penghapusan p
         JOIN barang b ON b.id = p.barang_id JOIN lokasi l ON l.id = p.lokasi_id
         WHERE p.status = 'Diusulkan' ORDER BY p.tanggal_usul ASC");
    $rusak = db_all($con,
        "SELECT x.*, b.kode_barang, b.nama_barang FROM kerusakan x JOIN barang b ON b.id = x.barang_id
         WHERE x.status = 'Menunggu Persetujuan' ORDER BY x.tanggal_lapor ASC");
    $opname = db_all($con,
        "SELECT o.id, o.kode, o.judul, o.tanggal, l.nama AS lokasi,
            (SELECT COUNT(*) FROM stok_opname_item i WHERE i.opname_id = o.id) AS total,
            (SELECT COUNT(*) FROM stok_opname_item i WHERE i.opname_id = o.id AND i.stok_fisik IS NOT NULL) AS terisi
         FROM stok_opname o LEFT JOIN lokasi l ON l.id = o.lokasi_id WHERE o.status = 'Draft' ORDER BY o.tanggal DESC");
    $jumlahAntrean = count($masuk) + count($usul) + count($rusak) + count($opname);

    echo ui_head('Persetujuan', 'Keputusan yang memerlukan Kepala Sekolah. Setiap keputusan tercatat atas nama Anda.', '');
    ?>
    <div class="row">
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi($jumlahAntrean ? 'amber' : 'green', 'fa-tasks', 'Total antrean', angka($jumlahAntrean), $jumlahAntrean ? 'Perlu keputusan' : 'Semua sudah diputuskan') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('blue', 'fa-truck-loading', 'Barang masuk', angka(count($masuk)), 'Nilai di atas ambang') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('rose', 'fa-archive', 'Usulan penghapusan', angka(count($usul)), 'Menunggu berita acara') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('violet', 'fa-tools', 'Perbaikan', angka(count($rusak)), 'Estimasi biaya menunggu') ?></div>
    </div>

    <div class="card mb-4"><div class="card-header">Barang masuk menunggu persetujuan</div>
        <?php if (!$masuk): ?><div class="card-body"><?= ui_kosong('fa-check-double', 'Tidak ada antrean barang masuk') ?></div>
        <?php else: ?><div class="table-responsive"><table class="table table-hover mb-0">
            <thead><tr><th>Tanggal</th><th>Barang</th><th>Ruangan</th><th class="text-right">Jumlah</th><th class="text-right">Nilai</th><th>Dokumen</th><th class="text-center">Keputusan</th></tr></thead>
            <tbody>
            <?php foreach ($masuk as $m): $nilai = (int)$m['jumlah'] * (float)$m['harga_satuan']; ?>
                <tr>
                    <td><?= tgl_indo($m['tanggal']) ?></td>
                    <td><strong><?= e($m['nama_barang']) ?></strong><span class="sub mono"><?= e($m['kode_barang']) ?></span></td>
                    <td><?= e($m['lokasi']) ?></td>
                    <td class="text-right">+<?= angka($m['jumlah']) ?></td>
                    <td class="text-right font-weight-bold"><?= rupiah($nilai) ?></td>
                    <td class="mono small"><?= e($m['nomor_dokumen'] ?: '-') ?><span class="sub"><?= e($m['sumber_dana']) ?></span></td>
                    <td class="text-center text-nowrap">
                        <form method="post" action="<?= e(url('persetujuan')) ?>" class="d-inline">
                            <?= csrf_field() ?><input type="hidden" name="aksi" value="masuk_setujui"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                            <button class="btn btn-sm btn-success" type="submit"><i class="fas fa-check mr-1"></i> Setujui</button></form>
                        <form method="post" action="<?= e(url('persetujuan')) ?>" class="d-inline" data-tolak="1">
                            <?= csrf_field() ?><input type="hidden" name="aksi" value="masuk_tolak"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><input type="hidden" name="alasan" value="">
                            <button class="btn btn-sm btn-light text-danger" type="submit"><i class="fas fa-times mr-1"></i> Tolak</button></form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div><?php endif; ?>
    </div>

    <div class="card mb-4"><div class="card-header">Usulan penghapusan aset</div>
        <?php if (!$usul): ?><div class="card-body"><?= ui_kosong('fa-check-double', 'Tidak ada usulan penghapusan') ?></div>
        <?php else: ?><div class="table-responsive"><table class="table table-hover mb-0">
            <thead><tr><th>Diusulkan</th><th>Aset</th><th>Ruangan</th><th class="text-right">Jumlah</th><th>Alasan</th><th>Keterangan</th><th class="text-center">Keputusan</th></tr></thead>
            <tbody>
            <?php foreach ($usul as $p): ?>
                <tr>
                    <td><?= tgl_indo($p['tanggal_usul']) ?><span class="sub"><?= e($p['diusulkan_oleh']) ?></span></td>
                    <td><strong><?= e($p['nama_barang']) ?></strong><span class="sub mono"><?= e($p['kode_barang']) ?></span></td>
                    <td><?= e($p['lokasi']) ?></td>
                    <td class="text-right"><?= angka($p['jumlah']) ?></td>
                    <td><?= e($p['alasan']) ?></td>
                    <td><?= e(potong($p['keterangan'], 60)) ?></td>
                    <td class="text-center text-nowrap">
                        <form method="post" action="<?= e(url('persetujuan')) ?>" class="d-inline" data-confirm="Menyetujui akan mengurangi jumlah dan menerbitkan berita acara penghapusan. Lanjutkan?">
                            <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus_setujui"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                            <button class="btn btn-sm btn-success" type="submit"><i class="fas fa-check mr-1"></i> Setujui</button></form>
                        <form method="post" action="<?= e(url('persetujuan')) ?>" class="d-inline" data-tolak="1">
                            <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus_tolak"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="alasan" value="">
                            <button class="btn btn-sm btn-light text-danger" type="submit"><i class="fas fa-times mr-1"></i> Tolak</button></form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div><?php endif; ?>
    </div>

    <div class="card mb-4"><div class="card-header">Perbaikan &amp; penghapusan aset rusak</div>
        <?php if (!$rusak): ?><div class="card-body"><?= ui_kosong('fa-check-double', 'Tidak ada perbaikan yang menunggu') ?></div>
        <?php else: ?><div class="table-responsive"><table class="table table-hover mb-0">
            <thead><tr><th>No.</th><th>Barang</th><th class="text-right">Jml</th><th>Dilaporkan</th><th>Deskripsi</th><th class="text-right">Estimasi</th><th class="text-center">Keputusan</th></tr></thead>
            <tbody>
            <?php foreach ($rusak as $x): ?>
                <tr>
                    <td><span class="mono"><?= rusak_kode((int)$x['id']) ?></span></td>
                    <td><strong><?= e($x['nama_barang']) ?></strong><span class="sub mono"><?= e($x['kode_barang']) ?></span></td>
                    <td class="text-right"><?= angka($x['jumlah']) ?></td>
                    <td><?= tgl_indo($x['tanggal_lapor']) ?><span class="sub"><?= e($x['pelapor']) ?></span></td>
                    <td><?= e(potong($x['deskripsi'], 70)) ?></td>
                    <td class="text-right font-weight-bold"><?= rupiah($x['estimasi_biaya']) ?></td>
                    <td class="text-center"><a class="btn btn-sm btn-success" href="<?= e(url('kerusakan', ['aksi' => 'detail', 'id' => $x['id']])) ?>"><i class="fas fa-check mr-1"></i> Tinjau</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div><?php endif; ?>
    </div>

    <div class="card mb-4"><div class="card-header">Opname barang menunggu finalisasi</div>
        <?php if (!$opname): ?><div class="card-body"><?= ui_kosong('fa-clipboard-check', 'Tidak ada sesi opname yang menunggu') ?></div>
        <?php else: ?><div class="table-responsive"><table class="table table-hover mb-0">
            <thead><tr><th>Kode</th><th>Judul</th><th>Ruangan</th><th>Progres</th><th class="text-center">Keputusan</th></tr></thead>
            <tbody>
            <?php foreach ($opname as $o): $lengkap = (int)$o['total'] > 0 && (int)$o['terisi'] === (int)$o['total']; ?>
                <tr>
                    <td><span class="code-chip"><?= e($o['kode']) ?></span></td>
                    <td><?= e($o['judul']) ?><span class="sub"><?= tgl_indo($o['tanggal']) ?></span></td>
                    <td><?= e($o['lokasi'] ?: '-') ?></td>
                    <td><?= (int)$o['terisi'] ?> / <?= (int)$o['total'] ?> <?= $lengkap ? badge('Siap difinalisasi', 'success') : badge('Belum lengkap', 'warning') ?></td>
                    <td class="text-center"><a class="btn btn-sm btn-light" href="<?= e(url('opname', ['aksi' => 'detail', 'id' => $o['id']])) ?>">Buka sesi</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div><?php endif; ?>
    </div>

    <div class="card"><div class="card-header">Keputusan terakhir</div><div class="card-body">
        <?php
        $terakhir = db_all($con,
            "SELECT r.status_baru, r.catatan, r.user_nama, r.created_at, x.id AS kid, b.nama_barang
             FROM kerusakan_riwayat r JOIN kerusakan x ON x.id = r.kerusakan_id JOIN barang b ON b.id = x.barang_id
             WHERE r.status_baru IN ('Dalam Perbaikan','Rusak Permanen','Selesai') ORDER BY r.id DESC LIMIT 8");
        $ba = db_all($con, "SELECT p.nomor_ba, p.tanggal_setujui, p.id, b.nama_barang FROM penghapusan p JOIN barang b ON b.id = p.barang_id
                            WHERE p.status = 'Disetujui' ORDER BY p.id DESC LIMIT 5");
        if (!$terakhir && !$ba): ?>
            <?= ui_kosong('fa-history', 'Belum ada keputusan') ?>
        <?php else: ?>
        <ul class="list-clean">
        <?php foreach ($ba as $b): ?>
            <li><div class="li-main"><strong><?= e($b['nama_barang']) ?> — dihapus</strong><small><?= e($b['nomor_ba']) ?> · <?= tgl_indo($b['tanggal_setujui']) ?></small></div>
                <a class="small" target="_blank" href="<?= e(base_url() . 'print/cetak.php?jenis=ba_hapus&id=' . (int)$b['id']) ?>">Berita acara</a></li>
        <?php endforeach; ?>
        <?php foreach ($terakhir as $h): ?>
            <li><div class="li-main"><strong><?= e($h['nama_barang']) ?> — <?= e($h['status_baru']) ?></strong>
                <small><?= e($h['user_nama']) ?> · <?= waktu_indo($h['created_at']) ?><?= $h['catatan'] ? ' · ' . e(potong($h['catatan'], 90)) : '' ?></small></div>
                <a class="small" href="<?= e(url('kerusakan', ['aksi' => 'detail', 'id' => $h['kid']])) ?>">Lihat</a></li>
        <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </div></div>
    <?php
    $GLOBALS['page_js'] = '$("form[data-tolak]").on("submit", function(ev){
      var f = this; if (f.dataset.ok === "1") return;
      ev.preventDefault();
      Swal.fire({ title: "Alasan penolakan", input: "text", inputPlaceholder: "Tulis alasan singkat", showCancelButton: true,
        confirmButtonText: "Tolak", cancelButtonText: "Batal", confirmButtonColor: "#dc2626",
        inputValidator: function (v) { return v ? null : "Alasan wajib diisi"; } }).then(function (r) {
        if (r.isConfirmed) { f.alasan.value = r.value; f.dataset.ok = "1"; f.submit(); }
      });
    });';
}

function persetujuan_post(array $r): void
{
    $con = db();
    $aksi = post_str('aksi', 20);
    $id = post_int('id');
    $alasan = post_str('alasan', 255);
    if ($aksi === 'masuk_setujui') {
        transaksi_masuk_setujui($con, $id);
        flash('success', 'Barang masuk disetujui. Jumlah di ruangan telah bertambah.');
    } elseif ($aksi === 'masuk_tolak') {
        transaksi_masuk_tolak($con, $id, $alasan !== '' ? $alasan : 'Tidak disetujui');
        flash('info', 'Pengajuan barang masuk ditolak.');
    } elseif ($aksi === 'hapus_setujui') {
        penghapusan_setujui($con, $id);
        flash('success', 'Usulan penghapusan disetujui. Berita acara telah diterbitkan.');
    } elseif ($aksi === 'hapus_tolak') {
        penghapusan_tolak($con, $id, $alasan !== '' ? $alasan : 'Tidak disetujui');
        flash('info', 'Usulan penghapusan ditolak.');
    } else {
        throw new AppException('Aksi tidak dikenali.');
    }
    redirect(url('persetujuan'));
}
