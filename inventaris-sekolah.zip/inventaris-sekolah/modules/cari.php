<?php
// modules/cari.php — pencarian global: barang, peminjaman, kerusakan, berita acara, dan pengguna (admin).

function cari_render(array $r): void
{
    $con = db();
    $q = get_str('q', 80);
    echo ui_head('Pencarian', $q !== '' ? 'Hasil untuk “' . $q . '”' : 'Cari barang, peminjam, laporan kerusakan, atau berita acara.', '');
    ?>
    <form method="get" action="<?= e(base_url()) ?>" class="mb-4">
        <input type="hidden" name="m" value="cari">
        <div class="input-group input-group-lg">
            <input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Kode barang, nama barang, nama peminjam, nomor BA…" autofocus>
            <div class="input-group-append"><button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i> Cari</button></div>
        </div>
    </form>
    <?php
    if ($q === '') return;
    $like = '%' . $q . '%';

    $barang = db_all($con,
        "SELECT id, kode_barang, nama_barang, jenis_barang FROM barang
         WHERE kode_barang LIKE ? OR nama_barang LIKE ? OR kode_bmn LIKE ? ORDER BY nama_barang LIMIT 15", 'sss', [$like, $like, $like]);
    $pinjam = db_all($con,
        "SELECT p.id, p.peminjam, p.status, p.tanggal_rencana_kembali, b.nama_barang FROM peminjaman p JOIN barang b ON b.id = p.barang_id
         WHERE p.peminjam LIKE ? OR b.nama_barang LIKE ? ORDER BY p.id DESC LIMIT 10", 'ss', [$like, $like]);
    $rusak = db_all($con,
        "SELECT x.id, x.status, x.deskripsi, b.nama_barang FROM kerusakan x JOIN barang b ON b.id = x.barang_id
         WHERE b.nama_barang LIKE ? OR x.deskripsi LIKE ? OR CONCAT('KR-', LPAD(x.id, 4, '0')) LIKE ? ORDER BY x.id DESC LIMIT 10", 'sss', [$like, $like, $like]);
    $ba = db_all($con,
        "SELECT p.id, p.nomor_ba, b.nama_barang FROM penghapusan p JOIN barang b ON b.id = p.barang_id
         WHERE p.nomor_ba LIKE ? OR b.nama_barang LIKE ? ORDER BY p.id DESC LIMIT 10", 'ss', [$like, $like]);
    $pengguna = can('pengguna.kelola') ? db_all($con,
        "SELECT id, nama, username, role FROM users WHERE nama LIKE ? OR username LIKE ? LIMIT 10", 'ss', [$like, $like]) : [];

    $total = count($barang) + count($pinjam) + count($rusak) + count($ba) + count($pengguna);
    if ($total === 0) { echo ui_kosong('fa-search', 'Tidak ada hasil', 'Coba kata kunci lain, atau kode barang seperti ELK-0001.'); return; }

    $blok = function ($judul, $items, $render) {
        if (!$items) return;
        echo '<div class="card mb-4"><div class="card-header">' . e($judul) . ' <span class="badge-soft badge-primary">' . count($items) . '</span></div><ul class="list-clean px-3">';
        foreach ($items as $it) echo '<li>' . $render($it) . '</li>';
        echo '</ul></div>';
    };
    $blok('Barang', $barang, function ($b) {
        return '<div class="li-main"><a href="' . e(url('barang', ['aksi' => 'detail', 'id' => $b['id']])) . '"><strong>' . e($b['nama_barang']) . '</strong></a>'
            . '<small><span class="mono">' . e($b['kode_barang']) . '</span> · ' . ($b['jenis_barang'] === 'aset' ? 'Aset tetap' : 'Habis pakai') . '</small></div>';
    });
    $blok('Peminjaman', $pinjam, function ($p) {
        return '<div class="li-main"><a href="' . e(url('peminjaman')) . '"><strong>' . e($p['nama_barang']) . ' — ' . e($p['peminjam']) . '</strong></a>'
            . '<small>Rencana kembali ' . tgl_indo($p['tanggal_rencana_kembali']) . '</small></div>' . badge_status($p['status']);
    });
    $blok('Kerusakan', $rusak, function ($x) {
        return '<div class="li-main"><a href="' . e(url('kerusakan', ['aksi' => 'detail', 'id' => $x['id']])) . '"><strong>' . rusak_kode((int)$x['id']) . ' — ' . e($x['nama_barang']) . '</strong></a>'
            . '<small>' . e(potong($x['deskripsi'], 70)) . '</small></div>' . badge_status($x['status']);
    });
    $blok('Berita acara penghapusan', $ba, function ($p) {
        return '<div class="li-main"><a target="_blank" href="' . e(base_url() . 'print/cetak.php?jenis=ba_hapus&id=' . (int)$p['id']) . '"><strong>' . e($p['nomor_ba']) . '</strong></a>'
            . '<small>' . e($p['nama_barang']) . '</small></div>';
    });
    $blok('Pengguna', $pengguna, function ($u) {
        return '<div class="li-main"><a href="' . e(url('pengguna', ['aksi' => 'edit', 'id' => $u['id']])) . '"><strong>' . e($u['nama']) . '</strong></a>'
            . '<small>@' . e($u['username']) . ' · ' . e(ROLE_LABEL[$u['role']] ?? '') . '</small></div>';
    });
}
