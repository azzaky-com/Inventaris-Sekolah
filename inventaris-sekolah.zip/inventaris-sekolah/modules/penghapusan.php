<?php
// modules/penghapusan.php — penghapusan aset: usulan manual dan daftar berita acara (BA) yang sudah terbit.

function penghapusan_render(array $r): void
{
    $con = db();
    if (get_str('aksi', 20) === 'usul') { penghapusan_render_form(); return; }
    $status = get_str('status', 20) ?: 'semua';
    $petaStatus = ['diusulkan' => 'Diusulkan', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak'];
    $where = isset($petaStatus[$status]) ? 'p.status = ?' : '1=1';
    $par = isset($petaStatus[$status]) ? [$petaStatus[$status]] : [];
    $tipe = isset($petaStatus[$status]) ? 's' : '';
    $rows = db_all($con,
        "SELECT p.*, b.kode_barang, b.nama_barang, l.nama AS lokasi FROM penghapusan p
         JOIN barang b ON b.id = p.barang_id JOIN lokasi l ON l.id = p.lokasi_id
         WHERE $where ORDER BY p.id DESC LIMIT 500", $tipe, $par);
    $cnt = db_row($con, "SELECT SUM(status='Diusulkan') AS usul, SUM(status='Disetujui') AS setuju, SUM(status='Ditolak') AS tolak,
                         COALESCE(SUM(CASE WHEN status='Disetujui' THEN jumlah*nilai_buku_unit END),0) AS nilai FROM penghapusan");

    echo ui_head('Penghapusan Aset', 'Aset yang keluar dari daftar. Setiap penghapusan disetujui Kepala Sekolah dan menerbitkan berita acara.',
        can('transaksi.input') ? '<a class="btn btn-primary btn-sm" href="' . e(url('penghapusan', ['aksi' => 'usul'])) . '"><i class="fas fa-plus mr-1"></i> Usulkan Penghapusan</a>' : '');
    ?>
    <div class="row">
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('amber', 'fa-paper-plane', 'Menunggu persetujuan', angka($cnt['usul'])) ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('rose', 'fa-file-signature', 'Berita acara terbit', angka($cnt['setuju'])) ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('violet', 'fa-coins', 'Nilai buku yang dihapus', rupiah($cnt['nilai']), 'Saat penghapusan') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('green', 'fa-ban', 'Ditolak', angka($cnt['tolak'])) ?></div>
    </div>
    <div class="card mb-4"><div class="card-body pb-2">
        <?= ui_pills(['semua' => ['Semua', null], 'diusulkan' => ['Menunggu', $cnt['usul']], 'disetujui' => ['Disetujui', $cnt['setuju']], 'ditolak' => ['Ditolak', $cnt['tolak']]], $status, 'status', ['m' => 'penghapusan']) ?>
        <hr class="my-3">
    </div>
    <div class="table-responsive">
        <table class="table table-hover datatable" data-order="0:desc" data-nosort="6">
            <thead><tr><th>No. BA / Usul</th><th>Aset</th><th>Ruangan</th><th class="text-right">Jml</th><th>Alasan</th><th>Status</th><th class="text-center">Berita acara</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $p): ?>
                <tr>
                    <td><?= $p['nomor_ba'] ? '<span class="mono">' . e($p['nomor_ba']) . '</span>' : '<span class="text-muted">belum terbit</span>' ?><span class="sub"><?= tgl_indo($p['tanggal_usul']) ?> · <?= e($p['sumber']) ?></span></td>
                    <td><strong><?= e($p['nama_barang']) ?></strong><span class="sub mono"><?= e($p['kode_barang']) ?></span></td>
                    <td><?= e($p['lokasi']) ?></td>
                    <td class="text-right"><?= angka($p['jumlah']) ?></td>
                    <td><?= e($p['alasan']) ?><span class="sub"><?= e(potong($p['keterangan'], 60)) ?></span></td>
                    <td><?= $p['status'] === 'Disetujui' ? badge('Disetujui', 'success') : ($p['status'] === 'Ditolak' ? badge('Ditolak', 'danger') : badge('Menunggu', 'warning')) ?></td>
                    <td class="text-center">
                        <?php if ($p['status'] === 'Disetujui'): ?>
                            <a class="btn btn-sm btn-light" target="_blank" href="<?= e(base_url() . 'print/cetak.php?jenis=ba_hapus&id=' . (int)$p['id']) ?>"><i class="fas fa-print mr-1"></i> Cetak</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

function penghapusan_render_form(): void
{
    require_perm('transaksi.input');
    $con = db();
    $barang = daftar_barang_saldo($con);
    echo ui_head('Usulkan Penghapusan Aset', 'Usulan ini belum mengurangi jumlah. Jumlah berkurang setelah Kepala Sekolah menyetujui.',
        '<a class="btn btn-light btn-sm" href="' . e(url('penghapusan')) . '"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('penghapusan', ['aksi' => 'usul'])) ?>" novalidate>
        <?= csrf_field() ?><input type="hidden" name="aksi" value="usul">
        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <div class="form-group"><label for="barang_id">Aset <span class="req">*</span></label>
                <select class="custom-select select2" id="barang_id" name="barang_id" required data-placeholder="Cari aset…"><?= opsi_barang($barang, (int)old('barang_id'), false, 'aset') ?></select></div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="lokasi_id">Ruangan <span class="req">*</span></label>
                    <select class="custom-select" id="lokasi_id" name="lokasi_id" required><option value="">-- Pilih aset dulu --</option></select>
                    <small class="help" id="hintLokasi"></small></div>
                <div class="form-group col-md-3"><label for="jumlah">Jumlah <span class="req">*</span></label>
                    <input class="form-control" type="number" id="jumlah" name="jumlah" min="1" required value="<?= e(old('jumlah', 1)) ?>"></div>
                <div class="form-group col-md-3"><label for="tanggal_usul">Tanggal <span class="req">*</span></label>
                    <input class="form-control" type="date" id="tanggal_usul" name="tanggal_usul" required max="<?= date('Y-m-d') ?>" value="<?= e(old('tanggal_usul', date('Y-m-d'))) ?>"></div>
            </div>
            <div class="form-group"><label for="alasan">Alasan penghapusan <span class="req">*</span></label>
                <select class="custom-select" id="alasan" name="alasan" required><?= opsi_html(array_combine(ALASAN_HAPUS, ALASAN_HAPUS), (string)old('alasan')) ?></select></div>
            <div class="form-group mb-0"><label for="keterangan">Uraian kondisi &amp; bukti</label>
                <textarea class="form-control" id="keterangan" name="keterangan" rows="3" maxlength="500" placeholder="Kondisi aset, alasan, dan dokumen pendukung"><?= e(old('keterangan')) ?></textarea></div>
        </div></div></div>
        <div class="col-lg-4"><div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold">Alur</h6>
            <ol class="small pl-3 mb-0"><li>Operator mengusulkan dan melampirkan uraian.</li><li>Kepala Sekolah menyetujui atau menolak.</li><li>Jumlah berkurang dan berita acara terbit dengan nomor resmi.</li></ol>
        </div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-paper-plane mr-1"></i> Kirim Usulan</button></div>
        </div>
    </form>
    <?php
    $GLOBALS['page_js'] = '$("#barang_id").on("change", function(){ isiLokasi(this.value, "#lokasi_id", "#hintLokasi"); }); if ($("#barang_id").val()) $("#barang_id").trigger("change");';
}

function penghapusan_post(array $r): void
{
    require_perm('transaksi.input');
    $con = db();
    if (post_str('aksi', 20) !== 'usul') throw new AppException('Aksi tidak dikenali.');
    $tgl = tanggal_valid($_POST['tanggal_usul'] ?? '');
    if (!$tgl) throw new AppException('Tanggal tidak valid.');
    $alasan = in_array($_POST['alasan'] ?? '', ALASAN_HAPUS, true) ? $_POST['alasan'] : null;
    if ($alasan === null) throw new AppException('Pilih alasan penghapusan.');
    $id = penghapusan_usul($con, [
        'barang_id' => post_int('barang_id'), 'lokasi_id' => post_int('lokasi_id') ?: null, 'jumlah' => post_int('jumlah'),
        'alasan' => $alasan, 'tanggal_usul' => $tgl, 'keterangan' => post_str('keterangan', 500),
    ]);
    flash('success', 'Usulan penghapusan dikirim ke Kepala Sekolah untuk disetujui.');
    redirect(url('penghapusan'));
}
