<?php
// modules/opname.php — opname barang (pencacahan fisik): buat sesi, isi hitung fisik, finalisasi & berita acara.

function opname_render(array $r): void
{
    $aksi = get_str('aksi', 20);
    if ($aksi === 'tambah') { opname_render_form(); return; }
    if ($aksi === 'detail') { opname_render_detail(get_int('id')); return; }
    opname_render_list();
}

function opname_render_list(): void
{
    $con = db();
    $rows = db_all($con,
        "SELECT o.*, l.nama AS lokasi,
            (SELECT COUNT(*) FROM stok_opname_item i WHERE i.opname_id = o.id) AS total,
            (SELECT COUNT(*) FROM stok_opname_item i WHERE i.opname_id = o.id AND i.stok_fisik IS NOT NULL) AS terisi,
            (SELECT COUNT(*) FROM stok_opname_item i WHERE i.opname_id = o.id AND i.selisih IS NOT NULL AND i.selisih <> 0) AS selisih_n
         FROM stok_opname o LEFT JOIN lokasi l ON l.id = o.lokasi_id ORDER BY o.tanggal DESC, o.id DESC");
    $aksiHtml = can('transaksi.input')
        ? '<a class="btn btn-primary btn-sm" href="' . e(url('opname', ['aksi' => 'tambah'])) . '"><i class="fas fa-plus mr-1"></i> Sesi Opname Baru</a>' : '';
    echo ui_head('Opname barang', 'Cocokkan jumlah sistem dengan hitung fisik. Selisih disesuaikan saat sesi difinalisasi.', $aksiHtml);
    $draft = count(array_filter($rows, function ($x) { return $x['status'] === 'Draft'; }));
    echo '<div class="row">';
    echo '<div class="col-md-4 mb-4">' . ui_kpi('blue', 'fa-clipboard-check', 'Total Sesi', angka(count($rows))) . '</div>';
    echo '<div class="col-md-4 mb-4">' . ui_kpi('amber', 'fa-pen', 'Sedang Draft', angka($draft)) . '</div>';
    echo '<div class="col-md-4 mb-4">' . ui_kpi('green', 'fa-check-double', 'Selesai', angka(count($rows) - $draft)) . '</div>';
    echo '</div>';
    ?>
    <div class="card"><div class="table-responsive">
        <table class="table table-hover datatable" data-order="2:desc" data-nosort="6">
            <thead><tr><th>Kode</th><th>Judul</th><th>Tanggal</th><th>Lingkup</th><th>Progres</th><th>Status</th><th class="text-center">Aksi</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $o): $pct = $o['total'] ? round($o['terisi'] / $o['total'] * 100) : 0; ?>
            <tr>
                <td><span class="code-chip"><?= e($o['kode']) ?></span></td>
                <td><strong><?= e($o['judul']) ?></strong></td>
                <td class="text-nowrap" data-order="<?= e($o['tanggal']) ?>"><?= tgl_indo($o['tanggal']) ?></td>
                <td><?= e($o['lokasi'] ?: 'Seluruh barang aktif') ?></td>
                <td style="min-width:150px">
                    <div class="d-flex justify-content-between small mb-1"><span><?= (int)$o['terisi'] ?> / <?= (int)$o['total'] ?></span><span><?= $pct ?>%</span></div>
                    <div class="progress"><div class="progress-bar" style="width:<?= $pct ?>%"></div></div>
                </td>
                <td><?= badge_status($o['status']) ?><?= $o['status'] === 'Selesai' && $o['selisih_n'] ? '<div class="small text-muted mt-1">' . (int)$o['selisih_n'] . ' selisih disesuaikan</div>' : '' ?></td>
                <td class="text-center"><?= ui_btn_link(url('opname', ['aksi' => 'detail', 'id' => $o['id']]), 'fa-arrow-right', 'light', 'Buka') ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div></div>
    <?php
}

function opname_render_form(): void
{
    require_perm('transaksi.input');
    $con = db();
    $lokasi = ui_opsi_tabel('lokasi', 'nama', (string)old('lokasi_id'), '-- Pilih ruangan --');
    echo ui_head('Sesi Opname barang Baru', 'Sistem menyalin jumlah di ruangan saat ini sebagai acuan. Hitung fisik dilakukan setelah sesi dibuat.',
        '<a class="btn btn-light btn-sm" href="' . e(url('opname')) . '"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('opname', ['aksi' => 'tambah'])) ?>" novalidate>
        <?= csrf_field() ?><input type="hidden" name="aksi" value="simpan_baru">
        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <div class="form-group"><label for="judul">Judul Sesi <span class="req">*</span></label>
                <input class="form-control" id="judul" name="judul" maxlength="150" required value="<?= e(old('judul')) ?>" placeholder="Contoh: Inventarisasi Akhir Semester Ganjil 2026"></div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="tanggal">Tanggal <span class="req">*</span></label>
                    <input class="form-control" type="date" id="tanggal" name="tanggal" required value="<?= e(old('tanggal', date('Y-m-d'))) ?>"></div>
                <div class="form-group col-md-6"><label for="lokasi_id">Ruangan yang dihitung <span class="req">*</span></label>
                    <select class="custom-select" id="lokasi_id" name="lokasi_id" required><?= $lokasi ?></select>
                    <small class="help">Opname dilakukan per ruangan. Barang yang tersimpan di ruangan ini akan ikut dihitung.</small></div>
            </div>
            <div class="form-group mb-0"><label for="catatan">Catatan</label>
                <textarea class="form-control" id="catatan" name="catatan" rows="2" maxlength="1000"><?= e(old('catatan')) ?></textarea></div>
        </div></div></div>
        <div class="col-lg-4"><div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold">Alur</h6>
            <ol class="small pl-3 mb-0"><li>Buat sesi (jumlah sistem disalin).</li><li>Isi hitung fisik per barang, simpan bertahap.</li><li>Finalisasi oleh Kepala Sekolah untuk menyesuaikan jumlah.</li></ol>
        </div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-plus mr-1"></i> Buat Sesi</button></div>
        </div>
    </form>
    <?php
}

function opname_render_detail(int $id): void
{
    $con = db();
    $o = db_row($con, "SELECT o.*, l.nama AS lokasi FROM stok_opname o LEFT JOIN lokasi l ON l.id = o.lokasi_id WHERE o.id = ?", 'i', [$id]);
    if (!$o) { echo ui_kosong('fa-search', 'Sesi tidak ditemukan'); return; }
    $items = db_all($con,
        "SELECT i.*, b.kode_barang, b.nama_barang, b.satuan, b.stok_total AS stok_sekarang
         FROM stok_opname_item i JOIN barang b ON b.id = i.barang_id WHERE i.opname_id = ? ORDER BY b.nama_barang", 'i', [$id]);
    $draft = $o['status'] === 'Draft';
    $terisi = count(array_filter($items, function ($x) { return $x['stok_fisik'] !== null; }));

    $aksiHtml = '<a class="btn btn-light btn-sm" href="' . e(url('opname')) . '"><i class="fas fa-arrow-left mr-1"></i> Daftar</a>';
    if (!$draft) {
        $aksiHtml .= '<a class="btn btn-primary btn-sm" target="_blank" href="' . e(base_url() . 'print/cetak.php?jenis=opname&id=' . $id) . '"><i class="fas fa-print mr-1"></i> Berita Acara</a>';
    }
    echo ui_head($o['judul'], $o['kode'] . ' · ' . tgl_indo($o['tanggal'], true) . ' · ' . ($o['lokasi'] ?: 'Seluruh barang aktif'), $aksiHtml);

    echo '<div class="row"><div class="col-md-4 mb-4">' . ui_kpi('blue', 'fa-list-ol', 'Barang dalam sesi', angka(count($items))) . '</div>';
    echo '<div class="col-md-4 mb-4">' . ui_kpi('teal', 'fa-keyboard', 'Sudah dihitung', angka($terisi) . ' / ' . angka(count($items))) . '</div>';
    echo '<div class="col-md-4 mb-4">' . ui_kpi($draft ? 'amber' : 'green', $draft ? 'fa-pen' : 'fa-check-double', 'Status', $o['status']) . '</div></div>';

    if ($draft && can('transaksi.input')) {
        ?>
        <form method="post" action="<?= e(url('opname', ['aksi' => 'detail', 'id' => $id])) ?>">
            <?= csrf_field() ?><input type="hidden" name="aksi" value="simpan_fisik"><input type="hidden" name="opname_id" value="<?= (int)$id ?>">
            <div class="card mb-4">
                <div class="card-header">Hasil Hitung Fisik
                    <button class="btn btn-primary btn-sm" type="submit"><i class="fas fa-save mr-1"></i> Simpan Hasil</button></div>
                <div class="table-responsive"><table class="table table-sm mb-0 align-middle">
                    <thead><tr><th>Kode</th><th>Nama Barang</th><th class="text-right">Jumlah Sistem</th><th style="width:150px">Hitung Fisik</th><th style="width:240px">Keterangan</th><th class="text-right">Selisih</th></tr></thead>
                    <tbody>
                    <?php foreach ($items as $it): ?>
                        <tr>
                            <td><span class="code-chip"><?= e($it['kode_barang']) ?></span></td>
                            <td><?= e($it['nama_barang']) ?> <span class="text-muted small"><?= e($it['satuan']) ?></span></td>
                            <td class="text-right"><?= angka($it['stok_sistem']) ?></td>
                            <td><input class="form-control form-control-sm" type="number" min="0" name="fisik[<?= (int)$it['barang_id'] ?>]" value="<?= $it['stok_fisik'] !== null ? (int)$it['stok_fisik'] : '' ?>" placeholder="—"></td>
                            <td><input class="form-control form-control-sm" name="ket[<?= (int)$it['barang_id'] ?>]" maxlength="255" value="<?= e($it['keterangan'] ?? '') ?>"></td>
                            <td class="text-right text-muted small"><?= $it['stok_fisik'] !== null ? angka((int)$it['stok_fisik'] - (int)$it['stok_sistem']) : '' ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            </div>
        </form>
        <?php if (can('opname.finalisasi')): ?>
        <div class="card mb-4"><div class="card-body d-flex flex-wrap justify-content-between align-items-center">
            <div><strong>Finalisasi sesi</strong><div class="small text-muted">Semua barang harus sudah dihitung. Selisih akan menyesuaikan jumlah dan tercatat di kartu persediaan.</div></div>
            <form method="post" action="<?= e(url('opname', ['aksi' => 'detail', 'id' => $id])) ?>" data-confirm="Finalisasi akan menyesuaikan jumlah sesuai hasil hitung fisik dan tidak dapat diubah. Lanjutkan?">
                <?= csrf_field() ?><input type="hidden" name="aksi" value="finalisasi"><input type="hidden" name="opname_id" value="<?= (int)$id ?>">
                <button class="btn btn-success" type="submit"><i class="fas fa-check-double mr-1"></i> Finalisasi</button>
            </form>
        </div></div>
        <?php else: ?>
            <div class="alert alert-soft alert-info"><i class="fas fa-lock mr-1"></i> Finalisasi dilakukan oleh Kepala Sekolah atau Administrator.</div>
        <?php endif; ?>
        <?php
    } else {
        ?>
        <div class="card mb-4"><div class="table-responsive"><table class="table table-sm mb-0 align-middle">
            <thead><tr><th>Kode</th><th>Nama Barang</th><th class="text-right">Jumlah Sistem (awal)</th><th class="text-right">Fisik</th><th class="text-right">Selisih</th><th>Keterangan</th></tr></thead>
            <tbody>
            <?php foreach ($items as $it):
                $sel = (int)$it['selisih']; ?>
                <tr>
                    <td><span class="code-chip"><?= e($it['kode_barang']) ?></span></td>
                    <td><?= e($it['nama_barang']) ?></td>
                    <td class="text-right"><?= angka($it['stok_sistem']) ?></td>
                    <td class="text-right"><?= $it['stok_fisik'] !== null ? angka($it['stok_fisik']) : '-' ?></td>
                    <td class="text-right"><?= $sel === 0 ? badge('Sesuai', 'success') : badge(($sel > 0 ? '+' : '−') . angka(abs($sel)), $sel > 0 ? 'info' : 'danger') ?></td>
                    <td class="small"><?= e($it['keterangan'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div></div>
        <?php
    }
}

function opname_post(array $r): void
{
    $con = db();
    $aksi = post_str('aksi', 20);
    // Izin dicek per aksi: finalisasi hanya untuk Kepala Sekolah/Administrator
    if ($aksi === 'finalisasi') {
        require_perm('opname.finalisasi');
    } else {
        require_perm('transaksi.input');
    }

    if ($aksi === 'simpan_baru') {
        $judul = post_str('judul', 150);
        if (mb_strlen($judul) < 3) throw new AppException('Judul sesi wajib diisi.');
        $tgl = tanggal_valid($_POST['tanggal'] ?? '');
        if (!$tgl) throw new AppException('Tanggal tidak valid.');
        $lok = post_int('lokasi_id') ?: null;   // wajib (dicek di layanan)
        $id = opname_buat($con, ['judul' => $judul, 'tanggal' => $tgl, 'lokasi_id' => $lok, 'catatan' => post_str('catatan', 1000)]);
        flash('success', 'Sesi opname dibuat. Silakan isi hasil hitung fisik.');
        redirect(url('opname', ['aksi' => 'detail', 'id' => $id]));
    }

    $id = post_int('opname_id');
    if ($aksi === 'simpan_fisik') {
        $fisikIn = is_array($_POST['fisik'] ?? null) ? $_POST['fisik'] : [];
        $ketIn = is_array($_POST['ket'] ?? null) ? $_POST['ket'] : [];
        $fisik = []; $ket = [];
        foreach ($fisikIn as $bid => $val) {
            $bid = (int)$bid;
            $val = trim((string)$val);
            if ($bid <= 0) continue;
            if ($val === '') { $fisik[$bid] = null; }
            else {
                if (!preg_match('/^\d{1,7}$/', $val)) throw new AppException('Hitung fisik harus berupa angka bulat tidak negatif.');
                $fisik[$bid] = (int)$val;
            }
            $ket[$bid] = str_bersih($ketIn[$bid] ?? '', 255);
        }
        opname_simpan_fisik($con, $id, $fisik, $ket);
        flash('success', 'Hasil hitung fisik disimpan.');
        redirect(url('opname', ['aksi' => 'detail', 'id' => $id]));
    }

    if ($aksi === 'finalisasi') {
        opname_finalisasi($con, $id);
        flash('success', 'Sesi opname difinalisasi dan jumlah telah disesuaikan.');
        redirect(url('opname', ['aksi' => 'detail', 'id' => $id]));
    }
    throw new AppException('Aksi tidak dikenali.');
}
