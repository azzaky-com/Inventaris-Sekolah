<?php
// modules/tahun.php — tahun ajaran & tutup buku. Hanya Administrator.

function tahun_render(array $r): void
{
    $con = db();
    $daftar = tahun_daftar($con);
    $aktif = tahun_aktif($con);
    echo ui_head('Tahun Ajaran & Tutup Buku', 'Tutup tahun ajaran untuk mengunci transaksi periode itu dan menyimpan posisi aset sebagai arsip resmi.', '');
    ?>
    <?php if ($aktif): ?>
    <div class="card mb-4"><div class="card-body d-flex flex-wrap justify-content-between align-items-center" style="gap:12px">
        <div>
            <div class="small-caps">Tahun ajaran berjalan</div>
            <div class="kpi-value"><?= e($aktif['nama']) ?></div>
            <div class="small text-muted"><?= tgl_indo($aktif['tanggal_mulai'], true) ?> s.d. <?= tgl_indo($aktif['tanggal_selesai'], true) ?></div>
        </div>
        <form method="post" action="<?= e(url('tahun')) ?>" data-confirm="Menutup tahun ajaran akan mengunci semua transaksi pada periode ini dan menyimpan posisi aset. Lanjutkan?">
            <?= csrf_field() ?><input type="hidden" name="aksi" value="tutup"><input type="hidden" name="id" value="<?= (int)$aktif['id'] ?>">
            <button class="btn btn-warning" type="submit"><i class="fas fa-lock mr-1"></i> Tutup tahun ajaran ini</button>
        </form>
    </div></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">Daftar tahun ajaran</div>
        <div class="table-responsive"><table class="table table-hover mb-0">
            <thead><tr><th>Tahun ajaran</th><th>Periode</th><th>Status</th><th>Ditutup</th><th class="text-center">Arsip</th></tr></thead>
            <tbody>
            <?php foreach ($daftar as $t): $tutup = $t['status'] === 'Ditutup'; ?>
                <tr>
                    <td><strong><?= e($t['nama']) ?></strong></td>
                    <td><?= tgl_indo($t['tanggal_mulai']) ?> – <?= tgl_indo($t['tanggal_selesai']) ?></td>
                    <td><?= $tutup ? badge('Ditutup', 'secondary') : badge('Berjalan', 'success') ?></td>
                    <td><?= $tutup ? waktu_indo($t['ditutup_pada']) . '<span class="sub">oleh ' . e($t['ditutup_oleh']) . '</span>' : '<span class="text-muted">-</span>' ?></td>
                    <td class="text-center">
                        <?php if ($tutup): ?>
                            <a class="btn btn-sm btn-light" href="<?= e(url('pemeliharaan')) ?>"><i class="fas fa-archive mr-1"></i> Arsipkan data</a>
                            <a class="btn btn-sm btn-light" target="_blank" href="<?= e(base_url() . 'print/cetak.php?jenis=tutup_buku&id=' . (int)$t['id']) ?>"><i class="fas fa-print mr-1"></i> Tutup buku</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    </div>
    <div class="alert alert-soft alert-info mt-4 small">
        Tutup buku menyimpan posisi setiap aset pada akhir tahun ajaran (jumlah, tersedia, perolehan, akumulasi penyusutan, nilai buku). Setelah ditutup, transaksi pada periode tersebut tidak dapat diubah. Koreksi dilakukan pada tahun ajaran berjalan.
    </div>
    <?php
}

function tahun_post(array $r): void
{
    if (post_str('aksi', 20) !== 'tutup') throw new AppException('Aksi tidak dikenali.');
    tahun_tutup(db(), post_int('id'));
    flash('success', 'Tahun ajaran ditutup. Posisi aset telah disimpan sebagai tutup buku.');
    redirect(url('tahun'));
}
