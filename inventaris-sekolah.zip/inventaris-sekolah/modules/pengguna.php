<?php
// modules/pengguna.php — manajemen akun pengguna (khusus Administrator).

function pengguna_render(array $r): void
{
    $con = db();
    $aksi = get_str('aksi', 20);
    $me = user_id();
    if ($aksi === 'tambah' || $aksi === 'edit') { pengguna_render_form($aksi, get_int('id')); return; }

    $rows = db_all($con, "SELECT * FROM users ORDER BY aktif DESC, nama ASC");
    echo ui_head('Pengguna', 'Kelola akun untuk Administrator, Operator, dan Kepala Sekolah.',
        '<a class="btn btn-primary btn-sm" href="' . e(url('pengguna', ['aksi' => 'tambah'])) . '"><i class="fas fa-user-plus mr-1"></i> Tambah Pengguna</a>');
    $badgeRole = ['admin' => 'primary', 'operator' => 'info', 'kepala_sekolah' => 'purple'];
    ?>
    <div class="card"><div class="table-responsive">
        <table class="table table-hover datatable" data-order="0:asc" data-nosort="6">
            <thead><tr><th>Nama</th><th>Username</th><th>No. HP</th><th>Peran</th><th>Status</th><th>Login Terakhir</th><th class="text-center">Aksi</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $u): $self = (int)$u['id'] === $me; ?>
            <tr>
                <td><div class="d-flex align-items-center"><span class="avatar mr-2"><?= e(mb_strtoupper(mb_substr($u['nama'], 0, 1))) ?></span>
                    <div><strong><?= e($u['nama']) ?></strong><?= $self ? ' <span class="badge-soft badge-success">Anda</span>' : '' ?></div></div></td>
                <td><span class="mono"><?= e($u['username']) ?></span></td>
                <td><?= e($u['no_hp'] ?: '-') ?></td>
                <td><?= badge(ROLE_LABEL[$u['role']] ?? $u['role'], $badgeRole[$u['role']] ?? 'secondary') ?></td>
                <td><?= $u['aktif'] ? badge('Aktif', 'success') : badge('Nonaktif', 'secondary') ?></td>
                <td class="text-nowrap"><?= $u['last_login'] ? waktu_indo($u['last_login']) : '<span class="text-muted">Belum pernah</span>' ?></td>
                <td class="text-center text-nowrap">
                    <?= ui_btn_link(url('pengguna', ['aksi' => 'edit', 'id' => $u['id']]), 'fa-pen', 'light', 'Ubah') ?>
                    <?php if (!$self): ?>
                    <form method="post" action="<?= e(url('pengguna')) ?>" class="d-inline"
                          data-confirm="<?= $u['aktif'] ? 'Nonaktifkan akun ini? Pengguna tidak dapat masuk.' : 'Aktifkan kembali akun ini?' ?>">
                        <?= csrf_field() ?><input type="hidden" name="aksi" value="toggle"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                        <button class="btn btn-sm btn-icon btn-light" type="submit" title="<?= $u['aktif'] ? 'Nonaktifkan' : 'Aktifkan' ?>" data-toggle="tooltip">
                            <i class="fas <?= $u['aktif'] ? 'fa-user-slash' : 'fa-user-check' ?>"></i></button>
                    </form>
                    <form method="post" action="<?= e(url('pengguna')) ?>" class="d-inline" data-confirm="Hapus akun ini secara permanen?">
                        <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                        <button class="btn btn-sm btn-icon btn-light text-danger" type="submit" title="Hapus" data-toggle="tooltip"><i class="fas fa-trash"></i></button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div></div>
    <?php
}

function pengguna_render_form(string $aksi, int $id): void
{
    $con = db();
    $u = null;
    if ($aksi === 'edit') {
        $u = db_row($con, "SELECT * FROM users WHERE id = ?", 'i', [$id]);
        if (!$u) { echo ui_kosong('fa-user-slash', 'Pengguna tidak ditemukan'); return; }
    }
    $v = function ($k, $def = '') use ($u) { return old($k, $u[$k] ?? $def); };
    $self = $u && (int)$u['id'] === user_id();
    echo ui_head($u ? 'Ubah Pengguna' : 'Tambah Pengguna', $u ? 'Kosongkan password bila tidak ingin mengubahnya.' : 'Password awal wajib minimal 8 karakter.',
        '<a class="btn btn-light btn-sm" href="' . e(url('pengguna')) . '"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('pengguna', $u ? ['aksi' => 'edit', 'id' => $id] : ['aksi' => 'tambah'])) ?>" novalidate>
        <?= csrf_field() ?><input type="hidden" name="aksi" value="simpan"><input type="hidden" name="id" value="<?= (int)$id ?>">
        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <div class="form-row">
                <div class="form-group col-md-6"><label for="nama">Nama Lengkap <span class="req">*</span></label>
                    <input class="form-control" id="nama" name="nama" maxlength="100" required value="<?= e($v('nama')) ?>"></div>
                <div class="form-group col-md-6"><label for="no_hp">No. HP</label>
                    <input class="form-control" id="no_hp" name="no_hp" maxlength="20" value="<?= e($v('no_hp')) ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="username">Username <span class="req">*</span></label>
                    <input class="form-control" id="username" name="username" maxlength="30" required pattern="[A-Za-z0-9_.]{3,30}" value="<?= e($v('username')) ?>">
                    <small class="help">3–30 karakter: huruf, angka, titik, atau garis bawah.</small></div>
                <div class="form-group col-md-6"><label for="role">Peran <span class="req">*</span></label>
                    <select class="custom-select" id="role" name="role" <?= $self ? 'disabled' : '' ?>><?= opsi_html(ROLE_LABEL, (string)$v('role', 'operator')) ?></select>
                    <?php if ($self): ?><input type="hidden" name="role" value="admin"><small class="help">Peran akun sendiri tidak dapat diubah.</small><?php endif; ?></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="password">Password <?= $u ? '' : '<span class="req">*</span>' ?></label>
                    <input class="form-control" type="password" id="password" name="password" autocomplete="new-password" maxlength="200" <?= $u ? '' : 'required' ?>></div>
                <div class="form-group col-md-6"><label for="password2">Ulangi Password</label>
                    <input class="form-control" type="password" id="password2" name="password2" autocomplete="new-password" maxlength="200"></div>
            </div>
            <?php if ($u && !$self): ?>
            <div class="custom-control custom-switch"><input class="custom-control-input" type="checkbox" id="aktif" name="aktif" value="1" <?= (int)$v('aktif', 1) ? 'checked' : '' ?>>
                <label class="custom-control-label" for="aktif">Akun aktif (dapat masuk)</label></div>
            <?php endif; ?>
        </div></div></div>
        <div class="col-lg-4"><div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold">Hak akses per peran</h6>
            <ul class="small pl-3 mb-0">
                <li><strong>Administrator</strong>: semua fitur, termasuk pengguna dan pengaturan.</li>
                <li><strong>Operator</strong>: mencatat transaksi, mengelola barang, dan melaporkan kerusakan.</li>
                <li><strong>Kepala Sekolah</strong>: menyetujui perbaikan/penghapusan, memfinalisasi opname, melihat log.</li>
            </ul>
        </div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-save mr-1"></i> Simpan</button></div>
        </div>
    </form>
    <?php
}

function pengguna_post(array $r): void
{
    require_perm('pengguna.kelola');
    $con = db();
    $aksi = post_str('aksi', 20);
    $id = post_int('id');
    $me = user_id();

    if ($aksi === 'hapus' || $aksi === 'toggle') {
        if ($id === $me) throw new AppException('Anda tidak dapat mengubah status atau menghapus akun sendiri.');
        $u = db_row($con, "SELECT username, aktif FROM users WHERE id = ?", 'i', [$id]);
        if (!$u) throw new AppException('Pengguna tidak ditemukan.');
        if ($aksi === 'hapus') {
            db_exec($con, "DELETE FROM users WHERE id = ?", 'i', [$id]);
            log_aktivitas('HAPUS', 'pengguna', "Menghapus akun {$u['username']}");
            flash('success', 'Akun berhasil dihapus.');
        } else {
            $baru = $u['aktif'] ? 0 : 1;
            db_exec($con, "UPDATE users SET aktif = ? WHERE id = ?", 'ii', [$baru, $id]);
            log_aktivitas('UBAH', 'pengguna', ($baru ? 'Mengaktifkan' : 'Menonaktifkan') . " akun {$u['username']}");
            flash('success', $baru ? 'Akun diaktifkan.' : 'Akun dinonaktifkan.');
        }
        redirect(url('pengguna'));
    }

    if ($aksi !== 'simpan') throw new AppException('Aksi tidak dikenali.');
    $nama = str_bersih($_POST['nama'] ?? '', 100);
    if (mb_strlen($nama) < 3) throw new AppException('Nama lengkap wajib diisi.');
    $username = str_bersih($_POST['username'] ?? '', 30);
    if (!preg_match('/^[A-Za-z0-9_.]{3,30}$/', $username)) throw new AppException('Username 3–30 karakter (huruf, angka, titik, garis bawah).');
    $hp = str_bersih($_POST['no_hp'] ?? '', 20);
    $pw = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
    $pw2 = is_string($_POST['password2'] ?? null) ? $_POST['password2'] : '';
    if ($pw !== '' && strlen($pw) < 8) throw new AppException('Password minimal 8 karakter.');
    if ($pw !== '' && $pw !== $pw2) throw new AppException('Konfirmasi password tidak sama.');
    $role = in_array($_POST['role'] ?? '', array_keys(ROLE_LABEL), true) ? $_POST['role'] : 'operator';
    $aktif = isset($_POST['aktif']) ? 1 : 1;

    $dup = db_value($con, "SELECT id FROM users WHERE username = ? AND id <> ?", 'si', [$username, $id]);
    if ($dup) throw new AppException('Username sudah digunakan pengguna lain.');

    if ($id) {
        $lama = db_row($con, "SELECT * FROM users WHERE id = ?", 'i', [$id]);
        if (!$lama) throw new AppException('Pengguna tidak ditemukan.');
        if ($id === $me) {
            $role = 'admin';
            $aktif = 1;
        } else {
            $aktif = isset($_POST['aktif']) ? 1 : 0;
        }
        db_exec($con, "UPDATE users SET nama = ?, no_hp = ?, username = ?, role = ?, aktif = ? WHERE id = ?",
            'ssssii', [$nama, $hp ?: null, $username, $role, $aktif, $id]);
        if ($pw !== '') {
            db_exec($con, "UPDATE users SET password = ? WHERE id = ?", 'si', [password_hash($pw, PASSWORD_DEFAULT), $id]);
        }
        if ($id === $me) { $_SESSION['auth']['nama'] = $nama; $_SESSION['auth']['username'] = $username; }
        log_aktivitas('UBAH', 'pengguna', "Mengubah akun {$username}" . ($pw !== '' ? ' (password diganti)' : ''));
        flash('success', 'Data pengguna diperbarui.');
    } else {
        if ($pw === '') throw new AppException('Password awal wajib diisi.');
        db_exec($con, "INSERT INTO users (nama, no_hp, username, password, role, aktif) VALUES (?, ?, ?, ?, ?, ?)",
            'sssssi', [$nama, $hp ?: null, $username, password_hash($pw, PASSWORD_DEFAULT), $role, $aktif]);
        log_aktivitas('TAMBAH', 'pengguna', "Menambah akun {$username} sebagai " . ROLE_LABEL[$role]);
        flash('success', 'Pengguna baru berhasil ditambahkan.');
    }
    redirect(url('pengguna'));
}
