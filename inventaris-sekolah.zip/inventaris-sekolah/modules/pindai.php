<?php
// modules/pindai.php — pindai kode QR aset dengan kamera (atau ketik kode). Hasil langsung membuka detail aset.

function pindai_render(array $r): void
{
    echo ui_head('Pindai Aset', 'Arahkan kamera ke label QR aset, atau ketik kode barang. Kamera memerlukan koneksi aman (HTTPS atau localhost).', '');
    ?>
    <div class="row">
        <div class="col-lg-7 mb-4"><div class="card"><div class="card-body">
            <div class="scan-box" id="scanBox">
                <video id="kamera" playsinline muted></video>
                <div class="scan-frame"></div>
                <div class="scan-status" id="scanStatus">Menyiapkan kamera…</div>
            </div>
            <div class="d-flex flex-wrap mt-3" style="gap:8px">
                <button class="btn btn-primary" id="btnMulai" type="button"><i class="fas fa-camera mr-1"></i> Mulai pindai</button>
                <button class="btn btn-light" id="btnBerhenti" type="button" disabled><i class="fas fa-stop mr-1"></i> Berhenti</button>
            </div>
        </div></div></div>
        <div class="col-lg-5 mb-4"><div class="card"><div class="card-header">Cari dengan kode</div><div class="card-body">
            <form id="formKode" class="mb-3">
                <div class="input-group">
                    <input class="form-control" id="kodeManual" placeholder="Contoh: ELK-0001" maxlength="20" autocomplete="off">
                    <div class="input-group-append"><button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button></div>
                </div>
            </form>
            <div id="hasilKode" class="small text-muted">Hasil pencarian akan tampil di sini.</div>
            <hr>
            <p class="small text-muted mb-0">Hasil pindai membuka halaman detail aset. Dari sana Anda bisa mencatat pemakaian, peminjaman, atau pemindahan.</p>
        </div></div></div>
    </div>
    <?php
    $GLOBALS['page_js_vendor'] = [base_url() . 'assets/vendor/jsqr/jsQR.js'];
    $GLOBALS['page_js'] = '
    (function(){
      var BASE = ' . ui_js(base_url()) . ';
      var video = document.getElementById("kamera"), status = document.getElementById("scanStatus");
      var canvas = document.createElement("canvas"), ctx = canvas.getContext("2d", { willReadFrequently: true });
      var stream = null, raf = null, aktif = false;
      function buka(url){ window.location.href = url; }
      function cariKode(kode){
        $.getJSON(BASE + "api.php", { aksi: "kode", kode: kode }, function (d) {
          if (d.ketemu) { $("#hasilKode").html(""); buka(BASE + "?m=barang&aksi=detail&id=" + d.id); }
          else { $("#hasilKode").removeClass("text-muted").addClass("text-danger").text("Kode " + kode + " tidak ditemukan."); }
        });
      }
      function prosesHasil(teks){
        var m = teks.match(/[?&]id=(\d+)/);
        if (teks.indexOf("m=barang") !== -1 && m) { buka(teks); return true; }
        var kode = teks.trim().toUpperCase();
        if (/^[A-Z]{2,5}-\d{4}$/.test(kode)) { cariKode(kode); return true; }
        return false;
      }
      function loop(){
        if (!aktif) return;
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
          canvas.width = video.videoWidth; canvas.height = video.videoHeight;
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          var img = ctx.getImageData(0, 0, canvas.width, canvas.height);
          var code = window.jsQR ? jsQR(img.data, img.width, img.height, { inversionAttempts: "dontInvert" }) : null;
          if (code && code.data) {
            aktif = false; status.textContent = "Terbaca: " + code.data;
            if (!prosesHasil(code.data)) { status.textContent = "QR tidak dikenali: " + code.data; aktif = true; }
          }
        }
        if (aktif) raf = requestAnimationFrame(loop);
      }
      function mulai(){
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          status.textContent = "Kamera tidak tersedia di peramban ini. Gunakan pencarian kode."; return;
        }
        navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }).then(function (s) {
          stream = s; video.srcObject = s; video.play();
          aktif = true; $("#btnMulai").prop("disabled", true); $("#btnBerhenti").prop("disabled", false);
          status.textContent = "Arahkan ke label QR…"; raf = requestAnimationFrame(loop);
        }).catch(function () { status.textContent = "Izin kamera ditolak atau kamera tidak ditemukan."; });
      }
      function berhenti(){
        aktif = false; if (raf) cancelAnimationFrame(raf);
        if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
        stream = null; $("#btnMulai").prop("disabled", false); $("#btnBerhenti").prop("disabled", true);
        status.textContent = "Pemindaian dihentikan.";
      }
      $("#btnMulai").on("click", mulai); $("#btnBerhenti").on("click", berhenti);
      $("#formKode").on("submit", function (ev) { ev.preventDefault(); var k = $("#kodeManual").val().trim().toUpperCase(); if (k) cariKode(k); });
      $(window).on("pagehide", berhenti);
    })();';
}
