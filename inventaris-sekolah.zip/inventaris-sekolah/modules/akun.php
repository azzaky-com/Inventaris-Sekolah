<?php
// modules/akun.php — profil & ganti password oleh pengguna sendiri.

function akun_render(array $r): void
{
    $con = db();
    $u = db_row($con, "SELECT * FROM users WHERE id = ?", 'i', [user_id()]);
    $v = function ($k, $def = '') use ($u) { return old($k, $u[$k] ?? $def); };
    echo ui_head('Akun Saya', 'Perbarui data diri dan password Anda.');
    ?>
    <div class="row">
        <div class="col-lg-6 mb-4"><div class="card"><div class="card-header">Data Diri</div><div class="card-body">
            <form method="post" action="<?= e(url('akun')) ?>" class="needs-validation" novalidate>
                <?= csrf_field() ?><input type="hidden" name="aksi" value="profil">
                <div class="form-group"><label>Username</label><input class="form-control" value="<?= e($u['username']) ?>" disabled></div>
                <div class="form-group"><label for="nama">Nama Lengkap <span class="req">*</span></label>
                    <input class="form-control" id="nama" name="nama" maxlength="100" required value="<?= e($v('nama')) ?>"></div>
                <div class="form-group"><label for="no_hp">No. HP</label>
                    <input class="form-control" id="no_hp" name="no_hp" maxlength="20" value="<?= e($v('no_hp')) ?>"></div>
                <div class="form-group"><label>Peran</label><div><?= badge(ROLE_LABEL[$u['role']] ?? '', 'primary') ?></div></div>
                <button class="btn btn-primary" type="submit"><i class="fas fa-save mr-1"></i> Simpan Profil</button>
            </form>
        </div></div></div>
        <div class="col-lg-6 mb-4"><div class="card"><div class="card-header">Ganti Password</div><div class="card-body">
            <form method="post" action="<?= e(url('akun')) ?>" class="needs-validation" novalidate>
                <?= csrf_field() ?><input type="hidden" name="aksi" value="password">
                <div class="form-group"><label for="pw_lama">Password saat ini <span class="req">*</span></label>
                    <input class="form-control" type="password" id="pw_lama" name="password_lama" required autocomplete="current-password"></div>
                <div class="form-group"><label for="pw_baru">Password baru <span class="req">*</span></label>
                    <input class="form-control" type="password" id="pw_baru" name="password_baru" required minlength="8" autocomplete="new-password"><small class="help">Minimal 8 karakter.</small></div>
                <div class="form-group"><label for="pw_ulang">Ulangi password baru <span class="req">*</span></label>
                    <input class="form-control" type="password" id="pw_ulang" name="password_ulang" required autocomplete="new-password"></div>
                <button class="btn btn-primary" type="submit"><i class="fas fa-key mr-1"></i> Ganti Password</button>
            </form>
        </div></div></div>
    </div>
    <?php
}

function akun_post(array $r): void
{
    $con = db();
    $aksi = post_str('aksi', 20);
    $me = user_id();
    if ($aksi === 'profil') {
        $nama = str_bersih($_POST['nama'] ?? '', 100);
        if (mb_strlen($nama) < 3) throw new AppException('Nama lengkap wajib diisi.');
        $hp = str_bersih($_POST['no_hp'] ?? '', 20);
        db_exec($con, "UPDATE users SET nama = ?, no_hp = ? WHERE id = ?", 'ssi', [$nama, $hp ?: null, $me]);
        $_SESSION['auth']['nama'] = $nama;
        log_aktivitas('UBAH', 'akun', 'Memperbarui profil sendiri');
        flash('success', 'Profil berhasil diperbarui.');
        redirect(url('akun'));
    }
    if ($aksi === 'password') {
        $lama = is_string($_POST['password_lama'] ?? null) ? $_POST['password_lama'] : '';
        $baru = is_string($_POST['password_baru'] ?? null) ? $_POST['password_baru'] : '';
        $ulang = is_string($_POST['password_ulang'] ?? null) ? $_POST['password_ulang'] : '';
        $hash = db_value($con, "SELECT password FROM users WHERE id = ?", 'i', [$me]);
        if (!password_verify($lama, (string)$hash)) throw new AppException('Password saat ini tidak sesuai.');
        if (strlen($baru) < 8) throw new AppException('Password baru minimal 8 karakter.');
        if ($baru !== $ulang) throw new AppException('Konfirmasi password baru tidak sama.');
        if ($baru === $lama) throw new AppException('Password baru harus berbeda dari password lama.');
        db_exec($con, "UPDATE users SET password = ? WHERE id = ?", 'si', [password_hash($baru, PASSWORD_DEFAULT), $me]);
        log_aktivitas('UBAH', 'akun', 'Mengganti password sendiri');
        flash('success', 'Password berhasil diganti.');
        redirect(url('akun'));
    }
    throw new AppException('Aksi tidak dikenali.');
}
