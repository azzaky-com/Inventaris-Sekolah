<?php
// modules/log.php — jejak audit: siapa melakukan apa dan kapan.

function log_render(array $r): void
{
    $con = db();
    $user = get_int('user_id') ?: null;
    $aksi = get_str('aksi_log', 20);
    $dari = tanggal_valid($_GET['dari'] ?? '');
    $sampai = tanggal_valid($_GET['sampai'] ?? '');
    [$where, $tipe, $par] = sql_where([
        ['l.user_id = ?', 'i', $user],
        ['l.aksi = ?', 's', $aksi !== '' ? $aksi : null],
        ['DATE(l.created_at) >= ?', 's', $dari],
        ['DATE(l.created_at) <= ?', 's', $sampai],
    ]);
    $rows = db_all($con,
        "SELECT l.*, u.nama FROM log_aktivitas l LEFT JOIN users u ON u.id = l.user_id
         WHERE $where ORDER BY l.id DESC LIMIT 1000", $tipe, $par);
    $users = db_all($con, "SELECT id, nama FROM users ORDER BY nama");
    $aksiList = db_all($con, "SELECT DISTINCT aksi FROM log_aktivitas ORDER BY aksi");

    echo ui_head('Log Aktivitas', 'Jejak audit seluruh perubahan data. Hanya dapat dilihat oleh Administrator dan Kepala Sekolah.',
        '<a class="btn btn-light btn-sm" href="' . e(base_url() . 'export.php?t=log') . '"><i class="fas fa-file-export mr-1"></i> Ekspor</a>');
    ?>
    <div class="card mb-4"><div class="card-body">
        <form class="toolbar" method="get" action="<?= e(base_url()) ?>">
            <input type="hidden" name="m" value="log">
            <div style="min-width:200px"><label class="small-caps d-block">Pengguna</label>
                <select class="custom-select" name="user_id"><?= opsi_html(array_column($users, 'nama', 'id'), (string)$user, 'Semua pengguna') ?></select></div>
            <div style="min-width:180px"><label class="small-caps d-block">Jenis aksi</label>
                <select class="custom-select" name="aksi_log"><?= opsi_html(array_combine(array_column($aksiList, 'aksi'), array_column($aksiList, 'aksi')), $aksi, 'Semua aksi') ?></select></div>
            <div><label class="small-caps d-block">Dari</label><input class="form-control" type="date" name="dari" value="<?= e($dari ?? '') ?>"></div>
            <div><label class="small-caps d-block">Sampai</label><input class="form-control" type="date" name="sampai" value="<?= e($sampai ?? '') ?>"></div>
            <button class="btn btn-primary" type="submit" style="margin-top:20px">Terapkan</button>
        </form>
    </div></div>
    <div class="card"><div class="table-responsive">
        <table class="table table-sm table-hover datatable" data-order="0:desc" data-pagelength="25">
            <thead><tr><th>Waktu</th><th>Pengguna</th><th>Aksi</th><th>Modul</th><th>Deskripsi</th><th>IP</th></tr></thead>
            <tbody>
            <?php
            $warnaAksi = ['TAMBAH' => 'success', 'UBAH' => 'info', 'HAPUS' => 'danger', 'LOGIN' => 'primary', 'LOGOUT' => 'secondary'];
            foreach ($rows as $x): ?>
            <tr>
                <td class="text-nowrap" data-order="<?= e($x['created_at']) ?>"><?= waktu_indo($x['created_at']) ?></td>
                <td><?= e($x['nama'] ?: $x['username']) ?></td>
                <td><?= badge($x['aksi'], $warnaAksi[$x['aksi']] ?? 'secondary') ?></td>
                <td><span class="mono"><?= e($x['modul']) ?></span></td>
                <td><?= e($x['deskripsi']) ?></td>
                <td class="small text-muted"><?= e($x['ip']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div></div>
    <?php
}
