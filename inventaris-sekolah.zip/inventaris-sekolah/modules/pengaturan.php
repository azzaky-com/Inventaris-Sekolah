<?php
// modules/pengaturan.php — identitas sekolah & penandatangan (dipakai pada kop dan tanda tangan laporan).

const PENGATURAN_FIELD = [
    'nama_instansi'        => ['Nama Sekolah', 100],
    'alamat'               => ['Alamat', 255],
    'kepala_sekolah'       => ['Nama Kepala Sekolah', 100],
    'nip_kepala'           => ['NIP Kepala Sekolah', 30],
    'penanggung_jawab_bmn' => ['Penanggung Jawab BMN', 100],
    'nip_pjbmn'            => ['NIP Penanggung Jawab BMN', 30],
    'tahun_ajaran'         => ['Tahun Ajaran', 20],
];

function pengaturan_render(array $r): void
{
    $cur = pengaturan_all();
    echo ui_head('Pengaturan Sekolah', 'Data ini tampil pada kop laporan, berita acara, dan kolom tanda tangan.');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('pengaturan')) ?>" novalidate>
        <?= csrf_field() ?><input type="hidden" name="aksi" value="simpan">
        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <?php foreach (PENGATURAN_FIELD as $k => [$label, $maks]): ?>
            <div class="form-group"><label for="<?= e($k) ?>"><?= e($label) ?></label>
                <input class="form-control" id="<?= e($k) ?>" name="<?= e($k) ?>" maxlength="<?= (int)$maks ?>" value="<?= e(old($k, $cur[$k] ?? '')) ?>"></div>
            <?php endforeach; ?>
        </div></div></div>
        <div class="col-lg-4"><div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold">Pratinjau kop</h6>
            <div class="small"><strong><?= e($cur['nama_instansi'] ?? '') ?></strong><br><span class="text-muted"><?= e($cur['alamat'] ?? '') ?></span></div>
        </div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-save mr-1"></i> Simpan Pengaturan</button></div>
        </div>
    </form>
    <?php
}

function pengaturan_post(array $r): void
{
    require_perm('pengaturan.kelola');
    $con = db();
    foreach (PENGATURAN_FIELD as $k => [$label, $maks]) {
        $val = str_bersih($_POST[$k] ?? '', $maks);
        db_exec($con, "INSERT INTO pengaturan (kunci, nilai) VALUES (?, ?) ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)", 'ss', [$k, $val]);
    }
    log_aktivitas('UBAH', 'pengaturan', 'Memperbarui pengaturan sekolah');
    flash('success', 'Pengaturan sekolah disimpan.');
    redirect(url('pengaturan'));
}
