<?php
// modules/pemeliharaan.php — pengendalian penumpukan data: arsip log, arsip kartu persediaan, foto yatim, dan kunci login.
//
// Prinsip: data dapat diarsipkan (diunduh sebagai CSV dulu), tetapi tidak dihapus tanpa jejak.
// Kartu persediaan diarsipkan dengan "saldo terbawa", sehingga saldo setiap barang tetap benar.

const PEMELIHARAAN_MIN_HARI = 30; // tidak boleh mengarsipkan data yang lebih baru dari ini

function foto_yatim(mysqli $con): array
{
    $dir = __DIR__ . '/../uploads/barang_rusak/';
    if (!is_dir($dir)) return [];
    $dipakai = array_column(db_all($con, "SELECT foto FROM kerusakan WHERE foto IS NOT NULL"), 'foto');
    $yatim = [];
    foreach (scandir($dir) as $f) {
        if ($f === '.' || $f === '..' || $f[0] === '.') continue;
        if (!in_array($f, $dipakai, true)) $yatim[] = $f;
    }
    return $yatim;
}

/** Arsip per tahun ajaran yang sudah ditutup: unduh lalu arsipkan (kartu persediaan dan log sampai akhir tahun itu). */
function pemeliharaan_tahun_card(mysqli $con): void
{
    $tutup = db_all($con, "SELECT * FROM tahun_ajaran WHERE status = 'Ditutup' ORDER BY tanggal_selesai DESC");
    echo '<div class="card mb-4"><div class="card-header">Arsip per tahun ajaran</div><div class="card-body">';
    if (!$tutup) {
        echo ui_kosong('fa-calendar-check', 'Belum ada tahun ajaran yang ditutup', 'Tutup tahun ajaran di menu Tahun Ajaran, lalu arsipkan datanya di sini.');
    } else {
        echo '<div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Tahun ajaran</th><th>Akhir periode</th><th>Ditutup</th><th class="text-center">Unduh</th><th class="text-center">Arsipkan</th></tr></thead><tbody>';
        foreach ($tutup as $t) {
            $cut = date('Y-m-d', strtotime($t['tanggal_selesai'] . ' +1 day'));
            echo '<tr><td><strong>' . e($t['nama']) . '</strong></td><td>' . tgl_indo($t['tanggal_selesai']) . '</td><td>' . waktu_indo($t['ditutup_pada']) . '</td>'
               . '<td class="text-center text-nowrap"><a class="btn btn-sm btn-light" href="' . e(base_url() . 'export.php?t=mutasi&sampai=' . $t['tanggal_selesai']) . '"><i class="fas fa-file-excel"></i> Kartu persediaan</a> '
               . '<a class="btn btn-sm btn-light" href="' . e(base_url() . 'export.php?t=log&sebelum=' . $cut) . '"><i class="fas fa-file-excel"></i> Log</a></td>'
               . '<td class="text-center"><form method="post" action="' . e(url('pemeliharaan')) . '" class="d-inline" data-confirm="Kartu persediaan dan log tahun ' . e($t['nama']) . ' akan dipindahkan ke arsip. Saldo tetap aman. Lanjutkan?">'
               . csrf_field() . '<input type="hidden" name="aksi" value="arsip_tahun"><input type="hidden" name="id" value="' . (int)$t['id'] . '">'
               . '<label class="small mr-2"><input type="checkbox" name="sudah_unduh" value="1" required> sudah diunduh</label>'
               . '<button class="btn btn-sm btn-warning" type="submit"><i class="fas fa-archive"></i> Arsipkan</button></form></td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div></div>';
}

function pemeliharaan_render(array $r): void
{
    $con = db();
    $stats = db_all($con,
        "SELECT table_name AS t, table_rows AS n, ROUND((data_length + index_length) / 1048576, 2) AS mb
         FROM information_schema.tables
         WHERE table_schema = DATABASE() AND table_name IN ('log_aktivitas','mutasi','barang_masuk','barang_keluar','peminjaman','kerusakan_riwayat','login_throttle')
         ORDER BY mb DESC");
    $namaTabel = ['log_aktivitas' => 'Log aktivitas', 'mutasi' => 'Kartu persediaan (mutasi)', 'barang_masuk' => 'Barang masuk',
                  'barang_keluar' => 'Barang keluar', 'peminjaman' => 'Peminjaman', 'kerusakan_riwayat' => 'Riwayat kerusakan',
                  'login_throttle' => 'Kunci login'];
    $totalMb = array_sum(array_column($stats, 'mb'));
    $tutupAkhir = db_row($con, "SELECT * FROM tahun_ajaran WHERE status = 'Ditutup' ORDER BY tanggal_selesai DESC LIMIT 1");
    $batas = $tutupAkhir ? date('Y-m-d', strtotime($tutupAkhir['tanggal_selesai'] . ' +1 day')) : date('Y-m-d', strtotime('-12 months'));
    $tuaLog = (int)db_value($con, "SELECT COUNT(*) FROM log_aktivitas WHERE created_at < ?", 's', [$batas . ' 00:00:00']);
    $tuaMutasi = (int)db_value($con, "SELECT COUNT(*) FROM mutasi WHERE tanggal < ?", 's', [$batas . ' 00:00:00']);
    $yatim = foto_yatim($con);

    pemeliharaan_tahun_card($con);
    echo ui_head('Pemeliharaan Data', 'Cegah data menumpuk. Arsipkan dulu (unduh CSV), baru hapus. Saldo jumlah tetap aman.', '');
    ?>
    <div class="row">
        <div class="col-lg-5 mb-4"><div class="card h-100">
            <div class="card-header">Ukuran data</div>
            <div class="card-body">
                <div class="kpi-value mb-1"><?= number_format($totalMb, 2, ',', '.') ?> MB</div>
                <div class="small text-muted mb-3">Total tabel yang dipantau</div>
                <table class="table table-sm mb-0"><tbody>
                <?php foreach ($stats as $s): ?>
                    <tr><td><?= e($namaTabel[$s['t']] ?? $s['t']) ?></td><td class="text-right"><?= angka($s['n']) ?> baris</td><td class="text-right text-muted"><?= $s['mb'] ?> MB</td></tr>
                <?php endforeach; ?>
                </tbody></table>
                <?php if ($tuaLog + $tuaMutasi > 0): ?>
                <div class="alert alert-soft alert-warning mt-3 mb-0 small">Ada <?= angka($tuaLog) ?> log dan <?= angka($tuaMutasi) ?> baris kartu persediaan berumur lebih dari 12 bulan.</div>
                <?php else: ?>
                <div class="alert alert-soft alert-success mt-3 mb-0 small">Tidak ada data lama yang perlu diarsipkan.</div>
                <?php endif; ?>
            </div>
        </div></div>

        <div class="col-lg-7 mb-4">
            <div class="card mb-4"><div class="card-body">
                <h6 class="font-weight-bold mb-1">1. Arsipkan log aktivitas</h6>
                <p class="small text-muted mb-3">Log lama jarang dibutuhkan. Unduh arsipnya, lalu hapus log yang lebih lama dari tanggal berikut.</p>
                <form method="post" action="<?= e(url('pemeliharaan')) ?>" class="needs-validation" novalidate>
                    <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus_log">
                    <div class="form-row align-items-end">
                        <div class="form-group col-sm-5 mb-2"><label for="sebelum_log">Log sebelum tanggal</label>
                            <input class="form-control" type="date" id="sebelum_log" name="sebelum" value="<?= e($batas) ?>" max="<?= date('Y-m-d', strtotime('-' . PEMELIHARAAN_MIN_HARI . ' days')) ?>" required></div>
                        <div class="form-group col-sm-7 mb-2">
                            <a class="btn btn-light btn-block" id="linkLog" href="<?= e(base_url() . 'export.php?t=log&sebelum=' . $batas) ?>"><i class="fas fa-file-excel mr-1"></i> 1. Unduh arsip CSV</a></div>
                    </div>
                    <div class="custom-control custom-checkbox mb-3"><input class="custom-control-input" type="checkbox" id="ck_log" name="sudah_unduh" value="1" required>
                        <label class="custom-control-label" for="ck_log">Saya sudah menyimpan arsipnya</label></div>
                    <button class="btn btn-danger" type="submit" data-confirm="Log sebelum tanggal ini akan dihapus permanen. Lanjutkan?"><i class="fas fa-trash mr-1"></i> 2. Hapus log lama</button>
                    <span class="small text-muted ml-2"><?= angka($tuaLog) ?> baris</span>
                </form>
            </div></div>

            <div class="card mb-4"><div class="card-body">
                <h6 class="font-weight-bold mb-1">2. Arsipkan kartu persediaan</h6>
                <p class="small text-muted mb-3">Mutasi sebelum tanggal ini diarsipkan. Setiap barang mendapat satu baris <em>Saldo terbawa dari arsip</em>, sehingga kartu persediaan tetap benar.</p>
                <form method="post" action="<?= e(url('pemeliharaan')) ?>" class="needs-validation" novalidate>
                    <?= csrf_field() ?><input type="hidden" name="aksi" value="arsip_mutasi">
                    <div class="form-row align-items-end">
                        <div class="form-group col-sm-5 mb-2"><label for="sebelum_mut">Mutasi sebelum tanggal</label>
                            <input class="form-control" type="date" id="sebelum_mut" name="sebelum" value="<?= e($batas) ?>" max="<?= date('Y-m-d', strtotime('-' . PEMELIHARAAN_MIN_HARI . ' days')) ?>" required></div>
                        <div class="form-group col-sm-7 mb-2">
                            <a class="btn btn-light btn-block" id="linkMut" href="<?= e(base_url() . 'export.php?t=mutasi&sampai=' . date('Y-m-d', strtotime($batas . ' -1 day'))) ?>"><i class="fas fa-file-excel mr-1"></i> 1. Unduh arsip CSV</a></div>
                    </div>
                    <div class="custom-control custom-checkbox mb-3"><input class="custom-control-input" type="checkbox" id="ck_mut" name="sudah_unduh" value="1" required>
                        <label class="custom-control-label" for="ck_mut">Saya sudah menyimpan arsipnya</label></div>
                    <button class="btn btn-warning" type="submit" data-confirm="Mutasi sebelum tanggal ini akan dipindahkan ke saldo terbawa. Lanjutkan?"><i class="fas fa-archive mr-1"></i> 2. Arsipkan kartu persediaan</button>
                    <span class="small text-muted ml-2"><?= angka($tuaMutasi) ?> baris</span>
                </form>
            </div></div>

            <div class="card mb-4"><div class="card-body d-flex flex-wrap justify-content-between align-items-center" style="gap:12px">
                <div><h6 class="font-weight-bold mb-1">3. Foto kerusakan yang tidak terpakai</h6>
                    <p class="small text-muted mb-0"><?= angka(count($yatim)) ?> file foto tidak lagi terhubung ke laporan kerusakan.</p></div>
                <form method="post" action="<?= e(url('pemeliharaan')) ?>">
                    <?= csrf_field() ?><input type="hidden" name="aksi" value="bersih_foto">
                    <button class="btn btn-light" type="submit" <?= $yatim ? '' : 'disabled' ?> data-confirm="Hapus semua foto yang tidak terhubung ke laporan?"><i class="fas fa-image mr-1"></i> Bersihkan</button>
                </form>
            </div></div>

            <div class="card"><div class="card-body d-flex flex-wrap justify-content-between align-items-center" style="gap:12px">
                <div><h6 class="font-weight-bold mb-1">4. Kunci login kedaluwarsa</h6>
                    <p class="small text-muted mb-0">Dibersihkan otomatis setiap kali ada login. Tombol ini untuk membersihkan sekarang.</p></div>
                <form method="post" action="<?= e(url('pemeliharaan')) ?>">
                    <?= csrf_field() ?><input type="hidden" name="aksi" value="bersih_login">
                    <button class="btn btn-light" type="submit"><i class="fas fa-user-clock mr-1"></i> Bersihkan</button>
                </form>
            </div></div>
        </div>
    </div>
    <?php
    $GLOBALS['page_js'] = '
    $("#sebelum_log").on("change", function(){ $("#linkLog").attr("href", ' . ui_js(base_url() . 'export.php?t=log&sebelum=') . ' + this.value); });
    $("#sebelum_mut").on("change", function(){
      var d = new Date(this.value); d.setDate(d.getDate() - 1);
      $("#linkMut").attr("href", ' . ui_js(base_url() . 'export.php?t=mutasi&sampai=') . ' + d.toISOString().slice(0,10));
    });';
}

function pemeliharaan_post(array $r): void
{
    require_perm('pengaturan.kelola');
    $con = db();
    $aksi = post_str('aksi', 20);
    $min = date('Y-m-d', strtotime('-' . PEMELIHARAAN_MIN_HARI . ' days'));

    if ($aksi === 'arsip_tahun') {
        if (empty($_POST['sudah_unduh'])) throw new AppException('Unduh arsip terlebih dahulu, lalu centang konfirmasi.');
        $t = db_row($con, "SELECT * FROM tahun_ajaran WHERE id = ? AND status = 'Ditutup'", 'i', [post_int('id')]);
        if (!$t) throw new AppException('Tahun ajaran tidak ditemukan atau belum ditutup.');
        $cut = date('Y-m-d', strtotime($t['tanggal_selesai'] . ' +1 day'));
        $logN = db_exec($con, "DELETE FROM log_aktivitas WHERE created_at < ?", 's', [$cut . ' 00:00:00'])['affected'];
        $mutN = arsip_mutasi_sebelum($con, $cut . ' 00:00:00', 'tahun ajaran ' . $t['nama']);
        log_aktivitas('HAPUS', 'pemeliharaan', "Mengarsipkan tahun ajaran {$t['nama']}: {$mutN} mutasi, {$logN} log");
        flash('success', "Arsip tahun ajaran {$t['nama']} selesai: {$mutN} baris kartu persediaan dan {$logN} log dipindahkan. Saldo tetap aman.");
        redirect(url('pemeliharaan'));
    }

    if ($aksi === 'hapus_log' || $aksi === 'arsip_mutasi') {
        if (empty($_POST['sudah_unduh'])) throw new AppException('Unduh arsip CSV terlebih dahulu, lalu centang konfirmasi.');
        $tgl = tanggal_valid($_POST['sebelum'] ?? '');
        if (!$tgl) throw new AppException('Tanggal tidak valid.');
        if ($tgl > $min) throw new AppException('Data dalam ' . PEMELIHARAAN_MIN_HARI . ' hari terakhir tidak dapat diarsipkan.');
        $batas = $tgl . ' 00:00:00';

        if ($aksi === 'hapus_log') {
            $n = db_exec($con, "DELETE FROM log_aktivitas WHERE created_at < ?", 's', [$batas])['affected'];
            log_aktivitas('HAPUS', 'pemeliharaan', "Menghapus {$n} log sebelum " . tgl_indo($tgl));
            flash('success', angka($n) . ' log lama dihapus. Arsip CSV tetap tersimpan di komputer Anda.');
            redirect(url('pemeliharaan'));
        }

        // arsip_mutasi: jumlah perubahan sebelum tanggal dipindahkan ke satu baris "saldo terbawa"
        $n = $aksi === 'arsip_mutasi' ? arsip_mutasi_sebelum($con, $batas, 'sebelum ' . tgl_indo($tgl)) : 0;
        flash('success', angka($n) . ' baris kartu persediaan diarsipkan. Saldo setiap barang tetap sama.');
        redirect(url('pemeliharaan'));
    }

    if ($aksi === 'bersih_foto') {
        $dir = __DIR__ . '/../uploads/barang_rusak/';
        $n = 0;
        foreach (foto_yatim($con) as $f) { if (@unlink($dir . $f)) $n++; }
        log_aktivitas('HAPUS', 'pemeliharaan', "Membersihkan {$n} foto kerusakan yang tidak terpakai");
        flash('success', angka($n) . ' foto tidak terpakai dihapus.');
        redirect(url('pemeliharaan'));
    }

    if ($aksi === 'bersih_login') {
        $n = db_exec($con, "DELETE FROM login_throttle WHERE terkunci_sampai IS NULL OR terkunci_sampai < NOW()")['affected'];
        flash('success', angka($n) . ' catatan kunci login dibersihkan.');
        redirect(url('pemeliharaan'));
    }
    throw new AppException('Aksi tidak dikenali.');
}
