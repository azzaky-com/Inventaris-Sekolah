<?php
// modules/transaksi_keluar.php — pemakaian barang habis pakai dan pengeluaran aset dari ruangan.

function keluar_render(array $r): void
{
    $con = db();
    if (get_str('aksi', 20) === 'tambah') { keluar_render_form(); return; }

    $dari = tanggal_valid($_GET['dari'] ?? '') ?: date('Y-01-01');
    $sampai = tanggal_valid($_GET['sampai'] ?? '') ?: date('Y-m-d');
    [$where, $tipe, $par] = sql_where([['t.tanggal >= ?', 's', $dari], ['t.tanggal <= ?', 's', $sampai]]);
    $rows = db_all($con,
        "SELECT t.*, b.kode_barang, b.nama_barang, b.satuan, b.jenis_barang, COALESCE(l.nama, '-') AS lokasi
         FROM barang_keluar t JOIN barang b ON b.id = t.barang_id LEFT JOIN lokasi l ON l.id = t.lokasi_id
         WHERE $where ORDER BY t.tanggal DESC, t.id DESC LIMIT 1000", $tipe, $par);
    $pemakaian = array_filter($rows, function ($x) { return $x['alasan'] === 'Pemakaian Operasional'; });

    echo ui_head('Pemakaian & Keluar', 'Pemakaian barang habis pakai dicatat di sini. Pengeluaran aset (distribusi, hibah, pindah) juga dicatat di sini.',
        (can('transaksi.input') ? '<a class="btn btn-primary btn-sm" href="' . e(url('keluar', ['aksi' => 'tambah'])) . '"><i class="fas fa-plus mr-1"></i> Catat Pemakaian / Keluar</a>' : ''));
    ?>
    <div class="row">
        <div class="col-md-4 mb-4"><?= ui_kpi('teal', 'fa-tint', 'Pemakaian (periode)', angka(count($pemakaian)), 'transaksi') ?></div>
        <div class="col-md-4 mb-4"><?= ui_kpi('amber', 'fa-dolly', 'Total transaksi keluar', angka(count($rows))) ?></div>
        <div class="col-md-4 mb-4"><?= ui_kpi('violet', 'fa-cubes', 'Unit keluar', angka(array_sum(array_column($rows, 'jumlah')))) ?></div>
    </div>
    <div class="card mb-4"><div class="card-body">
        <form class="toolbar" method="get" action="<?= e(base_url()) ?>">
            <input type="hidden" name="m" value="keluar">
            <div><label class="small-caps d-block">Dari</label><input class="form-control" type="date" name="dari" value="<?= e($dari) ?>"></div>
            <div><label class="small-caps d-block">Sampai</label><input class="form-control" type="date" name="sampai" value="<?= e($sampai) ?>"></div>
            <button class="btn btn-primary" type="submit" style="margin-top:20px">Terapkan</button>
        </form>
    </div></div>
    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover datatable" data-order="0:desc" data-nosort="7">
                <thead><tr><th>Tanggal</th><th>Barang</th><th>Dari ruangan</th><th class="text-right">Jumlah</th><th>Alasan</th><th>Penerima / unit</th><th>Keterangan</th><th class="text-center">Aksi</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $x): ?>
                <tr>
                    <td class="text-nowrap" data-order="<?= e($x['tanggal']) ?>"><?= tgl_indo($x['tanggal']) ?></td>
                    <td><strong><?= e($x['nama_barang']) ?></strong><span class="sub"><?= $x['jenis_barang'] === 'habis_pakai' ? badge('Habis pakai', 'info') : badge('Aset', 'primary') ?> <span class="mono"><?= e($x['kode_barang']) ?></span></span></td>
                    <td><?= e($x['lokasi']) ?></td>
                    <td class="text-right font-weight-bold">−<?= angka($x['jumlah']) ?> <span class="text-muted small"><?= e($x['satuan']) ?></span></td>
                    <td><?= e($x['alasan']) ?></td>
                    <td><?= e($x['penerima'] ?: '-') ?></td>
                    <td><?= e($x['keterangan']) ?></td>
                    <td class="text-center">
                        <?php if (can('transaksi.input')): ?>
                        <form method="post" action="<?= e(url('keluar')) ?>" class="d-inline" data-confirm="Membatalkan transaksi ini akan mengembalikan jumlah <?= (int)$x['jumlah'] ?> unit. Lanjutkan?">
                            <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
                            <button class="btn btn-sm btn-icon btn-light text-danger" type="submit" title="Batalkan" data-toggle="tooltip"><i class="fas fa-undo"></i></button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

function keluar_render_form(): void
{
    require_perm('transaksi.input');
    $con = db();
    $barang = daftar_barang_saldo($con);
    echo ui_head('Catat Pemakaian / Keluar', 'Pilih ruangan asal. Jumlah dibatasi pada jumlah yang tersedia di ruangan tersebut.',
        '<a class="btn btn-light btn-sm" href="' . e(url('keluar')) . '"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('keluar', ['aksi' => 'tambah'])) ?>" novalidate>
        <?= csrf_field() ?><input type="hidden" name="aksi" value="simpan">
        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <div class="form-row">
                <div class="form-group col-md-6"><label for="tanggal">Tanggal <span class="req">*</span></label>
                    <input class="form-control" type="date" id="tanggal" name="tanggal" required max="<?= date('Y-m-d') ?>" value="<?= e(old('tanggal', date('Y-m-d'))) ?>"></div>
                <div class="form-group col-md-6"><label for="alasan">Alasan <span class="req">*</span></label>
                    <select class="custom-select" id="alasan" name="alasan" required><?= opsi_html(array_combine(ALASAN_KELUAR, ALASAN_KELUAR), (string)old('alasan', 'Pemakaian Operasional')) ?></select></div>
            </div>
            <div class="form-group"><label for="barang_id">Barang <span class="req">*</span></label>
                <select class="custom-select select2" id="barang_id" name="barang_id" required data-placeholder="Cari barang…"><?= opsi_barang($barang, (int)old('barang_id'), false) ?></select></div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="lokasi_id">Dari ruangan <span class="req">*</span></label>
                    <select class="custom-select" id="lokasi_id" name="lokasi_id" required><option value="">-- Pilih barang dulu --</option></select>
                    <small class="help" id="hintLokasi"></small></div>
                <div class="form-group col-md-6"><label for="jumlah">Jumlah <span class="req">*</span></label>
                    <input class="form-control" type="number" id="jumlah" name="jumlah" min="1" required value="<?= e(old('jumlah')) ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="penerima">Penerima / unit tujuan</label>
                    <input class="form-control" id="penerima" name="penerima" maxlength="100" value="<?= e(old('penerima')) ?>" placeholder="Contoh: Kelas VIII B / Ruang Guru"></div>
                <div class="form-group col-md-6"><label for="keterangan">Keterangan</label>
                    <input class="form-control" id="keterangan" name="keterangan" maxlength="255" value="<?= e(old('keterangan')) ?>"></div>
            </div>
        </div></div></div>
        <div class="col-lg-4"><button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-save mr-1"></i> Simpan</button></div>
        </div>
    </form>
    <?php
    $GLOBALS['page_js'] = '$("#barang_id").on("change", function(){ isiLokasi(this.value, "#lokasi_id", "#hintLokasi"); }); if ($("#barang_id").val()) $("#barang_id").trigger("change");';
}

function keluar_post(array $r): void
{
    require_perm('transaksi.input');
    $con = db();
    $aksi = post_str('aksi', 20);
    if ($aksi === 'hapus') {
        transaksi_keluar_hapus($con, post_int('id'));
        flash('success', 'Transaksi dibatalkan dan jumlah dikembalikan.');
        redirect(url('keluar'));
    }
    if ($aksi !== 'simpan') throw new AppException('Aksi tidak dikenali.');
    $tgl = tanggal_valid($_POST['tanggal'] ?? '');
    if (!$tgl || $tgl > date('Y-m-d')) throw new AppException('Tanggal tidak valid.');
    $barang = post_int('barang_id');
    if (!$barang) throw new AppException('Pilih barang.');
    $jumlah = post_int('jumlah');
    if ($jumlah < 1) throw new AppException('Jumlah harus minimal 1.');
    $alasan = in_array($_POST['alasan'] ?? '', ALASAN_KELUAR, true) ? $_POST['alasan'] : null;
    if ($alasan === null) throw new AppException('Pilih alasan pengeluaran.');
    transaksi_keluar_tambah($con, [
        'tanggal' => $tgl, 'barang_id' => $barang, 'lokasi_id' => post_int('lokasi_id') ?: null, 'jumlah' => $jumlah,
        'alasan' => $alasan, 'penerima' => post_str('penerima', 100), 'keterangan' => post_str('keterangan', 255),
    ]);
    flash('success', 'Pemakaian/pengeluaran dicatat dan jumlah di ruangan telah diperbarui.');
    redirect(url('keluar'));
}
