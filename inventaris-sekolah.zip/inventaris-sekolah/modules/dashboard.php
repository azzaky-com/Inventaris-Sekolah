<?php
// modules/dashboard.php — beranda yang disesuaikan per peran.

function dashboard_render(array $r): void
{
    $role = user_role();
    if ($role === 'operator') { dash_operator(); return; }
    if ($role === 'kepala_sekolah') { dash_kepala(); return; }
    dash_admin();
}

/** Angka dasar yang dipakai beberapa peran. */
function dash_dasar(mysqli $con): array
{
    return db_row($con,
        "SELECT
           (SELECT COUNT(*) FROM barang WHERE aktif = 1) AS jenis,
           (SELECT COUNT(*) FROM barang WHERE aktif = 1 AND jenis_barang = 'habis_pakai') AS jenis_habis,
           (SELECT COALESCE(SUM(stok_total),0) FROM barang WHERE aktif = 1) AS unit,
           (SELECT COALESCE(SUM(sisa),0) FROM peminjaman WHERE status = 'Dipinjam') AS dipinjam,
           (SELECT COUNT(*) FROM peminjaman WHERE status = 'Dipinjam' AND tanggal_rencana_kembali < CURDATE()) AS terlambat,
           (SELECT COUNT(*) FROM peminjaman WHERE status = 'Dipinjam' AND tanggal_rencana_kembali BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)) AS jatuh_tempo,
           (SELECT COALESCE(SUM(jumlah),0) FROM kerusakan WHERE status NOT IN ('Selesai','Rusak Permanen')) AS rusak,
           (SELECT COUNT(*) FROM kerusakan WHERE status = 'Menunggu Persetujuan') AS menunggu,
           (SELECT COUNT(*) FROM kerusakan WHERE status IN ('Dilaporkan','Diperiksa')) AS belum_diproses,
           (SELECT COUNT(*) FROM stok_opname WHERE status = 'Draft') AS opname_draft,
           (SELECT COUNT(*) FROM barang_masuk WHERE status = 'Menunggu') AS pending_masuk,
           (SELECT COUNT(*) FROM penghapusan WHERE status = 'Diusulkan') AS usul_hapus");
}

/** Barang habis pakai beserta sisa hari, diurutkan dari yang paling mendesak. */
function dash_habis_pakai(mysqli $con): array
{
    $est = estimasi_pemakaian_semua($con);
    $rows = db_all($con,
        "SELECT b.id, b.kode_barang, b.nama_barang, b.satuan, b.stok_minimum, b.stok_total
         FROM barang b WHERE b.aktif = 1 AND b.jenis_barang = 'habis_pakai'");
    $out = [];
    foreach ($rows as $b) {
        $tersedia = (int)$b['stok_total'];
        $e = estimasi_sisa_pakai($est[(int)$b['id']] ?? null, $tersedia);
        $out[] = ['b' => $b, 'tersedia' => $tersedia, 'e' => $e];
    }
    usort($out, function ($x, $y) {
        $sx = $x['e']['ok'] ? $x['e']['sisa_hari'] : 99999;
        $sy = $y['e']['ok'] ? $y['e']['sisa_hari'] : 99999;
        return $sx <=> $sy;
    });
    return $out;
}

/** Nilai aset: sumber untuk kartu & grafik peran kepala sekolah dan admin. */
function dash_aset(mysqli $con): array
{
    $rows = aset_daftar($con);
    return ['rows' => $rows, 'ringkas' => aset_ringkas($rows)];
}

function dash_operator(): void
{
    $con = db();
    $k = dash_dasar($con);
    $habis = dash_habis_pakai($con);
    $perluPesan = array_values(array_filter($habis, function ($x) { return $x['e']['ok'] && $x['e']['status'] !== 'aman'; }));
    $terlambat = db_all($con,
        "SELECT p.id, p.peminjam, p.unit, p.sisa AS jumlah, p.tanggal_rencana_kembali, b.nama_barang,
                DATEDIFF(CURDATE(), p.tanggal_rencana_kembali) AS hari
         FROM peminjaman p JOIN barang b ON b.id = p.barang_id
         WHERE p.status = 'Dipinjam' AND p.tanggal_rencana_kembali < CURDATE() ORDER BY p.tanggal_rencana_kembali ASC LIMIT 6");
    $tugasRusak = db_all($con,
        "SELECT x.id, x.jumlah, x.status, x.tanggal_lapor, b.nama_barang FROM kerusakan x JOIN barang b ON b.id = x.barang_id
         WHERE x.status IN ('Dilaporkan','Diperiksa') ORDER BY x.tanggal_lapor ASC LIMIT 6");

    echo ui_head('Halo, ' . user_nama() . ' 👋', 'Berikut hal yang perlu Anda tindak lanjuti hari ini.', '');
    ?>
    <div class="quick-bar mb-4">
        <a class="quick-action" href="<?= e(url('keluar', ['aksi' => 'tambah'])) ?>"><span class="qa-icon bg-soft-info"><i class="fas fa-tint"></i></span><span><strong>Catat pemakaian</strong><small>Pulpen, kertas, tinta</small></span></a>
        <a class="quick-action" href="<?= e(url('peminjaman', ['aksi' => 'tambah'])) ?>"><span class="qa-icon bg-soft-success"><i class="fas fa-hand-holding"></i></span><span><strong>Pinjamkan aset</strong><small>Laptop, proyektor, dll.</small></span></a>
        <a class="quick-action" href="<?= e(url('kerusakan', ['aksi' => 'tambah'])) ?>"><span class="qa-icon bg-soft-danger"><i class="fas fa-tools"></i></span><span><strong>Lapor kerusakan</strong><small>Aset yang rusak</small></span></a>
        <a class="quick-action" href="<?= e(url('masuk', ['aksi' => 'tambah'])) ?>"><span class="qa-icon bg-soft-primary"><i class="fas fa-truck-loading"></i></span><span><strong>Barang masuk</strong><small>Pembelian & penerimaan</small></span></a>
    </div>

    <div class="row">
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('rose', 'fa-clock', 'Peminjaman terlambat', angka($k['terlambat']), '<a href="' . e(url('peminjaman', ['status' => 'Terlambat'])) . '">Tindak lanjut →</a>') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('amber', 'fa-bell', 'Jatuh tempo ≤ 3 hari', angka($k['jatuh_tempo']), 'Ingatkan peminjam') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('teal', 'fa-hourglass-half', 'Habis pakai perlu dipesan', angka(count($perluPesan)), 'Sisa jumlah ≤ 30 hari') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('blue', 'fa-clipboard-list', 'Laporan belum diproses', angka($k['belum_diproses']), 'Status dilaporkan / diperiksa') ?></div>
    </div>

    <div class="row">
        <div class="col-xl-6 mb-4"><div class="card h-100">
            <div class="card-header">Habis pakai yang perlu dipesan <a class="small" href="<?= e(url('barang', ['jenis' => 'habis_pakai'])) ?>">Semua</a></div>
            <div class="card-body">
                <?php if (!$perluPesan): ?>
                    <?= ui_kosong('fa-check-circle', 'Persediaan habis pakai aman', 'Tidak ada yang diperkirakan habis dalam 30 hari.') ?>
                <?php else: ?>
                <ul class="list-clean">
                <?php foreach (array_slice($perluPesan, 0, 7) as $x): $e = $x['e']; ?>
                    <li>
                        <div class="li-main"><strong><?= e($x['b']['nama_barang']) ?></strong>
                            <small>Tersedia <?= angka($x['tersedia']) ?> <?= e($x['b']['satuan']) ?> · saran pesan <?= angka($e['saran_pesan']) ?></small></div>
                        <?= $e['status'] === 'darurat' ? badge('±' . angka($e['sisa_hari']) . ' hari', 'danger') : badge('±' . angka($e['sisa_hari']) . ' hari', 'warning') ?>
                    </li>
                <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div></div>

        <div class="col-xl-6 mb-4"><div class="card h-100">
            <div class="card-header">Peminjaman terlambat <a class="small" href="<?= e(url('peminjaman', ['status' => 'Terlambat'])) ?>">Semua</a></div>
            <div class="card-body">
                <?php if (!$terlambat): ?>
                    <?= ui_kosong('fa-smile', 'Tidak ada keterlambatan', 'Semua peminjaman masih dalam tenggat.') ?>
                <?php else: ?>
                <ul class="list-clean">
                <?php foreach ($terlambat as $t): ?>
                    <li>
                        <div class="li-main"><strong><?= e($t['nama_barang']) ?> × <?= (int)$t['jumlah'] ?></strong>
                            <small><?= e($t['peminjam']) ?> · <?= e($t['unit'] ?: '-') ?></small></div>
                        <?= badge('Terlambat ' . (int)$t['hari'] . ' hari', 'danger') ?>
                    </li>
                <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div></div>

        <div class="col-12 mb-4"><div class="card">
            <div class="card-header">Laporan kerusakan yang belum diproses <a class="small" href="<?= e(url('kerusakan')) ?>">Buka daftar</a></div>
            <div class="card-body">
                <?php if (!$tugasRusak): ?>
                    <?= ui_kosong('fa-check-circle', 'Semua laporan sudah diproses') ?>
                <?php else: ?>
                <ul class="list-clean">
                <?php foreach ($tugasRusak as $x): ?>
                    <li>
                        <div class="li-main"><strong><?= e($x['nama_barang']) ?> × <?= (int)$x['jumlah'] ?></strong>
                            <small>Dilaporkan <?= tgl_indo($x['tanggal_lapor']) ?></small></div>
                        <?= badge_status($x['status']) ?>
                        <a class="btn btn-sm btn-light" href="<?= e(url('kerusakan', ['aksi' => 'detail', 'id' => $x['id']])) ?>">Proses</a>
                    </li>
                <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div></div>
    </div>
    <?php
}

function dash_kepala(): void
{
    $con = db();
    $k = dash_dasar($con);
    $a = dash_aset($con);
    $t = $a['ringkas'];
    $antrean = db_all($con,
        "SELECT x.id, x.jumlah, x.estimasi_biaya, x.tanggal_lapor, b.nama_barang FROM kerusakan x JOIN barang b ON b.id = x.barang_id
         WHERE x.status = 'Menunggu Persetujuan' ORDER BY x.tanggal_lapor ASC LIMIT 6");
    $keputusan = db_all($con,
        "SELECT r.status_baru, r.catatan, r.user_nama, r.created_at, x.id AS kid, b.nama_barang
         FROM kerusakan_riwayat r JOIN kerusakan x ON x.id = r.kerusakan_id JOIN barang b ON b.id = x.barang_id
         WHERE r.status_baru IN ('Dalam Perbaikan','Rusak Permanen','Selesai') ORDER BY r.id DESC LIMIT 6");
    $perluSusut = $a['rows'];
    usort($perluSusut, function ($x, $y) {
        $sx = $x['p']['ok'] ? $x['p']['sisa_bulan'] : 99999;
        $sy = $y['p']['ok'] ? $y['p']['sisa_bulan'] : 99999;
        return $sx <=> $sy;
    });
    $perluSusut = array_slice($perluSusut, 0, 6);

    echo ui_head('Ringkasan untuk Kepala Sekolah', 'Persetujuan, nilai aset, dan aset yang mendekati akhir masa manfaat.', '');
    ?>
    <div class="row">
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('amber', 'fa-file-signature', 'Menunggu persetujuan', angka($k['menunggu'] + $k['pending_masuk'] + $k['usul_hapus']), '<a href="' . e(url('persetujuan')) . '">Tinjau sekarang →</a>') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('blue', 'fa-coins', 'Nilai buku aset', rupiah($t['buku']), 'Setelah penyusutan') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('violet', 'fa-chart-line', 'Penyusutan per tahun', rupiah($t['per_tahun']), 'Perkiraan') ?></div>
        <div class="col-6 col-xl-3 mb-4"><?= ui_kpi('rose', 'fa-hourglass-end', 'Aset habis / segera habis', angka($t['habis'] + $t['segera']), angka($t['habis']) . ' habis masa manfaat') ?></div>
    </div>

    <div class="row">
        <div class="col-xl-6 mb-4"><div class="card h-100">
            <div class="card-header">Antrean persetujuan <a class="small" href="<?= e(url('persetujuan')) ?>">Buka</a></div>
            <div class="card-body">
                <?php
                $antreanKep = [];
                foreach (db_all($con, "SELECT t.id, t.jumlah, t.harga_satuan, t.tanggal, b.nama_barang FROM barang_masuk t JOIN barang b ON b.id = t.barang_id WHERE t.status = 'Menunggu' ORDER BY t.tanggal ASC LIMIT 5") as $m) {
                    $antreanKep[] = ['jenis' => 'Pembelian', 'judul' => $m['nama_barang'] . ' × ' . (int)$m['jumlah'],
                        'info' => 'Nilai ' . rupiah((int)$m['jumlah'] * (float)$m['harga_satuan']), 'tgl' => $m['tanggal']];
                }
                foreach (db_all($con, "SELECT p.id, p.jumlah, p.tanggal_usul, b.nama_barang FROM penghapusan p JOIN barang b ON b.id = p.barang_id WHERE p.status = 'Diusulkan' ORDER BY p.tanggal_usul ASC LIMIT 5") as $u) {
                    $antreanKep[] = ['jenis' => 'Penghapusan', 'judul' => $u['nama_barang'] . ' × ' . (int)$u['jumlah'],
                        'info' => 'Usulan penghapusan aset', 'tgl' => $u['tanggal_usul']];
                }
                foreach (db_all($con, "SELECT x.id, x.jumlah, x.estimasi_biaya, x.tanggal_lapor, b.nama_barang FROM kerusakan x JOIN barang b ON b.id = x.barang_id WHERE x.status = 'Menunggu Persetujuan' ORDER BY x.tanggal_lapor ASC LIMIT 5") as $x) {
                    $antreanKep[] = ['jenis' => 'Perbaikan', 'judul' => $x['nama_barang'] . ' × ' . (int)$x['jumlah'],
                        'info' => rusak_kode((int)$x['id']) . ' · estimasi ' . rupiah($x['estimasi_biaya']), 'tgl' => $x['tanggal_lapor']];
                }
                usort($antreanKep, function ($p, $q) { return strcmp($p['tgl'], $q['tgl']); });
                ?>
                <?php if (!$antreanKep): ?>
                    <?= ui_kosong('fa-check-double', 'Tidak ada antrean', 'Semua pengajuan sudah diputuskan.') ?>
                <?php else: ?>
                <ul class="list-clean">
                <?php foreach (array_slice($antreanKep, 0, 7) as $it): ?>
                    <li><div class="li-main"><strong><?= e($it['judul']) ?></strong>
                        <small><?= e($it['info']) ?> · diajukan <?= tgl_indo($it['tgl']) ?></small></div>
                        <?= badge($it['jenis'], $it['jenis'] === 'Pembelian' ? 'primary' : ($it['jenis'] === 'Penghapusan' ? 'danger' : 'warning')) ?></li>
                <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div></div>

        <div class="col-xl-6 mb-4"><div class="card h-100">
            <div class="card-header">Aset mendekati akhir masa manfaat <a class="small" href="<?= e(url('aset')) ?>">Semua aset</a></div>
            <div class="card-body">
                <ul class="list-clean">
                <?php foreach ($perluSusut as $x): if (!$x['p']['ok']) continue; ?>
                    <li><div class="li-main"><strong><?= e($x['nama_barang']) ?></strong>
                        <small>Nilai buku <?= rupiah($x['p']['nilai_buku_total']) ?> · habis sekitar <?= tgl_indo($x['p']['tgl_habis']) ?></small></div>
                        <?= badge(label_sisa_bulan($x['p']['sisa_bulan']), $x['p']['status'] === 'berjalan' ? 'info' : 'warning') ?></li>
                <?php endforeach; ?>
                </ul>
            </div>
        </div></div>

        <div class="col-12 mb-4"><div class="card">
            <div class="card-header">Keputusan terbaru</div>
            <div class="card-body">
                <?php if (!$keputusan): ?>
                    <?= ui_kosong('fa-history', 'Belum ada keputusan') ?>
                <?php else: ?>
                <ul class="list-clean">
                <?php foreach ($keputusan as $h): ?>
                    <li><div class="li-main"><strong><?= e($h['nama_barang']) ?> — <?= e($h['status_baru']) ?></strong>
                        <small><?= e($h['user_nama']) ?> · <?= waktu_indo($h['created_at']) ?><?= $h['catatan'] ? ' · ' . e(potong($h['catatan'], 80)) : '' ?></small></div>
                        <a class="small" href="<?= e(url('kerusakan', ['aksi' => 'detail', 'id' => $h['kid']])) ?>">Lihat</a></li>
                <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div></div>
    </div>
    <?php
}

function dash_admin(): void
{
    $con = db();
    $k = dash_dasar($con);
    $a = dash_aset($con);
    $t = $a['ringkas'];
    $habis = dash_habis_pakai($con);
    $perluPesan = array_values(array_filter($habis, function ($x) { return $x['e']['ok'] && $x['e']['status'] !== 'aman'; }));
    $terlambat = db_all($con,
        "SELECT p.peminjam, p.sisa AS jumlah, p.tanggal_rencana_kembali, b.nama_barang, DATEDIFF(CURDATE(), p.tanggal_rencana_kembali) AS hari
         FROM peminjaman p JOIN barang b ON b.id = p.barang_id WHERE p.status = 'Dipinjam' AND p.tanggal_rencana_kembali < CURDATE()
         ORDER BY p.tanggal_rencana_kembali ASC LIMIT 5");
    $aktivitas = db_all($con, "SELECT username, aksi, deskripsi, created_at FROM log_aktivitas ORDER BY id DESC LIMIT 6");
    $tutupTerakhir = db_row($con, "SELECT * FROM tahun_ajaran WHERE status = 'Ditutup' ORDER BY tanggal_selesai DESC LIMIT 1");
    $tuaLog = 0; $tuaMutasi = 0;
    if ($tutupTerakhir) {
        $batasTahun = $tutupTerakhir['tanggal_selesai'] . ' 23:59:59';
        $tuaLog = (int)db_value($con, "SELECT COUNT(*) FROM log_aktivitas WHERE created_at <= ?", 's', [$batasTahun]);
        $tuaMutasi = (int)db_value($con, "SELECT COUNT(*) FROM mutasi WHERE tanggal <= ? AND jenis <> 'saldo_awal'", 's', [$batasTahun]);
    }


    $nilaiKat = [];
    foreach ($a['rows'] as $r) {
        if (!$r['p']['ok']) continue;
        $nilaiKat[$r['kategori']] = ($nilaiKat[$r['kategori']] ?? 0) + $r['p']['nilai_buku_total'];
    }
    arsort($nilaiKat);

    echo ui_head('Beranda', 'Gambaran menyeluruh aset dan barang sekolah.', '<a class="btn btn-light btn-sm" href="' . e(url('aset')) . '"><i class="fas fa-chart-line mr-1"></i> Nilai Aset</a>');
    ?>
    <div class="row">
        <div class="col-6 col-xl-2 mb-4"><?= ui_kpi('blue', 'fa-boxes', 'Jenis barang', angka($k['jenis']), angka($k['jenis_habis']) . ' habis pakai') ?></div>
        <div class="col-6 col-xl-2 mb-4"><?= ui_kpi('teal', 'fa-cubes', 'Total unit', angka($k['unit']), angka($k['dipinjam']) . ' sedang dipinjam') ?></div>
        <div class="col-6 col-xl-2 mb-4"><?= ui_kpi('green', 'fa-coins', 'Nilai buku aset', rupiah($t['buku']), 'Perkiraan') ?></div>
        <div class="col-6 col-xl-2 mb-4"><?= ui_kpi('rose', 'fa-clock', 'Terlambat', angka($k['terlambat']), 'Peminjaman') ?></div>
        <div class="col-6 col-xl-2 mb-4"><?= ui_kpi('amber', 'fa-tools', 'Unit rusak', angka($k['rusak']), angka($k['menunggu']) . ' menunggu persetujuan') ?></div>
        <div class="col-6 col-xl-2 mb-4"><?= ui_kpi('violet', 'fa-tint', 'Habis pakai perlu dipesan', angka(count($perluPesan)), '≤ 30 hari') ?></div>
    </div>

    <?php if ($tuaLog + $tuaMutasi > 0): ?>
    <div class="alert alert-soft alert-info d-flex flex-wrap justify-content-between align-items-center mb-4" style="gap:10px">
        <span><i class="fas fa-database mr-1"></i> Tahun ajaran <strong><?= e($tutupTerakhir['nama'] ?? '') ?></strong> sudah ditutup dan masih punya <strong><?= angka($tuaLog + $tuaMutasi) ?></strong> catatan rinci. Arsipkan agar aplikasi tetap cepat.</span>
        <a class="btn btn-sm btn-light" href="<?= e(url('pemeliharaan')) ?>">Buka Pemeliharaan Data</a>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-xl-7 mb-4"><div class="card h-100">
            <div class="card-header">Nilai buku aset per kategori</div>
            <div class="card-body"><div class="chart-box"><canvas id="chartNilai"></canvas></div></div>
        </div></div>
        <div class="col-xl-5 mb-4"><div class="card h-100">
            <div class="card-header">Peminjaman terlambat</div>
            <div class="card-body">
                <?php if (!$terlambat): ?><?= ui_kosong('fa-smile', 'Tidak ada keterlambatan') ?><?php else: ?>
                <ul class="list-clean">
                <?php foreach ($terlambat as $t2): ?>
                    <li><div class="li-main"><strong><?= e($t2['nama_barang']) ?> × <?= (int)$t2['jumlah'] ?></strong><small><?= e($t2['peminjam']) ?></small></div>
                        <?= badge((int)$t2['hari'] . ' hari', 'danger') ?></li>
                <?php endforeach; ?></ul>
                <?php endif; ?>
            </div>
        </div></div>
        <div class="col-xl-6 mb-4"><div class="card h-100">
            <div class="card-header">Habis pakai perlu dipesan</div>
            <div class="card-body">
                <?php if (!$perluPesan): ?><?= ui_kosong('fa-check-circle', 'Persediaan habis pakai aman') ?><?php else: ?>
                <ul class="list-clean">
                <?php foreach (array_slice($perluPesan, 0, 6) as $x): ?>
                    <li><div class="li-main"><strong><?= e($x['b']['nama_barang']) ?></strong><small>Tersedia <?= angka($x['tersedia']) ?> <?= e($x['b']['satuan']) ?></small></div>
                        <?= badge('±' . angka($x['e']['sisa_hari']) . ' hari', $x['e']['status'] === 'darurat' ? 'danger' : 'warning') ?></li>
                <?php endforeach; ?></ul>
                <?php endif; ?>
            </div>
        </div></div>
        <div class="col-xl-6 mb-4"><div class="card h-100">
            <div class="card-header">Aktivitas terbaru <a class="small" href="<?= e(url('log')) ?>">Log lengkap</a></div>
            <div class="card-body">
                <ul class="list-clean">
                <?php foreach ($aktivitas as $x): ?>
                    <li><span class="badge-soft badge-primary" style="min-width:64px;text-align:center"><?= e($x['aksi']) ?></span>
                        <div class="li-main"><strong><?= e($x['deskripsi']) ?></strong><small><?= e($x['username']) ?> · <?= waktu_indo($x['created_at']) ?></small></div></li>
                <?php endforeach; ?>
                </ul>
            </div>
        </div></div>
    </div>
    <?php
    $labels = array_keys($nilaiKat);
    $values = array_map(function ($v) { return round($v, 0); }, array_values($nilaiKat));
    $GLOBALS['page_js_vendor'] = [base_url() . 'assets/vendor/chartjs/chart.umd.min.js'];
    $GLOBALS['page_js'] = '(function(){
      var grid = document.documentElement.getAttribute("data-theme") === "dark" ? "rgba(148,163,184,.12)" : "rgba(100,116,139,.12)";
      new Chart(document.getElementById("chartNilai"), { type: "bar",
        data: { labels: ' . ui_js($labels) . ', datasets: [{ label: "Nilai buku", data: ' . ui_js($values) . ', backgroundColor: "rgba(37,99,235,.85)", borderRadius: 8 }] },
        options: { maintainAspectRatio: false, plugins: { legend: { display: false } },
          scales: { y: { beginAtZero: true, grid: { color: grid } }, x: { grid: { display: false } } } } });
    })();';
}
