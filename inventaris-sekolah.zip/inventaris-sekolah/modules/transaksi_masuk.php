<?php
// modules/transaksi_masuk.php — barang masuk (pembelian, bantuan, hibah). Nilai besar menunggu persetujuan.

function masuk_input(): array
{
    $tgl = tanggal_valid($_POST['tanggal'] ?? '');
    if (!$tgl) throw new AppException('Tanggal tidak valid.');
    if ($tgl > date('Y-m-d')) throw new AppException('Tanggal barang masuk tidak boleh melebihi hari ini.');
    $barang = post_int('barang_id');
    if (!$barang) throw new AppException('Pilih barang.');
    $jumlah = post_int('jumlah');
    if ($jumlah < 1 || $jumlah > 1000000) throw new AppException('Jumlah harus minimal 1 unit.');
    $sumber = in_array($_POST['sumber_dana'] ?? '', SUMBER_DANA, true) ? $_POST['sumber_dana'] : 'Lainnya';
    return [
        'tanggal' => $tgl, 'barang_id' => $barang, 'lokasi_id' => post_int('lokasi_id') ?: null, 'jumlah' => $jumlah,
        'harga_satuan' => (float)post_int('harga_satuan'), 'sumber_dana' => $sumber,
        'nomor_dokumen' => post_str('nomor_dokumen', 60), 'keterangan' => post_str('keterangan', 255),
    ];
}

function masuk_render(array $r): void
{
    $con = db();
    $aksi = get_str('aksi', 20);
    if ($aksi === 'tambah' || $aksi === 'edit') { masuk_render_form($aksi, get_int('id')); return; }

    $dari = tanggal_valid($_GET['dari'] ?? '') ?: date('Y-01-01');
    $sampai = tanggal_valid($_GET['sampai'] ?? '') ?: date('Y-m-d');
    $barangId = get_int('barang_id') ?: null;
    [$where, $tipe, $par] = sql_where([
        ['t.tanggal >= ?', 's', $dari], ['t.tanggal <= ?', 's', $sampai], ['t.barang_id = ?', 'i', $barangId],
    ]);
    $rows = db_all($con,
        "SELECT t.*, b.kode_barang, b.nama_barang, b.satuan, COALESCE(l.nama, '-') AS lokasi
         FROM barang_masuk t JOIN barang b ON b.id = t.barang_id LEFT JOIN lokasi l ON l.id = t.lokasi_id
         WHERE $where ORDER BY t.tanggal DESC, t.id DESC LIMIT 1000", $tipe, $par);
    $disetujui = array_filter($rows, function ($x) { return $x['status'] === 'Disetujui'; });
    $totalUnit = array_sum(array_column($disetujui, 'jumlah'));
    $totalNilai = 0.0; foreach ($disetujui as $x) $totalNilai += (int)$x['jumlah'] * (float)$x['harga_satuan'];
    $menunggu = count(array_filter($rows, function ($x) { return $x['status'] === 'Menunggu'; }));

    echo ui_head('Barang Masuk', 'Penerimaan barang: pembelian, bantuan, atau hibah. Nilai di atas ambang menunggu persetujuan Kepala Sekolah.',
        (can('transaksi.input') ? '<a class="btn btn-primary btn-sm" href="' . e(url('masuk', ['aksi' => 'tambah'])) . '"><i class="fas fa-plus mr-1"></i> Catat Barang Masuk</a>' : '')
        . '<a class="btn btn-light btn-sm" href="' . e(base_url() . 'export.php?' . http_build_query(['t' => 'masuk', 'dari' => $dari, 'sampai' => $sampai])) . '"><i class="fas fa-file-export mr-1"></i> Ekspor</a>');
    ?>
    <div class="row">
        <div class="col-md-4 mb-4"><?= ui_kpi('blue', 'fa-truck-loading', 'Penerimaan (periode)', angka(count($disetujui)), tgl_indo($dari) . ' – ' . tgl_indo($sampai)) ?></div>
        <div class="col-md-4 mb-4"><?= ui_kpi('teal', 'fa-cubes', 'Unit masuk (disetujui)', angka($totalUnit)) ?></div>
        <div class="col-md-4 mb-4"><?= ui_kpi($menunggu ? 'amber' : 'green', 'fa-hourglass-half', 'Menunggu persetujuan', angka($menunggu), rupiah($totalNilai) . ' nilai disetujui') ?></div>
    </div>
    <div class="card mb-4"><div class="card-body">
        <form class="toolbar" method="get" action="<?= e(base_url()) ?>">
            <input type="hidden" name="m" value="masuk">
            <div><label class="small-caps d-block">Dari</label><input class="form-control" type="date" name="dari" value="<?= e($dari) ?>"></div>
            <div><label class="small-caps d-block">Sampai</label><input class="form-control" type="date" name="sampai" value="<?= e($sampai) ?>"></div>
            <div style="min-width:280px;flex:1"><label class="small-caps d-block">Barang</label>
                <select class="custom-select select2" name="barang_id" data-placeholder="Semua barang" data-allow-clear="1"><?= opsi_barang_semua($con, (int)$barangId) ?></select></div>
            <button class="btn btn-primary" type="submit" style="margin-top:20px">Terapkan</button>
        </form>
    </div></div>
    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover datatable" data-order="0:desc" data-nosort="7">
                <thead><tr>
                    <th>Tanggal</th><th>Barang</th><th>Ruangan</th><th class="text-right">Jumlah</th><th class="text-right">Nilai</th>
                    <th>Status</th><th>Sumber &amp; dokumen</th><th class="text-center">Aksi</th>
                </tr></thead>
                <tbody>
                <?php foreach ($rows as $x): $nilai = (int)$x['jumlah'] * (float)$x['harga_satuan']; ?>
                <tr>
                    <td class="text-nowrap" data-order="<?= e($x['tanggal']) ?>"><?= tgl_indo($x['tanggal']) ?></td>
                    <td><strong><?= e($x['nama_barang']) ?></strong><span class="sub"><span class="code-chip" style="font-size:11px"><?= e($x['kode_barang']) ?></span></span></td>
                    <td><?= e($x['lokasi']) ?></td>
                    <td class="text-right font-weight-bold">+<?= angka($x['jumlah']) ?> <span class="text-muted small"><?= e($x['satuan']) ?></span></td>
                    <td class="text-right"><?= $nilai > 0 ? rupiah($nilai) : '<span class="text-muted">-</span>' ?></td>
                    <td><?= $x['status'] === 'Menunggu' ? badge('Menunggu persetujuan', 'warning')
                        : ($x['status'] === 'Ditolak' ? badge('Ditolak', 'danger') : badge('Diterima', 'success')) ?>
                        <?php if ($x['disetujui_oleh']): ?><span class="sub">oleh <?= e($x['disetujui_oleh']) ?></span><?php endif; ?></td>
                    <td><?= e($x['sumber_dana']) ?><span class="sub mono"><?= e($x['nomor_dokumen'] ?: '-') ?></span></td>
                    <td class="text-center text-nowrap">
                        <?php if (can('transaksi.input') && $x['status'] !== 'Ditolak'): ?>
                            <?= ui_btn_link(url('masuk', ['aksi' => 'edit', 'id' => $x['id']]), 'fa-pen', 'light', 'Ubah') ?>
                            <form method="post" action="<?= e(url('masuk')) ?>" class="d-inline"
                                  data-confirm="<?= $x['status'] === 'Disetujui' ? 'Membatalkan transaksi ini akan mengurangi jumlah ' . (int)$x['jumlah'] . ' unit. Lanjutkan?' : 'Batalkan pengajuan ini?' ?>">
                                <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
                                <button class="btn btn-sm btn-icon btn-light text-danger" type="submit" title="Batalkan" data-toggle="tooltip"><i class="fas fa-undo"></i></button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}


function masuk_render_form(string $aksi, int $id): void
{
    require_perm('transaksi.input');
    $con = db();
    $row = null;
    if ($aksi === 'edit') {
        $row = db_row($con, "SELECT * FROM barang_masuk WHERE id = ?", 'i', [$id]);
        if (!$row) { echo ui_kosong('fa-search', 'Data tidak ditemukan'); return; }
        if ($row['status'] === 'Ditolak') { echo ui_kosong('fa-ban', 'Transaksi ditolak', 'Transaksi yang ditolak tidak dapat diubah.'); return; }
    }
    $sel = (int)old('barang_id', $row['barang_id'] ?? 0);
    $v = function ($k, $def = '') use ($row) { return old($k, $row[$k] ?? $def); };
    $harga = old('harga_satuan', $row ? angka((int)$row['harga_satuan']) : '');
    $lokasiSel = (int)old('lokasi_id', $row['lokasi_id'] ?? 0);

    echo ui_head($row ? 'Ubah Barang Masuk' : 'Catat Barang Masuk',
        $row ? 'Mengubah jumlah akan menyesuaikan jumlah di ruangan dan kartu persediaan.'
             : 'Pilih ruangan tujuan. Nilai di atas ambang akan menunggu persetujuan Kepala Sekolah sebelum jumlah bertambah.',
        '<a class="btn btn-light btn-sm" href="' . e(url('masuk')) . '"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>');
    ?>
    <form class="needs-validation" method="post" action="<?= e(url('masuk', $row ? ['aksi' => 'edit', 'id' => $id] : ['aksi' => 'tambah'])) ?>" novalidate>
        <?= csrf_field() ?><input type="hidden" name="aksi" value="simpan"><input type="hidden" name="id" value="<?= (int)$id ?>">
        <div class="row"><div class="col-lg-8"><div class="card mb-4"><div class="card-body">
            <div class="form-row">
                <div class="form-group col-md-6"><label for="tanggal">Tanggal diterima <span class="req">*</span></label>
                    <input class="form-control" type="date" id="tanggal" name="tanggal" required max="<?= date('Y-m-d') ?>" value="<?= e($v('tanggal', date('Y-m-d'))) ?>"></div>
                <div class="form-group col-md-6"><label for="nomor_dokumen">No. dokumen (BAST / faktur)</label>
                    <input class="form-control" id="nomor_dokumen" name="nomor_dokumen" maxlength="60" value="<?= e($v('nomor_dokumen')) ?>"></div>
            </div>
            <div class="form-group"><label for="barang_id">Barang <span class="req">*</span></label>
                <select class="custom-select select2" id="barang_id" name="barang_id" required data-placeholder="Cari barang…" <?= $row ? 'disabled' : '' ?>>
                    <?= opsi_barang_semua($con, $sel) ?>
                </select>
                <?php if ($row): ?><input type="hidden" name="barang_id" value="<?= (int)$row['barang_id'] ?>"><?php endif; ?></div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="lokasi_id">Ruangan penyimpanan <span class="req">*</span></label>
                    <select class="custom-select" id="lokasi_id" name="lokasi_id" required <?= $row ? 'disabled' : '' ?>>
                        <?= ui_opsi_tabel('lokasi', 'nama', (string)$lokasiSel, '-- Pilih ruangan --') ?></select>
                    <?php if ($row): ?><input type="hidden" name="lokasi_id" value="<?= (int)$row['lokasi_id'] ?>"><?php endif; ?></div>
                <div class="form-group col-md-6"><label for="jumlah">Jumlah (unit) <span class="req">*</span></label>
                    <input class="form-control" type="number" id="jumlah" name="jumlah" min="1" max="1000000" required value="<?= e($v('jumlah')) ?>">
                    <div class="invalid-feedback">Jumlah minimal 1.</div></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="harga_satuan">Harga per unit (Rp)</label>
                    <input class="form-control" id="harga_satuan" name="harga_satuan" inputmode="numeric" data-mask="rupiah" value="<?= e($harga) ?>" placeholder="0">
                    <small class="help" id="infoPersetujuan"></small></div>
                <div class="form-group col-md-6"><label for="sumber_dana">Sumber dana</label>
                    <select class="custom-select" id="sumber_dana" name="sumber_dana"><?= opsi_html(array_combine(SUMBER_DANA, SUMBER_DANA), (string)$v('sumber_dana', 'BOS')) ?></select></div>
            </div>
            <div class="form-group mb-0"><label for="keterangan">Keterangan</label>
                <textarea class="form-control" id="keterangan" name="keterangan" rows="2" maxlength="255"><?= e($v('keterangan')) ?></textarea></div>
        </div></div></div>
        <div class="col-lg-4"><div class="card mb-4"><div class="card-body">
            <h6 class="font-weight-bold">Ringkasan</h6>
            <div class="small text-muted">Total nilai penerimaan</div>
            <div class="kpi-value" id="totalNilai">Rp 0</div>
            <div class="small text-muted mt-3" id="ringkasLokasi"></div>
        </div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fas fa-save mr-1"></i> Simpan</button></div>
        </div>
    </form>
    <?php
    $GLOBALS['page_js_vendor'] = [];
    $GLOBALS['page_js'] = '
    (function(){
      var ambang = ' . (int)ambang_persetujuan_masuk($con) . ';
      function hitung(){
        var j = parseInt(($("#jumlah").val()||"0"),10)||0;
        var h = parseInt((""+($("#harga_satuan").val()||"0")).replace(/\D/g,""),10)||0;
        var total = j*h;
        $("#totalNilai").text("Rp " + total.toLocaleString("id-ID"));
        $("#infoPersetujuan").text(total >= ambang && total > 0 ? "Nilai di atas ambang: menunggu persetujuan Kepala Sekolah." : "");
      }
      $("#jumlah, #harga_satuan").on("input", hitung);
      hitung();
    })();';
}

function masuk_post(array $r): void
{
    require_perm('transaksi.input');
    $con = db();
    $aksi = post_str('aksi', 20);
    if ($aksi === 'hapus') {
        transaksi_masuk_hapus($con, post_int('id'));
        flash('success', 'Transaksi dibatalkan dan jumlah telah disesuaikan.');
        redirect(url('masuk'));
    }
    if ($aksi !== 'simpan') throw new AppException('Aksi tidak dikenali.');
    $id = post_int('id');
    $d = masuk_input();
    if ($id) {
        transaksi_masuk_ubah($con, $id, $d);
        flash('success', 'Transaksi barang masuk diperbarui.');
    } else {
        $baru = transaksi_masuk_tambah($con, $d);
        $st = db_value($con, "SELECT status FROM barang_masuk WHERE id = ?", 'i', [$baru]);
        flash($st === 'Menunggu' ? 'info' : 'success', $st === 'Menunggu'
            ? 'Nilai di atas ambang. Pengajuan menunggu persetujuan Kepala Sekolah sebelum jumlah bertambah.'
            : 'Barang masuk dicatat dan jumlah di ruangan telah diperbarui.');
    }
    redirect(url('masuk'));
}
